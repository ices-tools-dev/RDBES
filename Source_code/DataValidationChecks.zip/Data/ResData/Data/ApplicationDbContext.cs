﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using ResData.Models;
using ResData.Models.Account;
using ResData.Models.Admin;
using ResData.Models.TblCodes;
//using ResData.Models.Identity;
using ResData.Models.Error;
using DbDataModel.HierarchiesModels;
using EFCore.BulkExtensions;
//using ResData.KeyLessEntities;
using ResData.Models.Stock;
using ResData.Models.KeyLessEntities;
using DbDataModel.DeleteLogModels;
//using System.Data.SqlClient;

namespace ResData.Data

{
   
     
       

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options): base(options)
        {
            ////   _config = config;
            
            
        }

        public virtual DbSet<DeleteLog> DeleteLog { get; set; }
        public virtual DbSet<DeleteLogCodeField> DeleteLogCodeField { get; set; }
        public virtual DbSet<DeleteLogStringField> DeleteLogStringField { get; set; }

        public virtual DbSet<RSpeciesAreaQuarter> RSpeciesAreaQuarter { get; set; }

        public virtual DbSet<CommercialEffort> CommercialEffort { get; set; }
        public virtual DbSet<CommercialLanding> CommercialLanding { get; set; }

        public virtual DbSet<BiologicalVariable> BiologicalVariable { get; set; }
        public virtual DbSet<Design> Design { get; set; }
        public virtual DbSet<ExceptionLogs> ExceptionLogs { get; set; }
        public virtual DbSet<FishingOperation> FishingOperation { get; set; }
        public virtual DbSet<FishingTrip> FishingTrip { get; set; }
        public virtual DbSet<FrequencyMeasure> FrequencyMeasure { get; set; }
        public virtual DbSet<LandingEvent> LandingEvent { get; set; }
        public virtual DbSet<Location> Location { get; set; }
        public virtual DbSet<OnshoreEvent> OnshoreEvent { get; set; }
        public virtual DbSet<RelType> RelType { get; set; }
        public virtual DbSet<Sample> Sample { get; set; }
        public virtual DbSet<SamplingDetails> SamplingDetails { get; set; }        
        public virtual DbSet<SpeciesSelection> SpeciesSelection { get; set; }
        public virtual DbSet<TblCode> TblCode { get; set; }
        public virtual DbSet<TblCodeRel> TblCodeRel { get; set; }
        public virtual DbSet<TblCodeType> TblCodeType { get; set; }
        public virtual DbSet<TblCodeTypeRel> TblCodeTypeRel { get; set; }
        public virtual DbSet<TemporalEvent> TemporalEvent { get; set; }
        public virtual DbSet<UserAuditEvents> UserAuditEvents { get; set; }
        public virtual DbSet<UsersCountries> UsersCountries { get; set; }
        public virtual DbSet<VesselDetails> VesselDetails { get; set; }
        public virtual DbSet<VesselSelection> VesselSelection { get; set; }
        public virtual DbSet<SpeciesList> SpeciesList { get; set; }
        //public virtual DbSet<SpeciesListContent> SpeciesListContent { get; set; }
        //public virtual DbSet<SpeciesListSpecies> SpeciesListSpecies { get; set; }

       
        public DbSet<CodeLookup> CodeLookup { get; set; }

        public DbSet<LinePkMapping> LnMappingPk { get; set; }

        public DbSet<FilterOption> FilterOption { get; set; }

        // Unable to generate entity type for table 'dbo.RTestData'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //if (!optionsBuilder.IsConfigured)
            //{
            //    var conn = new SqlConnectionStringBuilder("Server=res-dev-data;Database=RES;Trusted_Connection=True;MultipleActiveResultSets=true;")
            //    {
                    
            //        MaxPoolSize = 200,
            //        MinPoolSize = 5
            //    };
            //    optionsBuilder.UseSqlServer(conn.ToString());
            //}

            base.OnConfiguring(optionsBuilder);


            //#region KeyLess Entities
            //modelBuilder.Query<CodeLookup>();
            //modelBuilder.Query<LinePkMapping>();
            //#endregion
        }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");
            base.OnModelCreating(modelBuilder);


            #region KeyLess Entities
            //modelBuilder.Query<CodeLookup>();
            //modelBuilder.Query<LinePkMapping>();
            #endregion

            modelBuilder.Entity<CodeLookup>(entity => entity.HasNoKey());
            modelBuilder.Entity<LinePkMapping>(entity => entity.HasNoKey());
            modelBuilder.Entity<FilterOption>(entity => entity.HasNoKey());

            modelBuilder.Entity<BiologicalVariable>(entity =>
            {
                entity.HasKey(e => e.Bvid);

                entity.ToTable("BiologicalVariable");

                entity.HasIndex(e => new { e.Said, e.Fmid, e.BvnationalUniqueFishId, e.BvtypeMeasured }).HasName("IX_BV_SAidFMidFidTyp")
                    .IsUnique();

                entity.HasIndex(e => e.Fmid).HasName("IX_BiologicalVariable_FMid");

                entity.HasIndex(e => e.Said).HasName("IX_BiologicalVariable_SAid");

                entity.Property(e => e.Bvid).HasColumnName("BVid");

                entity.Property(e => e.Bvaccuracy).HasColumnName("BVaccuracy");

                entity.Property(e => e.BvcertaintyQualitative).HasColumnName("BVcertaintyQualitative");

                entity.Property(e => e.BvcertaintyQuantitative)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("BVcertaintyQuantitative");

                entity.Property(e => e.BvconversionFactorAssessment)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("BVconversionFactorAssessment");

                entity.Property(e => e.BvinclusionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("BVinclusionProb");

                entity.Property(e => e.BvmeasurementEquipment).HasColumnName("BVmeasurementEquipment");

                entity.Property(e => e.Bvmethod).HasColumnName("BVmethod");

                entity.Property(e => e.BvnationalUniqueFishId)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("BVnationalUniqueFishId");

                entity.Property(e => e.BvnumberSampled).HasColumnName("BVnumberSampled");

                entity.Property(e => e.BvnumberTotal).HasColumnName("BVnumberTotal");

                entity.Property(e => e.Bvpresentation).HasColumnName("BVpresentation");

                entity.Property(e => e.BvrecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("BVrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Bvsampler).HasColumnName("BVsampler");

                entity.Property(e => e.BvselectionMethod).HasColumnName("BVselectionMethod");

                entity.Property(e => e.BvselectionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("BVselectionProb");

                entity.Property(e => e.BVstateOfProcessing).HasColumnName("BVstateOfProcessing");

                entity.Property(e => e.Bvstratification).HasColumnName("BVstratification");

                entity.Property(e => e.BvstratumName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("BVstratumName");

                entity.Property(e => e.BvtypeAssessment)
                    
                    .HasColumnName("BVtypeAssessment");

                entity.Property(e => e.BvtypeMeasured).HasColumnName("BVtypeMeasured");

                entity.Property(e => e.BvunitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("BVunitName");

                entity.Property(e => e.BvvalueMeasured)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("BVvalueMeasured");

                entity.Property(e => e.BvvalueUnitOrScale).HasColumnName("BVvalueUnitOrScale");

                entity.Property(e => e.Fmid).HasColumnName("FMid");

                entity.Property(e => e.Said).HasColumnName("SAid");

                entity.HasOne(d => d.Fm)
                    .WithMany(p => p.BiologicalVariables)
                    .HasForeignKey(d => d.Fmid)
                    .HasConstraintName("FK_BiologicalVariable_FrequencyMeasure");

                entity.HasOne(d => d.Sa)
                    .WithMany(p => p.BiologicalVariables)
                    .HasForeignKey(d => d.Said)
                    .HasConstraintName("FK_BiologicalVariable_Sample");
            });

            modelBuilder.Entity<CommercialEffort>(entity =>
            {
                entity.HasKey(e => e.Ceid);

                entity.ToTable("CommercialEffort");

                entity.HasIndex(e => new { e.CedataTypeForScientificEffort, e.CedataSourceForScientificEffort, e.CesamplingScheme, e.CevesselFlagCountry, e.Ceyear, e.Cequarter, e.Cemonth, e.Cearea, e.CestatisticalRectangle, e.CegsaSubarea, e.CejurisdictionArea, e.CeexclusiveEconomicZoneIndicator, e.CenationalFishingActivity, e.Cemetier6, e.CeincidentalByCatchMitigationDevice, e.CelandingLocation, e.CevesselLengthCategory, e.CefishingTechnique, e.CedeepSeaRegulation }).HasName("NonClusteredIndex-20200324-152835")
                    .IsUnique();

                entity.Property(e => e.Ceid).HasColumnName("CEid");

                entity.Property(e => e.Cearea).HasColumnName("CEarea");

                entity.Property(e => e.CedataSourceForScientificEffort).HasColumnName("CEdataSourceForScientificEffort");

                entity.Property(e => e.CedataTypeForScientificEffort).HasColumnName("CEdataTypeForScientificEffort");

                entity.Property(e => e.CedeepSeaRegulation).HasColumnName("CEdeepSeaRegulation");

                entity.Property(e => e.CeexclusiveEconomicZoneIndicator).HasColumnName("CEexclusiveEconomicZoneIndicator");

                entity.Property(e => e.CefishingTechnique).HasColumnName("CEfishingTechnique");

                entity.Property(e => e.CegTdaysAtSea).HasColumnName("CEgTDaysAtSea");

                entity.Property(e => e.CegTfishingDays).HasColumnName("CEgTFishingDays");

                entity.Property(e => e.CegTfishingHours).HasColumnName("CEgTFishingHours");

                entity.Property(e => e.CegsaSubarea).HasColumnName("CEgsaSubarea");

                entity.Property(e => e.CeincidentalByCatchMitigationDevice).HasColumnName("CEincidentalByCatchMitigationDevice");

                entity.Property(e => e.CejurisdictionArea).HasColumnName("CEjurisdictionArea");

                entity.Property(e => e.CelandingLocation).HasColumnName("CElandingLocation");

                entity.Property(e => e.Cemetier6).HasColumnName("CEmetier6");

                entity.Property(e => e.Cemonth).HasColumnName("CEmonth");

                entity.Property(e => e.CenationalFishingActivity).HasColumnName("CEnationalFishingActivity");

                entity.Property(e => e.CenumberOfDominantTrips).HasColumnName("CEnumberOfDominantTrips");

                entity.Property(e => e.CenumberOfFractionTrips)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("CEnumberOfFractionTrips");

                entity.Property(e => e.CenumberOfUniqueVessels).HasColumnName("CEnumberOfUniqueVessels");

                entity.Property(e => e.CeofficialDaysAtSea)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("CEofficialDaysAtSea");

                entity.Property(e => e.CeofficialFishingDays)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("CEofficialFishingDays");

                entity.Property(e => e.CeofficialNumberOfHaulsOrSets).HasColumnName("CEofficialNumberOfHaulsOrSets");

                entity.Property(e => e.CeofficialSoakingMeterHour)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("CEofficialSoakingMeterHour");

                entity.Property(e => e.CeofficialVesselFishingHour)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("CEofficialVesselFishingHour");

                entity.Property(e => e.CeofficialkWdaysAtSea).HasColumnName("CEofficialkWDaysAtSea");

                entity.Property(e => e.CeofficialkWfishingDays).HasColumnName("CEofficialkWFishingDays");

                entity.Property(e => e.CeofficialkWfishingHours).HasColumnName("CEofficialkWFishingHours");

                entity.Property(e => e.Cequarter).HasColumnName("CEquarter");

                entity.Property(e => e.CerecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("CErecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.CesamplingScheme).HasColumnName("CEsamplingScheme");

                entity.Property(e => e.CescientificDaysAtSea)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("CEScientificDaysAtSea");

                entity.Property(e => e.CescientificFishingDays)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("CEscientificFishingDays");

                entity.Property(e => e.CescientificFishingDaysQualitativeBias).HasColumnName("CEscientificFishingDaysQualitativeBias");

                entity.Property(e => e.CescientificFishingDaysRse).HasColumnName("CEscientificFishingDaysRSE");

                entity.Property(e => e.CescientificNumberOfHaulsOrSets).HasColumnName("CEscientificNumberOfHaulsOrSets");

                entity.Property(e => e.CescientificSoakingMeterHour)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("CEscientificSoakingMeterHour");

                entity.Property(e => e.CescientificVesselFishingHour)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("CEscientificVesselFishingHour");

                entity.Property(e => e.CescientifickWdaysAtSea).HasColumnName("CEscientifickWDaysAtSea");

                entity.Property(e => e.CescientifickWfishingDays).HasColumnName("CEscientifickWFishingDays");

                entity.Property(e => e.CescientifickWfishingHours).HasColumnName("CEscientifickWFishingHours");

                entity.Property(e => e.CestatisticalRectangle).HasColumnName("CEstatisticalRectangle");

                entity.Property(e => e.CevesselFlagCountry).HasColumnName("CEvesselFlagCountry");

                entity.Property(e => e.CevesselLengthCategory).HasColumnName("CEvesselLengthCategory");

                entity.Property(e => e.Ceyear).HasColumnName("CEyear");

                entity.Property(e => e.TimeStamp).HasColumnType("datetime");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(450);
            });

            modelBuilder.Entity<CommercialLanding>(entity =>
            {
                entity.HasKey(e => e.Clid);

                entity.ToTable("CommercialLanding");

                entity.HasIndex(e => new {e.ClregDisCategory, e.CldataTypeOfScientificWeight, e.CldataSourceOfScientificWeight, e.ClsamplingScheme, e.CldataSourceLandingsValue, e.CllandingCountry, e.ClvesselFlagCountry, e.Clyear, e.Clquarter, e.Clmonth, e.Clarea, e.ClstatisticalRectangle, e.ClgsaSubarea, e.CljurisdictionArea, e.ClexclusiveEconomicZoneIndicator, e.ClspeciesCode, e.ClspeciesFaoCode, e.CllandingCategory, e.ClcatchCategory, e.ClcommercialSizeCategoryScale, e.ClcommercialSizeCategory, e.ClnationalFishingActivity, e.Clmetier6, e.ClincidentialByCatchMitigationDevice, e.CllandingLocation, e.ClvesselLengthCategory, e.ClfishingTechnique, e.CldeepSeaRegulation }).HasName("IX_CL_UniqueIndex1")
                    .IsUnique();

                entity.Property(e => e.Clid).HasColumnName("CLid");

                entity.Property(e => e.Clarea).HasColumnName("CLarea");

                entity.Property(e => e.ClcatchCategory).HasColumnName("CLcatchCategory");
                entity.Property(e => e.ClregDisCategory).HasColumnName("CLregDisCategory");

                entity.Property(e => e.ClcommercialSizeCategory).HasColumnName("CLcommercialSizeCategory");

                entity.Property(e => e.ClcommercialSizeCategoryScale).HasColumnName("CLcommercialSizeCategoryScale");

                entity.Property(e => e.CldataSourceLandingsValue).HasColumnName("CLdataSourceLandingsValue");

                entity.Property(e => e.CldataSourceOfScientificWeight).HasColumnName("CLdataSourceOfScientificWeight");

                entity.Property(e => e.CldataTypeOfScientificWeight).HasColumnName("CLdataTypeOfScientificWeight");

                entity.Property(e => e.CldeepSeaRegulation).HasColumnName("CLdeepSeaRegulation");

                entity.Property(e => e.ClexclusiveEconomicZoneIndicator).HasColumnName("CLexclusiveEconomicZoneIndicator");

                entity.Property(e => e.ClexplainDifference).HasColumnName("CLexplainDifference");

                entity.Property(e => e.ClfishingTechnique).HasColumnName("CLfishingTechnique");

                entity.Property(e => e.ClgsaSubarea).HasColumnName("CLgsaSubarea");

                entity.Property(e => e.ClincidentialByCatchMitigationDevice).HasColumnName("CLincidentialByCatchMitigationDevice");

                entity.Property(e => e.CljurisdictionArea).HasColumnName("CLjurisdictionArea");

                entity.Property(e => e.CllandingCategory).HasColumnName("CLlandingCategory");

                entity.Property(e => e.CllandingCountry).HasColumnName("CLlandingCountry");

                entity.Property(e => e.CllandingLocation).HasColumnName("CLlandingLocation");

                entity.Property(e => e.Clmetier6).HasColumnName("CLmetier6");

                entity.Property(e => e.Clmonth).HasColumnName("CLmonth");

                entity.Property(e => e.ClnationalFishingActivity).HasColumnName("CLnationalFishingActivity");

                entity.Property(e => e.ClnumberOfUniqueVessels).HasColumnName("CLnumberOfUniqueVessels");

                entity.Property(e => e.ClofficialWeight).HasColumnName("CLofficialWeight");

                entity.Property(e => e.Clquarter).HasColumnName("CLquarter");

                entity.Property(e => e.ClrecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("CLrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.ClsamplingScheme).HasColumnName("CLsamplingScheme");

                entity.Property(e => e.ClscientificWeight).HasColumnName("CLscientificWeight");

                entity.Property(e => e.ClscientificWeightQualitativeBias).HasColumnName("CLscientificWeightQualitativeBias");

                entity.Property(e => e.ClscientificWeightRse).HasColumnName("CLscientificWeightRSE");

                entity.Property(e => e.ClspeciesCode).HasColumnName("CLspeciesCode");

                entity.Property(e => e.ClspeciesFaoCode).HasColumnName("CLspeciesFaoCode");

                entity.Property(e => e.ClstatisticalRectangle).HasColumnName("CLstatisticalRectangle");

                entity.Property(e => e.CltotalOfficialLandingsValue).HasColumnName("CLtotalOfficialLandingsValue");

                entity.Property(e => e.ClvalueRse).HasColumnName("CLvalueRSE");

                entity.Property(e => e.ClvesselFlagCountry).HasColumnName("CLvesselFlagCountry");

                entity.Property(e => e.ClvesselLengthCategory).HasColumnName("CLvesselLengthCategory");

                entity.Property(e => e.Clyear).HasColumnName("CLyear");

                entity.Property(e => e.TimeStamp).HasColumnType("datetime");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(450);
            });

           

            modelBuilder.Entity<DeleteLog>(entity =>
            {
                entity.ToTable("DeleteLog");

                entity.Property(e => e.DataType)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.TimeStamp).HasColumnType("datetime");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(450);
            });

            modelBuilder.Entity<DeleteLogCodeField>(entity =>
            {
                entity.ToTable("DeleteLogCodeField");

                entity.Property(e => e.FieldName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.DeleteLog)
                    .WithMany(p => p.DeleteLogCodeFields)
                    .HasForeignKey(d => d.DeleteLogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeleteLogCodeField_DeleteLog");
            });

            modelBuilder.Entity<DeleteLogStringField>(entity =>
            {
                entity.ToTable("DeleteLogStringField");

                entity.Property(e => e.FieldData)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.FieldName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.DeleteLog)
                    .WithMany(p => p.DeleteLogStringFields)
                    .HasForeignKey(d => d.DeleteLogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeleteLogStringField_DeleteLog");
            });

            modelBuilder.Entity<Design>(entity =>
            {
                entity.HasKey(e => e.Deid);

                entity.ToTable("Design");

                entity.HasIndex(e => new { e.DesamplingScheme, e.Deyear, e.DestratumName, e.Dehierarchy }).HasName("IX_DE_SamHieYeaStra")
                    .IsUnique();

                entity.Property(e => e.Deid).HasColumnName("DEid");

                entity.Property(e => e.Dehierarchy).HasColumnName("DEhierarchy");

                entity.Property(e => e.DehierarchyCorrect).HasColumnName("DEhierarchyCorrect");

                entity.Property(e => e.DereasonNotSampled).HasColumnName("DEreasonNotSampled");

                entity.Property(e => e.DerecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("DErecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Desampled).HasColumnName("DEsampled");

                entity.Property(e => e.DesamplingScheme).HasColumnName("DEsamplingScheme");

                entity.Property(e => e.DesamplingSchemeType).HasColumnName("DEsamplingSchemeType");

                entity.Property(e => e.DestratumName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("DEstratumName");

                entity.Property(e => e.Deyear).HasColumnName("DEyear");

                entity.Property(e => e.TimeStamp).HasColumnType("datetime");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(450);
            });

            

            modelBuilder.Entity<FishingOperation>(entity =>
            {
                entity.HasKey(e => e.Foid);

                entity.ToTable("FishingOperation");

                entity.HasIndex(e => new { e.Ftid, e.FosequenceNumber, e.Sdid }).HasName("IX_FO_FTidHalNum")
                    .IsUnique();

                entity.HasIndex(e => e.Ftid).HasName("IX_FishingOperation_FTid");

                entity.HasIndex(e => e.Sdid).HasName("IX_FishingOperation_SDid");

                entity.Property(e => e.Foid).HasColumnName("FOid");

                entity.Property(e => e.FoaggregationLevel).HasColumnName("FOaggregationLevel");

                entity.Property(e => e.Foarea).HasColumnName("FOarea");

                entity.Property(e => e.FocatchReg).HasColumnName("FOcatchReg");

                entity.Property(e => e.FoclusterName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("FOclusterName");

                entity.Property(e => e.Foclustering).HasColumnName("FOclustering");

                entity.Property(e => e.Foduration).HasColumnName("FOduration");

                entity.Property(e => e.FodurationSource).HasColumnName("FOdurationSource");

                entity.Property(e => e.FoendDate)
                    .HasColumnType("datetime")
                    .HasColumnName("FOendDate");

                entity.Property(e => e.FoendTime)
                    .HasColumnType("datetime")
                    .HasColumnName("FOendTime");

                entity.Property(e => e.FoexclusiveEconomicZoneIndicator).HasColumnName("FOexclusiveEconomicZoneIndicator");

                entity.Property(e => e.FofishingDepth).HasColumnName("FOfishingDepth");

                entity.Property(e => e.Fogear).HasColumnName("FOgear");

                entity.Property(e => e.FogearDimensions).HasColumnName("FOgearDimensions");

                entity.Property(e => e.FogsaSubarea).HasColumnName("FOgsaSubarea");

                entity.Property(e => e.FohandlingTime).HasColumnName("FOhandlingTime");

                entity.Property(e => e.FoincidentalByCatchMitigationDeviceFirst).HasColumnName("FOincidentalByCatchMitigationDeviceFirst");

                entity.Property(e => e.FoincidentalByCatchMitigationDeviceSecond).HasColumnName("FOincidentalByCatchMitigationDeviceSecond");

                entity.Property(e => e.FoincidentalByCatchMitigationDeviceTargetFirst).HasColumnName("FOincidentalByCatchMitigationDeviceTargetFirst");

                entity.Property(e => e.FoincidentalByCatchMitigationDeviceTargetSecond).HasColumnName("FOincidentalByCatchMitigationDeviceTargetSecond");

                entity.Property(e => e.FoinclusionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("FOInclusionProb");

                entity.Property(e => e.FoinclusionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("FOInclusionProbCluster");

                entity.Property(e => e.FojurisdictionArea).HasColumnName("FOjurisdictionArea");

                entity.Property(e => e.FomeshSize).HasColumnName("FOmeshSize");

                entity.Property(e => e.Fometier5).HasColumnName("FOmetier5");

                entity.Property(e => e.Fometier6).HasColumnName("FOmetier6");

                entity.Property(e => e.FonationalFishingActivity).HasColumnName("FOnationalFishingActivity");

                entity.Property(e => e.FonumberSampled)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("FOnumberSampled");

                entity.Property(e => e.FonumberSampledClusters).HasColumnName("FOnumberSampledClusters");

                entity.Property(e => e.FonumberTotal).HasColumnName("FOnumberTotal");

                entity.Property(e => e.FonumberTotalClusters).HasColumnName("FOnumberTotalClusters");

                entity.Property(e => e.FoobservationCode).HasColumnName("FOobservationCode");

                entity.Property(e => e.ForeasonNotSampled).HasColumnName("FOreasonNotSampled");

                entity.Property(e => e.ForecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("FOrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Forectangle).HasColumnName("FOrectangle");

                entity.Property(e => e.Fosampled).HasColumnName("FOsampled");

                entity.Property(e => e.Fosampler).HasColumnName("FOsampler");

                entity.Property(e => e.FoselectionDevice).HasColumnName("FOselectionDevice");

                entity.Property(e => e.FoselectionDeviceMeshSize).HasColumnName("FOselectionDeviceMeshSize");

                entity.Property(e => e.FoselectionMethod).HasColumnName("FOselectionMethod");

                entity.Property(e => e.FoselectionMethodCluster).HasColumnName("FOselectionMethodCluster");

                entity.Property(e => e.FoselectionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("FOSelectionProb");

                entity.Property(e => e.FoselectionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("FOSelectionProbCluster");

                entity.Property(e => e.FosequenceNumber).HasColumnName("FOsequenceNumber");

                entity.Property(e => e.FostartDate)
                    .HasColumnType("datetime")
                    .HasColumnName("FOstartDate");

                entity.Property(e => e.FostartLat)
                    .HasColumnType("decimal(18, 5)")
                    .HasColumnName("FOstartLat");

                entity.Property(e => e.FostartLon)
                    .HasColumnType("decimal(18, 5)")
                    .HasColumnName("FOstartLon");

                entity.Property(e => e.FostartTime)
                    .HasColumnType("datetime")
                    .HasColumnName("FOstartTime");

                entity.Property(e => e.FostopLat)
                    .HasColumnType("decimal(18, 5)")
                    .HasColumnName("FOstopLat");

                entity.Property(e => e.FostopLon)
                    .HasColumnType("decimal(18, 5)")
                    .HasColumnName("FOstopLon");

                entity.Property(e => e.Fostratification).HasColumnName("FOstratification");

                entity.Property(e => e.FostratumName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("FOstratumName");

                entity.Property(e => e.FotargetSpecies).HasColumnName("FOtargetSpecies");

                entity.Property(e => e.FounitName)
                    .HasMaxLength(100)
                    .HasColumnName("FOunitName");

                entity.Property(e => e.Fovalidity).HasColumnName("FOvalidity");

                entity.Property(e => e.FowaterDepth).HasColumnName("FOwaterDepth");

                entity.Property(e => e.Ftid).HasColumnName("FTid");

                entity.Property(e => e.Sdid).HasColumnName("SDid");

                entity.HasOne(d => d.Ft)
                    .WithMany(p => p.FishingOperations)
                    .HasForeignKey(d => d.Ftid)
                    .HasConstraintName("FK_FishingOperation_FishingTrip");

                entity.HasOne(d => d.Sd)
                    .WithMany(p => p.FishingOperations)
                    .HasForeignKey(d => d.Sdid)
                    .HasConstraintName("FK_FishingOperation_SamplingDetails");
            });

            modelBuilder.Entity<FishingTrip>(entity =>
            {
                entity.HasKey(e => e.Ftid);

                entity.ToTable("FishingTrip");

                entity.HasIndex(e => new { e.FtsequenceNumber, e.FtarrivalLocation, e.FtarrivalDate, e.Osid, e.Vsid, e.Sdid, e.Foid, e.Teid }).HasName("IX_FT_NacArlArd")
                    .IsUnique();

                entity.HasIndex(e => e.Foid).HasName("IX_FishingTrip_FOid");

                entity.HasIndex(e => e.Osid).HasName("IX_FishingTrip_OSid");

                entity.HasIndex(e => e.Sdid).HasName("IX_FishingTrip_SDid");

                entity.HasIndex(e => e.Teid).HasName("IX_FishingTrip_TEid");

                entity.HasIndex(e => e.Vdid).HasName("IX_FishingTrip_VDid");

                entity.HasIndex(e => e.Vsid).HasName("IX_FishingTrip_VSid");

                entity.Property(e => e.Ftid).HasColumnName("FTid");

                entity.Property(e => e.Foid).HasColumnName("FOid");

                entity.Property(e => e.FtarrivalDate)
                    .HasColumnType("datetime")
                    .HasColumnName("FTarrivalDate");

                entity.Property(e => e.FtarrivalLocation).HasColumnName("FTarrivalLocation");

                entity.Property(e => e.FtarrivalTime)
                    .HasColumnType("datetime")
                    .HasColumnName("FTarrivalTime");

                entity.Property(e => e.FtclusterName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("FTclusterName");

                entity.Property(e => e.Ftclustering).HasColumnName("FTclustering");

                entity.Property(e => e.FtdepartureDate)
                    .HasColumnType("datetime")
                    .HasColumnName("FTdepartureDate");

                entity.Property(e => e.FtdepartureLocation).HasColumnName("FTdepartureLocation");

                entity.Property(e => e.FtdepartureTime)
                    .HasColumnType("datetime")
                    .HasColumnName("FTdepartureTime");

                entity.Property(e => e.FtencryptedVesselCode)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("FTencryptedVesselCode");

                entity.Property(e => e.FtinclusionProb)
                    .HasColumnType("decimal(18, 10)")
                    .HasColumnName("FTinclusionProb");

                entity.Property(e => e.FtinclusionProbCluster)
                    .HasColumnType("decimal(18, 10)")
                    .HasColumnName("FTinclusionProbCluster");

                entity.Property(e => e.FtnumberOfHaulsOrSets).HasColumnName("FTnumberOfHaulsOrSets");

                entity.Property(e => e.FtnumberSampled).HasColumnName("FTnumberSampled");

                entity.Property(e => e.FtnumberSampledClusters).HasColumnName("FTnumberSampledClusters");

                entity.Property(e => e.FtnumberTotal).HasColumnName("FTnumberTotal");

                entity.Property(e => e.FtnumberTotalClusters).HasColumnName("FTnumberTotalClusters");

                entity.Property(e => e.FtreasonNotSampled).HasColumnName("FTreasonNotSampled");

                entity.Property(e => e.FtrecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("FTrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Ftsampled).HasColumnName("FTsampled");

                entity.Property(e => e.Ftsampler).HasColumnName("FTsampler");

                entity.Property(e => e.FtsamplingType).HasColumnName("FTsamplingType");

                entity.Property(e => e.FtselectionMethod).HasColumnName("FTselectionMethod");

                entity.Property(e => e.FtselectionMethodCluster).HasColumnName("FTselectionMethodCluster");

                entity.Property(e => e.FtselectionProb)
                    .HasColumnType("decimal(18, 10)")
                    .HasColumnName("FTselectionProb");

                entity.Property(e => e.FtselectionProbCluster)
                    .HasColumnType("decimal(18, 10)")
                    .HasColumnName("FTselectionProbCluster");

                entity.Property(e => e.FtsequenceNumber)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("FTsequenceNumber");

                entity.Property(e => e.Ftstratification).HasColumnName("FTstratification");

                entity.Property(e => e.FtstratumName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("FTstratumName");

                entity.Property(e => e.FtunitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("FTunitName");

                entity.Property(e => e.Osid).HasColumnName("OSid");

                entity.Property(e => e.Sdid).HasColumnName("SDid");

                entity.Property(e => e.Teid).HasColumnName("TEid");

                entity.Property(e => e.Vdid).HasColumnName("VDid");

                entity.Property(e => e.Vsid).HasColumnName("VSid");

                entity.HasOne(d => d.Fo)
                    .WithMany(p => p.FishingTrips)
                    .HasForeignKey(d => d.Foid)
                    .HasConstraintName("FK_FishingTrip_FishingOperation");

                entity.HasOne(d => d.Os)
                    .WithMany(p => p.FishingTrips)
                    .HasForeignKey(d => d.Osid)
                    .HasConstraintName("FK_FishingTrip_OnshoreEvent");

                entity.HasOne(d => d.Sd)
                    .WithMany(p => p.FishingTrips)
                    .HasForeignKey(d => d.Sdid)
                    .HasConstraintName("FK_FishingTrip_SamplingDetails");

                entity.HasOne(d => d.Te)
                    .WithMany(p => p.FishingTrips)
                    .HasForeignKey(d => d.Teid)
                    .HasConstraintName("FK_FishingTrip_TemporalEvent");

                entity.HasOne(d => d.Vd)
                    .WithMany(p => p.FishingTrips)
                    .HasForeignKey(d => d.Vdid)
                    .HasConstraintName("FK_FishingTrip_VesselDetails");

                entity.HasOne(d => d.Vs)
                    .WithMany(p => p.FishingTrips)
                    .HasForeignKey(d => d.Vsid)
                    .HasConstraintName("FK_FishingTrip_VesselSelection");
            });

            modelBuilder.Entity<FrequencyMeasure>(entity =>
            {
                entity.HasKey(e => e.Fmid);

                entity.ToTable("FrequencyMeasure");

                entity.HasIndex(e => new { e.Said, e.FmclassMeasured }).HasName("IX_FM_SAidClstype")
                    .IsUnique();

                entity.HasIndex(e => e.Said).HasName("IX_FrequencyMeasure_SAid");

                entity.Property(e => e.Fmid).HasColumnName("FMid");

                entity.Property(e => e.Fmaccuracy).HasColumnName("FMaccuracy");

                entity.Property(e => e.FmaddGrpMeasurement)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("FMaddGrpMeasurement");

                entity.Property(e => e.FmaddGrpMeasurementType).HasColumnName("FMaddGrpMeasurementType");

                entity.Property(e => e.FmclassMeasured).HasColumnName("FMclassMeasured");

                entity.Property(e => e.FmconversionFactorAssessment)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("FMconversionFactorAssessment");

                entity.Property(e => e.FmmeasurementEquipment).HasColumnName("FMmeasurementEquipment");

                entity.Property(e => e.Fmmethod).HasColumnName("FMmethod");

                entity.Property(e => e.FmnumberAtUnit).HasColumnName("FMnumberAtUnit");

                entity.Property(e => e.Fmpresentation).HasColumnName("FMpresentation");

                entity.Property(e => e.FmrecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("FMrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Fmsampler).HasColumnName("FMsampler");

                entity.Property(e => e.FmstateOfProcessing).HasColumnName("FMstateOfProcessing");

                entity.Property(e => e.FmtypeAssessment).HasColumnName("FMtypeAssessment");

                entity.Property(e => e.FmtypeMeasured).HasColumnName("FMtypeMeasured");

                entity.Property(e => e.Said).HasColumnName("SAid");

                entity.HasOne(d => d.Sa)
                    .WithMany(p => p.FrequencyMeasures)
                    .HasForeignKey(d => d.Said)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FrequencyMeasure_Sample");
            });

            

            modelBuilder.Entity<LandingEvent>(entity =>
            {
                entity.HasKey(e => e.Leid);

                entity.ToTable("LandingEvent");

                entity.HasIndex(e => new { e.Osid, e.Ftid, e.Vsid, e.Teid, e.Said, e.Vdid, e.Foid, e.Ssid, e.LesequenceNumber }).HasName("IX_LE_OSidFTidVSidTEidSAidVDidFOidSSidSeqn")
                    .IsUnique();

                entity.HasIndex(e => e.Foid).HasName("IX_LandingEvent_FOid");

                entity.HasIndex(e => e.Ftid).HasName("IX_LandingEvent_FTid");

                entity.HasIndex(e => e.Osid).HasName("IX_LandingEvent_OSid");

                entity.HasIndex(e => e.Said).HasName("IX_LandingEvent_SAid");

                entity.HasIndex(e => e.Ssid).HasName("IX_LandingEvent_SSid");

                entity.HasIndex(e => e.Teid).HasName("IX_LandingEvent_TEid");

                entity.HasIndex(e => e.Vdid).HasName("IX_LandingEvent_VDid");

                entity.HasIndex(e => e.Vsid).HasName("IX_LandingEvent_VSid");

                entity.Property(e => e.Leid).HasColumnName("LEid");

                entity.Property(e => e.Foid).HasColumnName("FOid");

                entity.Property(e => e.Ftid).HasColumnName("FTid");

                entity.Property(e => e.Learea).HasColumnName("LEarea");

                entity.Property(e => e.LecatchReg).HasColumnName("LEcatchReg");

                entity.Property(e => e.LeclusterName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("LEclusterName");

                entity.Property(e => e.Leclustering).HasColumnName("LEclustering");

                entity.Property(e => e.Lecountry).HasColumnName("LEcountry");

                entity.Property(e => e.Ledate)
                    .HasColumnType("datetime")
                    .HasColumnName("LEdate");

                entity.Property(e => e.LeencryptedVesselCode)
                    .HasMaxLength(100)
                    .HasColumnName("LEencryptedVesselCode");

                entity.Property(e => e.LeexclusiveEconomicZoneIndicator).HasColumnName("LEexclusiveEconomicZoneIndicator");

                entity.Property(e => e.LefullTripAvailable).HasColumnName("LEfullTripAvailable");

                entity.Property(e => e.Legear).HasColumnName("LEgear");

                entity.Property(e => e.LegearDimensions).HasColumnName("LEgearDimensions");

                entity.Property(e => e.LegsaSubarea).HasColumnName("LEgsaSubarea");

                entity.Property(e => e.LehaulNumber).HasColumnName("LEhaulNumber");

                entity.Property(e => e.LeinclusionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("LEInclusionProb");

                entity.Property(e => e.LeinclusionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("LEInclusionProbCluster");

                entity.Property(e => e.LejurisdictionArea).HasColumnName("LEjurisdictionArea");

                entity.Property(e => e.LelocationName)
                    .HasMaxLength(100)
                    .HasColumnName("LELocationName");

                entity.Property(e => e.LelocationType).HasColumnName("LElocationType");

                entity.Property(e => e.Lelocode).HasColumnName("LElocode");

                entity.Property(e => e.LemeshSize).HasColumnName("LEmeshSize");

                entity.Property(e => e.Lemetier5).HasColumnName("LEmetier5");

                entity.Property(e => e.Lemetier6).HasColumnName("LEmetier6");

                entity.Property(e => e.LemitigationDevice).HasColumnName("LEmitigationDevice");

                entity.Property(e => e.LemixedTrip).HasColumnName("LEmixedTrip");

                entity.Property(e => e.LenationalFishingActivity).HasColumnName("LEnationalFishingActivity");

                entity.Property(e => e.LenumberSampled).HasColumnName("LEnumberSampled");

                entity.Property(e => e.LenumberSampledClusters).HasColumnName("LEnumberSampledClusters");

                entity.Property(e => e.LenumberTotal).HasColumnName("LEnumberTotal");

                entity.Property(e => e.LenumberTotalClusters).HasColumnName("LEnumberTotalClusters");

                entity.Property(e => e.LereasonNotSampled).HasColumnName("LEreasonNotSampled");

                entity.Property(e => e.LerecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("LErecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Lerectangle).HasColumnName("LErectangle");

                entity.Property(e => e.Lesampled).HasColumnName("LEsampled");

                entity.Property(e => e.Lesampler).HasColumnName("LEsampler");

                entity.Property(e => e.LeselectionDevice).HasColumnName("LEselectionDevice");

                entity.Property(e => e.LeselectionDeviceMeshSize).HasColumnName("LEselectionDeviceMeshSize");

                entity.Property(e => e.LeselectionMethod).HasColumnName("LEselectionMethod");

                entity.Property(e => e.LeselectionMethodCluster).HasColumnName("LEselectionMethodCluster");

                entity.Property(e => e.LeselectionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("LESelectionProb");

                entity.Property(e => e.LeselectionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("LESelectionProbCluster");

                entity.Property(e => e.LesequenceNumber).HasColumnName("LEsequenceNumber");

                entity.Property(e => e.Lestratification).HasColumnName("LEstratification");

                entity.Property(e => e.LestratumName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("LEstratumName");

                entity.Property(e => e.LetargetSpecies).HasColumnName("LEtargetSpecies");

                entity.Property(e => e.Letime)
                    .HasColumnType("datetime")
                    .HasColumnName("LEtime");

                entity.Property(e => e.LeunitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("LEunitName");

                entity.Property(e => e.Osid).HasColumnName("OSid");

                entity.Property(e => e.Said).HasColumnName("SAid");

                entity.Property(e => e.Ssid).HasColumnName("SSid");

                entity.Property(e => e.Teid).HasColumnName("TEid");

                entity.Property(e => e.Vdid).HasColumnName("VDid");

                entity.Property(e => e.Vsid).HasColumnName("VSid");

                entity.HasOne(d => d.Fo)
                    .WithMany(p => p.LandingEvents)
                    .HasForeignKey(d => d.Foid)
                    .HasConstraintName("FK_LandingEvent_FishingOperation");

                entity.HasOne(d => d.Ft)
                    .WithMany(p => p.LandingEvents)
                    .HasForeignKey(d => d.Ftid)
                    .HasConstraintName("FK_LandingEvent_FishingTrip");

                entity.HasOne(d => d.Os)
                    .WithMany(p => p.LandingEvents)
                    .HasForeignKey(d => d.Osid)
                    .HasConstraintName("FK_LandingEvent_OnshoreEvent");

                entity.HasOne(d => d.Sa)
                    .WithMany(p => p.LandingEvents)
                    .HasForeignKey(d => d.Said)
                    .HasConstraintName("FK_LandingEvent_Sample");

                entity.HasOne(d => d.Ss)
                    .WithMany(p => p.LandingEvents)
                    .HasForeignKey(d => d.Ssid)
                    .HasConstraintName("FK_LandingEvent_SpeciesSelection");

                entity.HasOne(d => d.Te)
                    .WithMany(p => p.LandingEvents)
                    .HasForeignKey(d => d.Teid)
                    .HasConstraintName("FK_LandingEvent_TemporalEvent");

                entity.HasOne(d => d.Vd)
                    .WithMany(p => p.LandingEvents)
                    .HasForeignKey(d => d.Vdid)
                    .HasConstraintName("FK_LandingEvent_VesselDetails");

                entity.HasOne(d => d.Vs)
                    .WithMany(p => p.LandingEvents)
                    .HasForeignKey(d => d.Vsid)
                    .HasConstraintName("FK_LandingEvent_VesselSelection");
            });

            modelBuilder.Entity<Location>(entity =>
            {
                entity.HasKey(e => e.Loid);

                entity.ToTable("Location");

                entity.HasIndex(e => e.Sdid).HasName("IX_Location_SDid");

                entity.Property(e => e.Loid).HasColumnName("LOid");

                entity.Property(e => e.LoclusterName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("LOclusterName");

                entity.Property(e => e.Loclustering).HasColumnName("LOclustering");

                entity.Property(e => e.LoinclusionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("LOinclusionProb");

                entity.Property(e => e.LoinclusionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("LOInclusionProbCluster");

                entity.Property(e => e.LolocationName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("LOLocationName");

                entity.Property(e => e.LolocationType).HasColumnName("LOlocationType");

                entity.Property(e => e.Lolocode).HasColumnName("LOlocode");

                entity.Property(e => e.LonumberSampled).HasColumnName("LOnumberSampled");

                entity.Property(e => e.LonumberSampledClusters).HasColumnName("LOnumberSampledClusters");

                entity.Property(e => e.LonumberTotal).HasColumnName("LOnumberTotal");

                entity.Property(e => e.LonumberTotalClusters).HasColumnName("LOnumberTotalClusters");

                entity.Property(e => e.LoreasonNotSampled).HasColumnName("LOreasonNotSampled");

                entity.Property(e => e.LorecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("LOrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Losampled).HasColumnName("LOsampled");

                entity.Property(e => e.Losampler).HasColumnName("LOsampler");

                entity.Property(e => e.LoselectionMethod).HasColumnName("LOselectionMethod");

                entity.Property(e => e.LoselectionMethodCluster).HasColumnName("LOselectionMethodCluster");

                entity.Property(e => e.LoselectionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("LOselectionProb");

                entity.Property(e => e.LoselectionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("LOSelectionProbCluster");

                entity.Property(e => e.LosequenceNumber).HasColumnName("LOsequenceNumber");

                entity.Property(e => e.Lostratification).HasColumnName("LOstratification");

                entity.Property(e => e.LostratumName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("LOstratumName");

                entity.Property(e => e.LounitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("LOunitName");

                entity.Property(e => e.Sdid).HasColumnName("SDid");

                entity.HasOne(d => d.Sd)
                    .WithMany(p => p.Locations)
                    .HasForeignKey(d => d.Sdid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Location_SamplingDetails");
            });

            modelBuilder.Entity<OnshoreEvent>(entity =>
            {
                entity.HasKey(e => e.Osid);

                entity.ToTable("OnshoreEvent");

                entity.HasIndex(e => new { e.OssequenceNumber, e.Sdid }).HasName("IX_OS_SDidSequenceNumber")
                    .IsUnique();

                entity.Property(e => e.Osid).HasColumnName("OSid");

                entity.Property(e => e.OsclusterName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("OSclusterName");

                entity.Property(e => e.Osclustering).HasColumnName("OSclustering");

                entity.Property(e => e.OsinclusionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("OSinclusionProb");

                entity.Property(e => e.OsinclusionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("OSinclusionProbCluster");

                entity.Property(e => e.OslocationName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("OSLocationName");

                entity.Property(e => e.OslocationType).HasColumnName("OSlocationType");

                entity.Property(e => e.Oslocode).HasColumnName("OSlocode");

                entity.Property(e => e.OsnumberSampled).HasColumnName("OSnumberSampled");

                entity.Property(e => e.OsnumberSampledClusters).HasColumnName("OSnumberSampledClusters");

                entity.Property(e => e.OsnumberTotal).HasColumnName("OSnumberTotal");

                entity.Property(e => e.OsnumberTotalClusters).HasColumnName("OSnumberTotalClusters");

                entity.Property(e => e.OsreasonNotSampled).HasColumnName("OSreasonNotSampled");

                entity.Property(e => e.OsrecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("OSrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Ossampled).HasColumnName("OSsampled");

                entity.Property(e => e.Ossampler).HasColumnName("OSsampler");

                entity.Property(e => e.OssamplingDate)
                    .HasColumnType("datetime")
                    .HasColumnName("OSsamplingDate");

                entity.Property(e => e.OssamplingTime)
                    .HasColumnType("datetime")
                    .HasColumnName("OSsamplingTime");

                entity.Property(e => e.OsselectionMethod).HasColumnName("OSselectionMethod");

                entity.Property(e => e.OsselectionMethodCluster).HasColumnName("OSselectionMethodCluster");

                entity.Property(e => e.OsselectionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("OSselectionProb");

                entity.Property(e => e.OsselectionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("OSselectionProbCluster");

                entity.Property(e => e.OssequenceNumber).HasColumnName("OSsequenceNumber");

                entity.Property(e => e.Osstratification).HasColumnName("OSstratification");

                entity.Property(e => e.OsstratumName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("OSstratumName");

                entity.Property(e => e.OstimeUnit).HasColumnName("OStimeUnit");

                entity.Property(e => e.OstimeValue)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("OStimeValue");

                entity.Property(e => e.OsunitName)
                    .HasMaxLength(100)
                    .HasColumnName("OSunitName");

                entity.Property(e => e.Sdid).HasColumnName("SDid");

                entity.HasOne(d => d.Sd)
                    .WithMany(p => p.OnshoreEvents)
                    .HasForeignKey(d => d.Sdid)
                    .HasConstraintName("FK_OnshoreEvent_SamplingDetails");
            });



            modelBuilder.Entity<RelType>(entity =>
            {
                entity.ToTable("RelType");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Xmlnode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("XMLNode");
            });

            modelBuilder.Entity<Sample>(entity =>
            {
                entity.HasKey(e => e.Said);

                entity.ToTable("Sample");

                entity.HasIndex(e => new { e.SasequenceNumber, e.Ssid }).HasName("IX_SA_SAsequenceNumber_SSID")
                    .IsUnique();

                entity.HasIndex(e => e.Leid).HasName("IX_Sample_LEid");

                entity.HasIndex(e => e.SaparentId).HasName("IX_Sample_SAparentID");

                entity.HasIndex(e => e.Ssid).HasName("IX_Sample_SSid");

                entity.HasIndex(e => new { e.Ssid, e.SasequenceNumber, e.SaspeciesCode, e.SaspeciesCodeFao, e.Sapresentation, e.SacatchCategory, e.SalandingCategory, e.SacommSizeCatScale, e.SacommSizeCat, e.Sasex }).HasName("IX_SeqnumbSpeFaoPreCaCatLaCatComcatComcatScSex")
                    .IsUnique();

                entity.Property(e => e.Said).HasColumnName("SAid");

                entity.Property(e => e.Leid).HasColumnName("LEid");

                entity.Property(e => e.Saarea).HasColumnName("SAarea");

                entity.Property(e => e.SacatchCategory).HasColumnName("SAcatchCategory");

                entity.Property(e => e.SacommSizeCat).HasColumnName("SAcommSizeCat");

                entity.Property(e => e.SacommSizeCatScale).HasColumnName("SAcommSizeCatScale");

                entity.Property(e => e.SaconversionFactorMeasLive)
                    .HasColumnType("decimal(18, 5)")
                    .HasColumnName("SAconversionFactorMeasLive");

                entity.Property(e => e.SaexclusiveEconomicZoneIndicator).HasColumnName("SAexclusiveEconomicZoneIndicator");

                entity.Property(e => e.Sagear).HasColumnName("SAgear");

                entity.Property(e => e.SagsaSubarea).HasColumnName("SAgsaSubarea");

                entity.Property(e => e.SainclusionProb)
                    .HasColumnType("decimal(18, 10)")
                    .HasColumnName("SAinclusionProb");

                entity.Property(e => e.SajurisdictionArea).HasColumnName("SAjurisdictionArea");

                entity.Property(e => e.SalandingCategory).HasColumnName("SAlandingCategory");

                entity.Property(e => e.SalowerHierarchy).HasColumnName("SAlowerHierarchy");

                entity.Property(e => e.SameshSize).HasColumnName("SAmeshSize");

                entity.Property(e => e.Sametier5).HasColumnName("SAmetier5");

                entity.Property(e => e.Sametier6).HasColumnName("SAmetier6");

                entity.Property(e => e.SanationalFishingActivity).HasColumnName("SAnationalFishingActivity");

                entity.Property(e => e.SanumberSampled)
                    .HasColumnType("decimal(18, 10)")
                    .HasColumnName("SAnumberSampled");

                entity.Property(e => e.SanumberTotal)
                    .HasColumnType("decimal(18, 10)")
                    .HasColumnName("SAnumberTotal");

                entity.Property(e => e.SaparentId).HasColumnName("SAparentID");

                entity.Property(e => e.SaparentSequenceNumber).HasColumnName("SAparentSequenceNumber");

                entity.Property(e => e.Sapresentation).HasColumnName("SApresentation");

                entity.Property(e => e.SareasonNotSampledBv).HasColumnName("SAreasonNotSampledBV");

                entity.Property(e => e.SareasonNotSampledFm).HasColumnName("SAreasonNotSampledFM");

                entity.Property(e => e.SarecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("SArecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Sarectangle).HasColumnName("SArectangle");

                entity.Property(e => e.SasampleWeightLive).HasColumnName("SAsampleWeightLive");

                entity.Property(e => e.SasampleWeightMeasured).HasColumnName("SAsampleWeightMeasured");

                entity.Property(e => e.Sasampled).HasColumnName("SAsampled");

                entity.Property(e => e.Sasampler).HasColumnName("SAsampler");

                entity.Property(e => e.SaselectionDevice).HasColumnName("SAselectionDevice");

                entity.Property(e => e.SaselectionDeviceMeshSize).HasColumnName("SAselectionDeviceMeshSize");

                entity.Property(e => e.SaselectionMethod).HasColumnName("SAselectionMethod");

                entity.Property(e => e.SaselectionProb)
                    .HasColumnType("decimal(18, 10)")
                    .HasColumnName("SAselectionProb");

                entity.Property(e => e.SasequenceNumber).HasColumnName("SAsequenceNumber");

                entity.Property(e => e.Sasex).HasColumnName("SAsex");

                entity.Property(e => e.SaspeciesCode).HasColumnName("SAspeciesCode");

                entity.Property(e => e.SaspeciesCodeFao).HasColumnName("SAspeciesCodeFAO");

                entity.Property(e => e.SaspecimensState).HasColumnName("SAspecimensState");

                entity.Property(e => e.SastateOfProcessing).HasColumnName("SAstateOfProcessing");

                entity.Property(e => e.Sastratification).HasColumnName("SAstratification");

                entity.Property(e => e.SastratumName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("SAstratumName");

                entity.Property(e => e.SatotalWeightLive).HasColumnName("SAtotalWeightLive");

                entity.Property(e => e.SatotalWeightMeasured).HasColumnName("SAtotalWeightMeasured");

                entity.Property(e => e.SaunitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("SAunitName");

                entity.Property(e => e.SaunitType).HasColumnName("SAunitType");

                entity.Property(e => e.Ssid).HasColumnName("SSid");

                entity.HasOne(d => d.Le)
                    .WithMany(p => p.Samples)
                    .HasForeignKey(d => d.Leid)
                    .HasConstraintName("FK_Sample_LandingEvent");

                entity.HasOne(d => d.Saparent)
                    .WithMany(p => p.InverseSaparent)
                    .HasForeignKey(d => d.SaparentId)
                    .HasConstraintName("FK_Sample_Sample");

                entity.HasOne(d => d.Ss)
                    .WithMany(p => p.Samples)
                    .HasForeignKey(d => d.Ssid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Sample_SpeciesSelection");
            });

            modelBuilder.Entity<SamplingDetails>(entity =>
            {
                entity.HasKey(e => e.Sdid);

                entity.HasIndex(e => new { e.Deid, e.Sdcountry, e.Sdinstitution }).HasName("IX_SD_DEidCouIns")
                    .IsUnique();

                entity.HasIndex(e => e.Sdid).HasName("IX_SamplingDetails_DEid");

                entity.Property(e => e.Sdid).HasColumnName("SDid");

                entity.Property(e => e.Deid).HasColumnName("DEid");

                entity.Property(e => e.Sdcountry).HasColumnName("SDcountry");

                entity.Property(e => e.Sdinstitution).HasColumnName("SDinstitution");

                entity.Property(e => e.SdrecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("SDrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.TimeStamp).HasColumnType("datetime");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(450);

                entity.HasOne(d => d.De)
                    .WithMany(p => p.SamplingDetails)
                    .HasForeignKey(d => d.Deid)
                    .HasConstraintName("FK_SamplingDetails_Design");
            });

            modelBuilder.Entity<SpeciesList>(entity =>
            {
                entity.HasKey(e => e.Slid)
                    .HasName("PK__SpeciesL__A43C4907BA7226F8");

                entity.ToTable("SpeciesList");

                entity.HasIndex(e => new { e.Slcountry, e.SlspeciesListName, e.Slyear, e.SlcatchFraction, e.SlcommercialTaxon, e.SlspeciesCode }).HasName("IX_Cou_Spe_Yea_Fra_Tax_SpeCod")
                    .IsUnique();

                entity.Property(e => e.Slid).HasColumnName("SLid");

                entity.Property(e => e.SlcatchFraction).HasColumnName("SLcatchFraction");

                entity.Property(e => e.SlcommercialTaxon).HasColumnName("SLcommercialTaxon");

                entity.Property(e => e.Slcountry).HasColumnName("SLcountry");

                entity.Property(e => e.Slinstitute).HasColumnName("SLinstitute");

                entity.Property(e => e.SlrecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("SLrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.SlspeciesCode).HasColumnName("SLspeciesCode");

                entity.Property(e => e.SlspeciesListName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("SLspeciesListName");

                entity.Property(e => e.Slyear).HasColumnName("SLyear");

                entity.Property(e => e.TimeStamp).HasColumnType("datetime");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(450);
            });

            modelBuilder.Entity<SpeciesSelection>(entity =>
            {
                entity.HasKey(e => e.Ssid);

                entity.ToTable("SpeciesSelection");

                entity.HasIndex(e => new { e.Leid, e.Foid, e.Teid, e.Ftid, e.Osid, e.SsobservationActivityType, e.SscatchFraction, e.SsobservationType }).HasName("IX_SS_LEiFOidcaf")
                    .IsUnique();

                entity.HasIndex(e => new { e.Leid, e.Foid, e.Teid, e.Ftid, e.Osid, e.SssequenceNumber }).HasName("IX_SS_LEidFOidTEidFTidOSidSeq")
                    .IsUnique();

                entity.HasIndex(e => e.Foid).HasName("IX_SpeciesSelection_FOid");

                entity.HasIndex(e => e.Ftid).HasName("IX_SpeciesSelection_FTid");

                entity.HasIndex(e => e.Leid).HasName("IX_SpeciesSelection_LEid");

                entity.HasIndex(e => e.Osid).HasName("IX_SpeciesSelection_OSid");

                entity.HasIndex(e => e.Slid).HasName("IX_SpeciesSelection_SLid");

                entity.HasIndex(e => e.Teid).HasName("IX_SpeciesSelection_TEid");

                entity.Property(e => e.Ssid).HasColumnName("SSid");

                entity.Property(e => e.Foid).HasColumnName("FOid");

                entity.Property(e => e.Ftid).HasColumnName("FTid");

                entity.Property(e => e.Leid).HasColumnName("LEid");

                entity.Property(e => e.Osid).HasColumnName("OSid");

                entity.Property(e => e.Slid).HasColumnName("SLid");

                entity.Property(e => e.SscatchFraction).HasColumnName("SScatchFraction");

                entity.Property(e => e.SsclusterName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("SSclusterName");

                entity.Property(e => e.Ssclustering).HasColumnName("SSclustering");

                entity.Property(e => e.SsinclusionProb).HasColumnName("SSinclusionProb");

                entity.Property(e => e.SsinclusionProbCluster)
                    .HasColumnType("decimal(18, 10)")
                    .HasColumnName("SSinclusionProbCluster");

                entity.Property(e => e.SsnumberSampled).HasColumnName("SSnumberSampled");

                entity.Property(e => e.SsnumberSampledClusters).HasColumnName("SSnumberSampledClusters");

                entity.Property(e => e.SsnumberTotal).HasColumnName("SSnumberTotal");

                entity.Property(e => e.SsnumberTotalClusters).HasColumnName("SSnumberTotalClusters");

                entity.Property(e => e.SsobservationActivityType).HasColumnName("SSObservationActivityType");

                entity.Property(e => e.SsobservationType).HasColumnName("SSObservationType");

                entity.Property(e => e.SsreasonNotSampled).HasColumnName("SSreasonNotSampled");

                entity.Property(e => e.SsrecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("SSrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Sssampled).HasColumnName("SSsampled");

                entity.Property(e => e.Sssampler).HasColumnName("SSsampler");

                entity.Property(e => e.SsselectionMethod).HasColumnName("SSselectionMethod");

                entity.Property(e => e.SsselectionMethodCluster).HasColumnName("SSselectionMethodCluster");

                entity.Property(e => e.SsselectionProb).HasColumnName("SSselectionProb");

                entity.Property(e => e.SsselectionProbCluster)
                    .HasColumnType("decimal(18, 10)")
                    .HasColumnName("SSselectionProbCluster");

                entity.Property(e => e.SssequenceNumber).HasColumnName("SSsequenceNumber");

                entity.Property(e => e.SsspeciesListName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("SSspeciesListName");

                entity.Property(e => e.Ssstratification).HasColumnName("SSstratification");

                entity.Property(e => e.SsstratumName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("SSstratumName");

                entity.Property(e => e.SsunitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("SSunitName");

                entity.Property(e => e.SsuseForCalculateZero).HasColumnName("SSuseForCalculateZero");

                entity.Property(e => e.Teid).HasColumnName("TEid");

                entity.HasOne(d => d.Fo)
                    .WithMany(p => p.SpeciesSelections)
                    .HasForeignKey(d => d.Foid)
                    .HasConstraintName("FK_SpeciesSelection_FishingOperation");

                entity.HasOne(d => d.Ft)
                    .WithMany(p => p.SpeciesSelections)
                    .HasForeignKey(d => d.Ftid)
                    .HasConstraintName("FK_SpeciesSelection_FishingTrip");

                entity.HasOne(d => d.Le)
                    .WithMany(p => p.SpeciesSelections)
                    .HasForeignKey(d => d.Leid)
                    .HasConstraintName("FK_SpeciesSelection_LandingEvent");

                entity.HasOne(d => d.Os)
                    .WithMany(p => p.SpeciesSelections)
                    .HasForeignKey(d => d.Osid)
                    .HasConstraintName("FK_SpeciesSelection_OnshoreEvent");

                entity.HasOne(d => d.Sl)
                    .WithMany(p => p.SpeciesSelections)
                    .HasForeignKey(d => d.Slid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SpeciesSelection_SpeciesList");

                entity.HasOne(d => d.Te)
                    .WithMany(p => p.SpeciesSelections)
                    .HasForeignKey(d => d.Teid)
                    .HasConstraintName("FK_SpeciesSelection_TemporalEvent");
            });

            modelBuilder.Entity<TblCode>(entity =>
            {
                entity.ToTable("tblCode");

                entity.HasIndex(e => new { e.TblCodeTypeId, e.Code }).HasName("CN_tblCode")
                    .IsUnique();

                entity.Property(e => e.TblCodeId).HasColumnName("tblCodeID");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(400);

                entity.Property(e => e.LongDescription)
                    .HasMaxLength(4000)
                    .IsUnicode(false);

                entity.Property(e => e.Modified).HasColumnType("datetime");

                entity.Property(e => e.TblCodeTypeId).HasColumnName("tblCodeTypeID");

                entity.Property(e => e.User)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Visibility)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.HasOne(d => d.TblCodeType)
                    .WithMany(p => p.TblCodes)
                    .HasForeignKey(d => d.TblCodeTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblCode_tblCodeType");
            });

            modelBuilder.Entity<TblCodeRel>(entity =>
            {
                entity.HasKey(e => new { e.TblCodeOneId, e.TblCodeManyId, e.TblCodeTypeRelId });

                entity.ToTable("tblCodeRel");

                entity.Property(e => e.TblCodeOneId).HasColumnName("tblCodeOneID");

                entity.Property(e => e.TblCodeManyId).HasColumnName("tblCodeManyID");

                entity.Property(e => e.TblCodeTypeRelId).HasColumnName("tblCodeTypeRelID");

                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.Modified).HasColumnType("datetime");

                entity.Property(e => e.User)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.TblCodeMany)
                    .WithMany(p => p.TblCodeRelTblCodeManies)
                    .HasForeignKey(d => d.TblCodeManyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblCodeRel_tblCode1");

                entity.HasOne(d => d.TblCodeOne)
                    .WithMany(p => p.TblCodeRelTblCodeOnes)
                    .HasForeignKey(d => d.TblCodeOneId)
                    .HasConstraintName("FK_tblCodeRel_tblCode");

                entity.HasOne(d => d.TblCodeTypeRel)
                    .WithMany(p => p.TblCodeRels)
                    .HasForeignKey(d => d.TblCodeTypeRelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tblCodeRe__tblCo__60DDFCE7");
            });

            modelBuilder.Entity<TblCodeType>(entity =>
            {
                entity.ToTable("tblCodeType");

                entity.HasIndex(e => e.CodeType).HasName("CN_tblCodeType")
                    .IsUnique();

                entity.Property(e => e.TblCodeTypeId).HasColumnName("tblCodeTypeID");

                entity.Property(e => e.CodeType)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.Definition)
                    .HasMaxLength(4000)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(400);

                entity.Property(e => e.Modified).HasColumnType("datetime");

                entity.Property(e => e.User)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.VerDate).HasColumnType("datetime");

                entity.Property(e => e.Visibility)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<TblCodeTypeRel>(entity =>
            {
                entity.ToTable("tblCodeTypeRel");

                entity.HasIndex(e => new { e.TblCodeTypeParId, e.TblCodeTypeChdId, e.RelTypeId }).HasName("CN_tblTypeRel")
                    .IsUnique();

                entity.Property(e => e.TblCodeTypeRelId).HasColumnName("tblCodeTypeRelID");

                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.Description).HasMaxLength(300);

              //  entity.Property(e => e.Join).HasComment("Join Type 1=one to one, 2 = one to many, 3 = many to many");

                entity.Property(e => e.Modified).HasColumnType("datetime");

                entity.Property(e => e.RelTypeId)
                    .HasColumnName("RelTypeID")
                    .HasDefaultValueSql("((3))");

                entity.Property(e => e.TblCodeTypeChdId).HasColumnName("tblCodeTypeChdID");

                entity.Property(e => e.TblCodeTypeParId).HasColumnName("tblCodeTypeParID");

                entity.Property(e => e.User)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.RelType)
                    .WithMany(p => p.TblCodeTypeRels)
                    .HasForeignKey(d => d.RelTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblCodeTypeRel_RelType");

                entity.HasOne(d => d.TblCodeTypeChd)
                    .WithMany(p => p.TblCodeTypeRelTblCodeTypeChds)
                    .HasForeignKey(d => d.TblCodeTypeChdId)
                    .HasConstraintName("FK_tblCodeTypeRel_tblCodeType1");

                entity.HasOne(d => d.TblCodeTypePar)
                    .WithMany(p => p.TblCodeTypeRelTblCodeTypePars)
                    .HasForeignKey(d => d.TblCodeTypeParId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblCodeTypeRel_tblCodeType");
            });

            modelBuilder.Entity<RSpeciesAreaQuarter>(entity =>
            {
                entity.ToTable("R_SpeciesAreaQuarter");

                entity.Property(e => e.Description).HasMaxLength(255);

                entity.HasOne(d => d.AreaNavigation)
                    .WithMany(p => p.RSpeciesAreaQuarterAreaNavigations)
                    .HasForeignKey(d => d.Area)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.QuarterNavigation)
                    .WithMany(p => p.RSpeciesAreaQuarterQuarterNavigations)
                    .HasForeignKey(d => d.Quarter)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.SpeciesNavigation)
                    .WithMany(p => p.RSpeciesAreaQuarterSpeciesNavigations)
                    .HasForeignKey(d => d.Species)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.StockNavigation)
                    .WithMany(p => p.RSpeciesAreaQuarterStockNavigations)
                    .HasForeignKey(d => d.Stock)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });


            modelBuilder.Entity<TemporalEvent>(entity =>
            {
                entity.HasKey(e => e.Teid);

                entity.ToTable("TemporalEvent");

                entity.HasIndex(e => new { e.Sdid, e.Loid, e.Vsid, e.TetimeUnit, e.TesequenceNumber }).HasName("IX_TE_SDidTuNc")
                    .IsUnique();

                entity.HasIndex(e => e.Loid).HasName("IX_TemporalEvent_LOid");

                entity.HasIndex(e => e.Sdid).HasName("IX_TemporalEvent_SDid");

                entity.HasIndex(e => e.Vsid).HasName("IX_TemporalEvent_VSid");

                entity.Property(e => e.Teid).HasColumnName("TEid");

                entity.Property(e => e.Loid).HasColumnName("LOid");

                entity.Property(e => e.Sdid).HasColumnName("SDid");

                entity.Property(e => e.TeclusterName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("TEclusterName");

                entity.Property(e => e.Teclustering).HasColumnName("TEclustering");

                entity.Property(e => e.TeinclusionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("TEinclusionProb");

                entity.Property(e => e.TeinclusionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("TEinclusionProbCluster");

                entity.Property(e => e.TenumberSampled).HasColumnName("TEnumberSampled");

                entity.Property(e => e.TenumberSampledClusters).HasColumnName("TEnumberSampledClusters");

                entity.Property(e => e.TenumberTotal).HasColumnName("TEnumberTotal");

                entity.Property(e => e.TenumberTotalClusters).HasColumnName("TEnumberTotalClusters");

                entity.Property(e => e.TereasonNotSampled).HasColumnName("TEreasonNotSampled");

                entity.Property(e => e.TerecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("TErecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Tesampled).HasColumnName("TEsampled");

                entity.Property(e => e.Tesampler).HasColumnName("TEsampler");

                entity.Property(e => e.TeselectionMethod).HasColumnName("TEselectionMethod");

                entity.Property(e => e.TeselectionMethodCluster).HasColumnName("TEselectionMethodCluster");

                entity.Property(e => e.TeselectionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("TEselectionProb");

                entity.Property(e => e.TeselectionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("TEselectionProbCluster");

                entity.Property(e => e.TesequenceNumber).HasColumnName("TEsequenceNumber");

                entity.Property(e => e.Testratification).HasColumnName("TEstratification");

                entity.Property(e => e.TestratumName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("TEstratumName");

                entity.Property(e => e.TetimeUnit).HasColumnName("TEtimeUnit");

                entity.Property(e => e.TeunitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("TEunitName");

                entity.Property(e => e.Vsid).HasColumnName("VSid");

                entity.HasOne(d => d.Lo)
                    .WithMany(p => p.TemporalEvents)
                    .HasForeignKey(d => d.Loid)
                    .HasConstraintName("FK_TemporalEvent_Location");

                entity.HasOne(d => d.Sd)
                    .WithMany(p => p.TemporalEvents)
                    .HasForeignKey(d => d.Sdid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TemporalEvent_SamplingDetails");

                entity.HasOne(d => d.Vs)
                    .WithMany(p => p.TemporalEvents)
                    .HasForeignKey(d => d.Vsid)
                    .HasConstraintName("FK_TemporalEvent_VesselSelection");
            });

          

            

            

            modelBuilder.Entity<VesselDetails>(entity =>
            {
                entity.HasKey(e => e.Vdid)
                    .HasName("PK_VesselDetails_1");

                entity.HasIndex(e => new { e.Vdcountry, e.VdencryptedVesselCode, e.Vdyear }).HasName("IX_Sub_VesselCode_Yea")
                    .IsUnique();

                entity.Property(e => e.Vdid).HasColumnName("VDid");

                entity.Property(e => e.TimeStamp).HasColumnType("datetime");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(450);

                entity.Property(e => e.Vdcountry).HasColumnName("VDcountry");

                entity.Property(e => e.VdencryptedVesselCode)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("VDencryptedVesselCode");

                entity.Property(e => e.VdflagCountry).HasColumnName("VDflagCountry");

                entity.Property(e => e.VdhomePort).HasColumnName("VDhomePort");

                entity.Property(e => e.Vdlength)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("VDlength");

                entity.Property(e => e.VdlengthCategory).HasColumnName("VDlengthCategory");

                entity.Property(e => e.Vdpower).HasColumnName("VDpower");

                entity.Property(e => e.VdrecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("VDrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.VdtonUnit).HasColumnName("VDtonUnit");

                entity.Property(e => e.Vdtonnage).HasColumnName("VDtonnage");

                entity.Property(e => e.Vdyear).HasColumnName("VDyear");
            });

            modelBuilder.Entity<VesselSelection>(entity =>
            {
                entity.HasKey(e => e.Vsid)
                    .HasName("PK_Vessel");

                entity.ToTable("VesselSelection");

                entity.HasIndex(e => e.Sdid).HasName("IX_VesselSelection_SDid");

                entity.HasIndex(e => e.Teid).HasName("IX_VesselSelection_TEid");

                entity.HasIndex(e => e.Vdid).HasName("IX_VesselSelection_VDid");

                entity.Property(e => e.Vsid).HasColumnName("VSid");

                entity.Property(e => e.Sdid).HasColumnName("SDid");

                entity.Property(e => e.Teid).HasColumnName("TEid");

                entity.Property(e => e.Vdid).HasColumnName("VDid");

                entity.Property(e => e.VsclusterName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("VSclusterName");

                entity.Property(e => e.Vsclustering).HasColumnName("VSclustering");

                entity.Property(e => e.VsencryptedVesselCode)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("VSencryptedVesselCode");

                entity.Property(e => e.VsinclusionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("VSinclusionProb");

                entity.Property(e => e.VsinclusionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("VSInclusionProbCluster");

                entity.Property(e => e.VsnumberSampled).HasColumnName("VSnumberSampled");

                entity.Property(e => e.VsnumberSampledClusters).HasColumnName("VSnumberSampledClusters");

                entity.Property(e => e.VsnumberTotal).HasColumnName("VSnumberTotal");

                entity.Property(e => e.VsnumberTotalClusters).HasColumnName("VSnumberTotalClusters");

                entity.Property(e => e.VsreasonNotSampled).HasColumnName("VSreasonNotSampled");

                entity.Property(e => e.VsrecordType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("VSrecordType")
                    .IsFixedLength(true);

                entity.Property(e => e.Vssampled).HasColumnName("VSsampled");

                entity.Property(e => e.Vssampler).HasColumnName("VSsampler");

                entity.Property(e => e.VsselectionMethod).HasColumnName("VSselectionMethod");

                entity.Property(e => e.VsselectionMethodCluster).HasColumnName("VSselectionMethodCluster");

                entity.Property(e => e.VsselectionProb)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("VSselectionProb");

                entity.Property(e => e.VsselectionProbCluster)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("VSSelectionProbCluster");

                entity.Property(e => e.VssequenceNumber).HasColumnName("VSsequenceNumber");

                entity.Property(e => e.Vsstratification).HasColumnName("VSstratification");

                entity.Property(e => e.VsstratumName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("VSstratumName");

                entity.Property(e => e.VsunitName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("VSunitName");

                entity.HasOne(d => d.Sd)
                    .WithMany(p => p.VesselSelections)
                    .HasForeignKey(d => d.Sdid)
                    .HasConstraintName("FK_VesselSelection_SamplingDetails");

                entity.HasOne(d => d.Te)
                    .WithMany(p => p.VesselSelections)
                    .HasForeignKey(d => d.Teid)
                    .HasConstraintName("FK_VesselSelection_TemporalEvent");

                entity.HasOne(d => d.Vd)
                    .WithMany(p => p.VesselSelections)
                    .HasForeignKey(d => d.Vdid)
                    .HasConstraintName("FK_VesselSelection_VesselDetails");
            });

            
        }




        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{

        //    base.OnModelCreating(modelBuilder);

        //    modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

        //    #region KeyLess Entities
        //    modelBuilder.Query<CodeLookup>();
        //    modelBuilder.Query<LinePkMapping>();
        //    #endregion






        //    modelBuilder.Entity<TblCode>(entity =>
        //    {
        //        entity.ToTable("tblCode");

        //        entity.HasIndex(e => new { e.TblCodeTypeId, e.Code })
        //            .HasName("CN_tblCode")
        //            .IsUnique();

        //        entity.Property(e => e.TblCodeId).HasColumnName("tblCodeID");

        //        entity.Property(e => e.Code)
        //            .IsRequired()
        //            .HasMaxLength(60)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Created).HasColumnType("datetime");

        //        entity.Property(e => e.Deprecated).HasDefaultValueSql("((0))");

        //        entity.Property(e => e.Description).HasMaxLength(300);

        //        entity.Property(e => e.LongDescription)
        //            .HasMaxLength(4000)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Modified).HasColumnType("datetime");

        //        entity.Property(e => e.TblCodeTypeId).HasColumnName("tblCodeTypeID");

        //        entity.Property(e => e.User)
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Visibility).HasDefaultValueSql("((1))");

        //        entity.HasOne(d => d.TblCodeType)
        //            .WithMany(p => p.TblCode)
        //            .HasForeignKey(d => d.TblCodeTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_tblCode_tblCodeType");
        //    });

        //    modelBuilder.Entity<TblCodeRel>(entity =>
        //    {
        //        entity.HasKey(e => new { e.TblCodeOneId, e.TblCodeManyId, e.TblCodeTypeRelId });

        //        entity.ToTable("tblCodeRel");

        //        entity.Property(e => e.TblCodeOneId).HasColumnName("tblCodeOneID");

        //        entity.Property(e => e.TblCodeManyId).HasColumnName("tblCodeManyID");

        //        entity.Property(e => e.TblCodeTypeRelId).HasColumnName("tblCodeTypeRelID");

        //        entity.Property(e => e.Created).HasColumnType("datetime");

        //        entity.Property(e => e.Modified).HasColumnType("datetime");

        //        entity.Property(e => e.User)
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.HasOne(d => d.TblCodeMany)
        //            .WithMany(p => p.TblCodeRelTblCodeMany)
        //            .HasForeignKey(d => d.TblCodeManyId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_tblCodeRel_tblCode1");

        //        entity.HasOne(d => d.TblCodeOne)
        //            .WithMany(p => p.TblCodeRelTblCodeOne)
        //            .HasForeignKey(d => d.TblCodeOneId)
        //            .HasConstraintName("FK_tblCodeRel_tblCode");
        //    });

        //    modelBuilder.Entity<TblCodeType>(entity =>
        //    {
        //        entity.ToTable("tblCodeType");

        //        entity.HasIndex(e => e.CodeType)
        //            .HasName("CN_tblCodeType")
        //            .IsUnique();

        //        entity.Property(e => e.TblCodeTypeId).HasColumnName("tblCodeTypeID");

        //        entity.Property(e => e.CodeType)
        //            .IsRequired()
        //            .HasMaxLength(30)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Created).HasColumnType("datetime");

        //        entity.Property(e => e.Definition)
        //            .HasMaxLength(4000)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Modified).HasColumnType("datetime");

        //        entity.Property(e => e.User)
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.VerDate).HasColumnType("datetime");

        //        entity.Property(e => e.Visibility).HasDefaultValueSql("((1))");
        //    });

        //    modelBuilder.Entity<TblCodeTypeRel>(entity =>
        //    {
        //        entity.ToTable("tblCodeTypeRel");

        //        entity.HasIndex(e => new { e.TblCodeTypeParId, e.TblCodeTypeChdId, e.RelTypeId })
        //            .HasName("CN_tblTypeRel")
        //            .IsUnique();

        //        entity.Property(e => e.TblCodeTypeRelId).HasColumnName("tblCodeTypeRelID");

        //        entity.Property(e => e.Created).HasColumnType("datetime");

        //        entity.Property(e => e.Description).HasMaxLength(300);

        //        entity.Property(e => e.Modified).HasColumnType("datetime");

        //        entity.Property(e => e.RelTypeId)
        //            .HasColumnName("RelTypeID")
        //            .HasDefaultValueSql("((3))");

        //        entity.Property(e => e.TblCodeTypeChdId).HasColumnName("tblCodeTypeChdID");

        //        entity.Property(e => e.TblCodeTypeParId).HasColumnName("tblCodeTypeParID");

        //        entity.Property(e => e.User)
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.HasOne(d => d.RelType)
        //            .WithMany(p => p.TblCodeTypeRel)
        //            .HasForeignKey(d => d.RelTypeId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_tblCodeTypeRel_RelType");

        //        entity.HasOne(d => d.TblCodeTypeChd)
        //            .WithMany(p => p.TblCodeTypeRelTblCodeTypeChd)
        //            .HasForeignKey(d => d.TblCodeTypeChdId)
        //            .HasConstraintName("FK_tblCodeTypeRel_tblCodeType1");

        //        entity.HasOne(d => d.TblCodeTypePar)
        //            .WithMany(p => p.TblCodeTypeRelTblCodeTypePar)
        //            .HasForeignKey(d => d.TblCodeTypeParId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_tblCodeTypeRel_tblCodeType");
        //    });



        //    modelBuilder.Entity<RelType>(entity =>
        //    {
        //        entity.Property(e => e.Id)
        //            .HasColumnName("ID")
        //            .ValueGeneratedNever();

        //        entity.Property(e => e.Description)
        //            .IsRequired()
        //            .HasMaxLength(50);

        //        entity.Property(e => e.Xmlnode)
        //            .IsRequired()
        //            .HasColumnName("XMLNode")
        //            .HasMaxLength(50);
        //    });








        //    modelBuilder.Entity<BiologicalVariable>(entity =>
        //    {
        //        entity.HasKey(e => e.Bvid);

        //        entity.HasIndex(e => e.Fmid);

        //        entity.HasIndex(e => e.Said);

        //        entity.HasIndex(e => new { e.Said, e.Fmid, e.BvfishId, e.Bvtype })
        //            .HasName("IX_BV_SAidFMidFidTyp")
        //            .IsUnique();

        //        entity.Property(e => e.Bvid).HasColumnName("BVid");

        //        entity.Property(e => e.Bvaccuracy).HasColumnName("BVaccuracy");

        //        entity.Property(e => e.BvceratintyQuantitative)
        //            .HasColumnName("BVceratintyQuantitative")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.BvcertaintyQualitative).HasColumnName("BVcertaintyQualitative");

        //        entity.Property(e => e.BvfishId).HasColumnName("BVfishId");

        //        entity.Property(e => e.BvinclusionProb)
        //            .HasColumnName("BVinclusionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.BvmeasurementEquipment).HasColumnName("BVmeasurementEquipment");

        //        entity.Property(e => e.Bvmethod).HasColumnName("BVmethod");

        //        entity.Property(e => e.BvnumberSampled).HasColumnName("BVnumberSampled");

        //        entity.Property(e => e.BvnumberTotal).HasColumnName("BVnumberTotal");

        //        entity.Property(e => e.BvrecordType)
        //            .IsRequired()
        //            .HasColumnName("BVrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Bvsampler).HasColumnName("BVsampler");

        //        entity.Property(e => e.BvselectionMethod).HasColumnName("BVselectionMethod");

        //        entity.Property(e => e.BvselectionProb)
        //            .HasColumnName("BVselectionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.Bvstratification).HasColumnName("BVstratification");

        //        entity.Property(e => e.BvstratumName)
        //            .IsRequired()
        //            .HasColumnName("BVstratumName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Bvtype).HasColumnName("BVtype");

        //        entity.Property(e => e.BvunitName)
        //            .IsRequired()
        //            .HasColumnName("BVunitName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Bvvalue)
        //            .IsRequired()
        //            .HasColumnName("BVvalue")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.BvvalueUnitOrScale).HasColumnName("BVvalueUnitOrScale");

        //        entity.Property(e => e.Fmid).HasColumnName("FMid");

        //        entity.Property(e => e.Said).HasColumnName("SAid");

        //        entity.HasOne(d => d.Fm)
        //            .WithMany(p => p.BiologicalVariable)
        //            .HasForeignKey(d => d.Fmid)
        //            .HasConstraintName("FK_BiologicalVariable_FrequencyMeasure");

        //        entity.HasOne(d => d.Sa)
        //            .WithMany(p => p.BiologicalVariable)
        //            .HasForeignKey(d => d.Said)
        //            .HasConstraintName("FK_BiologicalVariable_Sample");
        //    });

        //    modelBuilder.Entity<CommercialEffort>(entity =>
        //    {
        //        entity.HasKey(e => e.Ceid);

        //        entity.HasIndex(e => new { e.CedataTypeForScientificEffort, e.CedataSourceForScientificEffort, e.CesamplingScheme, e.CevesselFlagCountry, e.Ceyear, e.Cequarter, e.Cemonth, e.Cearea, e.CestatisticalRectangle, e.CegsaSubarea, e.CejurisdictionArea, e.CeexclusiveEconomicZoneIndicator, e.CenationalFishingActivity, e.Cemetier6, e.CeincidentalByCatchMitigationDevice, e.CelandingLocation, e.CevesselLengthCategory, e.CefishingTechnique, e.CedeepSeaRegulation })
        //            .HasName("NonClusteredIndex-20200324-152835")
        //            .IsUnique();

        //        entity.Property(e => e.Ceid).HasColumnName("CEid");

        //        entity.Property(e => e.Cearea).HasColumnName("CEarea");

        //        entity.Property(e => e.CedataSourceForScientificEffort).HasColumnName("CEdataSourceForScientificEffort");

        //        entity.Property(e => e.CedataTypeForScientificEffort).HasColumnName("CEdataTypeForScientificEffort");

        //        entity.Property(e => e.CedeepSeaRegulation).HasColumnName("CEdeepSeaRegulation");

        //        entity.Property(e => e.CeexclusiveEconomicZoneIndicator).HasColumnName("CEexclusiveEconomicZoneIndicator");

        //        entity.Property(e => e.CefishingTechnique).HasColumnName("CEfishingTechnique");

        //        entity.Property(e => e.CegTdaysAtSea).HasColumnName("CEgTDaysAtSea");

        //        entity.Property(e => e.CegTfishingDays).HasColumnName("CEgTFishingDays");

        //        entity.Property(e => e.CegTfishingHours).HasColumnName("CEgTFishingHours");

        //        entity.Property(e => e.CegsaSubarea).HasColumnName("CEgsaSubarea");

        //        entity.Property(e => e.CeincidentalByCatchMitigationDevice).HasColumnName("CEincidentalByCatchMitigationDevice");

        //        entity.Property(e => e.CejurisdictionArea).HasColumnName("CEjurisdictionArea");

        //        entity.Property(e => e.CelandingLocation).HasColumnName("CElandingLocation");

        //        entity.Property(e => e.Cemetier6).HasColumnName("CEmetier6");

        //        entity.Property(e => e.Cemonth).HasColumnName("CEmonth");

        //        entity.Property(e => e.CenationalFishingActivity).HasColumnName("CEnationalFishingActivity");

        //        entity.Property(e => e.CenumberOfDominantTrips).HasColumnName("CEnumberOfDominantTrips");

        //        entity.Property(e => e.CenumberOfFractionTrips)
        //            .HasColumnName("CEnumberOfFractionTrips")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.CenumberOfUniqueVessels).HasColumnName("CEnumberOfUniqueVessels");

        //        entity.Property(e => e.CeofficialDaysAtSea)
        //            .HasColumnName("CEofficialDaysAtSea")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.CeofficialFishingDays)
        //            .HasColumnName("CEofficialFishingDays")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.CeofficialNumberOfHaulsOrSets).HasColumnName("CEofficialNumberOfHaulsOrSets");

        //        entity.Property(e => e.CeofficialSoakingMeterHour)
        //            .HasColumnName("CEofficialSoakingMeterHour")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.CeofficialVesselFishingHour)
        //            .HasColumnName("CEofficialVesselFishingHour")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.CeofficialkWdaysAtSea).HasColumnName("CEofficialkWDaysAtSea");

        //        entity.Property(e => e.CeofficialkWfishingDays).HasColumnName("CEofficialkWFishingDays");

        //        entity.Property(e => e.CeofficialkWfishingHours).HasColumnName("CEofficialkWFishingHours");

        //        entity.Property(e => e.Cequarter).HasColumnName("CEquarter");

        //        entity.Property(e => e.CerecordType)
        //            .IsRequired()
        //            .HasColumnName("CErecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.CesamplingScheme).HasColumnName("CEsamplingScheme");

        //        entity.Property(e => e.CescientificDaysAtSea)
        //            .HasColumnName("CEScientificDaysAtSea")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.CescientificFishingDays)
        //            .HasColumnName("CEscientificFishingDays")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.CescientificFishingDaysQualitativeBias).HasColumnName("CEscientificFishingDaysQualitativeBias");

        //        entity.Property(e => e.CescientificFishingDaysRse).HasColumnName("CEscientificFishingDaysRSE");

        //        entity.Property(e => e.CescientificNumberOfHaulsOrSets).HasColumnName("CEscientificNumberOfHaulsOrSets");

        //        entity.Property(e => e.CescientificSoakingMeterHour)
        //            .HasColumnName("CEscientificSoakingMeterHour")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.CescientificVesselFishingHour)
        //            .HasColumnName("CEscientificVesselFishingHour")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.CescientifickWdaysAtSea).HasColumnName("CEscientifickWDaysAtSea");

        //        entity.Property(e => e.CescientifickWfishingDays).HasColumnName("CEscientifickWFishingDays");

        //        entity.Property(e => e.CescientifickWfishingHours).HasColumnName("CEscientifickWFishingHours");

        //        entity.Property(e => e.CestatisticalRectangle).HasColumnName("CEstatisticalRectangle");

        //        entity.Property(e => e.CevesselFlagCountry).HasColumnName("CEvesselFlagCountry");

        //        entity.Property(e => e.CevesselLengthCategory).HasColumnName("CEvesselLengthCategory");

        //        entity.Property(e => e.Ceyear).HasColumnName("CEyear");

        //        entity.Property(e => e.TimeStamp).HasColumnType("datetime");

        //        entity.Property(e => e.UserId)
        //            .IsRequired()
        //            .HasMaxLength(450);
        //    });

        //    modelBuilder.Entity<CommercialLanding>(entity =>
        //    {
        //        entity.HasKey(e => e.Clid);

        //        entity.HasIndex(e => new { e.CldataTypeOfScientificWeight, e.CldataSourceOfScientificWeight, e.ClsamplingScheme, e.CldataSourceLandingsValue, e.CllandingCountry, e.ClvesselFlagCountry, e.Clyear, e.Clquarter, e.Clmonth, e.Clarea, e.ClstatisticalRectangle, e.ClgsaSubarea, e.CljurisdictionArea, e.ClexclusiveEconomicZoneIndicator, e.ClspeciesCode, e.ClspeciesFaoCode, e.CllandingCategory, e.ClcatchCategory, e.ClcommercialSizeCategoryScale, e.ClcommercialSizeCategory, e.ClnationalFishingActivity, e.Clmetier6, e.ClincidentialByCatchMitigationDevice, e.CllandingLocation, e.ClvesselLengthCategory, e.ClfishingTechnique, e.CldeepSeaRegulation })
        //            .HasName("IX_CL_UniqueIndex1")
        //            .IsUnique();

        //        entity.Property(e => e.Clid).HasColumnName("CLid");

        //        entity.Property(e => e.Clarea).HasColumnName("CLarea");

        //        entity.Property(e => e.ClcatchCategory).HasColumnName("CLcatchCategory");

        //        entity.Property(e => e.ClcommercialSizeCategory).HasColumnName("CLcommercialSizeCategory");

        //        entity.Property(e => e.ClcommercialSizeCategoryScale).HasColumnName("CLcommercialSizeCategoryScale");

        //        entity.Property(e => e.CldataSourceLandingsValue).HasColumnName("CLdataSourceLandingsValue");

        //        entity.Property(e => e.CldataSourceOfScientificWeight).HasColumnName("CLdataSourceOfScientificWeight");

        //        entity.Property(e => e.CldataTypeOfScientificWeight).HasColumnName("CLdataTypeOfScientificWeight");

        //        entity.Property(e => e.CldeepSeaRegulation).HasColumnName("CLdeepSeaRegulation");

        //        entity.Property(e => e.ClexclusiveEconomicZoneIndicator).HasColumnName("CLexclusiveEconomicZoneIndicator");

        //        entity.Property(e => e.ClexplainDifference).HasColumnName("CLexplainDifference");

        //        entity.Property(e => e.ClfishingTechnique).HasColumnName("CLfishingTechnique");

        //        entity.Property(e => e.ClgsaSubarea).HasColumnName("CLgsaSubarea");

        //        entity.Property(e => e.ClincidentialByCatchMitigationDevice).HasColumnName("CLincidentialByCatchMitigationDevice");

        //        entity.Property(e => e.CljurisdictionArea).HasColumnName("CLjurisdictionArea");

        //        entity.Property(e => e.CllandingCategory).HasColumnName("CLlandingCategory");

        //        entity.Property(e => e.CllandingCountry).HasColumnName("CLlandingCountry");

        //        entity.Property(e => e.CllandingLocation).HasColumnName("CLlandingLocation");

        //        entity.Property(e => e.Clmetier6).HasColumnName("CLmetier6");

        //        entity.Property(e => e.Clmonth).HasColumnName("CLmonth");

        //        entity.Property(e => e.ClnationalFishingActivity).HasColumnName("CLnationalFishingActivity");

        //        entity.Property(e => e.ClnumberOfUniqueVessels).HasColumnName("CLnumberOfUniqueVessels");

        //        entity.Property(e => e.ClofficialWeight).HasColumnName("CLofficialWeight");

        //        entity.Property(e => e.Clquarter).HasColumnName("CLquarter");

        //        entity.Property(e => e.ClrecordType)
        //            .IsRequired()
        //            .HasColumnName("CLrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.ClsamplingScheme).HasColumnName("CLsamplingScheme");

        //        entity.Property(e => e.ClscientificWeight).HasColumnName("CLscientificWeight");

        //        entity.Property(e => e.ClscientificWeightQualitativeBias).HasColumnName("CLscientificWeightQualitativeBias");

        //        entity.Property(e => e.ClscientificWeightRse).HasColumnName("CLscientificWeightRSE");

        //        entity.Property(e => e.ClspeciesCode).HasColumnName("CLspeciesCode");

        //        entity.Property(e => e.ClspeciesFaoCode).HasColumnName("CLspeciesFaoCode");

        //        entity.Property(e => e.ClstatisticalRectangle).HasColumnName("CLstatisticalRectangle");

        //        entity.Property(e => e.CltotalOfficialLandingsValue).HasColumnName("CLtotalOfficialLandingsValue");

        //        entity.Property(e => e.ClvalueRse).HasColumnName("CLvalueRSE");

        //        entity.Property(e => e.ClvesselFlagCountry).HasColumnName("CLvesselFlagCountry");

        //        entity.Property(e => e.ClvesselLengthCategory).HasColumnName("CLvesselLengthCategory");

        //        entity.Property(e => e.Clyear).HasColumnName("CLyear");

        //        entity.Property(e => e.TimeStamp).HasColumnType("datetime");

        //        entity.Property(e => e.UserId)
        //            .IsRequired()
        //            .HasMaxLength(450);
        //    });

        //    modelBuilder.Entity<DeleteLog>(entity =>
        //    {
        //        entity.HasKey(e => e.DeleteLogId);
        //        entity.Property(e => e.DataType)
        //            .IsRequired()
        //            .HasMaxLength(10);

        //        entity.Property(e => e.TimeStamp).HasColumnType("datetime");

        //        entity.Property(e => e.UserId)
        //            .IsRequired()
        //            .HasMaxLength(450);
        //    });

        //    modelBuilder.Entity<DeleteLogCodeField>(entity =>
        //    {
        //        entity.HasKey(e => e.Id);
        //        entity.Property(e => e.FieldName)
        //            .IsRequired()
        //            .HasMaxLength(100);

        //        entity.HasOne(d => d.DeleteLog)
        //            .WithMany(p => p.DeleteLogCodeField)
        //            .HasForeignKey(d => d.DeleteLogId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_DeleteLogCodeField_DeleteLog");
        //    });

        //    modelBuilder.Entity<DeleteLogStringField>(entity =>
        //    {
        //        entity.HasKey(e => e.Id);
        //        entity.Property(e => e.FieldData)
        //            .IsRequired()
        //            .HasMaxLength(100);

        //        entity.Property(e => e.FieldName)
        //            .IsRequired()
        //            .HasMaxLength(100);

        //        entity.HasOne(d => d.DeleteLog)
        //            .WithMany(p => p.DeleteLogStringField)
        //            .HasForeignKey(d => d.DeleteLogId)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_DeleteLogStringField_DeleteLog");
        //    });

        //    modelBuilder.Entity<Design>(entity =>
        //    {
        //        entity.HasKey(e => e.Deid);

        //        entity.HasIndex(e => new { e.DesamplingScheme, e.Deyear, e.DestratumName, e.Dehierarchy })
        //            .HasName("IX_DE_SamHieYeaStra")
        //            .IsUnique();

        //        entity.Property(e => e.Deid).HasColumnName("DEid");

        //        entity.Property(e => e.Dehierarchy).HasColumnName("DEhierarchy");

        //        entity.Property(e => e.DehierarchyCorrect).HasColumnName("DEhierarchyCorrect");

        //        entity.Property(e => e.DerecordType)
        //            .IsRequired()
        //            .HasColumnName("DErecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.DesamplingScheme).HasColumnName("DEsamplingScheme");

        //        entity.Property(e => e.DesamplingSchemeType).HasColumnName("DEsamplingSchemeType");

        //        entity.Property(e => e.DestratumName)
        //            .IsRequired()
        //            .HasColumnName("DEstratumName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Deyear).HasColumnName("DEyear");

        //        entity.Property(e => e.TimeStamp).HasColumnType("datetime");

        //        entity.Property(e => e.UserId)
        //            .IsRequired()
        //            .HasMaxLength(450);
        //    });

        //    modelBuilder.Entity<ExceptionLogs>(entity =>
        //    {
        //        entity.Property(e => e.Type).HasMaxLength(500);
        //    });

        //    modelBuilder.Entity<FishingOperation>(entity =>
        //    {
        //        entity.HasKey(e => e.Foid);

        //        entity.HasIndex(e => e.Ftid);

        //        entity.HasIndex(e => e.Sdid);

        //        entity.HasIndex(e => new { e.Ftid, e.FosequenceNumber, e.Sdid })
        //            .HasName("IX_FO_FTidHalNum")
        //            .IsUnique();

        //        entity.Property(e => e.Foid).HasColumnName("FOid");

        //        entity.Property(e => e.FoaggregationLevel).HasColumnName("FOaggregationLevel");

        //        entity.Property(e => e.Foarea).HasColumnName("FOarea");

        //        entity.Property(e => e.FocatchReg).HasColumnName("FOcatchReg");

        //        entity.Property(e => e.FoclusterName)
        //            .IsRequired()
        //            .HasColumnName("FOclusterName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Foclustering).HasColumnName("FOclustering");

        //        entity.Property(e => e.Foduration).HasColumnName("FOduration");

        //        entity.Property(e => e.FoendDate)
        //            .HasColumnName("FOendDate")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.FoendTime)
        //            .HasColumnName("FOendTime")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.FoexclusiveEconomicZoneIndicator).HasColumnName("FOexclusiveEconomicZoneIndicator");

        //        entity.Property(e => e.FofishingDepth).HasColumnName("FOfishingDepth");

        //        entity.Property(e => e.Fogear).HasColumnName("FOgear");

        //        entity.Property(e => e.FogearDimensions).HasColumnName("FOgearDimensions");

        //        entity.Property(e => e.FogsaSubarea).HasColumnName("FOgsaSubarea");

        //        entity.Property(e => e.FoincidentialByCatchMitigationDevice).HasColumnName("FOincidentialByCatchMitigationDevice");

        //        entity.Property(e => e.FoinclusionProb)
        //            .HasColumnName("FOInclusionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.FoinclusionProbCluster)
        //            .HasColumnName("FOInclusionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.FojurisdictionArea).HasColumnName("FOjurisdictionArea");

        //        entity.Property(e => e.FomeshSize).HasColumnName("FOmeshSize");

        //        entity.Property(e => e.Fometier5).HasColumnName("FOmetier5");

        //        entity.Property(e => e.Fometier6).HasColumnName("FOmetier6");

        //        entity.Property(e => e.FonationalFishingActivity).HasColumnName("FOnationalFishingActivity");

        //        entity.Property(e => e.FonumberSampled)
        //            .HasColumnName("FOnumberSampled")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.FonumberSampledClusters).HasColumnName("FOnumberSampledClusters");

        //        entity.Property(e => e.FonumberTotal).HasColumnName("FOnumberTotal");

        //        entity.Property(e => e.FonumberTotalClusters).HasColumnName("FOnumberTotalClusters");

        //        entity.Property(e => e.FoobservationCode).HasColumnName("FOobservationCode");

        //        entity.Property(e => e.ForeasonNotSampled).HasColumnName("FOreasonNotSampled");

        //        entity.Property(e => e.ForecordType)
        //            .IsRequired()
        //            .HasColumnName("FOrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Forectangle).HasColumnName("FOrectangle");

        //        entity.Property(e => e.Fosampled).HasColumnName("FOsampled");

        //        entity.Property(e => e.Fosampler).HasColumnName("FOsampler");

        //        entity.Property(e => e.FoselectionDevice).HasColumnName("FOselectionDevice");

        //        entity.Property(e => e.FoselectionDeviceMeshSize).HasColumnName("FOselectionDeviceMeshSize");

        //        entity.Property(e => e.FoselectionMethod).HasColumnName("FOselectionMethod");

        //        entity.Property(e => e.FoselectionMethodCluster).HasColumnName("FOselectionMethodCluster");

        //        entity.Property(e => e.FoselectionProb)
        //            .HasColumnName("FOSelectionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.FoselectionProbCluster)
        //            .HasColumnName("FOSelectionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.FosequenceNumber).HasColumnName("FOsequenceNumber");

        //        entity.Property(e => e.FostartDate)
        //            .HasColumnName("FOstartDate")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.FostartLat)
        //            .HasColumnName("FOstartLat")
        //            .HasColumnType("decimal(18, 5)");

        //        entity.Property(e => e.FostartLon)
        //            .HasColumnName("FOstartLon")
        //            .HasColumnType("decimal(18, 5)");

        //        entity.Property(e => e.FostartTime)
        //            .HasColumnName("FOstartTime")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.FostopLat)
        //            .HasColumnName("FOstopLat")
        //            .HasColumnType("decimal(18, 5)");

        //        entity.Property(e => e.FostopLon)
        //            .HasColumnName("FOstopLon")
        //            .HasColumnType("decimal(18, 5)");

        //        entity.Property(e => e.Fostratification).HasColumnName("FOstratification");

        //        entity.Property(e => e.FostratumName)
        //            .IsRequired()
        //            .HasColumnName("FOstratumName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.FotargetSpecies).HasColumnName("FOtargetSpecies");

        //        entity.Property(e => e.FounitName)
        //            .HasColumnName("FOunitName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Fovalidity).HasColumnName("FOvalidity");

        //        entity.Property(e => e.FowaterDepth).HasColumnName("FOwaterDepth");

        //        entity.Property(e => e.Ftid).HasColumnName("FTid");

        //        entity.Property(e => e.Sdid).HasColumnName("SDid");

        //        entity.HasOne(d => d.Ft)
        //            .WithMany(p => p.FishingOperation)
        //            .HasForeignKey(d => d.Ftid)
        //            .HasConstraintName("FK_FishingOperation_FishingTrip");

        //        entity.HasOne(d => d.Sd)
        //            .WithMany(p => p.FishingOperation)
        //            .HasForeignKey(d => d.Sdid)
        //            .HasConstraintName("FK_FishingOperation_SamplingDetails");
        //    });

        //    modelBuilder.Entity<FishingTrip>(entity =>
        //    {
        //        entity.HasKey(e => e.Ftid);

        //        entity.HasIndex(e => e.Foid);

        //        entity.HasIndex(e => e.Osid);

        //        entity.HasIndex(e => e.Sdid);

        //        entity.HasIndex(e => e.Teid);

        //        entity.HasIndex(e => e.Vdid);

        //        entity.HasIndex(e => e.Vsid);

        //        entity.HasIndex(e => new { e.FtsequenceNumber, e.FtarrivalLocation, e.FtarrivalDate, e.Osid, e.Vsid, e.Sdid, e.Foid, e.Teid })
        //            .HasName("IX_FT_NacArlArd")
        //            .IsUnique();

        //        entity.Property(e => e.Ftid).HasColumnName("FTid");

        //        entity.Property(e => e.Foid).HasColumnName("FOid");

        //        entity.Property(e => e.FtarrivalDate)
        //            .HasColumnName("FTarrivalDate")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.FtarrivalLocation).HasColumnName("FTarrivalLocation");

        //        entity.Property(e => e.FtarrivalTime)
        //            .HasColumnName("FTarrivalTime")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.FtclusterName)
        //            .IsRequired()
        //            .HasColumnName("FTclusterName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Ftclustering).HasColumnName("FTclustering");

        //        entity.Property(e => e.FtdepartureDate)
        //            .HasColumnName("FTdepartureDate")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.FtdepartureLocation).HasColumnName("FTdepartureLocation");

        //        entity.Property(e => e.FtdepartureTime)
        //            .HasColumnName("FTdepartureTime")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.FtencryptedVesselCode)
        //            .IsRequired()
        //            .HasColumnName("FTencryptedVesselCode")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.FtinclusionProb)
        //            .HasColumnName("FTinclusionProb")
        //            .HasColumnType("decimal(18, 10)");

        //        entity.Property(e => e.FtinclusionProbCluster)
        //            .HasColumnName("FTinclusionProbCluster")
        //            .HasColumnType("decimal(18, 10)");

        //        entity.Property(e => e.FtnumberOfHauls).HasColumnName("FTnumberOfHauls");

        //        entity.Property(e => e.FtnumberSampled).HasColumnName("FTnumberSampled");

        //        entity.Property(e => e.FtnumberSampledClusters).HasColumnName("FTnumberSampledClusters");

        //        entity.Property(e => e.FtnumberTotal).HasColumnName("FTnumberTotal");

        //        entity.Property(e => e.FtnumberTotalClusters).HasColumnName("FTnumberTotalClusters");

        //        entity.Property(e => e.FtreasonNotSampled).HasColumnName("FTreasonNotSampled");

        //        entity.Property(e => e.FtrecordType)
        //            .IsRequired()
        //            .HasColumnName("FTrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Ftsampled).HasColumnName("FTsampled");

        //        entity.Property(e => e.Ftsampler).HasColumnName("FTsampler");

        //        entity.Property(e => e.FtsamplingType).HasColumnName("FTsamplingType");

        //        entity.Property(e => e.FtselectionMethod).HasColumnName("FTselectionMethod");

        //        entity.Property(e => e.FtselectionMethodCluster).HasColumnName("FTselectionMethodCluster");

        //        entity.Property(e => e.FtselectionProb)
        //            .HasColumnName("FTselectionProb")
        //            .HasColumnType("decimal(18, 10)");

        //        entity.Property(e => e.FtselectionProbCluster)
        //            .HasColumnName("FTselectionProbCluster")
        //            .HasColumnType("decimal(18, 10)");

        //        entity.Property(e => e.FtsequenceNumber)
        //            .IsRequired()
        //            .HasColumnName("FTsequenceNumber")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Ftstratification).HasColumnName("FTstratification");

        //        entity.Property(e => e.FtstratumName)
        //            .IsRequired()
        //            .HasColumnName("FTstratumName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.FtunitName)
        //            .IsRequired()
        //            .HasColumnName("FTunitName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Osid).HasColumnName("OSid");

        //        entity.Property(e => e.Sdid).HasColumnName("SDid");

        //        entity.Property(e => e.Teid).HasColumnName("TEid");

        //        entity.Property(e => e.Vdid).HasColumnName("VDid");

        //        entity.Property(e => e.Vsid).HasColumnName("VSid");

        //        entity.HasOne(d => d.Fo)
        //            .WithMany(p => p.FishingTrip)
        //            .HasForeignKey(d => d.Foid)
        //            .HasConstraintName("FK_FishingTrip_FishingOperation");

        //        entity.HasOne(d => d.Os)
        //            .WithMany(p => p.FishingTrip)
        //            .HasForeignKey(d => d.Osid)
        //            .HasConstraintName("FK_FishingTrip_OnshoreEvent");

        //        entity.HasOne(d => d.Sd)
        //            .WithMany(p => p.FishingTrip)
        //            .HasForeignKey(d => d.Sdid)
        //            .HasConstraintName("FK_FishingTrip_SamplingDetails");

        //        entity.HasOne(d => d.Te)
        //            .WithMany(p => p.FishingTrip)
        //            .HasForeignKey(d => d.Teid)
        //            .HasConstraintName("FK_FishingTrip_TemporalEvent");

        //        entity.HasOne(d => d.Vd)
        //            .WithMany(p => p.FishingTrip)
        //            .HasForeignKey(d => d.Vdid)
        //            .HasConstraintName("FK_FishingTrip_VesselDetails");

        //        entity.HasOne(d => d.Vs)
        //            .WithMany(p => p.FishingTrip)
        //            .HasForeignKey(d => d.Vsid)
        //            .HasConstraintName("FK_FishingTrip_VesselSelection");
        //    });

        //    modelBuilder.Entity<FrequencyMeasure>(entity =>
        //    {
        //        entity.HasKey(e => e.Fmid);

        //        entity.HasIndex(e => e.Said);

        //        entity.HasIndex(e => new { e.Said, e.Fmclass })
        //            .HasName("IX_FM_SAidClstype")
        //            .IsUnique();

        //        entity.Property(e => e.Fmid).HasColumnName("FMid");

        //        entity.Property(e => e.Fmaccuracy).HasColumnName("FMaccuracy");

        //        entity.Property(e => e.FmaddGrpMeasurement)
        //            .HasColumnName("FMaddGrpMeasurement")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.FmaddGrpMeasurementType).HasColumnName("FMaddGrpMeasurementType");

        //        entity.Property(e => e.Fmclass).HasColumnName("FMclass");

        //        entity.Property(e => e.FmmeasurementEquipment).HasColumnName("FMmeasurementEquipment");

        //        entity.Property(e => e.FmnumberAtUnit)
        //            .HasColumnName("FMnumberAtUnit")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.FmrecordType)
        //            .IsRequired()
        //            .HasColumnName("FMrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Fmsampler).HasColumnName("FMsampler");

        //        entity.Property(e => e.Fmtype).HasColumnName("FMtype");

        //        entity.Property(e => e.Said).HasColumnName("SAid");

        //        entity.HasOne(d => d.Sa)
        //            .WithMany(p => p.FrequencyMeasure)
        //            .HasForeignKey(d => d.Said)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_FrequencyMeasure_Sample");
        //    });

        //    //modelBuilder.Entity<ImportQueue>(entity =>
        //    //{
        //    //    entity.HasIndex(e => e.AddedAt);

        //    //    entity.HasIndex(e => e.Hierarchy);

        //    //    entity.HasIndex(e => e.Success);

        //    //    entity.HasIndex(e => e.UserId);

        //    //    entity.Property(e => e.AddedAt).HasColumnType("datetime");

        //    //    entity.Property(e => e.Email)
        //    //        .IsRequired()
        //    //        .HasMaxLength(500);

        //    //    entity.Property(e => e.FilePath).IsRequired();

        //    //    entity.Property(e => e.FirstName).HasMaxLength(500);

        //    //    entity.Property(e => e.Hierarchy)
        //    //        .IsRequired()
        //    //        .HasMaxLength(50);

        //    //    entity.Property(e => e.LastName).HasMaxLength(500);

        //    //    entity.Property(e => e.ProcessingEndedAt).HasColumnType("datetime");

        //    //    entity.Property(e => e.ProcessingStartedAt).HasColumnType("datetime");

        //    //    entity.Property(e => e.UploadedFileName)
        //    //        .IsRequired()
        //    //        .HasMaxLength(500);

        //    //    entity.Property(e => e.UserId).IsRequired();
        //    //});

        //    modelBuilder.Entity<LandingEvent>(entity =>
        //    {
        //        entity.HasKey(e => e.Leid);

        //        entity.HasIndex(e => e.Foid);

        //        entity.HasIndex(e => e.Ftid);

        //        entity.HasIndex(e => e.Osid);

        //        entity.HasIndex(e => e.Said);

        //        entity.HasIndex(e => e.Ssid);

        //        entity.HasIndex(e => e.Teid);

        //        entity.HasIndex(e => e.Vdid);

        //        entity.HasIndex(e => e.Vsid);

        //        entity.HasIndex(e => new { e.Osid, e.Ftid, e.Vsid, e.Teid, e.Said, e.Vdid, e.Foid, e.Ssid, e.LesequenceNumber })
        //            .HasName("IX_LE_OSidFTidVSidTEidSAidVDidFOidSSidSeqn")
        //            .IsUnique();

        //        entity.Property(e => e.Leid).HasColumnName("LEid");

        //        entity.Property(e => e.Foid).HasColumnName("FOid");

        //        entity.Property(e => e.Ftid).HasColumnName("FTid");

        //        entity.Property(e => e.Learea).HasColumnName("LEarea");

        //        entity.Property(e => e.LecatchReg).HasColumnName("LEcatchReg");

        //        entity.Property(e => e.LeclusterName)
        //            .IsRequired()
        //            .HasColumnName("LEclusterName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Leclustering).HasColumnName("LEclustering");

        //        entity.Property(e => e.Lecountry).HasColumnName("LEcountry");

        //        entity.Property(e => e.Ledate)
        //            .HasColumnName("LEdate")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.LeencryptedVesselCode)
        //            .HasColumnName("LEencryptedVesselCode")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.LeexclusiveEconomicZoneIndicator).HasColumnName("LEexclusiveEconomicZoneIndicator");

        //        entity.Property(e => e.LefullTripAvailable).HasColumnName("LEfullTripAvailable");

        //        entity.Property(e => e.Legear).HasColumnName("LEgear");

        //        entity.Property(e => e.LegearDimensions).HasColumnName("LEgearDimensions");

        //        entity.Property(e => e.LegsaSubarea).HasColumnName("LEgsaSubarea");

        //        entity.Property(e => e.LehaulNumber).HasColumnName("LEhaulNumber");

        //        entity.Property(e => e.LeinclusionProb)
        //            .HasColumnName("LEInclusionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.LeinclusionProbCluster)
        //            .HasColumnName("LEInclusionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.LejurisdictionArea).HasColumnName("LEjurisdictionArea");

        //        entity.Property(e => e.Lelocation).HasColumnName("LElocation");

        //        entity.Property(e => e.LelocationType).HasColumnName("LElocationType");

        //        entity.Property(e => e.LemeshSize).HasColumnName("LEmeshSize");

        //        entity.Property(e => e.Lemetier5).HasColumnName("LEmetier5");

        //        entity.Property(e => e.Lemetier6).HasColumnName("LEmetier6");

        //        entity.Property(e => e.LemitigationDevice).HasColumnName("LEmitigationDevice");

        //        entity.Property(e => e.LemixedTrip).HasColumnName("LEmixedTrip");

        //        entity.Property(e => e.LenationalFishingActivity).HasColumnName("LEnationalFishingActivity");

        //        entity.Property(e => e.LenumberSampled).HasColumnName("LEnumberSampled");

        //        entity.Property(e => e.LenumberSampledClusters).HasColumnName("LEnumberSampledClusters");

        //        entity.Property(e => e.LenumberTotal).HasColumnName("LEnumberTotal");

        //        entity.Property(e => e.LenumberTotalClusters).HasColumnName("LEnumberTotalClusters");

        //        entity.Property(e => e.LereasonNotSampled).HasColumnName("LEreasonNotSampled");

        //        entity.Property(e => e.LerecordType)
        //            .IsRequired()
        //            .HasColumnName("LErecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Lerectangle).HasColumnName("LErectangle");

        //        entity.Property(e => e.Lesampled).HasColumnName("LEsampled");

        //        entity.Property(e => e.Lesampler).HasColumnName("LEsampler");

        //        entity.Property(e => e.LeselectionDevice).HasColumnName("LEselectionDevice");

        //        entity.Property(e => e.LeselectionDeviceMeshSize).HasColumnName("LEselectionDeviceMeshSize");

        //        entity.Property(e => e.LeselectionMethod).HasColumnName("LEselectionMethod");

        //        entity.Property(e => e.LeselectionMethodCluster).HasColumnName("LEselectionMethodCluster");

        //        entity.Property(e => e.LeselectionProb)
        //            .HasColumnName("LESelectionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.LeselectionProbCluster)
        //            .HasColumnName("LESelectionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.LesequenceNumber).HasColumnName("LEsequenceNumber");

        //        entity.Property(e => e.Lestratification).HasColumnName("LEstratification");

        //        entity.Property(e => e.LestratumName)
        //            .IsRequired()
        //            .HasColumnName("LEstratumName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.LetargetSpecies).HasColumnName("LEtargetSpecies");

        //        entity.Property(e => e.Letime)
        //            .HasColumnName("LEtime")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.LeunitName)
        //            .IsRequired()
        //            .HasColumnName("LEunitName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Osid).HasColumnName("OSid");

        //        entity.Property(e => e.Said).HasColumnName("SAid");

        //        entity.Property(e => e.Ssid).HasColumnName("SSid");

        //        entity.Property(e => e.Teid).HasColumnName("TEid");

        //        entity.Property(e => e.Vdid).HasColumnName("VDid");

        //        entity.Property(e => e.Vsid).HasColumnName("VSid");

        //        entity.HasOne(d => d.Fo)
        //            .WithMany(p => p.LandingEvent)
        //            .HasForeignKey(d => d.Foid)
        //            .HasConstraintName("FK_LandingEvent_FishingOperation");

        //        entity.HasOne(d => d.Ft)
        //            .WithMany(p => p.LandingEvent)
        //            .HasForeignKey(d => d.Ftid)
        //            .HasConstraintName("FK_LandingEvent_FishingTrip");

        //        entity.HasOne(d => d.Os)
        //            .WithMany(p => p.LandingEvent)
        //            .HasForeignKey(d => d.Osid)
        //            .HasConstraintName("FK_LandingEvent_OnshoreEvent");

        //        entity.HasOne(d => d.Sa)
        //            .WithMany(p => p.LandingEvent)
        //            .HasForeignKey(d => d.Said)
        //            .HasConstraintName("FK_LandingEvent_Sample");

        //        entity.HasOne(d => d.Ss)
        //            .WithMany(p => p.LandingEvent)
        //            .HasForeignKey(d => d.Ssid)
        //            .HasConstraintName("FK_LandingEvent_SpeciesSelection");

        //        entity.HasOne(d => d.Te)
        //            .WithMany(p => p.LandingEvent)
        //            .HasForeignKey(d => d.Teid)
        //            .HasConstraintName("FK_LandingEvent_TemporalEvent");

        //        entity.HasOne(d => d.Vd)
        //            .WithMany(p => p.LandingEvent)
        //            .HasForeignKey(d => d.Vdid)
        //            .HasConstraintName("FK_LandingEvent_VesselDetails");

        //        entity.HasOne(d => d.Vs)
        //            .WithMany(p => p.LandingEvent)
        //            .HasForeignKey(d => d.Vsid)
        //            .HasConstraintName("FK_LandingEvent_VesselSelection");
        //    });

        //    modelBuilder.Entity<Location>(entity =>
        //    {
        //        entity.HasKey(e => e.Loid);

        //        entity.HasIndex(e => e.Sdid);

        //        entity.Property(e => e.Loid).HasColumnName("LOid");

        //        entity.Property(e => e.LoclusterName)
        //            .IsRequired()
        //            .HasColumnName("LOclusterName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Loclustering).HasColumnName("LOclustering");

        //        entity.Property(e => e.LoinclusionProb)
        //            .HasColumnName("LOinclusionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.LoinclusionProbCluster)
        //            .HasColumnName("LOInclusionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.Lolocation)
        //            .IsRequired()
        //            .HasColumnName("LOlocation")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Lolocode).HasColumnName("LOlocode");

        //        entity.Property(e => e.LonumberSampled).HasColumnName("LOnumberSampled");

        //        entity.Property(e => e.LonumberSampledClusters).HasColumnName("LOnumberSampledClusters");

        //        entity.Property(e => e.LonumberTotal).HasColumnName("LOnumberTotal");

        //        entity.Property(e => e.LonumberTotalClusters).HasColumnName("LOnumberTotalClusters");

        //        entity.Property(e => e.LoreasonNotSampled).HasColumnName("LOreasonNotSampled");

        //        entity.Property(e => e.LorecordType)
        //            .IsRequired()
        //            .HasColumnName("LOrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Losampled).HasColumnName("LOsampled");

        //        entity.Property(e => e.Losampler).HasColumnName("LOsampler");

        //        entity.Property(e => e.LoselectionMethod).HasColumnName("LOselectionMethod");

        //        entity.Property(e => e.LoselectionMethodCluster).HasColumnName("LOselectionMethodCluster");

        //        entity.Property(e => e.LoselectionProb)
        //            .HasColumnName("LOselectionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.LoselectionProbCluster)
        //            .HasColumnName("LOSelectionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.LosequenceNumber).HasColumnName("LOsequenceNumber");

        //        entity.Property(e => e.Lostratification).HasColumnName("LOstratification");

        //        entity.Property(e => e.LostratumName)
        //            .IsRequired()
        //            .HasColumnName("LOstratumName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.LounitName)
        //            .IsRequired()
        //            .HasColumnName("LOunitName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Sdid).HasColumnName("SDid");

        //        entity.HasOne(d => d.Sd)
        //            .WithMany(p => p.Location)
        //            .HasForeignKey(d => d.Sdid)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_Location_SamplingDetails");
        //    });

        //    modelBuilder.Entity<OnshoreEvent>(entity =>
        //    {
        //        entity.HasKey(e => e.Osid);

        //        entity.HasIndex(e => new { e.OssequenceNumber, e.Sdid })
        //            .HasName("IX_OS_SDidSequenceNumber")
        //            .IsUnique();

        //        entity.HasIndex(e => new { e.Sdid, e.OsnationalLocationName, e.Oslocode, e.OssamplingDate, e.OssamplingTime })
        //            .HasName("IX_OS_SDidNalnLocSamdSamt")
        //            .IsUnique();

        //        entity.Property(e => e.Osid).HasColumnName("OSid");

        //        entity.Property(e => e.OsclusterName)
        //            .IsRequired()
        //            .HasColumnName("OSclusterName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Osclustering).HasColumnName("OSclustering");

        //        entity.Property(e => e.OsinclusionProb)
        //            .HasColumnName("OSinclusionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.OsinclusionProbCluster)
        //            .HasColumnName("OSinclusionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.OslocationType).HasColumnName("OSlocationType");

        //        entity.Property(e => e.Oslocode).HasColumnName("OSlocode");

        //        entity.Property(e => e.OsnationalLocationName)
        //            .IsRequired()
        //            .HasColumnName("OSnationalLocationName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.OsnumberSampled).HasColumnName("OSnumberSampled");

        //        entity.Property(e => e.OsnumberSampledClusters).HasColumnName("OSnumberSampledClusters");

        //        entity.Property(e => e.OsnumberTotal).HasColumnName("OSnumberTotal");

        //        entity.Property(e => e.OsnumberTotalClusters).HasColumnName("OSnumberTotalClusters");

        //        entity.Property(e => e.OsreasonNotSampled).HasColumnName("OSreasonNotSampled");

        //        entity.Property(e => e.OsrecordType)
        //            .IsRequired()
        //            .HasColumnName("OSrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Ossampled).HasColumnName("OSsampled");

        //        entity.Property(e => e.Ossampler).HasColumnName("OSsampler");

        //        entity.Property(e => e.OssamplingDate)
        //            .HasColumnName("OSsamplingDate")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.OssamplingTime)
        //            .HasColumnName("OSsamplingTime")
        //            .HasColumnType("datetime");

        //        entity.Property(e => e.OsselectionMethod).HasColumnName("OSselectionMethod");

        //        entity.Property(e => e.OsselectionMethodCluster).HasColumnName("OSselectionMethodCluster");

        //        entity.Property(e => e.OsselectionProb)
        //            .HasColumnName("OSselectionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.OsselectionProbCluster)
        //            .HasColumnName("OSselectionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.OssequenceNumber).HasColumnName("OSsequenceNumber");

        //        entity.Property(e => e.Osstratification).HasColumnName("OSstratification");

        //        entity.Property(e => e.OsstratumName)
        //            .IsRequired()
        //            .HasColumnName("OSstratumName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.OstimeUnit).HasColumnName("OStimeUnit");

        //        entity.Property(e => e.OstimeValue)
        //            .HasColumnName("OStimeValue")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.OsunitName)
        //            .HasColumnName("OSunitName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Sdid).HasColumnName("SDid");

        //        entity.HasOne(d => d.Sd)
        //            .WithMany(p => p.OnshoreEvent)
        //            .HasForeignKey(d => d.Sdid)
        //            .HasConstraintName("FK_OnshoreEvent_SamplingDetails");
        //    });

        //    modelBuilder.Entity<RSpeciesAreaQuarter>(entity =>
        //    {
        //        entity.ToTable("R_SpeciesAreaQuarter");

        //        entity.Property(e => e.Description).HasMaxLength(255);

        //        entity.HasOne(d => d.AreaNavigation)
        //            .WithMany(p => p.RSpeciesAreaQuarterAreaNavigation)
        //            .HasForeignKey(d => d.Area)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.QuarterNavigation)
        //            .WithMany(p => p.RSpeciesAreaQuarterQuarterNavigation)
        //            .HasForeignKey(d => d.Quarter)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.SpeciesNavigation)
        //            .WithMany(p => p.RSpeciesAreaQuarterSpeciesNavigation)
        //            .HasForeignKey(d => d.Species)
        //            .OnDelete(DeleteBehavior.ClientSetNull);

        //        entity.HasOne(d => d.StockNavigation)
        //            .WithMany(p => p.RSpeciesAreaQuarterStockNavigation)
        //            .HasForeignKey(d => d.Stock)
        //            .OnDelete(DeleteBehavior.ClientSetNull);
        //    });

        //    modelBuilder.Entity<Sample>(entity =>
        //    {
        //        entity.HasKey(e => e.Said);

        //        entity.HasIndex(e => e.Leid);

        //        entity.HasIndex(e => e.SaparentId);

        //        entity.HasIndex(e => e.Ssid);

        //        entity.HasIndex(e => new { e.SasequenceNumber, e.Ssid })
        //            .HasName("IX_SA_SAsequenceNumber_SSID")
        //            .IsUnique();

        //        entity.HasIndex(e => new { e.Ssid, e.SasequenceNumber, e.SaspeciesCode, e.SaspeciesCodeFao, e.Sapresentation, e.SacatchCategory, e.SalandingCategory, e.SacommSizeCatScale, e.SacommSizeCat, e.Sasex })
        //            .HasName("IX_SeqnumbSpeFaoPreCaCatLaCatComcatComcatScSex")
        //            .IsUnique();

        //        entity.Property(e => e.Said).HasColumnName("SAid");

        //        entity.Property(e => e.Leid).HasColumnName("LEid");

        //        entity.Property(e => e.Saarea).HasColumnName("SAarea");

        //        entity.Property(e => e.SacatchCategory).HasColumnName("SAcatchCategory");

        //        entity.Property(e => e.SacommSizeCat).HasColumnName("SAcommSizeCat");

        //        entity.Property(e => e.SacommSizeCatScale).HasColumnName("SAcommSizeCatScale");

        //        entity.Property(e => e.SaconversionFactorMesLive)
        //            .HasColumnName("SAconversionFactorMesLive")
        //            .HasColumnType("decimal(18, 5)");

        //        entity.Property(e => e.SaexclusiveEconomicZoneIndicator).HasColumnName("SAexclusiveEconomicZoneIndicator");

        //        entity.Property(e => e.Sagear).HasColumnName("SAgear");

        //        entity.Property(e => e.SagsaSubarea).HasColumnName("SAgsaSubarea");

        //        entity.Property(e => e.SainclusionProb)
        //            .HasColumnName("SAinclusionProb")
        //            .HasColumnType("decimal(18, 10)");

        //        entity.Property(e => e.SajurisdictionArea).HasColumnName("SAjurisdictionArea");

        //        entity.Property(e => e.SalandingCategory).HasColumnName("SAlandingCategory");

        //        entity.Property(e => e.SalowerHierarchy).HasColumnName("SAlowerHierarchy");

        //        entity.Property(e => e.SameshSize).HasColumnName("SAmeshSize");

        //        entity.Property(e => e.Sametier5).HasColumnName("SAmetier5");

        //        entity.Property(e => e.Sametier6).HasColumnName("SAmetier6");

        //        entity.Property(e => e.SanationalFishingActivity).HasColumnName("SAnationalFishingActivity");

        //        entity.Property(e => e.SanumberSampled)
        //            .HasColumnName("SAnumberSampled")
        //            .HasColumnType("decimal(18, 10)");

        //        entity.Property(e => e.SanumberTotal)
        //            .HasColumnName("SAnumberTotal")
        //            .HasColumnType("decimal(18, 10)");

        //        entity.Property(e => e.SaparentId).HasColumnName("SAparentID");

        //        entity.Property(e => e.SaparentSequenceNumber).HasColumnName("SAparentSequenceNumber");

        //        entity.Property(e => e.Sapresentation).HasColumnName("SApresentation");

        //        entity.Property(e => e.SareasonNotSampledBv).HasColumnName("SAreasonNotSampledBV");

        //        entity.Property(e => e.SareasonNotSampledFm).HasColumnName("SAreasonNotSampledFM");

        //        entity.Property(e => e.SarecordType)
        //            .IsRequired()
        //            .HasColumnName("SArecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Sarectangle).HasColumnName("SArectangle");

        //        entity.Property(e => e.SasampleWeightLive).HasColumnName("SAsampleWeightLive");

        //        entity.Property(e => e.SasampleWeightMeasured).HasColumnName("SAsampleWeightMeasured");

        //        entity.Property(e => e.Sasampled).HasColumnName("SAsampled");

        //        entity.Property(e => e.Sasampler).HasColumnName("SAsampler");

        //        entity.Property(e => e.SaselectionDevice).HasColumnName("SAselectionDevice");

        //        entity.Property(e => e.SaselectionDeviceMeshSize).HasColumnName("SAselectionDeviceMeshSize");

        //        entity.Property(e => e.SaselectionMethod).HasColumnName("SAselectionMethod");

        //        entity.Property(e => e.SaselectionProb)
        //            .HasColumnName("SAselectionProb")
        //            .HasColumnType("decimal(18, 10)");

        //        entity.Property(e => e.SasequenceNumber).HasColumnName("SAsequenceNumber");

        //        entity.Property(e => e.Sasex).HasColumnName("SAsex");

        //        entity.Property(e => e.SaspeciesCode).HasColumnName("SAspeciesCode");

        //        entity.Property(e => e.SaspeciesCodeFao).HasColumnName("SAspeciesCodeFAO");

        //        entity.Property(e => e.SaspecimensState).HasColumnName("SAspecimensState");

        //        entity.Property(e => e.Sastratification).HasColumnName("SAstratification");

        //        entity.Property(e => e.SastratumName)
        //            .IsRequired()
        //            .HasColumnName("SAstratumName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.SatotalWeightLive).HasColumnName("SAtotalWeightLive");

        //        entity.Property(e => e.SatotalWeightMeasured).HasColumnName("SAtotalWeightMeasured");

        //        entity.Property(e => e.SaunitName)
        //            .IsRequired()
        //            .HasColumnName("SAunitName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.SaunitType).HasColumnName("SAunitType");

        //        entity.Property(e => e.Ssid).HasColumnName("SSid");

        //        entity.HasOne(d => d.Le)
        //            .WithMany(p => p.Sample)
        //            .HasForeignKey(d => d.Leid)
        //            .HasConstraintName("FK_Sample_LandingEvent");

        //        entity.HasOne(d => d.Saparent)
        //            .WithMany(p => p.InverseSaparent)
        //            .HasForeignKey(d => d.SaparentId)
        //            .HasConstraintName("FK_Sample_Sample");

        //        entity.HasOne(d => d.Ss)
        //            .WithMany(p => p.Sample)
        //            .HasForeignKey(d => d.Ssid)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_Sample_SpeciesSelection");
        //    });

        //    modelBuilder.Entity<SamplingDetails>(entity =>
        //    {
        //        entity.HasKey(e => e.Sdid);

        //        entity.HasIndex(e => e.Sdid)
        //            .HasName("IX_SamplingDetails_DEid");

        //        entity.HasIndex(e => new { e.Deid, e.Sdcountry, e.Sdinstitution })
        //            .HasName("IX_SD_DEidCouIns")
        //            .IsUnique();

        //        entity.Property(e => e.Sdid).HasColumnName("SDid");

        //        entity.Property(e => e.Deid).HasColumnName("DEid");

        //        entity.Property(e => e.Sdcountry).HasColumnName("SDcountry");

        //        entity.Property(e => e.Sdinstitution).HasColumnName("SDinstitution");

        //        entity.Property(e => e.SdrecordType)
        //            .IsRequired()
        //            .HasColumnName("SDrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.TimeStamp).HasColumnType("datetime");

        //        entity.Property(e => e.UserId)
        //            .IsRequired()
        //            .HasMaxLength(450);

        //        entity.HasOne(d => d.De)
        //            .WithMany(p => p.SamplingDetails)
        //            .HasForeignKey(d => d.Deid)
        //            .HasConstraintName("FK_SamplingDetails_Design");
        //    });

        //    modelBuilder.Entity<SpeciesList>(entity =>
        //    {
        //        entity.HasKey(e => e.Slid)
        //            .HasName("PK__SpeciesL__A43C4907BA7226F8");

        //        entity.HasIndex(e => new { e.Slcountry, e.SlspeciesListName, e.Slyear, e.SlcatchFraction, e.SlcommercialTaxon, e.SlspeciesCode })
        //            .HasName("IX_Cou_Spe_Yea_Fra_Tax_SpeCod")
        //            .IsUnique();

        //        entity.Property(e => e.Slid).HasColumnName("SLid");

        //        entity.Property(e => e.SlcatchFraction).HasColumnName("SLcatchFraction");

        //        entity.Property(e => e.SlcommercialTaxon).HasColumnName("SLcommercialTaxon");

        //        entity.Property(e => e.Slcountry).HasColumnName("SLcountry");

        //        entity.Property(e => e.Slinstitute).HasColumnName("SLinstitute");

        //        entity.Property(e => e.SlrecordType)
        //            .IsRequired()
        //            .HasColumnName("SLrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.SlspeciesCode).HasColumnName("SLspeciesCode");

        //        entity.Property(e => e.SlspeciesListName)
        //            .IsRequired()
        //            .HasColumnName("SLspeciesListName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Slyear).HasColumnName("SLyear");

        //        entity.Property(e => e.TimeStamp).HasColumnType("datetime");

        //        entity.Property(e => e.UserId)
        //            .IsRequired()
        //            .HasMaxLength(450);
        //    });

        //    modelBuilder.Entity<SpeciesSelection>(entity =>
        //    {
        //        entity.HasKey(e => e.Ssid);

        //        entity.HasIndex(e => e.Foid);

        //        entity.HasIndex(e => e.Ftid);

        //        entity.HasIndex(e => e.Leid);

        //        entity.HasIndex(e => e.Osid);

        //        entity.HasIndex(e => e.Slid);

        //        entity.HasIndex(e => e.Teid);

        //        entity.HasIndex(e => new { e.Leid, e.Foid, e.Teid, e.Ftid, e.Osid, e.SsobservationActivityType, e.SscatchFraction, e.SsobservationType })
        //            .HasName("IX_SS_LEiFOidcaf")
        //            .IsUnique();

        //        entity.Property(e => e.Ssid).HasColumnName("SSid");

        //        entity.Property(e => e.Foid).HasColumnName("FOid");

        //        entity.Property(e => e.Ftid).HasColumnName("FTid");

        //        entity.Property(e => e.Leid).HasColumnName("LEid");

        //        entity.Property(e => e.Osid).HasColumnName("OSid");

        //        entity.Property(e => e.Slid).HasColumnName("SLid");

        //        entity.Property(e => e.SscatchFraction).HasColumnName("SScatchFraction");

        //        entity.Property(e => e.SsclusterName)
        //            .IsRequired()
        //            .HasColumnName("SSclusterName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Ssclustering).HasColumnName("SSclustering");

        //        entity.Property(e => e.SsinclusionProb).HasColumnName("SSinclusionProb");

        //        entity.Property(e => e.SsinclusionProbCluster)
        //            .HasColumnName("SSinclusionProbCluster")
        //            .HasColumnType("decimal(18, 10)");

        //        entity.Property(e => e.SsnumberSampled).HasColumnName("SSnumberSampled");

        //        entity.Property(e => e.SsnumberSampledClusters).HasColumnName("SSnumberSampledClusters");

        //        entity.Property(e => e.SsnumberTotal).HasColumnName("SSnumberTotal");

        //        entity.Property(e => e.SsnumberTotalClusters).HasColumnName("SSnumberTotalClusters");

        //        entity.Property(e => e.SsobservationActivityType).HasColumnName("SSObservationActivityType");

        //        entity.Property(e => e.SsobservationType).HasColumnName("SSObservationType");

        //        entity.Property(e => e.SsreasonNotSampled).HasColumnName("SSreasonNotSampled");

        //        entity.Property(e => e.SsrecordType)
        //            .IsRequired()
        //            .HasColumnName("SSrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Sssampled).HasColumnName("SSsampled");

        //        entity.Property(e => e.Sssampler).HasColumnName("SSsampler");

        //        entity.Property(e => e.SsselectionMethod).HasColumnName("SSselectionMethod");

        //        entity.Property(e => e.SsselectionMethodCluster).HasColumnName("SSselectionMethodCluster");

        //        entity.Property(e => e.SsselectionProb).HasColumnName("SSselectionProb");

        //        entity.Property(e => e.SsselectionProbCluster)
        //            .HasColumnName("SSselectionProbCluster")
        //            .HasColumnType("decimal(18, 10)");

        //        entity.Property(e => e.SssequenceNumber).HasColumnName("SSsequenceNumber");

        //        entity.Property(e => e.SsspeciesListName)
        //            .IsRequired()
        //            .HasColumnName("SSspeciesListName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Ssstratification).HasColumnName("SSstratification");

        //        entity.Property(e => e.SsstratumName)
        //            .IsRequired()
        //            .HasColumnName("SSstratumName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.SsunitName)
        //            .IsRequired()
        //            .HasColumnName("SSunitName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.SsuseForCalculateZero).HasColumnName("SSuseForCalculateZero");

        //        entity.Property(e => e.Teid).HasColumnName("TEid");

        //        entity.HasOne(d => d.Fo)
        //            .WithMany(p => p.SpeciesSelection)
        //            .HasForeignKey(d => d.Foid)
        //            .HasConstraintName("FK_SpeciesSelection_FishingOperation");

        //        entity.HasOne(d => d.Ft)
        //            .WithMany(p => p.SpeciesSelection)
        //            .HasForeignKey(d => d.Ftid)
        //            .HasConstraintName("FK_SpeciesSelection_FishingTrip");

        //        entity.HasOne(d => d.Le)
        //            .WithMany(p => p.SpeciesSelection)
        //            .HasForeignKey(d => d.Leid)
        //            .HasConstraintName("FK_SpeciesSelection_LandingEvent");

        //        entity.HasOne(d => d.Os)
        //            .WithMany(p => p.SpeciesSelection)
        //            .HasForeignKey(d => d.Osid)
        //            .HasConstraintName("FK_SpeciesSelection_OnshoreEvent");

        //        entity.HasOne(d => d.Sl)
        //            .WithMany(p => p.SpeciesSelection)
        //            .HasForeignKey(d => d.Slid)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_SpeciesSelection_SpeciesList");

        //        entity.HasOne(d => d.Te)
        //            .WithMany(p => p.SpeciesSelection)
        //            .HasForeignKey(d => d.Teid)
        //            .HasConstraintName("FK_SpeciesSelection_TemporalEvent");
        //    });

        //    modelBuilder.Entity<TblCode>(entity =>
        //    {
        //        entity.ToTable("tblCode");

        //        entity.HasIndex(e => new { e.TblCodeTypeId, e.Code })
        //            .HasName("CN_tblCode")
        //            .IsUnique();

        //        entity.Property(e => e.TblCodeId).HasColumnName("tblCodeID");

        //        entity.Property(e => e.Code)
        //            .IsRequired()
        //            .HasMaxLength(60)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Created).HasColumnType("datetime");

        //        entity.Property(e => e.Description).HasMaxLength(300);

        //        entity.Property(e => e.LongDescription)
        //            .HasMaxLength(4000)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Modified).HasColumnType("datetime");

        //        entity.Property(e => e.TblCodeTypeId).HasColumnName("tblCodeTypeID");

        //        entity.Property(e => e.User)
        //            .HasMaxLength(50)
        //            .IsUnicode(false);
        //    });

        //    modelBuilder.Entity<TblCodeRel>(entity =>
        //    {
        //        entity.HasKey(e => new { e.TblCodeOneId, e.TblCodeManyId, e.TblCodeTypeRelId });

        //        entity.ToTable("tblCodeRel");

        //        entity.Property(e => e.TblCodeOneId).HasColumnName("tblCodeOneID");

        //        entity.Property(e => e.TblCodeManyId).HasColumnName("tblCodeManyID");

        //        entity.Property(e => e.TblCodeTypeRelId).HasColumnName("tblCodeTypeRelID");

        //        entity.Property(e => e.Created).HasColumnType("datetime");

        //        entity.Property(e => e.Modified).HasColumnType("datetime");

        //        entity.Property(e => e.User)
        //            .HasMaxLength(50)
        //            .IsUnicode(false);
        //    });

        //    modelBuilder.Entity<TblCodeType>(entity =>
        //    {
        //        entity.ToTable("tblCodeType");

        //        entity.HasIndex(e => e.CodeType)
        //            .HasName("CN_tblCodeType")
        //            .IsUnique();

        //        entity.Property(e => e.TblCodeTypeId).HasColumnName("tblCodeTypeID");

        //        entity.Property(e => e.CodeType)
        //            .IsRequired()
        //            .HasMaxLength(100)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Created).HasColumnType("datetime");

        //        entity.Property(e => e.Definition)
        //            .HasMaxLength(4000)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Description)
        //            .HasMaxLength(200)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Modified).HasColumnType("datetime");

        //        entity.Property(e => e.User)
        //            .HasMaxLength(50)
        //            .IsUnicode(false);

        //        entity.Property(e => e.VerDate).HasColumnType("datetime");
        //    });

        //    modelBuilder.Entity<TblCodeTypeRel>(entity =>
        //    {
        //        entity.ToTable("tblCodeTypeRel");

        //        entity.Property(e => e.TblCodeTypeRelId).HasColumnName("tblCodeTypeRelID");

        //        entity.Property(e => e.Created).HasColumnType("datetime");

        //        entity.Property(e => e.Description).HasMaxLength(300);

        //        entity.Property(e => e.Modified).HasColumnType("datetime");

        //        entity.Property(e => e.RelTypeId).HasColumnName("RelTypeID");

        //        entity.Property(e => e.TblCodeTypeChdId).HasColumnName("tblCodeTypeChdID");

        //        entity.Property(e => e.TblCodeTypeParId).HasColumnName("tblCodeTypeParID");

        //        entity.Property(e => e.User)
        //            .HasMaxLength(50)
        //            .IsUnicode(false);
        //    });

        //    modelBuilder.Entity<TemporalEvent>(entity =>
        //    {
        //        entity.HasKey(e => e.Teid);

        //        entity.HasIndex(e => e.Loid);

        //        entity.HasIndex(e => e.Sdid);

        //        entity.HasIndex(e => e.Vsid);

        //        entity.HasIndex(e => new { e.Sdid, e.Loid, e.Vsid, e.TetimeUnit, e.TesequenceNumber })
        //            .HasName("IX_TE_SDidTuNc")
        //            .IsUnique();

        //        entity.Property(e => e.Teid).HasColumnName("TEid");

        //        entity.Property(e => e.Loid).HasColumnName("LOid");

        //        entity.Property(e => e.Sdid).HasColumnName("SDid");

        //        entity.Property(e => e.TeclusterName)
        //            .IsRequired()
        //            .HasColumnName("TEclusterName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Teclustering).HasColumnName("TEclustering");

        //        entity.Property(e => e.TeinclusionProb)
        //            .HasColumnName("TEinclusionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.TeinclusionProbCluster)
        //            .HasColumnName("TEinclusionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.TenumberSampled).HasColumnName("TEnumberSampled");

        //        entity.Property(e => e.TenumberSampledClusters).HasColumnName("TEnumberSampledClusters");

        //        entity.Property(e => e.TenumberTotal).HasColumnName("TEnumberTotal");

        //        entity.Property(e => e.TenumberTotalClusters).HasColumnName("TEnumberTotalClusters");

        //        entity.Property(e => e.TereasonNotSampled).HasColumnName("TEreasonNotSampled");

        //        entity.Property(e => e.TerecordType)
        //            .IsRequired()
        //            .HasColumnName("TErecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Tesampled).HasColumnName("TEsampled");

        //        entity.Property(e => e.Tesampler).HasColumnName("TEsampler");

        //        entity.Property(e => e.TeselectionMethod).HasColumnName("TEselectionMethod");

        //        entity.Property(e => e.TeselectionMethodCluster).HasColumnName("TEselectionMethodCluster");

        //        entity.Property(e => e.TeselectionProb)
        //            .HasColumnName("TEselectionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.TeselectionProbCluster)
        //            .HasColumnName("TEselectionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.TesequenceNumber).HasColumnName("TEsequenceNumber");

        //        entity.Property(e => e.Testratification).HasColumnName("TEstratification");

        //        entity.Property(e => e.TestratumName)
        //            .IsRequired()
        //            .HasColumnName("TEstratumName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.TetimeUnit).HasColumnName("TEtimeUnit");

        //        entity.Property(e => e.TeunitName)
        //            .IsRequired()
        //            .HasColumnName("TEunitName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Vsid).HasColumnName("VSid");

        //        entity.HasOne(d => d.Lo)
        //            .WithMany(p => p.TemporalEvent)
        //            .HasForeignKey(d => d.Loid)
        //            .HasConstraintName("FK_TemporalEvent_Location");

        //        entity.HasOne(d => d.Sd)
        //            .WithMany(p => p.TemporalEvent)
        //            .HasForeignKey(d => d.Sdid)
        //            .OnDelete(DeleteBehavior.ClientSetNull)
        //            .HasConstraintName("FK_TemporalEvent_SamplingDetails");

        //        entity.HasOne(d => d.Vs)
        //            .WithMany(p => p.TemporalEvent)
        //            .HasForeignKey(d => d.Vsid)
        //            .HasConstraintName("FK_TemporalEvent_VesselSelection");
        //    });

        //    modelBuilder.Entity<UserAuditEvents>(entity =>
        //    {
        //        entity.HasKey(e => e.UserAuditId);

        //        entity.Property(e => e.UserId).IsRequired();
        //    });

        //    modelBuilder.Entity<VesselDetails>(entity =>
        //    {
        //        entity.HasKey(e => e.Vdid)
        //            .HasName("PK_VesselDetails_1");

        //        entity.HasIndex(e => new { e.Vdcountry, e.VdencryptedVesselCode, e.Vdyear })
        //            .HasName("IX_Sub_VesselCode_Yea")
        //            .IsUnique();

        //        entity.Property(e => e.Vdid).HasColumnName("VDid");

        //        entity.Property(e => e.TimeStamp).HasColumnType("datetime");

        //        entity.Property(e => e.UserId)
        //            .IsRequired()
        //            .HasMaxLength(450);

        //        entity.Property(e => e.Vdcountry).HasColumnName("VDcountry");

        //        entity.Property(e => e.VdencryptedVesselCode)
        //            .IsRequired()
        //            .HasColumnName("VDencryptedVesselCode")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.VdflagCountry).HasColumnName("VDflagCountry");

        //        entity.Property(e => e.VdhomePort).HasColumnName("VDhomePort");

        //        entity.Property(e => e.Vdlength)
        //            .HasColumnName("VDlength")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.VdlengthCategory).HasColumnName("VDlengthCategory");

        //        entity.Property(e => e.Vdpower).HasColumnName("VDpower");

        //        entity.Property(e => e.VdrecordType)
        //            .IsRequired()
        //            .HasColumnName("VDrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.VdtonUnit).HasColumnName("VDtonUnit");

        //        entity.Property(e => e.Vdtonnage).HasColumnName("VDtonnage");

        //        entity.Property(e => e.Vdyear).HasColumnName("VDyear");
        //    });

        //    modelBuilder.Entity<VesselSelection>(entity =>
        //    {
        //        entity.HasKey(e => e.Vsid)
        //            .HasName("PK_Vessel");

        //        entity.HasIndex(e => e.Sdid);

        //        entity.HasIndex(e => e.Teid);

        //        entity.HasIndex(e => e.Vdid);

        //        entity.Property(e => e.Vsid).HasColumnName("VSid");

        //        entity.Property(e => e.Sdid).HasColumnName("SDid");

        //        entity.Property(e => e.Teid).HasColumnName("TEid");

        //        entity.Property(e => e.Vdid).HasColumnName("VDid");

        //        entity.Property(e => e.VsclusterName)
        //            .IsRequired()
        //            .HasColumnName("VSclusterName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.Vsclustering).HasColumnName("VSclustering");

        //        entity.Property(e => e.VsencryptedVesselCode)
        //            .IsRequired()
        //            .HasColumnName("VSencryptedVesselCode")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.VsinclusionProb)
        //            .HasColumnName("VSinclusionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.VsinclusionProbCluster)
        //            .HasColumnName("VSInclusionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.VsnumberSampled).HasColumnName("VSnumberSampled");

        //        entity.Property(e => e.VsnumberSampledClusters).HasColumnName("VSnumberSampledClusters");

        //        entity.Property(e => e.VsnumberTotal).HasColumnName("VSnumberTotal");

        //        entity.Property(e => e.VsnumberTotalClusters).HasColumnName("VSnumberTotalClusters");

        //        entity.Property(e => e.VsreasonNotSampled).HasColumnName("VSreasonNotSampled");

        //        entity.Property(e => e.VsrecordType)
        //            .IsRequired()
        //            .HasColumnName("VSrecordType")
        //            .HasMaxLength(2)
        //            .IsUnicode(false);

        //        entity.Property(e => e.Vssampled).HasColumnName("VSsampled");

        //        entity.Property(e => e.Vssampler).HasColumnName("VSsampler");

        //        entity.Property(e => e.VsselectionMethod).HasColumnName("VSselectionMethod");

        //        entity.Property(e => e.VsselectionMethodCluster).HasColumnName("VSselectionMethodCluster");

        //        entity.Property(e => e.VsselectionProb)
        //            .HasColumnName("VSselectionProb")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.VsselectionProbCluster)
        //            .HasColumnName("VSSelectionProbCluster")
        //            .HasColumnType("decimal(18, 2)");

        //        entity.Property(e => e.VssequenceNumber).HasColumnName("VSsequenceNumber");

        //        entity.Property(e => e.Vsstratification).HasColumnName("VSstratification");

        //        entity.Property(e => e.VsstratumName)
        //            .IsRequired()
        //            .HasColumnName("VSstratumName")
        //            .HasMaxLength(100);

        //        entity.Property(e => e.VsunitName)
        //            .IsRequired()
        //            .HasColumnName("VSunitName")
        //            .HasMaxLength(100);

        //        entity.HasOne(d => d.Sd)
        //            .WithMany(p => p.VesselSelection)
        //            .HasForeignKey(d => d.Sdid)
        //            .HasConstraintName("FK_VesselSelection_SamplingDetails");

        //        entity.HasOne(d => d.Te)
        //            .WithMany(p => p.VesselSelection)
        //            .HasForeignKey(d => d.Teid)
        //            .HasConstraintName("FK_VesselSelection_TemporalEvent");

        //        entity.HasOne(d => d.Vd)
        //            .WithMany(p => p.VesselSelection)
        //            .HasForeignKey(d => d.Vdid)
        //            .HasConstraintName("FK_VesselSelection_VesselDetails");
        //    });
        //}
    }
    }






