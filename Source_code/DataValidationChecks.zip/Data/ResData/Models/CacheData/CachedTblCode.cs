﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ResData.Models.CacheData
{
    /// <summary>
    /// This class represents DB table tblCode and is used to keep codes in cache for faster access. 
    /// </summary>
    public class CodeWithType
    {
        /// <summary>
        /// Primary key
        /// </summary>
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }
        /// <summary>
        /// Code
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// Code Type
        /// </summary>
        public string Type { get; set; }
        /// <summary>
        /// Code description
        /// </summary>
        public string Description { get; set; }

        public int CodeTypeId { get; set; }
    }
}
