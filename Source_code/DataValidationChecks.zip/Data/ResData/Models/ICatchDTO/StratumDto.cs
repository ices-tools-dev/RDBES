﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ResData.Models.ICatchDTO
{
    public class StratumDto
    {

        public string FishingArea { get; set; }
      
        public string Year { get; set; }
      
        public string Country { get; set; }
      
        public string Stock { get; set; }
        public string ReportingCategory { get; set; }
        public string CatchCategory { get; set; }
        public decimal Caton { get; set; }


    }
}
