﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace ResData.Models.KeyLessEntities
{
    public class CodeLookupVD
    {
        public int? Id { get; set; }
        public string VesselEncriptedCode {get;set;}
        public string Country { get; set; }
        public string Year { get; set; }
       

    }
}
