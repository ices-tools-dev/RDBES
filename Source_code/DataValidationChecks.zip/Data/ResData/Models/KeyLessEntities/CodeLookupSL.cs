﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace ResData.Models.KeyLessEntities
{
    public class CodeLookupSL
    {
        public int? Id { get; set; }
        public string SpeciesListName {get;set;}
        public string CatchFraction { get; set; }
        public string Country { get; set; }
        public string Year { get; set; }
      
        

    }
}
