﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace ResData.Models.KeyLessEntities
{
    public class CodeLookup
    {
        public int? Id { get; set; }
        public string Code { get; set; }
        public string Country { get; set; }
        public string Year { get; set; }
        public string DbTable { get; set; }
        public string FieldName { get; set; }

        public string CatchFractionFieldName { get;set;}
        public string CatchFractionFieldValue { get; set; }

    }
}
