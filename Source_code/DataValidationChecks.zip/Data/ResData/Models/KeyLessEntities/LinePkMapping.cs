﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ResData.Models.KeyLessEntities
{
    public class LinePkMapping
    {
        public int ln { get; set; }
        public int pk { get; set; }
    }
}
