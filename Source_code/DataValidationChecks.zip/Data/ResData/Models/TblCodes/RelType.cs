﻿using System;
using System.Collections.Generic;



namespace ResData.Models.TblCodes
{
    public partial class RelType
    {
        public RelType()
        {
            TblCodeTypeRels = new HashSet<TblCodeTypeRel>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public string Xmlnode { get; set; }

        public virtual ICollection<TblCodeTypeRel> TblCodeTypeRels { get; set; }
    }
}
