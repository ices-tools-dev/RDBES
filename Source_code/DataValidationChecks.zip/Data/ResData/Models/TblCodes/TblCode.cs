﻿using ResData.Models.Stock;
using System;
using System.Collections.Generic;



namespace ResData.Models.TblCodes
{
    public partial class TblCode
    {
        public TblCode()
        {
            RSpeciesAreaQuarterAreaNavigations = new HashSet<RSpeciesAreaQuarter>();
            RSpeciesAreaQuarterQuarterNavigations = new HashSet<RSpeciesAreaQuarter>();
            RSpeciesAreaQuarterSpeciesNavigations = new HashSet<RSpeciesAreaQuarter>();
            RSpeciesAreaQuarterStockNavigations = new HashSet<RSpeciesAreaQuarter>();
            TblCodeRelTblCodeManies = new HashSet<TblCodeRel>();
            TblCodeRelTblCodeOnes = new HashSet<TblCodeRel>();
        }

        public int TblCodeId { get; set; }
        public int TblCodeTypeId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string User { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public bool? Visibility { get; set; }
        public bool Deprecated { get; set; }
        public string LongDescription { get; set; }

        public virtual TblCodeType TblCodeType { get; set; }
        public virtual ICollection<RSpeciesAreaQuarter> RSpeciesAreaQuarterAreaNavigations { get; set; }
        public virtual ICollection<RSpeciesAreaQuarter> RSpeciesAreaQuarterQuarterNavigations { get; set; }
        public virtual ICollection<RSpeciesAreaQuarter> RSpeciesAreaQuarterSpeciesNavigations { get; set; }
        public virtual ICollection<RSpeciesAreaQuarter> RSpeciesAreaQuarterStockNavigations { get; set; }
        public virtual ICollection<TblCodeRel> TblCodeRelTblCodeManies { get; set; }
        public virtual ICollection<TblCodeRel> TblCodeRelTblCodeOnes { get; set; }
    }
}
