﻿using ResData.Models.TblCodes;
using System;
using System.Collections.Generic;



namespace ResData.Models.Stock
{
    public partial class RSpeciesAreaQuarter
    {
        public int Id { get; set; }
        public int Stock { get; set; }
        public int Species { get; set; }
        public int Area { get; set; }
        public int Quarter { get; set; }
        public string Description { get; set; }

        public virtual TblCode AreaNavigation { get; set; }
        public virtual TblCode QuarterNavigation { get; set; }
        public virtual TblCode SpeciesNavigation { get; set; }
        public virtual TblCode StockNavigation { get; set; }
    }
}
