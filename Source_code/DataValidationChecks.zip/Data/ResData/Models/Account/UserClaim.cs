﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace ResData.Models.Account
{
    public class UserClaim
    {
        public int Id { get; set; }
        
        [Required]
        public string Type { get; set; }
        [Required]
        public string Value { get; set; }


    }
}
