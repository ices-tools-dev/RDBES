﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace ResData.Models.Account
{
    public class Country
    {
        [DisplayName("Id")]
        public int Id { get; set; }
        [DisplayName("Country")]
        public string Code { get; set; }
        [DisplayName("Descrption")]
        public string Description { get; set; }
    }
}
