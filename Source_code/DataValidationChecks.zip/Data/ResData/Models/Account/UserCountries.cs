﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ResData.Models.Account
{
    public class UsersCountries
    {

        public int Id { get; set; }
        public Guid UserId { get; set; }
        public int CountryId { get; set; }
    }
}
