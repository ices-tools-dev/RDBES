﻿using System;
using System.Collections.Generic;

namespace ResData.Models.Account
{
    public partial class ClaimValue
    {
        public int Id { get; set; }
        public string Value { get; set; }
    }
}
