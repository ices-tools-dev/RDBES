﻿using System;
using System.Collections.Generic;

namespace ResData.Models.Account
{
    public partial class ClaimType
    {
        public string Type { get; set; }
        public int Id { get; set; }
    }
}
