﻿namespace ResData.Models.Account
{
    public class FakeClaimType
    {

        public int Id { get; set; }
        public string ClaimType { get; set; }
      





    }
}