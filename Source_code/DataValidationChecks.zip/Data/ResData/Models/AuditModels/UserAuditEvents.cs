﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ResData.Models.Admin
{
    public class UserAuditEvents
    {
        [Key]
        public int UserAuditId { get; private set; }

        [Required]
        public string UserId { get;  set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required]
        public DateTimeOffset Timestamp { get; private set; } = DateTime.Now;

        [Required]
        public UserAuditEventType AuditEvent { get; set; }

        public string IpAddress { get; private set; }

        // public string Action { get; set; }
         public string Message { get; set; }

        ////public static UserAuditEvents CreateAuditEvent(string userId, UserAuditEventType auditEventType, string ipAddress)
        ////{
        ////    return new UserAudit { UserId = userId, AuditEvent = auditEventType, IpAddress = ipAddress };
        ////}
      
    }
    public enum UserAuditEventType
    {
        Login = 1,
        FailedLogin = 2,
        LogOut = 3,
        SyncOperation =4
    }
}
