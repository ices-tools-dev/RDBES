﻿using Microsoft.AspNetCore.Mvc.Rendering;
using ResData.Models.Account;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace ResData.Models.AccountViewModels
{
    public class EditAccountViewModel
    {
        [Required(ErrorMessage ="User name field is required")]
        public string UserName { get; set; }        
        public string RowIndex { get; set; }
        public string ScrollPosition { get; set; }
        public string CurrentTab { get; set; }       
    }
}
