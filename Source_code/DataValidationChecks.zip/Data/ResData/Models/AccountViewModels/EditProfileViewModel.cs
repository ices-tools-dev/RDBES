﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ResData.Models.AccountViewModels
{
    public class EditProfileViewModel
    {
        public RegisterViewModel UserRegistration { get; set; }
        public string UserName { get; set; }       
        
       
        public EditProfileViewModel()
        {
            
           
           
        }
    }
}
