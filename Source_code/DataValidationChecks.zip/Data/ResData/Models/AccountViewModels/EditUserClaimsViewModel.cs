﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ResData.Models.Account;

namespace ResData.Models.AccountViewModels
{
    public class EditUserClaimsViewModel
    {
        public string UserId { get; set; }
        public List<UserClaim> Claims { get; set; }
        public UserClaim NewClaim { get; set; }
    }
}
