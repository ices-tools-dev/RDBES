﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Errors
{
    public class ErrorHeader
    {
        public string DataType { get; set; }
        public string[] AllFields { get; set; }
        public int[] InvolvedFieldsIndexies { get; set; }
        public string ConstraintName { get; set; }
    }
}
