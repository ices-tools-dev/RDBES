﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Errors
{
    public class DuplicateGroup
    {
        public List<string> DataLines { get; set; }
       
    }
}
