﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Errors
{
    public class ParentRecord
    {
        public string ParentDataLine { get; set; }
        public string ParentLineNumber { get; set; }
        public string ParentRecordType { get; set; }
    }
}
