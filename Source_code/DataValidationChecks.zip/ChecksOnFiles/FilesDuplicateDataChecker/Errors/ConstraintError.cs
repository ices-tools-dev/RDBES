﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Errors
{
    public class ConstraintError
    {
        public ErrorHeader ErrorHeader { get; set; }
        
        public List<DuplicateGroupUnderParent> DuplicateGroupsUnderParent { get; set; }

        
    }
}
