﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Errors
{
    public class DuplicateGroupUnderParent
    {
       
        public List<DuplicateGroup> DuplicateGroups { get; set; }
        public List<ParentRecord> Parents { get; set; }
    }
}
