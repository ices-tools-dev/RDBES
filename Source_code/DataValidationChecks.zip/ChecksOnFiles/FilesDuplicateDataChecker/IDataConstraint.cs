﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;

namespace FilesDuplicateDataChecker
{
    internal interface IDataConstraint
    {
        IDataRecordType DataTable { get; }
        int[] KeyFields { get; }
        Utility.RecordType[] Parents { get; }


    }
}
