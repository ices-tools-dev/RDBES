﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker
{
    internal interface IHierarchy
    {
        IDataConstraint[] DataConstraints { get; }
        
    
    }
}
