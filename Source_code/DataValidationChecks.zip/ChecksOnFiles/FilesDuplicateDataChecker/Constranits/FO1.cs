﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using ResCommon;
using TypeDefinitions.RecordTypes.Records;

namespace FilesDuplicateDataChecker.Constranits
{
    internal class FO1 : IDataConstraint
    {
        public IDataRecordType DataTable => new FO();

        public int[] KeyFields => new int[] { 3 };

        public Utility.RecordType[] Parents => new Utility.RecordType[]
        { Utility.RecordType.SD, Utility.RecordType.FT };
    }
}
