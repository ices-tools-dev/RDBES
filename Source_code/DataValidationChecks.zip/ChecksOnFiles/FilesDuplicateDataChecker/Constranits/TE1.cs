﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes.Records;
using TypeDefinitions.RecordTypes;
using ResCommon;

namespace FilesDuplicateDataChecker.Constranits
{
    internal class TE1 : IDataConstraint
    {
        public IDataRecordType DataTable => new TE();

        public int[] KeyFields => new int[] { 2,4};

        public Utility.RecordType[] Parents => new Utility.RecordType[] 
        { Utility.RecordType.SD };
    }
}
