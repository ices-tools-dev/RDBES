﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using ResCommon;
using TypeDefinitions.RecordTypes.Records;
namespace FilesDuplicateDataChecker.Constranits
{
    internal class SD1 : IDataConstraint
    {
        public  int[] KeyFields =>  new int[] { 2,3 }; 
      
        public  Utility.RecordType[] Parents=>
         new Utility.RecordType[] { Utility.RecordType.DE }; 

        public IDataRecordType DataTable => new SD();

        
    }

   
}
