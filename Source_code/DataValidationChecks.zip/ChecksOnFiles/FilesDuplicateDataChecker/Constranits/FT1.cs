﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using ResCommon;
using TypeDefinitions.RecordTypes.Records;

namespace FilesDuplicateDataChecker.Constranits
{
    internal class FT1 : IDataConstraint
    {
        public IDataRecordType DataTable =>  new FT();

        public int[] KeyFields => new int[] 
        {
            3,14,15
        };

        public Utility.RecordType[] Parents => 
            new Utility.RecordType[] { };
    }
}
