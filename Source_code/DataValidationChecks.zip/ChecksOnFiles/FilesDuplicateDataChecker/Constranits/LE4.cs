﻿using System.Text;
using TypeDefinitions.RecordTypes;
using System.Collections.Generic;
using ResCommon;
using TypeDefinitions.RecordTypes.Records;

namespace FilesDuplicateDataChecker.Constranits
{
    //for hierarchy 9 and hierarchy 11
    //unique index on LandingEvent table
    //[OSid] ASC,[FTid] ASC,[VSid] ASC,	[LEsequenceNumber] ASC
    //we have to catch duplicate on file or add SAid in uniqe index 
     
    internal class LE4 : IDataConstraint
    {
        public IDataRecordType DataTable => new LE();

        public int[] KeyFields => new int[] { 4 };

        public Utility.RecordType[] Parents => new Utility.RecordType[]
        {  Utility.RecordType.SA };

    }
}
