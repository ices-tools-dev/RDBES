﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using ResCommon;
using TypeDefinitions.RecordTypes.Records;

namespace FilesDuplicateDataChecker.Constranits
{
     internal class DE1 : IDataConstraint
    {
        public IDataRecordType DataTable => new DE();

        public int[] KeyFields => new int[] { 2, 4, 5, 7 };

        public Utility.RecordType[] Parents => new Utility.RecordType[] {  };
    }
}
