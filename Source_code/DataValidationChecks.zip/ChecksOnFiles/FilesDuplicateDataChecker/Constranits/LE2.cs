﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using ResCommon;
using TypeDefinitions.RecordTypes.Records;

namespace FilesDuplicateDataChecker.Constranits
{
    internal class LE2 : IDataConstraint
    {
        public IDataRecordType DataTable => new LE();

        public int[] KeyFields => new int[] { 4};

        public Utility.RecordType[] Parents => new Utility.RecordType[] 
        { Utility.RecordType.VS };
    }
}
