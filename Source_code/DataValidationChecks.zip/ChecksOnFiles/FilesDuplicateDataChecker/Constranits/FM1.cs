﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using TypeDefinitions.RecordTypes.Records;
using ResCommon;

namespace FilesDuplicateDataChecker.Constranits
{
    internal class FM1 : IDataConstraint
    {
        public IDataRecordType DataTable => new FM();

        public int[] KeyFields => new int[] { 4 };

        public Utility.RecordType[] Parents => new Utility.RecordType[] { Utility.RecordType.SA }; 

    }
}
