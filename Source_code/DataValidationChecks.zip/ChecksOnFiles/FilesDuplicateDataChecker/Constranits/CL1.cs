﻿using TypeDefinitions.RecordTypes;
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes.Records;

namespace FilesDuplicateDataChecker.Constranits
{
    internal class CL1 : IDataConstraint
    {
        public Utility.RecordType[] Parents => new Utility.RecordType[] { };
        public IDataRecordType DataTable => new CL();

        public int[] KeyFields => new int[] {
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            22,
            23,
            24,
            25,
            26,
            27,
            28,
            29
            

        };
    }
}
