﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using ResCommon;
using TypeDefinitions.RecordTypes.Records;

namespace FilesDuplicateDataChecker.Constranits
{
    internal class CE1 : IDataConstraint
    {
        public IDataRecordType DataTable => new CE();

        public int[] KeyFields => new int[] { 
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            16,
            17,
            18,
            19,
            20

        };

        public Utility.RecordType[] Parents => new Utility.RecordType[] { };
    }
}
