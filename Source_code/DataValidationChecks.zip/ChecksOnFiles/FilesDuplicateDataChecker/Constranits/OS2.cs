﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using ResCommon;
using TypeDefinitions.RecordTypes.Records;

namespace FilesDuplicateDataChecker.Constranits
{
    class OS2: IDataConstraint
    {
        public IDataRecordType DataTable => new OS();

        public int[] KeyFields => new int[] { 2 };

        public Utility.RecordType[] Parents => new Utility.RecordType[] { Utility.RecordType.SD };
    }
}
