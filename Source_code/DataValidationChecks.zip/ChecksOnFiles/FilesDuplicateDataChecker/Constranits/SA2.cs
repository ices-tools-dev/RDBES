﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using ResCommon;
using TypeDefinitions.RecordTypes.Records;

namespace FilesDuplicateDataChecker.Constranits
{
    internal class SA2 : IDataConstraint
    {
        public IDataRecordType DataTable => new SA();

        public int[] KeyFields => new int[] {2 };

        public Utility.RecordType[] Parents => new Utility.RecordType[] { Utility.RecordType.SS };
    }
}
