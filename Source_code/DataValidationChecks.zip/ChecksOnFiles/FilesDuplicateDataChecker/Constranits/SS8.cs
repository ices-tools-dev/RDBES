﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using TypeDefinitions.RecordTypes.Records;

namespace FilesDuplicateDataChecker.Constranits
{
    internal class SS8 : IDataConstraint
    {
        public int[] KeyFields =>
       new int[] { 2 };



        public Utility.RecordType[] Parents =>
            new Utility.RecordType[] { Utility.RecordType.OS };


        public IDataRecordType DataTable => new SS();
    }
}
