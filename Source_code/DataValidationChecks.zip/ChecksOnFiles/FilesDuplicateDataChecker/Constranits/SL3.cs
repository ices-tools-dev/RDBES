﻿using TypeDefinitions.RecordTypes;
using TypeDefinitions.RecordTypes.Records;
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Constranits
{
    internal class SL3 : IDataConstraint
    {
        public IDataRecordType DataTable => new SL();

        public int[] KeyFields => new int[] { 2, 4,5,6,7,8 };

        public Utility.RecordType[] Parents => new Utility.RecordType[] { };
    }
}
