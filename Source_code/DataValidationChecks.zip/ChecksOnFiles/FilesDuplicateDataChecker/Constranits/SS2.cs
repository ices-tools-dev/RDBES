﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using ResCommon;
using TypeDefinitions.RecordTypes.Records;

namespace FilesDuplicateDataChecker.Constranits
{
    internal class SS2 : IDataConstraint
    {
        public int[] KeyFields =>
        new int[] { 6, 4, 5 };



        public Utility.RecordType[] Parents =>
            new Utility.RecordType[] { Utility.RecordType.FO };


        public IDataRecordType DataTable => new SS();
    }
}
