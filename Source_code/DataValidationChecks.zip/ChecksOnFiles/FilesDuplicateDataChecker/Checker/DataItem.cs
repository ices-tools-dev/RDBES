﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace FilesDuplicateDataChecker.Checker
{
    internal class DataItem
    {
        public string Key { get; set; }
        public XElement Element { get; set; }
        public string Ln { get; set; }
        public string ConstraintName { get; set; }
        public Dictionary<string, string> Ancesstors { get; set; }
    }
}
