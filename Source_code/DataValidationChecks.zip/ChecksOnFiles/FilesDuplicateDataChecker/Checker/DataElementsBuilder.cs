﻿using FilesDuplicateDataChecker.Constranits;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace FilesDuplicateDataChecker.Checker
{
   internal class DataElementsBuilder
    {
        private readonly string pathToXml = string.Empty;
        private readonly XDocument document;
        //private readonly List<IDataConstraint> constraints;
       
        public DataElementsBuilder(string path)
        {
            this.pathToXml = path;
           //this.document = XDocument.Load(pathToXml);


        }

        public List<DataItem> BuildDataItems(IDataConstraint con)
        {
            var parentsCount = con.Parents.Length;

            List<DataItem> dataItems;
            dataItems = new List<DataItem>();

            using (XmlReader reader = XmlReader.Create(this.pathToXml))
            {
                reader.MoveToContent();
                if (parentsCount == 0)
                {
                    while (reader.ReadToFollowing(con.DataTable.RecordType.ToString()))
                    {
                        var parentsInfo = new Dictionary<string, string>();
                        var dataItem = CreateDataItem(con, reader, parentsInfo);
                        dataItems.Add(dataItem);
                    }
                }
                else if (parentsCount == 1)
                {

                    while (reader.ReadToFollowing(con.Parents[0].ToString()))
                    {
                       

                        string pln = reader.GetAttribute("ln");                      

                        var readerParent = reader.ReadSubtree();
                        while (readerParent.ReadToFollowing(con.DataTable.RecordType.ToString()))
                        {
                            var parentsInfo = new Dictionary<string, string>();
                            parentsInfo.Add(con.Parents[0].ToString(), pln);
                            var dataItem = CreateDataItem(con, readerParent, parentsInfo);
                            dataItems.Add(dataItem);
                        }
                    }
                }
                else if (parentsCount == 2)
                {
                    while (reader.ReadToFollowing(con.Parents[0].ToString()))
                    {
                       
                        string gpln = reader.GetAttribute("ln");
                       

                        var readerGrandParent = reader.ReadSubtree();
                        while (readerGrandParent.ReadToFollowing(con.Parents[1].ToString()))
                        {
                            string pln = readerGrandParent.GetAttribute("ln");
                           

                            var readerParent = readerGrandParent.ReadSubtree();
                            while (readerParent.ReadToFollowing(con.DataTable.RecordType.ToString()))
                            { var parentsInfo = new Dictionary<string, string>();
                                parentsInfo.Add(con.Parents[0].ToString(), gpln);
                                parentsInfo.Add(con.Parents[1].ToString(), pln);
                                var dataItem = CreateDataItem(con, readerParent, parentsInfo);
                                dataItems.Add(dataItem);
                            }
                        }
                    }
                }
                else
                {
                    throw new Exception("its not supported to find file based duplicate data for more than 2 parents");

                }
            }


            return dataItems;
        }
        private DataItem CreateDataItem(IDataConstraint con, XmlReader reader, Dictionary<string, string> parentsInfo)
        {
           
                
                    var res = new DataItem();
                    string ln = reader.GetAttribute("ln");
                    res.Ancesstors = parentsInfo;
                    res.ConstraintName = con.GetType().Name;
                    res.Ln = ln;
                    SetDataItemKey(con, reader.ReadSubtree(), res);

                return res;
                

            
            

        }
        private void SetDataItemKey(IDataConstraint cons, XmlReader reader, DataItem res)
        {


            var keyCount = cons.KeyFields.Count();
            var parentCount = cons.Parents.Count();
            string[] Lastkey = new string[keyCount + parentCount];

            var eleDic = new Dictionary<string, string>();


            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element)
                {

                    //if (reader.IsStartElement() && reader.Name.StartsWith(cons.DataTable.RecordType.ToString()))
                    //{

                    //    var val = reader.ReadString();

                    //    eleDic.Add(reader.Name, val);
                    //}

                    var name = reader.Name;
                    if(cons.DataTable.Allfields.Contains(name))
                    {
                           var val = reader.ReadString();

                          eleDic.Add(name, val);
                    }


                }
            }

            for (int i = 0; i < keyCount; i++)
            {

                if (eleDic.ContainsKey(cons.DataTable.Allfields[cons.KeyFields[i]]))

                    Lastkey[i] = eleDic[cons.DataTable.Allfields[cons.KeyFields[i]]];
                else
                    Lastkey[i] = "OptionalElementValueNotFound";



            }




            for (int i = 0; i < parentCount; i++)
            {

                if (res.Ancesstors.ContainsKey(cons.Parents[i].ToString()))
                {
                    var pln = res.Ancesstors[cons.Parents[i].ToString()];
                    Lastkey[keyCount + i] = pln;
                }
                else
                {
                    Lastkey[keyCount + i] = "";
                }
            }

            res.Key = string.Concat(Lastkey);




        }





    }
}
