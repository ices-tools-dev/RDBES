﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using FilesDuplicateDataChecker.Errors;

namespace FilesDuplicateDataChecker.Checker
{
    internal class DuplicateDataFinder
    {
        private readonly XDocument document;
        
        public DuplicateDataFinder(string path) 
        {
       
            this.document = XDocument.Load(path);
        }    

       

        public List<ConstraintError> BuildErrorResult(List<DataItem> allDataItems, List<IDataConstraint> constraints, int maxErrors)
        {
            List<ConstraintError> ConstraintErrors;
            ConstraintErrors = new List<ConstraintError>();


            int errorsFound = 0;
          
            var groupByConstraints = allDataItems.GroupBy(g => g.ConstraintName);
            foreach (var grp in groupByConstraints)
            {
                var cons = constraints.FirstOrDefault(c => c.GetType().Name.Equals(grp.Key));
                if (cons == null) throw new Exception("Constraint name found in data item do not exist in collection of IDataConstraint");
                var err = new ConstraintError
                {
                    ErrorHeader = GetErrorHeaderByConstraint(cons),
                    DuplicateGroupsUnderParent = new List<DuplicateGroupUnderParent>()
                };

                var duplicatesByParentLines = grp.GroupBy(g => string.Join(",", g.Ancesstors.Values)).Where(g => g.Count() > 1);           
                
               
                foreach (var subgrp in duplicatesByParentLines)
                {
                    DuplicateGroupUnderParent parentgroup = new DuplicateGroupUnderParent();
                    parentgroup.DuplicateGroups = new List<DuplicateGroup>();

                    var parentsDuplicateByElementsKey = subgrp.GroupBy(g => g.Key).Where(g => g.Count() > 1);

                    
                    var parentInfoFound = false;
                    foreach (var item in parentsDuplicateByElementsKey)
                    {
                        if (parentInfoFound == false)
                        {
                            err.ErrorHeader.ConstraintName = item.First().ConstraintName;
                            parentgroup.Parents = GetErrorParentsInfo(item.First());
                            parentInfoFound = true;
                        }

                        var groupElementsLineNumbers = item.Select(i => i.Ln);
                       var groupXElements=  this.document.Descendants().Where(e => e.HasAttributes)
                            .Where(e => groupElementsLineNumbers.Contains(e.Attribute("ln").Value));

                        var grpLines = GetErrorDuplicateGroup(err.ErrorHeader, groupXElements,ref errorsFound,maxErrors);

                        //errorsFound = errorsFound + grpLines.DataLines.Count;
                       
                        parentgroup.DuplicateGroups.Add(grpLines);
                        // no more errors to find
                        if (errorsFound >= maxErrors) break;
                    }
                    
                    if (parentgroup.DuplicateGroups.Count() > 0)
                    {

                        err.DuplicateGroupsUnderParent.Add(parentgroup);
                    }

                    // no more errors to find
                    if (errorsFound >= maxErrors) break;

                }
                if (err.DuplicateGroupsUnderParent.Count() > 0)
                {
                    ConstraintErrors.Add(err);
                }
                // no more errors to find
                if (errorsFound >= maxErrors) break;
            }
            return ConstraintErrors;
        }
        private DuplicateGroup GetErrorDuplicateGroup(ErrorHeader consHeader, IEnumerable<XElement> els,ref int errorsFound,int maxErrors)
        {
            var grp = new DuplicateGroup();
            var dataLines = new List<string>();

            foreach (var el in els)
            {

                StringBuilder line = new StringBuilder();
                line.Append(el.Attribute("ln").Value);
                line.Append(",");
                line.Append(consHeader.DataType);
                for (int i = 2; i < consHeader.AllFields.Length; i++)
                {
                    line.Append(",");
                    line.Append(
                    el.Element(consHeader.AllFields[i]) == null ? ""
                     : string.IsNullOrWhiteSpace(el.Element(consHeader.AllFields[i]).Value) ? ""
                     : el.Element(consHeader.AllFields[i]).Value);
                }
                dataLines.Add(line.ToString());

                errorsFound++;
                if (errorsFound >= maxErrors)
                    break;
                

            }
            grp.DataLines = dataLines;
            return grp;
        }

        private ErrorHeader GetErrorHeaderByConstraint(IDataConstraint cons)
        {
            var errorHeader = new ErrorHeader()
            { 
                AllFields = cons.DataTable.Allfields,
                DataType = cons.DataTable.RecordType.ToString(),
                InvolvedFieldsIndexies =  cons.KeyFields //cons.KeyFields.DataTable.Allfields.Select((b, i) => cons.KeyFields.Contains(b) ? i : -1).Where(i => i != -1).ToArray()

            };

            return errorHeader;

        }

        private List<ParentRecord> GetErrorParentsInfo(DataItem duplicateItem)
        {


            



            var parents = new List<ParentRecord>();

            var ele = this.document.Descendants().Where(e => e.HasAttributes).Where(e => e.Attribute("ln").Value.Equals(duplicateItem.Ln)).FirstOrDefault();
            if (ele != null)
            {
                duplicateItem.Element = ele;



                foreach (var ancestor in duplicateItem.Ancesstors)
                {

                    var pr = new ParentRecord();
                    var parentElement = duplicateItem.Element.Ancestors(ancestor.Key).FirstOrDefault();
                    if (parentElement != null)
                    {
                        var parentFileds = parentElement.Descendants().Where(e => e.Name.LocalName.StartsWith(ancestor.Key));
                        StringBuilder lineSb = new StringBuilder();
                        lineSb.Append(ancestor.Key);


                        foreach (var f in parentFileds)
                        {
                            lineSb.Append(",");
                            lineSb.Append(f == null ? "" : string.IsNullOrWhiteSpace(f.Value) ? "" : f.Value);

                        }
                        pr.ParentDataLine = lineSb.ToString();

                        pr.ParentRecordType = ancestor.Key + "record";
                        pr.ParentLineNumber = ancestor.Value;
                    }
                    else
                    {
                        pr.ParentRecordType = ancestor.Key + "record";
                        pr.ParentLineNumber = "parent not found";
                    }
                    parents.Add(pr);

                }
            }
                return parents;
        }
    }
}
