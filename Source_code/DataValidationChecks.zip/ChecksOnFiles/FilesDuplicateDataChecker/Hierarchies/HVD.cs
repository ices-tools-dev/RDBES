﻿using FilesDuplicateDataChecker.Constranits;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Hierarchies
{
    internal class HVD : IHierarchy
    {
        public IDataConstraint[] DataConstraints => new IDataConstraint[]
         {
            new VD1()
         };
    }
}
