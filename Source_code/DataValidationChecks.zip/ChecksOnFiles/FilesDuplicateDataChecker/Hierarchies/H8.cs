﻿using FilesDuplicateDataChecker.Constranits;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Hierarchies
{
    internal class H8 : IHierarchy
    {
        public IDataConstraint[] DataConstraints => new IDataConstraint[]
            {
          new DE1(),
              

            new SD1(),
            
            new TE1(),   
            new LE2(),            
            new SS1(),
            new SS6(),
            new SA1(),
            new FM1(),
            new BV1()
            ,new BV2(),
            new BV3()
            };
    }
}
