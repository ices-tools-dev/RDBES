﻿using FilesDuplicateDataChecker.Constranits;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Hierarchies
{
    internal class HSL : IHierarchy
    {
        public IDataConstraint[] DataConstraints => new IDataConstraint[]
         {
           
            new SL3()
         };
    }
}
