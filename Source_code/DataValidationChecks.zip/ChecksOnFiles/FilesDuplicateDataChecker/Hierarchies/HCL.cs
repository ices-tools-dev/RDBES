﻿using FilesDuplicateDataChecker.Constranits;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Hierarchies
{
    internal class HCL : IHierarchy
    {
        public IDataConstraint[] DataConstraints => new IDataConstraint[]
          {
            new CL1()
          };

       
    }
}
