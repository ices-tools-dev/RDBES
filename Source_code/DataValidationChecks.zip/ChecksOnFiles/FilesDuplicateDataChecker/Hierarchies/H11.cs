﻿using FilesDuplicateDataChecker.Constranits;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Hierarchies
{
    internal class H11 : IHierarchy
    {
        public IDataConstraint[] DataConstraints => new IDataConstraint[]
            {
            new DE1(),
              
            new SD1(),
            
            new FT1(),

             new TE1(),
              // for hierarchy 11: LE is after FT(as child in xml)
    // unique index fileds on table Landing event
    //[OSid] ASC,	[FTid] ASC,	[VSid] ASC,	[LEsequenceNumber] ASC
    // we have to catch duplicate on file or add (some other filed to make it unique)
    // 
            new SS5(),
            new SS10(),
            new LE4(),
            new SA1(),
            new FM1(),
            new BV1(),new BV2(),
            new BV3()

            };
    }
}
