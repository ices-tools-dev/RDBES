﻿using FilesDuplicateDataChecker.Constranits;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Hierarchies
{
    internal class H6 : IHierarchy
    {
        public IDataConstraint[] DataConstraints => new IDataConstraint[]
            {
         new DE1(),
              

            new SD1(),

            new OS1(),
            new OS2(),
            new FT1(),           
            new LE7(),
            new SS2(),
            new SS7(),
            new SA1(),
            new FM1(),
            new BV1()
                ,new BV2(),
            new BV3()
            };
    }
}
