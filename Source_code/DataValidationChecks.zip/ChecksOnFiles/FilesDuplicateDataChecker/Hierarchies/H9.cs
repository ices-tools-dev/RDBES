﻿using FilesDuplicateDataChecker.Constranits;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Hierarchies
{
    internal class H9 : IHierarchy
    {
        public IDataConstraint[] DataConstraints => new IDataConstraint[]
            {
            new DE1(),
              

            new SD1(),
            new TE1(),
            //for hierarchy 9: LE is after SA(as child in xml)
            //unique index fileds on table Landing event
            //[OSid] ASC,	[FTid] ASC,	[VSid] ASC,	[LEsequenceNumber] ASC
            //we have to catch duplicate on file or add SAid in uniqe index 
    
            
            new LE4(),            
            new SS4(),
            new SS9(),
            new SA1(),
            new SA3(),
            new FM1(),
            new BV1(),
            new BV2(),
            new BV3()

            };
    }
}
