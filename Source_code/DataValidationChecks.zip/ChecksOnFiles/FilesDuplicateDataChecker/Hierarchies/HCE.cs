﻿using System;
using System.Collections.Generic;
using System.Text;
using FilesDuplicateDataChecker.Constranits;
namespace FilesDuplicateDataChecker.Hierarchies
{
    internal class HCE : IHierarchy
    {
        public IDataConstraint[] DataConstraints => new IDataConstraint[]
          {
            new CE1()
          };
    }
}
