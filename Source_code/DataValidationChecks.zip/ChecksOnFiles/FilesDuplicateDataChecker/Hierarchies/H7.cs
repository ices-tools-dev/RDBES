﻿using FilesDuplicateDataChecker.Constranits;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Hierarchies
{
    internal class H7 : IHierarchy
    {
        public IDataConstraint[] DataConstraints => new IDataConstraint[]
            {
           new DE1(),
              

            new SD1(),
            new OS1(),
            new OS2(),
            new SA1(),
            new FM1(),
            new LE1(),
            new LE2(),
            new LE3(),
            new SS3(),
            new SS8(),
            new BV1()
            ,new BV2(),
            new BV3()
            };
    }
}
