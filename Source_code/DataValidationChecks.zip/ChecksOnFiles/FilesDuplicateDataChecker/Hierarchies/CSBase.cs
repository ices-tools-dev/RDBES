﻿using FilesDuplicateDataChecker.Constranits;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesDuplicateDataChecker.Hierarchies
{
    internal abstract class CSBase 
    {
        public IDataConstraint[] DataConstraints = new IDataConstraint[]{} ;

        public CSBase()
        {
           this.DataConstraints = new IDataConstraint[]
             {

            new DE1(),
            new SD1(),            
            new BV1(),
            new BV2(),
            new BV3()
             };
        }

      
    }
}
