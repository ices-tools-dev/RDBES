﻿using FilesDuplicateDataChecker.Checker;
using FilesDuplicateDataChecker.Constranits;
using FilesDuplicateDataChecker.Errors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Linq;

namespace FilesDuplicateDataChecker.Client
{
  public static class DuplicateClient
    {

        private static List<IDataConstraint> LoadAllConstraints(string hierarchcyName)
        {

            //var allConstraintsTypes = from t in Assembly
            //                                     .GetExecutingAssembly()
            //                                     .GetTypes()
            //                                     .Where(t =>  typeof(IDataConstraint).IsAssignableFrom(t) && t.IsClass)
            //                         select t;
            //List<IDataConstraint> allConcreateImplementaions=new List<IDataConstraint>();
            //foreach (var t in allConstraintsTypes)
            //{
            //    var con = (IDataConstraint)Activator.CreateInstance(t);
            //    allConcreateImplementaions.Add(con);
            //}


            //return allConcreateImplementaions;




            var hierarchiesClasses = from t in Assembly
                                                 .GetExecutingAssembly()
                                                 .GetTypes()
                                                 .Where(t => typeof(IHierarchy) != t && typeof(IHierarchy).IsAssignableFrom(t))
                                     select t;

            var foundHierarchy = hierarchiesClasses.Where(c => c.Name.EndsWith(hierarchcyName)).FirstOrDefault();
            if (foundHierarchy == null)
                throw new Exception($"No duplicate data rules are defined for hierarchy {hierarchcyName} ");

            return ((IHierarchy)Activator.CreateInstance(foundHierarchy) as IHierarchy).DataConstraints.ToList();

        }

        public static List<ConstraintError> GetDuplicateErrorsResult(string path,int maxErrors, string hierachyName)
        {



            List<ConstraintError> allErrors = new List<ConstraintError>();


            List<IDataConstraint> constrains = LoadAllConstraints(hierachyName.ToUpper());

            var builder = new DataElementsBuilder(path);
            DuplicateDataFinder duplicateFinder = new DuplicateDataFinder(path);

            int foundError = 0;
            foreach (var con in constrains)
            {
                
                var items = builder.BuildDataItems(con);

                int findMaxError = maxErrors - foundError;

                var errors = duplicateFinder.BuildErrorResult(items, constrains, findMaxError);
              
                allErrors.AddRange(errors);


                foundError = allErrors.SelectMany(r => r.DuplicateGroupsUnderParent).SelectMany(p => p.DuplicateGroups).SelectMany(g => g.DataLines).Count();

                if (foundError < maxErrors) continue;
                else break;
                
               



            }







            //    return duplicateFinder.BuildErrorResult(allDataItems, constrains, maxErrors);

            return allErrors;  


        }

    }
}
