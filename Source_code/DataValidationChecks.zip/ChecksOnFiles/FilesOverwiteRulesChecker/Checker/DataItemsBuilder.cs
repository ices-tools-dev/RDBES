﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace FilesOverwiteRulesChecker.Checker
{

    internal  class DataItemsBuilder
    {


        private readonly string pathToXml = string.Empty;
        private readonly XDocument document;
        private readonly IHierarchy hierarchy;
        private readonly List<DataItem> dataItems;
        private int keyFiledsCounter = 0;
        public DataItemsBuilder(string pathToXml,IHierarchy hierarchy )
        {
            this.pathToXml = pathToXml;
            this.document = XDocument.Load(pathToXml);
            this.hierarchy = hierarchy;
            this.dataItems = new List<DataItem>();

        }

         
       
        public List<DataItem> BuildDataItems()
        {
            SetFiledsCounter();
            using (XmlReader reader = XmlReader.Create(this.pathToXml))
            {
                reader.MoveToContent();             
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element)
                    {
                        string ln = reader.GetAttribute("ln");
                        var foundStartTag = this.hierarchy.startFromDataType.ToString().Equals(reader.Name);
                        if (foundStartTag)
                        {
                          
                                var resSet = GetDataItem(ln);
                                if (resSet != null)
                                    dataItems.AddRange(resSet);
                            
                        }
                    }
                }
            }

            return dataItems;
        }

        private List<DataItem> GetDataItem(string ln)
        {

            List<DataItem> items = new List<DataItem>();

            var el = this.document.Descendants(this.hierarchy.startFromDataType.ToString())
                .Where(e => e.Attribute("ln").Value.Equals(ln)).First();

            var leastConstraint = hierarchy.DataConstraints[hierarchy.DataConstraints.Length - 1];
            var leastChildres = el.Descendants(leastConstraint.DataTable.RecordType.ToString()).ToList();
            foreach (var child in leastChildres)
            {

                var item = new DataItem
                {
                    ParentsLineNumbers = new List<KeyValuePair<string, string>>()
                };

                string[] Lastkey = new string[keyFiledsCounter];
                var previousKeyCounts = 0;

                foreach (var constraint in hierarchy.DataConstraints)
                {

                    var parents = child.AncestorsAndSelf(constraint.DataTable.RecordType.ToString());
                    var keyCount = constraint.KeyFields.Length;

                    foreach (var parent in parents)
                    {
                        for (int i = 0; i < keyCount; i++)
                        {
                            var childElement = parent.Element(constraint.DataTable.Allfields[constraint.KeyFields[i]]);
                            if (childElement == null) throw new Exception(" Element '" + constraint.DataTable.Allfields[constraint.KeyFields[i]] + "' is part of OverwirteConstraintKey but not found in xml");
                            Lastkey[i + previousKeyCounts] = (string)childElement.Value;

                        }
                        previousKeyCounts += keyCount;

                        KeyValuePair<string, string> parentLineNumber = new KeyValuePair<string, string>(parent.Name.ToString(), parent.Attribute("ln").Value);
                        item.ParentsLineNumbers.Add(parentLineNumber);
                    }
                }
                    item.Element = child;
                    item.Key = string.Concat(Lastkey);
                    item.KeyData = Lastkey;
                

                items.Add(item);
            }
            return items;

        }

        private void SetFiledsCounter()
        {
            foreach (var item in hierarchy.DataConstraints)
            {
                keyFiledsCounter += item.KeyFields.Length;
            }
        }
    }
}


    


