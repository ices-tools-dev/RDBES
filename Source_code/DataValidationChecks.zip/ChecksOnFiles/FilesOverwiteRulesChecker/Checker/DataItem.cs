﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace FilesOverwiteRulesChecker.Checker
{
    internal class DataItem
    {
        public string Key { get; set; }
        public string[] KeyData { get; set; }
        public XElement Element { get; set; }
        //public string ConstraintName { get; set; }
        public List<KeyValuePair<string,string>> ParentsLineNumbers { get; set; }
    }
}
