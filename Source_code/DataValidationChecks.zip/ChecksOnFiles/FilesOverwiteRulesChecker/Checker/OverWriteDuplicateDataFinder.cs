﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using FilesOverwiteRulesChecker.Errors;

namespace FilesOverwiteRulesChecker.Checker
{
    internal class OverWriteDuplicateDataFinder
    {
       
        public OverWriteDuplicateDataFinder() 
        {
       
        }    

        public OverWriteErrorContainer BuildErrorResult(List<DataItem> allDataItems, IHierarchy hierarchy, int maxErrors)
        {
            int errorsFound = 0;


            var errorContainer = new OverWriteErrorContainer();
            errorContainer.KeyFields = GetKeyFiledsFromHierarchy(hierarchy);
          
            List<DuplicateGroup> duplicateGroups = new List<DuplicateGroup>();
            errorContainer.DuplicateGroups = duplicateGroups;


            var groupByKey = allDataItems.GroupBy(g => g.Key);
         
           
            foreach (var grp in groupByKey)
            {
                if (grp.Count() > 1)
                {
                    var elements = grp.ToList();

                    var duplicateGroup = new DuplicateGroup();                 
                    
                    var keyLinesGroups  =  new List<KeyLineGroup>();
                     
                    
                    foreach (var ele in elements)
                    {
                        var keyLinesGroup = new KeyLineGroup();


                        var keyLines = new List<KeyLine>();
                        foreach (var pln in ele.ParentsLineNumbers)
                        {
                            KeyLine keyLine = new KeyLine();
                            keyLine.DataType = pln.Key;
                            keyLine.LineNumber = pln.Value;


                            keyLines.Add(keyLine);
                           
                        }
                        keyLinesGroup.KeyLines = keyLines;


                        keyLinesGroups.Add(keyLinesGroup);
                    }
                    var dataLine = grp.First().KeyData;
                    duplicateGroup.KeyDataLine = string.Join(" | ", dataLine);
                    duplicateGroup.KeyLinesGroups = keyLinesGroups;
                    duplicateGroups.Add(duplicateGroup);
                }
               
            }
            return errorContainer;
        }



        private string GetKeyFiledsFromHierarchy(IHierarchy hierarchy) {
            List<string> Kyes = new List<string>();
            foreach (var constraint in hierarchy.DataConstraints)
            {
                var keyCount = constraint.KeyFields.Length;
                for (int i = 0; i < keyCount; i++)
                {
                   var key =  constraint.DataTable.Allfields[constraint.KeyFields[i]];
                    Kyes.Add(key);
                }

               
            }
           return string.Join(",", Kyes);

        }
    }
}
