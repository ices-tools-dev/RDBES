﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FilesOverwiteRulesChecker.Errors
{
    public class KeyLine
    {
        public string DataType { get; set; }
        public string LineNumber { get; set; }
    }
}
