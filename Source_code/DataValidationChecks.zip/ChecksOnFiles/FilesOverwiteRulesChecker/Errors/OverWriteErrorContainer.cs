﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FilesOverwiteRulesChecker.Errors
{
    public class OverWriteErrorContainer
    {
        
        public string KeyFields { get; set; }
        public List<DuplicateGroup> DuplicateGroups { get; set; }
    }

   
   
    
}
