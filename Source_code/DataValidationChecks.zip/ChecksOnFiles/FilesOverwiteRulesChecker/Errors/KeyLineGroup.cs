﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FilesOverwiteRulesChecker.Errors
{
    public class KeyLineGroup
    {
        public List<KeyLine> KeyLines { get; set; }
    }
}
