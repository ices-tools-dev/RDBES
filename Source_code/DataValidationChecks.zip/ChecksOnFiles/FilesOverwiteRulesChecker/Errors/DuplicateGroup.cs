﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FilesOverwiteRulesChecker.Errors
{
    public class DuplicateGroup
    {
        public string KeyDataLine { get; set; }

        public List<KeyLineGroup> KeyLinesGroups { get; set; }

    }
}
