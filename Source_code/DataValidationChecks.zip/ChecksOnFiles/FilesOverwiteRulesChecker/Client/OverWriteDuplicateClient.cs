﻿using FilesOverwiteRulesChecker.Checker;

using FilesOverwiteRulesChecker.Errors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace FilesOverwiteRulesChecker.Client
{
  public static class OverWriteDuplicateClient
    {

        private static IHierarchy LoadHierarchy(string hierarchcyName)
        {
            var hierarchiesForOverwrites = new string[] { "H1", "H2", "H3", "H4", "H5", "H6", "H7", "H8", "H9", "H10", "H11", "H12", "H13" };
            if (!hierarchiesForOverwrites.Contains(hierarchcyName))
                throw new Exception($"No Overwrite rules are defined for hierarchy {hierarchcyName} ");

            var baseHierarchy = "CS";


            var hierarchiesClasses = from t in Assembly
                                     .GetExecutingAssembly()
                                     .GetTypes()
                                     .Where(t => typeof(IHierarchy) != t && typeof(IHierarchy).IsAssignableFrom(t))
                                     select t;

            var foundHierarchy =  hierarchiesClasses.Where(c => c.Name.EndsWith(baseHierarchy)).FirstOrDefault();
            if (foundHierarchy == null) throw new Exception($"No Overwrite rules are defined for hierarchy {hierarchcyName} ");

            return (IHierarchy)Activator.CreateInstance(foundHierarchy) as IHierarchy;
        }

        public static OverWriteErrorContainer GetOverwriteErrorsResult(string path,int maxErrors,string hierachyName)
        {
          
            IHierarchy hierarchy = LoadHierarchy(hierachyName);
            DataItemsBuilder builder = new DataItemsBuilder(path, hierarchy);
            List<DataItem> allDataItems = builder.BuildDataItems();

            OverWriteDuplicateDataFinder duplicateFinder = new OverWriteDuplicateDataFinder();

            
            return duplicateFinder.BuildErrorResult(allDataItems, hierarchy, maxErrors);


        }

       

    }
}
