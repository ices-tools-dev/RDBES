﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using ResCommon;
using TypeDefinitions.RecordTypes.Records;

namespace FilesOverwiteRulesChecker.Constranits
{
     internal class DE1 : IDataConstraint
    {
        public IDataRecordType DataTable => new DE();

        public int[] KeyFields => new int[] { 2, 4, 5,7 };

        
    }
}
