﻿using System;
using System.Collections.Generic;
using System.Text;
using TypeDefinitions.RecordTypes;
using TypeDefinitions.RecordTypes.Records;
using ResCommon;
namespace FilesOverwiteRulesChecker.Constranits
{
    internal class SD1 : IDataConstraint
    {
        public  int[] KeyFields =>  new int[] { 2,3 }; 
        public IDataRecordType DataTable => new SD();
        

        
    }

   
}
