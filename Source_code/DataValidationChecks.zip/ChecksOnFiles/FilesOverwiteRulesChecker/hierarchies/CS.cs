﻿using System;
using System.Collections.Generic;
using System.Text;
using FilesOverwiteRulesChecker.Constranits;
using ResCommon;

namespace FilesOverwiteRulesChecker.hierarchies
{
   internal  class CS: IHierarchy
    {
        public IDataConstraint[] DataConstraints => new IDataConstraint[]
        {
            new DE1(),
            new SD1()
        };

        public Utility.RecordType startFromDataType { get { return Utility.RecordType.DE; } }
    }
}
