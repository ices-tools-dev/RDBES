﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace FilesOverwiteRulesChecker
{
    internal interface IHierarchy
    {
        IDataConstraint[] DataConstraints { get; }
        Utility.RecordType startFromDataType { get; }
    
    }
}
