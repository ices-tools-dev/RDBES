﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HierarchyValidation.HierarchyCheck
{
    public class HierarchyCheckErro
    {
     public string LineNo { get; set; }
     public string Error { get; set; }

    }
}
