﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace HierarchyValidation
{
  public  interface IValidation 
    {
        bool IsValid { get; set; }
        void Validate();
    }
}
