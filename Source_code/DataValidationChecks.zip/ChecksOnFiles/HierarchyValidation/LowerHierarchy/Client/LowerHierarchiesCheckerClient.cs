﻿using HierarchyValidation.HierarchyCheck;
using HierarchyValidation.LowerHierarchy.Hierarchies;
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace HierarchyValidation.LowerHierarchy.Client
{
  public static  class LowerHierarchiesCheckerClient
    {

        public static List<LowerHierarchyValidationInfo> GetLowerHierarchiesValidationInfo(XDocument document)
        {
            List<LowerHierarchyValidationInfo> LowerHierarchiesValidationInfo = new List<LowerHierarchyValidationInfo>();

            var lhiA = new CheckerA(Utility.LowerHierarchy.A,document).GetLowerHierarchyInfo();
            var lhiB = new CheckerB(Utility.LowerHierarchy.B, document).GetLowerHierarchyInfo();
            var lhiC = new CheckerC(Utility.LowerHierarchy.C, document).GetLowerHierarchyInfo();
            var lhiD = new CheckerD(Utility.LowerHierarchy.D, document).GetLowerHierarchyInfo();


            LowerHierarchiesValidationInfo.Add(lhiA);
            LowerHierarchiesValidationInfo.Add(lhiB);
            LowerHierarchiesValidationInfo.Add(lhiC);
            LowerHierarchiesValidationInfo.Add(lhiD);

            return LowerHierarchiesValidationInfo;
    }

}
}
