﻿using HierarchyValidation.HierarchyCheck;
using ResCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;


namespace HierarchyValidation.LowerHierarchy
{
    public abstract class BaseChecker
    {
        protected XDocument Document { get; set; }
        protected IEnumerable<XElement> LowerSAs;
        protected LowerHierarchyValidationInfo LowerHierarchyValidationInfo;
        protected readonly Utility.LowerHierarchy LowerHierarchy;
       

        protected List<LowerHierarchyValidationInfo> LowerHierarchiesInfo { get; set; }
        public  BaseChecker(Utility.LowerHierarchy lowerHierarchy, XDocument document){
            this.Document = document;
            this.LowerHierarchy = lowerHierarchy;
            this.LowerHierarchyValidationInfo = new LowerHierarchyValidationInfo
            {
                LowerHierarchyErrors = new List<HierarchyCheckErro>()
            };

        }

        protected abstract void SetUpLowerHierarchyMessage();
        protected abstract void SetUpLowerHierarchyErrors();
        
        public LowerHierarchyValidationInfo GetLowerHierarchyInfo() {
            this.SetLowerHierarchyElements();
            this.SetLowerHierarchyName();
            this.SetLowerHierarchyFound();

            // concreaetre implementation call
            this.SetUpLowerHierarchyMessage();
            // concreaetre implementation call
            this.SetUpLowerHierarchyErrors();

            return this.LowerHierarchyValidationInfo;
        }

        protected void SetLowerHierarchyElements()
        {
            var allSAs = from sa in this.Document.Descendants("SA") select sa;
            var allSAsForOfLowerHierarchy = from sa in allSAs
                                      where sa.Element("SAlowerHierarchy").Value.Trim().Equals(LowerHierarchy.ToString())
                                      select sa;
            this.LowerSAs = allSAsForOfLowerHierarchy;
        }
        protected void SetLowerHierarchyName()
        {
            this.LowerHierarchyValidationInfo.LowerHierarchy = this.LowerHierarchy.ToString();
        }
        protected void SetLowerHierarchyFound()
        {
            if (this.LowerSAs.LongCount() > 0)
                LowerHierarchyValidationInfo.HierarchyFound = true;
            else
                LowerHierarchyValidationInfo.HierarchyFound = false;
        }
       
    }
}
