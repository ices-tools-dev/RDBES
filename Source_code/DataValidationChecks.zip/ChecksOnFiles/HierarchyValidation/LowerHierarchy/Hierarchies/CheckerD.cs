﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HierarchyValidation.HierarchyCheck;
using ResCommon;

namespace HierarchyValidation.LowerHierarchy.Hierarchies
{
    public class CheckerD : BaseChecker
    {
        public CheckerD(Utility.LowerHierarchy lowerHierarchy, XDocument document) : base(lowerHierarchy, document)
        { }

        protected override void SetUpLowerHierarchyMessage() {
            this.LowerHierarchyValidationInfo.Message = "Lower hierarchy D: no elements are allowed under SA ";
        }


        protected override void SetUpLowerHierarchyErrors()
        {



            //var allNonAllowed = from e in this.LowerSAs.Elements()
            //                    where !(e.Name.ToString().Substring(0, 2).Equals("SA"))
            //                    select e;
            //foreach (var e in allNonAllowed)
            //{
            //    this.LowerHierarchyValidationInfo.LowerHierarchyErrors.Add(new HierarchyCheckErro()
            //    {
            //        LineNo = e.Parent.Attribute("ln").Value,
            //        Error = "element " + e.Name + " is not allowed under SA record"
            //    });



            //}

            //if (allNonAllowed.LongCount() == 0)
            //    this.LowerHierarchyValidationInfo.IsValid = true;
            //else
            //    this.LowerHierarchyValidationInfo.IsValid = false;


            this.LowerHierarchyValidationInfo.IsValid = true;
        }
    }
}
