﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HierarchyValidation.HierarchyCheck;
using ResCommon;

namespace HierarchyValidation.LowerHierarchy.Hierarchies
{
    public class CheckerB : BaseChecker
    {
        public CheckerB(Utility.LowerHierarchy lowerHierarchy, XDocument document) : base(lowerHierarchy, document)
        { }

        protected override void SetUpLowerHierarchyMessage() {
            this.LowerHierarchyValidationInfo.Message = "Lower hierarchy B: only FM elements are allowed under SA ";
        }
       
       
    protected override void SetUpLowerHierarchyErrors()
    {
          

            var notOccursAtLeastOnce = from e in this.LowerSAs
                                       where !e.Elements("FM").Any()
                                       select e;

            foreach (var e in notOccursAtLeastOnce)
            {
                this.LowerHierarchyValidationInfo.LowerHierarchyErrors.Add(new HierarchyCheckErro()
                {
                    LineNo = e.Attribute("ln").Value,
                    Error = " There must exists at least one FM element under SA record"
                });

            }

            var NoBvAllowedUndertheSA = from e in this.LowerSAs.Descendants("BV")
                                       
                                       select e;

            foreach (var e in NoBvAllowedUndertheSA)
            {
                this.LowerHierarchyValidationInfo.LowerHierarchyErrors.Add(new HierarchyCheckErro()
                {
                    LineNo = e.Attribute("ln").Value,
                    Error = " BV records are not allowed under the Sa record for lower hierarchy type B"
                });

            }

            //There should be no Bv record

            //var allNonAllowed = from e in this.LowerSAs.Elements()
            //                    where !(e.Name.ToString().Substring(0, 2).Equals("FM") 
            //                    || e.Name.ToString().Substring(0, 2).Equals("SA"))
            //                    select e;
            //foreach (var e in allNonAllowed)
            //{
            //    this.LowerHierarchyValidationInfo.LowerHierarchyErrors.Add(new HierarchyCheckErro()
            //    {
            //        LineNo = e.Parent.Attribute("ln").Value,
            //        Error = "element " + e.Name + " is not allowed under SA record"
            //    });



            //}

            if ( notOccursAtLeastOnce.LongCount() == 0)
                //if (allNonAllowed.LongCount() == 0 && notOccursAtLeastOnce.LongCount() == 0)
                this.LowerHierarchyValidationInfo.IsValid = true;
            else
                this.LowerHierarchyValidationInfo.IsValid = false;

            

        }
    }
}
