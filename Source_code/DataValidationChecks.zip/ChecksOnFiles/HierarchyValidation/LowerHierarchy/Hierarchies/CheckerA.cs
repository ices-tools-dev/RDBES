﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HierarchyValidation.HierarchyCheck;
using ResCommon;

namespace HierarchyValidation.LowerHierarchy.Hierarchies
{
    public class CheckerA : BaseChecker
    {
        public CheckerA(Utility.LowerHierarchy lowerHierarchy,XDocument document) : base(lowerHierarchy,document)
        { }

        protected override void SetUpLowerHierarchyMessage() {
            this.LowerHierarchyValidationInfo.Message = "Lower hierarchy A checks";
        }
        protected override void SetUpLowerHierarchyErrors()
        {


            var fmNotOccursAtLeastOnce = from e in this.LowerSAs
                                         where !e.Elements("FM").Any()
                                         select e;

            foreach (var e in fmNotOccursAtLeastOnce)
            {
                this.LowerHierarchyValidationInfo.LowerHierarchyErrors.Add(new HierarchyCheckErro()
                {
                    LineNo = e.Attribute("ln").Value,
                    Error = " At least one FM element is missing under SA record"
                });

            }
         //  var ParentSaLineNumber = this.LowerSAs.First().Attribute("ln").Value.ToString();

            // 2019 10 01 : comment this code to work with what David wanted to submit by not having BV under FM

            //var bvNotOccursAtLeastOnceUnderFM = from e in this.LowerSAs.Elements("FM")
            //                                    where !e.Elements("BV").Any()
            //                                    select e;

            //At least one of the FM must have a BV record

            foreach (var SA in LowerSAs)

            {
                //Is there any child Bv of an FM in the Sa children?
                var ParentFM_of_BV = SA.Descendants("BV").Select(bv => new {
                    ParentLineNumber = bv.Parent.Attribute("ln").Value.ToString(),
                    ParentRecordType = bv.Parent.Name
                }
               ).Where( p=> p.ParentRecordType=="FM").FirstOrDefault();


                if (ParentFM_of_BV == null)
                    this.LowerHierarchyValidationInfo.LowerHierarchyErrors.Add(new HierarchyCheckErro()
                    {

                        LineNo = SA.Attribute("ln").Value.ToString(),
                        Error = " At least 1 of the FM records under this SA record emust have a BV"
                    });
            }




            //if (allNonAllowed.LongCount() == 0 && fmNotOccursAtLeastOnce.LongCount() == 0)

            //    if (allNonAllowed.LongCount() == 0 && fmNotOccursAtLeastOnce.LongCount() == 0
            //        && bvNotOccursAtLeastOnceUnderFM.LongCount() == 0)

                    if (fmNotOccursAtLeastOnce.LongCount() == 0)
                  // && bvNotOccursAtLeastOnceUnderFM.LongCount() == 0)
                        this.LowerHierarchyValidationInfo.IsValid = true;
                    else
                        this.LowerHierarchyValidationInfo.IsValid = false;


        }
    }
}
