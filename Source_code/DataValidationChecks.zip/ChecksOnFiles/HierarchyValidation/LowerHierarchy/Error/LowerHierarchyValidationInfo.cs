﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HierarchyValidation.HierarchyCheck
{
    public class LowerHierarchyValidationInfo 
    {

        public bool IsValid { get; set; }
        public bool HierarchyFound { get; set; }
        public string Message { get; set; }
        public string LowerHierarchy { get; set; }
        public List<HierarchyCheckErro> LowerHierarchyErrors { get; set; }

    }
}
