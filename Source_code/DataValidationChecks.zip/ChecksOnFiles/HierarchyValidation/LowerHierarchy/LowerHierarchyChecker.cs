﻿using HierarchyValidation.LowerHierarchy;
using HierarchyValidation.LowerHierarchy.Client;
using HierarchyValidation.LowerHierarchy.Hierarchies;
using ResCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HierarchyValidation.HierarchyCheck
{
    public class LowerHierarchyChecker : IValidation
    {
        
        

        private XDocument Document { get; set; }
        public List<LowerHierarchyValidationInfo> LowerHierarchiesValidationInfo { get; set; }


        public LowerHierarchyChecker(XDocument _Document)
        {
            this.Document = _Document;
            this.LowerHierarchiesValidationInfo = new List<LowerHierarchyValidationInfo>();
            
        }
        public bool IsValid { get; set; }
        public void Validate()
        {

            this.LowerHierarchiesValidationInfo =  LowerHierarchiesCheckerClient.GetLowerHierarchiesValidationInfo(this.Document);
            this.IsValid = this.LowerHierarchiesValidationInfo.All(i => i.IsValid == true);



          
        }

        
    
    
    
    }
}
