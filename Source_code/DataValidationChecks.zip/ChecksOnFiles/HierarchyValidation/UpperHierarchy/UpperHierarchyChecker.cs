﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HierarchyValidation.HierarchyCheck
{
 public   class UpperHierarchyChecker : IValidation
    {
        public UpperHierarchyChecker(string _UpperHierarchy, XDocument _Document) {
            this.Document = _Document;
            this.UpperHierarchy = _UpperHierarchy;
            
            
            
            this.UpperHierarchyErrors = new List<HierarchyCheckErro>();

        }
        private string UpperHierarchy { get; set; }
        
        private XDocument Document { get; set; }

        public bool IsValid { get; set; }        
        public List<HierarchyCheckErro> UpperHierarchyErrors { get; set; }

        public void Validate()
        {
           
            var invalidDEs = from d in Document.Descendants("DE")
                             where !d.Element("DEhierarchy").Value.Trim().Equals(UpperHierarchy)
                             select d;
            //var invalidSAs = from d in Document.Descendants("SA")
            //                 where !d.Element("SAlowerHierarchy").Value.Equals(LowerHierarchy)
            //                 select d;



            foreach (var de in invalidDEs)
            {
               this.UpperHierarchyErrors.Add(new HierarchyCheckErro() { 
                   LineNo = de.Attribute("ln").Value, 
                   Error = de.Element("DEhierarchy").Value });
            }
            //foreach (var sa in invalidSAs)
            //{
            //    this.LowerHierarchyErrors.Add(new HierarchyCheckErro() { LineNo = sa.Attribute("ln").Value, Error = sa.Element("SAlowerHierarchy").Value });
            //}

            if (invalidDEs.LongCount() > 0 )                 
                this.IsValid = false;
           else this.IsValid = true;

           


        }
    }

   
    

   

}
