﻿
//using InValidClustring.Builder;
//using InValidClustring.Errors;
//using ResData.Models.KeyLessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
//using ResData.Data;
//using InValidClustring.ErrorsFinder;
using static ResCommon.Utility;
//using InValidClustring.Constranits;

namespace InValidClustring
{
  public  class InvalidClustringValidator: IInvalidClustringValidator
    {
    
        public InvalidClustringValidator() {
            
         
        }
     

        public  List<ErrorLine> GetValidationResult(string path,int maxErrors)
        {
            List<DataItem> dataItems = new List<DataItem>();
            var constraintsChecks = Settings.ConstraintsChecks();

            var builder = new DataItemsBuilder(path);
            foreach (var check in constraintsChecks)
            {

                var items = builder.BuildDataItmes(check);
                dataItems.AddRange(items);

            }

            var invalidClusteringCombinations = Settings.InvalidClustringCombinations();
            var errorsFinder = new ValidationErrorsFinder(dataItems, invalidClusteringCombinations);
            return errorsFinder.BuildErrors(maxErrors);

        }


        


    }
}
