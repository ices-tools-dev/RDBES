﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace InValidClustring
{
    internal static class Settings
    {

       


        internal static Dictionary<string, string[]> InvalidClustringCombinations()
        {
            Dictionary<string, string[]> InvalidClustringDic = new Dictionary<string, string[]>() {
                { "Y", new string[] { "1C", "2C" } },
                { "N", new string[] { "S1C", "S2C", "1CS", "2CS" } }
            };

            return InvalidClustringDic;
        }




        internal static List<IInvalidCustringCheck> ConstraintsChecks()
        {

            var constraints = new List<IInvalidCustringCheck>();
            var foundConstraintsClasses = from t in Assembly
                                     .GetExecutingAssembly()
                                     .GetTypes()
                                     .Where(t => typeof(IInvalidCustringCheck) != t && typeof(IInvalidCustringCheck).IsAssignableFrom(t))
                                          select t;



            if (foundConstraintsClasses.Count() == 0) throw new Exception("no constraints found for IInvalidCustringCheck check");
            foreach (var item in foundConstraintsClasses)
            {
                var check = (IInvalidCustringCheck)Activator.CreateInstance(item) as IInvalidCustringCheck;

                constraints.Add(check);
            }

            return constraints;
        }

    }
}
