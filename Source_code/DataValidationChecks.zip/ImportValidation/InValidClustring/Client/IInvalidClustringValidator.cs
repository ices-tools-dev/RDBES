﻿//using InValidClustring.Errors;
using System;
using System.Collections.Generic;
using System.Text;

namespace InValidClustring
{
  public  interface IInvalidClustringValidator
    {
        List<ErrorLine> GetValidationResult(string path,int maxErrors);
    }
}
