﻿
//using InValidClustring.Constranits;
using ResCommon;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace InValidClustring
{

    internal  class DataItemsBuilder
    {


        private readonly string pathToXml = string.Empty;
      
        
        public DataItemsBuilder(string pathToXml)
        {
            this.pathToXml = pathToXml;           
          

        }



        public List<DataItem> BuildDataItmes(IInvalidCustringCheck check)
        {


            List<DataItem> dataItems = new List<DataItem>();
             
            using (XmlReader reader = XmlReader.Create(this.pathToXml))
            {
                reader.MoveToContent();

               
                while (reader.ReadToFollowing(check.RecordType.ToString()))
                {
                    //var name = reader.Name;
                    //var checkFound = checks.ContainsKey(name);
                    
                    //if (checkFound)
                    //{
                    //        var check = checks[name];                        
                            string ln = reader.GetAttribute("ln");
                            var currentNodeReader = reader.ReadSubtree();
                            var dataItem = CreateDataItem(check, currentNodeReader, ln);
                            dataItems.Add(dataItem);
                        
                    //}
                }
            }


            return dataItems;
        }
        private DataItem CreateDataItem(IInvalidCustringCheck check, XmlReader reader, string ln)
        {

            var res = GetFieldValues(check, reader);

            var dataItem = new DataItem
            {
                LN =Convert.ToInt32(ln),
                InvalidCustringCheck = check,
                StratificationFieldValue = res.ContainsKey(check.StratificationField) ? !string.IsNullOrWhiteSpace(res[check.StratificationField])? res[check.StratificationField]:null : null,
                ClustringFieldValue = res.ContainsKey(check.ClustringField) ? !string.IsNullOrWhiteSpace(res[check.ClustringField]) ? res[check.ClustringField] : null : null
            };

            return dataItem;


        }
        private Dictionary<string, string> GetFieldValues(IInvalidCustringCheck check, XmlReader reader)
        {
            var res = new Dictionary<string, string>
            {
                
            };
            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element)
                {
                    var name = reader.Name;
                    if (name.Equals(check.StratificationField) || name.Equals(check.ClustringField)) 
                    {
                        var val = reader.ReadString();
                        res.Add(name, val);
                    }
                }

            }
            return res;
        }


    }
}


    


