﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace InValidClustring
{
    internal class DataItem
    {
        public int LN { get; set; }        
        public string StratificationFieldValue { get; set; }
        public string ClustringFieldValue { get; set; }
        
        public IInvalidCustringCheck InvalidCustringCheck { get; set; }
    }
}
