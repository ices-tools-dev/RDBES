﻿//using InValidClustring.Errors;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
//using InValidClustring.Builder;

namespace InValidClustring
{
    internal class ValidationErrorsFinder
    {
        
        private List<DataItem> allDataItems;
        private Dictionary<string,string[]> invalidClustringDic = new Dictionary<string, string[]>() {
               
            };

        public ValidationErrorsFinder(List<DataItem> allDataItems, Dictionary<string, string[]> invalidClustringDic)
        {
            
            
            this.allDataItems = allDataItems;
            this.invalidClustringDic = invalidClustringDic;
        }
      
        public List<ErrorLine> BuildErrors(int maxErrors)
        {
          
           
            List<ErrorLine> errors = new List<ErrorLine>();

             

            foreach (var item in allDataItems)
            {
                var error = GetError(item);
                if (error != null)
                {
                    errors.Add(error);
                }
            }



            return errors;
        }
        private ErrorLine GetError(DataItem dataItem)
        {

            ErrorLine error = null;


            if (this.invalidClustringDic.ContainsKey(dataItem.StratificationFieldValue))
            {
                if (this.invalidClustringDic[dataItem.StratificationFieldValue].Contains(dataItem.ClustringFieldValue))
                {
                    error = new ErrorLine()
                    {
                        LN = dataItem.LN,
                        StratificationField = dataItem.InvalidCustringCheck.StratificationField,
                        StratificationValue = dataItem.StratificationFieldValue,
                        ClustringField = dataItem.InvalidCustringCheck.ClustringField,
                        ClustringValue = dataItem.ClustringFieldValue

                    };
                }
            }

            return error;
        }



    }





}
