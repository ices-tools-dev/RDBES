﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InValidClustring
{
   public class ErrorLine
    {
        public int LN { get; set; }
        public string StratificationValue { get; set; }
        public string ClustringValue { get; set; }
        public string StratificationField { get; set; }
        public string ClustringField { get; set; }
        // public string ErrorMessage { get; set; }
    }
}
