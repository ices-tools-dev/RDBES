﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace InValidClustring
{
    internal class OSInvalidClustringCheck : IInvalidCustringCheck
    {
        public Utility.RecordType RecordType => Utility.RecordType.OS;
        public string StratificationField => "OSstratification";
        public string ClustringField => "OSclustering";
        
    }
}
