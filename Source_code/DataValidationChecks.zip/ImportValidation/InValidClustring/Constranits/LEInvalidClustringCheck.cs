﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace InValidClustring
{
    internal class LEInvalidClustringCheck : IInvalidCustringCheck
    {
        public Utility.RecordType RecordType => Utility.RecordType.LE;
        public string StratificationField => "LEstratification";
        public string ClustringField => "LEclustering";
        
    }
}
