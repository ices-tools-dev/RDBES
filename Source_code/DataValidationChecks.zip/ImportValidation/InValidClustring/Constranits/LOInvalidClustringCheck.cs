﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace InValidClustring
{
    internal class LOInvalidClustringCheck : IInvalidCustringCheck
    {
        public Utility.RecordType RecordType => Utility.RecordType.LO;
        public string StratificationField => "LOstratification";
        public string ClustringField => "LOclustering";
       
    }
}
