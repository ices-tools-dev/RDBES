﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace InValidClustring
{
    internal class VSInvalidClustringCheck : IInvalidCustringCheck
    {
        public Utility.RecordType RecordType => Utility.RecordType.VS;
        public string StratificationField => "VSstratification";
        public string ClustringField => "VSclustering";
       
    }
}
