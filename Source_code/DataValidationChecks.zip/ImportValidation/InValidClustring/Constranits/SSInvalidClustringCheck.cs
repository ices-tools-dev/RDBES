﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace InValidClustring
{
    internal class SSInvalidClustringCheck : IInvalidCustringCheck
    {
        public Utility.RecordType RecordType => Utility.RecordType.SS;
        public string StratificationField => "SSstratification";
        public string ClustringField => "SSclustering";
       
    }
}
