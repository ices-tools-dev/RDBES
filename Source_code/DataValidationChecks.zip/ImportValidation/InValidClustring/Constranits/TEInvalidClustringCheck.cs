﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace InValidClustring
{
    internal class TEInvalidClustringCheck : IInvalidCustringCheck
    {
        public Utility.RecordType RecordType => Utility.RecordType.TE;
        public string StratificationField => "TEstratification";
        public string ClustringField => "TEclustering";
       
    }
}
