﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace InValidClustring
{
    internal class FTInvalidClustringCheck : IInvalidCustringCheck
    {
        public Utility.RecordType RecordType => Utility.RecordType.FT;
        public string StratificationField => "FTstratification";
        public string ClustringField => "FTclustering";
       
    }
}
