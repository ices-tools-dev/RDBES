﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace InValidClustring
{
    internal interface IInvalidCustringCheck
    {
        Utility.RecordType RecordType {  get;  }
        string StratificationField { get; }
        string ClustringField { get; }

      

        

    }
}
