﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace InValidClustring
{
    internal class FOInvalidClustringCheck : IInvalidCustringCheck
    {
        public Utility.RecordType RecordType => Utility.RecordType.FO;
        public string StratificationField => "FOstratification";
        public string ClustringField => "FOclustering";
      
    }
}
