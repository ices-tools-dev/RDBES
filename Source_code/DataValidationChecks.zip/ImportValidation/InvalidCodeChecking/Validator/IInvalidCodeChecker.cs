﻿//using InValidClustring.Errors;
using System;
using System.Collections.Generic;
using System.Text;

namespace InvalidCodeChecking
{
  public  interface IInvalidCodeChecker
    {
        List<ErrorLine> GetCheckingResult(string path,int maxErrors);
    }
}
