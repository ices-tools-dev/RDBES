﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace InvalidCodeChecking
{
    internal static class Settings
    {

       


       




        internal static List<IInvalidFieldCheck> InvalidFieldChecks()
        {

            var constraints = new List<IInvalidFieldCheck>();
            var foundConstraintsClasses = from t in Assembly
                                     .GetExecutingAssembly()
                                     .GetTypes()
                                     .Where(t => typeof(IInvalidFieldCheck) != t && typeof(IInvalidFieldCheck).IsAssignableFrom(t))
                                          select t;



            if (foundConstraintsClasses.Count() == 0) throw new Exception("no constraints found for IInvalidCustringCheck check");
            foreach (var item in foundConstraintsClasses)
            {
                var check = (IInvalidFieldCheck)Activator.CreateInstance(item) as IInvalidFieldCheck;

                constraints.Add(check);
            }

            return constraints;
        }

    }
}
