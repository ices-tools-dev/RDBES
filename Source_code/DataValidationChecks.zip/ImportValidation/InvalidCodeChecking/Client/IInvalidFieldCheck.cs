﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace InvalidCodeChecking
{
    internal interface IInvalidFieldCheck
    {
        Utility.RecordType RecordType {  get;  }
        string Field { get; }
        public List<string> InvalidValues { get; }






    }
}
