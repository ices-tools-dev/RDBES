﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace InvalidCodeChecking
{
    internal class CLCatchCategoryFieldCheck : IInvalidFieldCheck
    {
        public Utility.RecordType RecordType => Utility.RecordType.CL;
        public string Field => "CLcatchCategory";
        public List<string> InvalidValues => new List<string>() { "Dis", "Catch" };
        
      
    }
}
