﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InvalidCodeChecking
{
   public class ErrorLine
    {
        public int LN { get; set; }
        public string InvalidValue { get; set; }       
        public string InvalidField { get; set; }
        
    }
}
