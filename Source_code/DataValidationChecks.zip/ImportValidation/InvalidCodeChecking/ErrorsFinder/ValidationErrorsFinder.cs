﻿//using InValidClustring.Errors;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
//using InValidClustring.Builder;

namespace InvalidCodeChecking
{
    internal class ValidationErrorsFinder
    {
        
        private List<DataItem> allDataItems;


        public ValidationErrorsFinder(List<DataItem> allDataItems) => this.allDataItems = allDataItems;

        public List<ErrorLine> BuildErrors(int maxErrors)
        {
          
           
            var errors = new List<ErrorLine>();

             

            foreach (var item in this.allDataItems)
            {
                if (errors.Count >= maxErrors) break;
                var error = this.GetError(item);
                if (error != null)
                {
                    
                    errors.Add(error);
                    

                }

                
            }



            return errors;
        }
        private ErrorLine GetError(DataItem dataItem)
        {

            ErrorLine error = null;


            if (dataItem.InvalidFieldCheck.InvalidValues.Contains(dataItem.FieldValue))
            {
                
                    error = new ErrorLine()
                    {
                        LN = dataItem.LN,
                        InvalidField = dataItem.InvalidFieldCheck.Field,
                        InvalidValue = dataItem.FieldValue,
                        

                    };
                
            }

            return error;
        }



    }





}
