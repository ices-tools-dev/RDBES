﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace InvalidCodeChecking
{
    internal class DataItem
    {
        public int LN { get; set; }        
        public string FieldValue { get; set; }       
        public IInvalidFieldCheck InvalidFieldCheck { get; set; }
    }
}
