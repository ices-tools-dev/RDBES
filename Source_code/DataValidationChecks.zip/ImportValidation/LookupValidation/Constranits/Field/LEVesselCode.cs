﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation.Constranits.Field
{
    public class LEVesselCode : ILookupField
    {
        public string Field => "LEencryptedVesselCode";
        public Utility.RecordType DataType => Utility.RecordType.LE;

        public bool IsOptional => true;
    }
}
