﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation.Constranits.Field
{
    public class SSSpeciesName : ILookupField
    {
        public string Field => "SSspeciesListName";
        public Utility.RecordType DataType => Utility.RecordType.SS;

        public bool IsOptional => false;
    }
}
