﻿using System;
using System.Collections.Generic;
using System.Text;

using ResCommon;
namespace LookupValidation.Constranits.Field
{
    public class FTVesselCode : ILookupField
    {
        public string Field => "FTencryptedVesselCode";
        public Utility.RecordType DataType => Utility.RecordType.FT;

        public bool IsOptional => false;
    }

   
}
