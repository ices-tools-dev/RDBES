﻿using System;
using System.Collections.Generic;
using System.Text;

using ResCommon;

namespace LookupValidation.Constranits.Field
{
     public class VSVesselCode : ILookupField
    {
        public string Field => "VSencryptedVesselCode";
        public Utility.RecordType DataType => Utility.RecordType.VS;
        public bool IsOptional => false;

    }
}
