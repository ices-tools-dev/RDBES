﻿using LookupValidation.Constranits.Table;
using LookupValidation.Constranits.Field;
using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation.Constranits
{
    public class SSConstraint1 : IConstraint
    {
        public ILookupField LookupFeildConstraint => new SSSpeciesName();
        public ILookupTable LookupTableConstraint => new SpeciesName();
       
    }
}
