﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation.Constranits.Table
{
    public class VesselEcryptedCode : ILookupTable
    {
        public string Table => "VesselDetails";
        public string PrimaryKey => "VDid";
        public string CountryField => "VDcountry";
        public string YearField => "VDyear";
        public string CodeField => "VDencryptedVesselCode";
        public string CatchFractionField => "";

    }
}
