﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation.Constranits.Table
{
    public class SpeciesName : ILookupTable
    {
        public string Table => "SpeciesList";
        public string PrimaryKey => "SLid";
        public string CountryField => "SLcountry";
        public string YearField => "SLyear";
        public string CodeField => "SLspeciesListName";
        public string CatchFractionField => "SLcatchFraction";

    }
}
