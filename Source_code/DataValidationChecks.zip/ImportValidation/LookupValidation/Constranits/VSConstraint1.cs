﻿using LookupValidation.Constranits.Table;
using LookupValidation.Constranits.Field;
using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation.Constranits
{
    public class VSConstraint1 : IConstraint
    {
        public ILookupField LookupFeildConstraint => new VSVesselCode();
        public ILookupTable LookupTableConstraint => new VesselEcryptedCode();
      
    }
}
