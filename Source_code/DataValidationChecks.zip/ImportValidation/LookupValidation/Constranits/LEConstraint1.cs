﻿using LookupValidation.Constranits.Table;
using LookupValidation.Constranits.Field;
using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation.Constranits
{
    public class LEConstraint1 : IConstraint
    {
        public ILookupField LookupFeildConstraint => new LEVesselCode();
        public ILookupTable LookupTableConstraint => new VesselEcryptedCode();
        
    }
}
