﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation
{
    public interface IHierarchy
    {
        
      
        List<IConstraint> Constraints { get; }
    }
}
