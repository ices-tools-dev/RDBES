﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation
{
    public interface IDataItemsBuilder
    {
        List<DataItem> BuildDataItems(string pathToXml, IHierarchy hierarchy);
    }
}
