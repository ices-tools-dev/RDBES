﻿using System;

namespace LookupValidation
{
    public class Class1
    {
    }
}
