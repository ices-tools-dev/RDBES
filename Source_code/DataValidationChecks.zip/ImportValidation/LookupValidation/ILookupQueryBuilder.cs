﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation
{
   public interface ILookupQueryBuilder
    {
         string BuildQuery(List<DataItem> allDataItems);
    }
}
