﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation
{
    public interface ILookupTable
    {
        string Table { get;  }
        string PrimaryKey { get;  }
        string CountryField { get;  }
        string YearField { get;  }
        string CodeField { get;  }
        string CatchFractionField { get; }
    }
}
