﻿using LookupValidation.Client;

using ResData.Models.KeyLessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LookupValidation.Validator
{
    public class LookupErrorsFinder
    {
        private List<CodeLookup> codelookups;
        private List<DataItem> allDataItems;       
        List<CodeLookupError> codeLookupErrors;
        public LookupErrorsFinder(List<DataItem> allDataItems, List<CodeLookup> codeLookups)
        {
            this.codeLookupErrors = new List<CodeLookupError>();           
            this.allDataItems = allDataItems;
            this.codelookups = codeLookups;
        }

        public List<CodeLookupError> GetErrors(int maxErrors)
        {
            foreach (var item in this.allDataItems)
            {
                

                var codeLookup = this.codelookups.Where(c =>
                                       
                                        c.FieldName.Equals(item.Constraint.LookupTableConstraint.CodeField)
                                        &&
                                        c.DbTable.Equals(item.Constraint.LookupTableConstraint.Table)
                                        &&
                                        c.Code.Equals(item.CodeValue)
                                        &&
                                        c.Country.Equals(item.CountryValue)
                                        &&
                                        c.Year.Equals(item.YearValue)
                                        &&
                                        c.CatchFractionFieldValue.Equals(item.CatchFractionValue)
                                                ).FirstOrDefault();

                var idFound = true;

                if (codeLookup == null)
                {
                    idFound = false;
                }
                else
                {
                    if (codeLookup.Id == null)
                        idFound = false;
                }

                // id not found: report as Error
                if (!idFound)
                {


                    var datConsisErr = new CodeLookupError()
                    {
                        LN = item.LN,
                        Field = item.Constraint.LookupFeildConstraint.Field,
                        DataType = item.Constraint.LookupFeildConstraint.DataType.ToString(), 
                        CatchFractionField = "SScatchFraction", 


                        CodeValue = item.CodeValue,
                        CountryValue = item.CountryValue,
                        YearValue = item.YearValue,
                        CatchFractionValue = item.CatchFractionValue
                        
                         
                    };
                    if (this.codeLookupErrors.Count < maxErrors)
                        this.codeLookupErrors.Add(datConsisErr);
                    else
                        break;
                }


            }

            return this.codeLookupErrors;
        }
    }
}
