﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace LookupValidation
{
    public class DataItem
    {
        public string LN { get; set; }        
        public string CodeValue { get; set; }
        public string YearValue { get; set; }
        public string CountryValue { get; set; }
        public string CatchFractionValue { get; set; }
        public IConstraint Constraint { get; set; }
    }
}
