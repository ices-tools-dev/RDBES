﻿using ResData.Data;
using ResData.Models.KeyLessEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation.Client
{
    public interface ILookupValidator
    {
        List<CodeLookupError> GetLookupValidationResult(string path, string hierachyName,int maxErrors);
        List<CodeLookup> GetLookupCodes(string path, string hierachyName);
    }
}
