﻿

using LookupValidation.Client;
using ResData.Models.KeyLessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using ResData.Data;
using LookupValidation.Validator;
using LookupValidation.Builder;

namespace LookupValidation.Client
{
  public  class LookupValidator: ILookupValidator
    {
         ApplicationDbContext context;


        public LookupValidator(ApplicationDbContext context) {
            this.context = context;    
        }
      
       


       
      
        public List<CodeLookupError> GetLookupValidationResult(string path, string hierachyName,int maxErrors)
        {
             
                 
         
            List<DataItem> dataItems = GetItems(path, hierachyName);          

            var lookupBuilder = new LookupBuilder(dataItems);
            List<CodeLookup> lookupCodes = lookupBuilder.Build(context);

            LookupErrorsFinder consistencyChecker = new LookupErrorsFinder(dataItems, lookupCodes);
            return consistencyChecker.GetErrors(maxErrors);

        }
        public List<CodeLookup> GetLookupCodes(string path, string hierachyName)
        {
            

            List<DataItem> dataItems = GetItems(path, hierachyName);

            var lookupBuilder = new LookupBuilder(dataItems);
            List<CodeLookup> lookupCodes = lookupBuilder.Build(context);

            return lookupCodes;

        }

        private List<DataItem>  GetItems(string path, string hierachyName)
        {
            var hierarchy = LoadHierarchy(hierachyName);
            IDataItemsBuilder itemsBuilder = new DataItemsBuilder();
            List<DataItem> dataItems = itemsBuilder.BuildDataItems(path, hierarchy);
            var validDataItems = dataItems.Where(c => c.CodeValue != null).ToList();
            return validDataItems;
        }


        private static IHierarchy LoadHierarchy(string hierarchcyName)
        {
            var hierarchiesClasses = from t in Assembly
                                     .GetExecutingAssembly()
                                     .GetTypes()
                                     .Where(t => typeof(IHierarchy) != t && typeof(IHierarchy).IsAssignableFrom(t))
                                     select t;


            var foundHierarchy = hierarchiesClasses.Where(c => c.Name.EndsWith(hierarchcyName)).FirstOrDefault();
            if (foundHierarchy == null) throw new Exception("no hierarchy found with name that ends with '" + hierarchcyName + "'");

            return (IHierarchy)Activator.CreateInstance(foundHierarchy) as IHierarchy;
        }



    }
}
