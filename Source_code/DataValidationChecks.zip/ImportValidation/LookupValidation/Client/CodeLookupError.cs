﻿using System;
using System.Collections.Generic;
using System.Text;
using ResCommon;

namespace LookupValidation.Client
{
    public class CodeLookupError
    {
        public string LN { get; set; }
        public string Field { get; set; }
        public string CodeValue { get; set; }
        public string CountryValue { get; set; }

        public string YearValue { get; set; }
        public string CatchFractionField { get; set; }
        public string CatchFractionValue { get; set; }
        public string DataType { get; set; }
    }
}
