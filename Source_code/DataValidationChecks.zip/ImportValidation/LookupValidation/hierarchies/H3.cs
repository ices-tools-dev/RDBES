﻿using LookupValidation.Constranits;
using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation.hierarchies
{
    internal class H3 : IHierarchy
    {
        public List<IConstraint> Constraints => new List<IConstraint>() {
        new VSConstraint1(),
         new FTConstraint1(),
         new SSConstraint1()

        };
    }
}
