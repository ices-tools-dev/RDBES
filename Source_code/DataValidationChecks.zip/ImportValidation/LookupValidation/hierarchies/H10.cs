﻿using System;
using System.Collections.Generic;
using System.Text;
using LookupValidation.Constranits;

namespace LookupValidation.hierarchies
{
    internal class H10 : IHierarchy
    {
        public List<IConstraint> Constraints => new List<IConstraint>() {

        new VSConstraint1(),
            new FTConstraint1(),
            new SSConstraint1()
        };
    }
}
