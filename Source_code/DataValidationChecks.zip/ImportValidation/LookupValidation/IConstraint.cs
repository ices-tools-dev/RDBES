﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation
{
    public interface IConstraint  
    {
        ILookupField LookupFeildConstraint { get;  }
        ILookupTable LookupTableConstraint { get; }
      
    }
}
