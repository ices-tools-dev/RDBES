﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace LookupValidation
{
    public interface ILookupField
    {
        Utility.RecordType DataType { get;  }
        string Field { get;  }
        bool IsOptional { get; }
    }
}
