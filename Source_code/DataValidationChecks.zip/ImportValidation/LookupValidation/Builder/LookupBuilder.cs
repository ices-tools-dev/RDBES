﻿
using Microsoft.EntityFrameworkCore;
using ResData.Data;
using ResData.Models.KeyLessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LookupValidation.Builder
{
    internal  class LookupBuilder
    {
        private ILookupQueryBuilder lookupQueryBuilder;
        List<DataItem> allDataItems;
        public LookupBuilder(List<DataItem> allDataItems)
        {
             lookupQueryBuilder = new LookupQueryBuilder();
            this.allDataItems = allDataItems;
           

        }
        public  List<CodeLookup> Build(ApplicationDbContext context)
        {
            var query = lookupQueryBuilder.BuildQuery(this.allDataItems);
            var res = context.CodeLookup.FromSqlRaw(query).ToList();

            return res;

        }
    }
}
