﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace LookupValidation.Builder

{

    internal  class DataItemsBuilder: IDataItemsBuilder
    {

        public DataItemsBuilder() { }
        
       private XDocument document;

        public List<DataItem> BuildDataItems(string pathToXml, IHierarchy hierarchy)
        {

           //  this.document = XDocument.Load(pathToXml);
           List<DataItem> dataItems = new List<DataItem>();
           document = XDocument.Load(pathToXml);


            using (XmlReader reader = XmlReader.Create(pathToXml))
            {
                reader.MoveToContent();
               while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element)
                    {
                        
                        var cons = hierarchy.Constraints.Where(c => c.LookupFeildConstraint.DataType.ToString().Equals(reader.Name));
                        string ln = reader.GetAttribute("ln");
                        foreach (var item in cons)
                        {
                            var itm = GetDataItem(item, ln);
                            if(itm!=null)
                            dataItems.Add(itm);
                        }
                        
                    }
                }
            }
            document = null;

            return dataItems;
        }

        private DataItem GetDataItem(IConstraint constraint,string ln)
        {
            var lookupField = constraint.LookupFeildConstraint;
            
            var el = this.document.Descendants(lookupField.DataType.ToString())
               .Where(e => e.Attribute("ln").Value.Equals(ln)).First();

            #region code
            string fieldValue = "";
            var fieldElement = el.Element(lookupField.Field);
            if (fieldElement == null) fieldValue = "";
            else
            {
                if (string.IsNullOrWhiteSpace(fieldElement.Value))
                    fieldValue = "";
                else
                    fieldValue = fieldElement.Value;
            }

            #endregion

            if(lookupField.IsOptional)
            {

                if (string.IsNullOrWhiteSpace(fieldValue)) return null;
            }


            #region catchfraction
            string catchfractionValue = "";
            var catchfractionElement = el.Element("SScatchFraction");
            if (catchfractionElement == null) catchfractionValue = "";
            else
            {
                if (string.IsNullOrWhiteSpace(catchfractionElement.Value))
                    catchfractionValue = "";
                else
                    catchfractionValue = catchfractionElement.Value;
            }

            #endregion

            #region country
            string countryValue = "";
            var countryMainElement = el.Ancestors("SD").FirstOrDefault();
            if (countryMainElement != null)
            {

                var countryElement = countryMainElement.Element("SDcountry");
                if (countryElement != null)
                    countryValue = countryElement.Value;
            }

            #endregion

            #region year
            string yearValue = "";
            var yearMainElement = el.Ancestors("DE").FirstOrDefault();
            if (yearMainElement != null)
            {
                var yearElement = yearMainElement.Element("DEyear");
                if (yearElement != null)
                {
                    yearValue = yearElement.Value;
                }
            }

            #endregion

            var res = new DataItem
            {
                LN = ln,
                CodeValue = fieldValue,
                CountryValue = countryValue,
                YearValue = yearValue,
                CatchFractionValue = catchfractionValue,
                Constraint = constraint
            };

            return res;

        }
        //private DataItem GetDataItem(IConstraint constraint, string ln)
        //{
        //    var lookupField = constraint.LookupFeildConstraint;
        //    var el = this.document.Descendants(lookupField.DataType.ToString())
        //       .Where(e => e.Attribute("ln").Value.Equals(ln)).First();

        //    #region code
        //    string fieldValue = null;
        //    var fieldElement = el.Element(lookupField.Field);
        //    if (fieldElement == null) fieldValue = null;
        //    else
        //    {
        //        if (string.IsNullOrWhiteSpace(fieldElement.Value))
        //            fieldValue = null;
        //        else
        //        fieldValue = fieldElement.Value;
        //    }

        //    #endregion

        //    #region country
        //    string countryValue = null;
        //    var countryMainElement = el.Ancestors("SD").FirstOrDefault();
        //    if (countryMainElement != null)
        //    {

        //        var countryElement = countryMainElement.Element("SDcountry");
        //        if (countryElement != null)
        //            countryValue = countryElement.Value;
        //    }

        //    #endregion

        //    #region year
        //    string yearValue = null;
        //    var yearMainElement = el.Ancestors("DE").FirstOrDefault();
        //    if (yearMainElement != null)
        //    {
        //        var yearElement = yearMainElement.Element("DEyear");
        //        if (yearElement != null)
        //        {
        //            yearValue = yearElement.Value;
        //        }
        //    }

        //    #endregion

        //    var res = new DataItem
        //    {
        //        LN = ln,
        //        CodeValue =fieldValue,
        //        CountryValue = countryValue,
        //        YearValue = yearValue,
        //        Constraint = constraint
        //    };

        //    return res;

        //}
    }
}


    


