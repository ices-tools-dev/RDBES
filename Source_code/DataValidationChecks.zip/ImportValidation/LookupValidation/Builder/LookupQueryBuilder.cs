﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using LookupValidation.Client;
using ResCommon;

namespace LookupValidation.Builder
{
    internal class LookupQueryBuilder: ILookupQueryBuilder
    {
       // private List<DataItem> allDataItems;
       
       

        public LookupQueryBuilder()
        {


        }
        public string BuildQuery(List<DataItem> allDataItems)
        {
          //  this.allDataItems = allDataItems;
            var sb = new StringBuilder();
            string tempTabName = "#temp_" + Guid.NewGuid().ToString().Replace("-", "_");
            sb.Append(CreateTableScript(tempTabName));
          
            var lookupConstraints = allDataItems.Select(i=>i.Constraint.LookupTableConstraint)                                                  
                                                  .GroupBy(c => new { c.CodeField, c.CountryField,c.YearField, c.PrimaryKey, c.Table, c.CatchFractionField })
                                                  .Select(c => c.Key)
                                                  .ToList();

            var lookupConstrantCounter = lookupConstraints.Count();
            foreach (var lookupCon in lookupConstraints)
            {
                lookupConstrantCounter--;
                var items = allDataItems
                    .Where(
                        r =>
                        r.Constraint.LookupTableConstraint.CodeField.Equals(lookupCon.CodeField)
                        &&
                        r.Constraint.LookupTableConstraint.CountryField.Equals(lookupCon.CountryField)
                        &&
                        r.Constraint.LookupTableConstraint.YearField.Equals(lookupCon.YearField)
                          &&
                        r.Constraint.LookupTableConstraint.PrimaryKey.Equals(lookupCon.PrimaryKey)
                        &&
                        r.Constraint.LookupTableConstraint.Table.Equals(lookupCon.Table)
                        &&
                        r.Constraint.LookupTableConstraint.CatchFractionField.Equals(lookupCon.CatchFractionField)
                        

                        ).ToList();

                var distinctCodesByTable = items.GroupBy(g => new { g.CodeValue,g.CountryValue,g.YearValue, g.CatchFractionValue });

                var counter = 0;
                foreach (var item in distinctCodesByTable)
                {
                    var key = item.Key;
                    if (key != null)
                    {
                        var idVariable = "id_" + lookupConstrantCounter.ToString() + "_" + counter.ToString();
                        sb.Append(IdFinderScript(idVariable,lookupCon.PrimaryKey,lookupCon.Table,lookupCon.CodeField,key.CodeValue, lookupCon.CountryField, key.CountryValue, lookupCon.YearField, key.YearValue, lookupCon.CatchFractionField, key.CatchFractionValue));
                        sb.Append(InsertToTableScript(tempTabName, idVariable, key.CodeValue, lookupCon.Table, lookupCon.CodeField,key.CountryValue,key.YearValue,lookupCon.CatchFractionField, key.CatchFractionValue));
                    }
                    counter++;
                }

            }

            sb.Append(SelectTableScript(tempTabName));
            sb.Append(DropTableScript(tempTabName));

            return sb.ToString();
        }

        //////private string DeclareCountryVariableScript(int countryId)
        //////{
        //////    return $" DECLARE @countryId int ={countryId} ";
        //////}

       
        private string SelectTableScript(string tabName)
        {
            
            return $" select * from {tabName} ";
        }
        private string DropTableScript(string tabName)
        {
            
            return $"drop table {tabName} ";
        }
        private string IdFinderScript(string idVariableVal, string primaryKeyField, string table, string codeField, string codeVal , string countryField,string countryVal,string yearField,string yearVal, string catchFractionField, string catchFractionVal)
        {
            
            var specificToSL = $" AND {catchFractionField} = (SELECT TOP 1 c.tblCodeID FROM tblCode c join tblCodeType t ON c.tblCodeTypeID = t.tblCodeTypeID WHERE t.CodeType = '{Utility.CodeType.CatchFraction.ToString()}' and c.Code='{catchFractionVal}')";
            
            if (table == "VesselDetails") specificToSL = "";

            string pkScript = $"{primaryKeyField} FROM {table}  WHERE {codeField} = '{codeVal}' AND {countryField} = (SELECT TOP 1 c.tblCodeID FROM tblCode c join tblCodeType t ON c.tblCodeTypeID = t.tblCodeTypeID WHERE t.CodeType = '{Utility.CodeType.ISO_3166.ToString()}' AND c.Code='{countryVal}') AND {yearField} = (SELECT TOP 1 c.tblCodeID FROM tblCode c join tblCodeType t ON c.tblCodeTypeID = t.tblCodeTypeID WHERE t.CodeType = '{Utility.CodeType.Year.ToString()}' AND c.Code='{yearVal}')  {specificToSL}  ";

            var sb = new StringBuilder();
            sb.Append($" declare @{idVariableVal} int = NULL ");
            sb.Append($" if (exists(select top 1 {pkScript})) ");
            sb.Append(" begin ");
            sb.Append($" select  top 1  @{idVariableVal} = {pkScript}");
            sb.Append(" end ");


            return sb.ToString();
        }

        private string CreateTableScript(string tabName)
        {

            return $" CREATE TABLE {tabName} (Id INT null,Code NVARCHAR(100),DbTable NVARCHAR(100),FieldName NVARCHAR(100),Country NVARCHAR(100),Year NVARCHAR(100),CatchFractionFieldName NVARCHAR(100),CatchFractionFieldValue NVARCHAR(100)) ";
        }
        private string InsertToTableScript(string tempTabName,string idVariableVal, string codeVal, string tableName, string codeFieldName,string country,string year, string catchFractionFieldName,string catchFractionFieldValue)
        {
            string selectQuery = $"insert into {tempTabName}  select @{idVariableVal} as Id, '{codeVal}' as Code,'{tableName}' as DbTable,'{codeFieldName}' as FieldName,'{country}' as Country, '{year}' as Year, '{catchFractionFieldName}' as CatchFractionFieldName, '{catchFractionFieldValue}' as  CatchFractionFieldValue ";
            return selectQuery;
        }
    }
}        
    

