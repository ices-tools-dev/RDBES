﻿using SubSampleValidation.Check;
using System;
using System.Collections.Generic;
using System.Text;

namespace SubSampleValidation.Errors
{
    public class SubSampleErrors
    {

        public  ISubSampleCheck CheckInfo { get; set; }
        
        public List<ErrorLine> DuplicateSampleNumberErrors { get; set; }
        public List<ErrorLine> ParentSampleNumberErrors { get; set; }

    }
}
    

    

