﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubSampleValidation.Errors
{
   public class ErrorLine
    {
        public string LN { get; set; }        
        public string SampleNumber { get; set; }

    }
}
