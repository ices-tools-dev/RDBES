﻿using SubSampleValidation.Errors;
using ResData.Data;
using System;
using System.Collections.Generic;
using System.Text;
using ResCommon;

namespace SubSampleValidation.Checker
{
    public interface ISubSampleChecker
    {
        SubSampleErrors Validate(string path,int maxErrors);
    }
}
