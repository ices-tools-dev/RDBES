﻿
using ResCommon;
using SubSampleValidation.Check;
using SubSampleValidation.Errors;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace SubSampleValidation.Checker
{

    public class SubSampleChecker : ISubSampleChecker
    {


        public SubSampleErrors Validate(string pathToXml, int maxErrors)
        {
            ISubSampleCheck subSampleCheck = new SubSampleCheck();

            var errors = new SubSampleErrors
            {
                CheckInfo = subSampleCheck,
                ParentSampleNumberErrors = new List<ErrorLine>(),
                DuplicateSampleNumberErrors = new List<ErrorLine>()
            };

            

            var dataItems = BuildDataItems(pathToXml, subSampleCheck);

            
            var allSequenceValues = dataItems.Where(d=>d.SequenceNumber!=null).Select(d => d.SequenceNumber);
          
            var allParentSequenceValuesWithLineInfo = dataItems.Where(d=>d.ParentSequenceNumber!=null).Select(d => new { ln =d.Ln , val = d.ParentSequenceNumber }).ToList();


            // values that are found in field 'parentSequenceNumber' but not in field 'SequenceNumber'
            var allParentSequenceWithNullParents = allParentSequenceValuesWithLineInfo.Where(f => !allSequenceValues.Any(p => p.Contains(f.val)));

            foreach (var item in allParentSequenceWithNullParents)
            {
                if (GetErrorCount(errors) >= maxErrors) break;
                errors.ParentSampleNumberErrors.Add(new ErrorLine() { LN = item.ln, SampleNumber = item.val });

            }


            // values that are not unique in field 'SequenceNumber'
            var duplicateSequenceNumbers = dataItems.Where(d => d.SequenceNumber != null).GroupBy(f => f.SequenceNumber).Where(g => g.Count() > 1);

            foreach (var group in duplicateSequenceNumbers)
            {
                

                var duplicateNumber = group.Key;
                foreach (var item in group)
                {
                    if (GetErrorCount(errors) >= maxErrors) break;
                    errors.DuplicateSampleNumberErrors.Add(new ErrorLine() { LN = item.Ln, SampleNumber = duplicateNumber });
                }

                if (GetErrorCount(errors) >= maxErrors) break;
            }


         //   document = null;
            return errors;
        }

        private int GetErrorCount(SubSampleErrors errors)
        {
            return errors.DuplicateSampleNumberErrors.Count() + errors.ParentSampleNumberErrors.Count();
        }

        private List<DataItem> BuildDataItems(string pathToXml, ISubSampleCheck subSampleCheck )
        {
            List<DataItem> dataItems;
            dataItems = new List<DataItem>();
            using (XmlReader reader = XmlReader.Create(pathToXml))
            {
                reader.MoveToContent();

                while (reader.ReadToFollowing(subSampleCheck.RecordType.ToString()))
                {
                    string ln = reader.GetAttribute("ln");
                    var dataItem = CreateDataItem(subSampleCheck, reader,ln);
                    dataItems.Add(dataItem);
                }

            }
            return dataItems;
        }
        private DataItem CreateDataItem(ISubSampleCheck check, XmlReader reader, string ln)
        {

            var res = GetFieldsValues(check, reader.ReadSubtree());

            var dataItem = new DataItem
            {
                Ln = ln,
                SequenceNumber = res.ContainsKey(check.PrincipalField) ? !string.IsNullOrWhiteSpace(res[check.PrincipalField]) ? res[check.PrincipalField] : null : null,
                ParentSequenceNumber = res.ContainsKey(check.DependentField) ? !string.IsNullOrWhiteSpace(res[check.DependentField]) ? res[check.DependentField] : null : null
            };

            return dataItem;


        }
        private Dictionary<string, string> GetFieldsValues(ISubSampleCheck check, XmlReader reader)
        {
            var res = new Dictionary<string, string>
            {

            };
            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element)
                {
                    var name = reader.Name;
                    if (name.Equals(check.PrincipalField) || name.Equals(check.DependentField))
                    {
                        var val = reader.ReadString();
                        res.Add(name, val);
                    }
                }

            }
            return res;
        }



    }
}


    


