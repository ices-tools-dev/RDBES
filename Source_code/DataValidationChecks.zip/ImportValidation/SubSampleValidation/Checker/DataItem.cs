﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubSampleValidation.Checker
{
    internal class DataItem
    {
        public string Ln { get; set; }
        public string SequenceNumber { get; set; }
        public string ParentSequenceNumber { get; set; }
    }
}
