﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace SubSampleValidation.Check
{
    public interface ISubSampleCheck
    {
        string RecordType { get; }
        string PrincipalField { get; }
        string DependentField { get; }



    }
}
