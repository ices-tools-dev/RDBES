﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace SubSampleValidation.Check
{
    public class SubSampleCheck : ISubSampleCheck
    {
        public string RecordType => Utility.RecordType.SA.ToString();

        public string PrincipalField => "SAsequenceNumber";

        public string DependentField => "SAparentSequenceNumber";
    }
}
