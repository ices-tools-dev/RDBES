﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace HierarchyDependentCheck.Builder
{
    public class DataItem
    {
        public string LN { get; set; }        
        public string CodeValue { get; set; }
        //public string YearValue { get; set; }
        //public string CountryValue { get; set; }
        public IFieldDataReportCheck DataReportCheck { get; set; }
    }
}
