﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace HierarchyDependentCheck.Builder
{

    internal  class DataItemsBuilder
    {


        private readonly string pathToXml = string.Empty;
        private XDocument document;
        private readonly IHierarchy hierarchy;
        private readonly List<DataItem> dataItems;
        
        public DataItemsBuilder(string pathToXml,IHierarchy hierarchy )
        {
            this.pathToXml = pathToXml;           
            this.hierarchy = hierarchy;
            this.dataItems = new List<DataItem>();
            this.document = XDocument.Load(pathToXml);

        }



        public List<DataItem> BuildDataItems()
        {


            using (XmlReader reader = XmlReader.Create(this.pathToXml))
            {
                reader.MoveToContent();
                // reader.Read();
                // reader.Read();
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element)
                    {
                       
                        var checks = this.hierarchy.DataReportChecks.Where(c => c.Key.DataType.ToString().Equals(reader.Name));
                        string ln = reader.GetAttribute("ln");
                        foreach (var item in checks)
                        {
                           
                              dataItems.Add(GetDataItem(item.Key, ln));
                        }

                      
                    }
                }
            }

            this.document = null;

            return dataItems;
        }

        private DataItem GetDataItem(IFieldDataReportCheck dataReportCheck, string ln)
        {

            var el = this.document.Descendants(dataReportCheck.DataType.ToString())
                .Where(e => e.Attribute("ln").Value.Equals(ln)).First();

            #region code
            string fieldValue = null;
            var fieldElement = el.Element(dataReportCheck.Field);
            if (fieldElement != null)
            {
                if (string.IsNullOrWhiteSpace(fieldElement.Value))
                    fieldValue = null;
                else
                fieldValue = fieldElement.Value;
            }

            #endregion

            var res = new DataItem
            {
                LN = ln,
                CodeValue =fieldValue,
                DataReportCheck = dataReportCheck
            };

            return res;

        }
    }
}


    


