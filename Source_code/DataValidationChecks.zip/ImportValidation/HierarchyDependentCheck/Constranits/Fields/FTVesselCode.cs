﻿using System;
using System.Collections.Generic;
using System.Text;

using ResCommon;
namespace HierarchyDependentCheck.Constranits.Fields
{
    public class FTVesselCode : IFieldDataReportCheck
    {
        public string Field => "FTencryptedVesselCode";
        public Utility.RecordType DataType => Utility.RecordType.FT;

       
    }

   
}
