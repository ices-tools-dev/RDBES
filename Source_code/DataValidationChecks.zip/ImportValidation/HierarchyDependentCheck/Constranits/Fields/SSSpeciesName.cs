﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace HierarchyDependentCheck.Constranits.Fields
{
    public class SSSpeciesName : IFieldDataReportCheck
    {
        public string Field => "SSspeciesListName";
        public Utility.RecordType DataType => Utility.RecordType.SS;

        
    }
}
