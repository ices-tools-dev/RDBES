﻿using System;
using System.Collections.Generic;
using System.Text;

using ResCommon;

namespace HierarchyDependentCheck.Constranits.Fields
{
     public class VSVesselCode : IFieldDataReportCheck
    {
        public string Field => "VSencryptedVesselCode";
        public Utility.RecordType DataType => Utility.RecordType.VS;

       
    }
}
