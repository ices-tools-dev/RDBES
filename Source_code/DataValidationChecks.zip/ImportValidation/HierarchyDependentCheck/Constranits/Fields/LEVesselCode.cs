﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace HierarchyDependentCheck.Constranits.Fields
{
    public class LEVesselCode : IFieldDataReportCheck
    {
        public string Field => "LEencryptedVesselCode";
        public Utility.RecordType DataType => Utility.RecordType.LE;

        
    }
}
