﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace HierarchyDependentCheck
{
    internal interface IHierarchy
    {
        
        List<KeyValuePair<IFieldDataReportCheck, bool>> DataReportChecks { get; }
    }
}
