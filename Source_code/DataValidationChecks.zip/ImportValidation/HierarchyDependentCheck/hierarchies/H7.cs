﻿using System;
using System.Collections.Generic;
using System.Text;
using HierarchyDependentCheck.Constranits.Fields;

namespace HierarchyDependentCheck.hierarchies
{
    internal class H7 : IHierarchy
    {
        public List<KeyValuePair<IFieldDataReportCheck, bool>> DataReportChecks => new List<KeyValuePair<IFieldDataReportCheck, bool>>() {
          
            new KeyValuePair<IFieldDataReportCheck, bool>( new LEVesselCode(),true ),
            new KeyValuePair<IFieldDataReportCheck, bool>( new SSSpeciesName(),true ),

        };
    }
}
