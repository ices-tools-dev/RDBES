﻿using System;
using System.Collections.Generic;
using System.Text;
using HierarchyDependentCheck.Constranits.Fields;

namespace HierarchyDependentCheck.hierarchies
{
    internal class H8 : IHierarchy
    {
        public List<KeyValuePair<IFieldDataReportCheck, bool>> DataReportChecks => new List<KeyValuePair<IFieldDataReportCheck, bool>>() {
            new KeyValuePair<IFieldDataReportCheck, bool>( new VSVesselCode(),true ),
            new KeyValuePair<IFieldDataReportCheck, bool>( new LEVesselCode(),false ),
            new KeyValuePair<IFieldDataReportCheck, bool>( new FTVesselCode(),false ),
            new KeyValuePair<IFieldDataReportCheck, bool>( new SSSpeciesName(),true )

        };
    }
}
