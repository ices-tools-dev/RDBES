﻿using HierarchyDependentCheck.Constranits.Fields;
using System;
using System.Collections.Generic;
using System.Text;

namespace HierarchyDependentCheck.hierarchies
{
    internal class H3 : IHierarchy
    {
        public List<KeyValuePair<IFieldDataReportCheck, bool>> DataReportChecks => new List<KeyValuePair<IFieldDataReportCheck, bool>>() {
     new KeyValuePair<IFieldDataReportCheck, bool>(new VSVesselCode(),true),
         new KeyValuePair<IFieldDataReportCheck, bool>(new FTVesselCode(),true),
         new KeyValuePair<IFieldDataReportCheck, bool>(new SSSpeciesName(),true)


        };
    }
}
