﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HierarchyDependentCheck.Errors
{
    public class DependentCheckError
    {

        public string DataType { get; set; }
        public string Field { get; set; }
        public bool MustProvide { get; set; }
        public List<ErrorLine> Errors { get; set; }

    }
}
    

    

