﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HierarchyDependentCheck.Errors
{
   public class ErrorLine
    {
        public string LN { get; set; }
        public string Code { get; set; }
    }
}
