﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace HierarchyDependentCheck
{
    public interface IFieldDataReportCheck
    {
        Utility.RecordType DataType { get;  }
        string Field { get;  }
       


    }
}
