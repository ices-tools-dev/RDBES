﻿using HierarchyDependentCheck.Errors;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using HierarchyDependentCheck.Builder;

namespace HierarchyDependentCheck.ErrorsFinder
{
    internal class ValidationErrorsFinder
    {
        
        private List<DataItem> allDataItems;
        private readonly IHierarchy hierarchy;
        List<DependentCheckError> DataValErrors;
        public ValidationErrorsFinder(List<DataItem> allDataItems, IHierarchy hierarchy)
        {
            this.DataValErrors = new List<DependentCheckError>();
            this.hierarchy = hierarchy;
            this.allDataItems = allDataItems;
        }

        public List<DependentCheckError> BuildErrors()
        {
            foreach (var cons in hierarchy.DataReportChecks)
            {
                var valConstraint = cons.Key;// cons.Key.FieldDataReportConstraint;
                //var consisConstraint = cons.Key.LookupConstraint;

              

                var datValErr = new DependentCheckError()
                {
                    DataType = valConstraint.DataType.ToString(),
                    Field = valConstraint.Field,
                    MustProvide = cons.Value,
                    Errors = new List<ErrorLine>() 
                };
                var items = allDataItems.Where(i => 
                        i.DataReportCheck.DataType.ToString().Equals(valConstraint.DataType.ToString()) 
                        && 
                        i.DataReportCheck.Field.Equals(valConstraint.Field)).ToList();

                List<DataItem> notAllowed= new List<DataItem>();
                
                if (cons.Value)  //field must have value i.e. code
                {
                     notAllowed = items.Where(i => i.CodeValue==null ).ToList();   
                }
                else // field must not have value i.e no code should be provided
                {
                     notAllowed = items.Where(i => i.CodeValue!=null).ToList();                 
                }
                foreach (var item in notAllowed)
                {
                    datValErr.Errors.Add(new ErrorLine() { LN = item.LN, Code = item.CodeValue });
                }
                if(datValErr.Errors.Count>0)// add only if there is at least one error
                this.DataValErrors.Add(datValErr);

            }

            return this.DataValErrors;

        }


       

    }





}
