﻿using HierarchyDependentCheck.Errors;
using ResData.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace HierarchyDependentCheck.Client
{
    public interface IDependentCheckValidator
    {
        List<DependentCheckError> GetValidationResult(string path, string hierachyName);
    }
}
