﻿
using HierarchyDependentCheck.Builder;
using HierarchyDependentCheck.Errors;
using ResData.Models.KeyLessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using ResData.Data;
using HierarchyDependentCheck.ErrorsFinder;

namespace HierarchyDependentCheck.Client
{
  public  class DependentCheckValidator: IDependentCheckValidator
    {
       
        public DependentCheckValidator() {
            
         
        }
     

        public  List<DependentCheckError> GetValidationResult(string path, string hierachyName)
        {
            var hierarchy = LoadHierarchy(hierachyName);

            DataItemsBuilder builder = new DataItemsBuilder(path, hierarchy);
            var dataItems =builder.BuildDataItems();


            ValidationErrorsFinder dataValidator = new ValidationErrorsFinder(dataItems, hierarchy);
            return dataValidator.BuildErrors();

        }


        private static IHierarchy LoadHierarchy(string hierarchcyName)
        {
            var hierarchiesClasses = from t in Assembly
                                     .GetExecutingAssembly()
                                     .GetTypes()
                                     .Where(t => typeof(IHierarchy) != t && typeof(IHierarchy).IsAssignableFrom(t))
                                     select t;


            var foundHierarchy = hierarchiesClasses.Where(c => c.Name.EndsWith(hierarchcyName)).FirstOrDefault();
            if (foundHierarchy == null) throw new Exception("no hierarchy found with name that ends with '" + hierarchcyName + "'");

            return (IHierarchy)Activator.CreateInstance(foundHierarchy) as IHierarchy;
        }



    }
}
