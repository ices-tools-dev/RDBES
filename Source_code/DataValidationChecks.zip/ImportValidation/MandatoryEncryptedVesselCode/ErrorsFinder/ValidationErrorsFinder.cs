﻿using MandatoryEncryptedVesselCode.Errors;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using MandatoryEncryptedVesselCode.Builder;

namespace MandatoryEncryptedVesselCode.ErrorsFinder
{
    internal class ValidationErrorsFinder
    {
        
        private List<DataItem> allDataItems;
        
        
        public ValidationErrorsFinder(List<DataItem> allDataItems)
        {
            
            
            this.allDataItems = allDataItems;
        }

        public MandatoryCheckError BuildErrors(IMandatoryFieldCheck check, int maxErrors)
        {


            List<ErrorLine> errors = new List<ErrorLine>();

                var shoulNotReportErrorItems = allDataItems.Where(item => 
                item.PrincipalFieldValue != null 
                && 
                item.TargetFieldValue == item.IMandatoryFieldCheck.TargetFieldValue);

            foreach (var item in shoulNotReportErrorItems)
            {
                if (errors.Count < maxErrors)
                {
                    errors.Add(new ErrorLine() { ErrorMessage = "Encripted Vesel code should not be reported", LN = item.LN, PrincipalFieldValue = item.PrincipalFieldValue, TargetFieldValue = item.TargetFieldValue });
                }
                else
                    break;
            }

                var shoulReportErrorItems = allDataItems.Where(item =>
               item.PrincipalFieldValue == null
               &&
               item.TargetFieldValue != item.IMandatoryFieldCheck.TargetFieldValue);

            foreach (var item in shoulReportErrorItems)
            {
                if (errors.Count < maxErrors)
                {
                    errors.Add(new ErrorLine() { ErrorMessage = "Encripted Vesel code should  be reported", LN = item.LN, PrincipalFieldValue = item.PrincipalFieldValue, TargetFieldValue = item.TargetFieldValue });
                }
                else
                    break;
            }




            var datValErr = new MandatoryCheckError()
            {

                Errors = errors.OrderBy(e => e.LN).ToList(),
                Check = check
            };


            return datValErr;

        }


       

    }





}
