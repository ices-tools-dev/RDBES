﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace MandatoryEncryptedVesselCode
{
    public interface IMandatoryFieldCheck
    {
        Utility.RecordType RecordType { get; }
        string PricipalField { get; }

        string TargetField { get; }

        string TargetFieldValue { get; }

        

    }
}
