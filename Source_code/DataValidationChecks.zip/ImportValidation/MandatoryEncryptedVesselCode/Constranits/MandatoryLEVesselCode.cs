﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace MandatoryEncryptedVesselCode.Constranits
{
    public class MandatoryLEVesselCode : IMandatoryFieldCheck
    {
        public Utility.RecordType RecordType => Utility.RecordType.LE;
        public string PricipalField => "LEencryptedVesselCode";
        public string TargetField => "LEmixedTrip";
        public string TargetFieldValue => "Y";

        public string CheckName => "MandatoryEncripted";
    }
}
