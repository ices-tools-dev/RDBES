﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace MandatoryEncryptedVesselCode.Builder
{
    public class DataItem
    {
        public int LN { get; set; }        
        public string PrincipalFieldValue { get; set; }
        public string TargetFieldValue { get; set; }
        
        public IMandatoryFieldCheck IMandatoryFieldCheck { get; set; }
    }
}
