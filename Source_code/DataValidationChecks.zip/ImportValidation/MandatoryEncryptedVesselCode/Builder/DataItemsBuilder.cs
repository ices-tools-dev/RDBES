﻿
using ResCommon;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace MandatoryEncryptedVesselCode.Builder
{

    internal  class DataItemsBuilder
    {


        private readonly string pathToXml = string.Empty;
      
        
        public DataItemsBuilder(string pathToXml)
        {
            this.pathToXml = pathToXml;           
          

        }



        public List<DataItem> BuildDataItmes(IMandatoryFieldCheck check)
        {


            List<DataItem> dataItems = new List<DataItem>();
             
            using (XmlReader reader = XmlReader.Create(this.pathToXml))
            {
                reader.MoveToContent();

                
                while (reader.ReadToFollowing( check.RecordType.ToString()))
                {
                    string ln = reader.GetAttribute("ln");
                    var dataItem = CreateDataItem(check, reader.ReadSubtree(), ln);
                    dataItems.Add(dataItem);
                }

            }


            return dataItems;
        }
        private DataItem CreateDataItem(IMandatoryFieldCheck check, XmlReader reader, string ln)
        {

            var res = GetFieldValues(check, reader, ln);

            var dataItem = new DataItem
            {
                LN = Convert.ToInt32(res["ln"]),
                IMandatoryFieldCheck = check,
                PrincipalFieldValue = res.ContainsKey(check.PricipalField) ? !string.IsNullOrWhiteSpace(res[check.PricipalField])? res[check.PricipalField]:null : null,
                TargetFieldValue = res.ContainsKey(check.TargetField) ? !string.IsNullOrWhiteSpace(res[check.TargetField]) ? res[check.TargetField] : null : null
            };

            return dataItem;


        }
        private Dictionary<string, string> GetFieldValues(IMandatoryFieldCheck check, XmlReader reader,string ln)
        {
            var res = new Dictionary<string, string>
            {
                { "ln", ln }
            };
            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element)
                {
                    var name = reader.Name;
                    if (!name.Equals(check.RecordType.ToString()) && name.StartsWith(check.RecordType.ToString()) )
                    {
                        var val = reader.ReadString();
                        res.Add(name, val);
                    }
                }

            }
            return res;
        }


    }
}


    


