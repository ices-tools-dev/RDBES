﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MandatoryEncryptedVesselCode.Errors
{
   public class ErrorLine
    {
        public int LN { get; set; }
        public string PrincipalFieldValue { get; set; }
        public string TargetFieldValue { get; set; }
        public string ErrorMessage { get; set; }
    }
}
