﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MandatoryEncryptedVesselCode.Errors
{
    public class MandatoryCheckError
    {

    public    IMandatoryFieldCheck Check { get; set; }
        public List<ErrorLine> Errors { get; set; }

    }
}
    

    

