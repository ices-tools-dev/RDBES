﻿using MandatoryEncryptedVesselCode.Errors;
using System;
using System.Collections.Generic;
using System.Text;

namespace MandatoryEncryptedVesselCode.Client
{
  public  interface IMandatoryLEVesselCodeValidator
    {
        MandatoryCheckError GetValidationResult(string path,int maxErrors);
    }
}
