﻿
using MandatoryEncryptedVesselCode.Builder;
using MandatoryEncryptedVesselCode.Errors;
//using ResData.Models.KeyLessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
//using ResData.Data;
using MandatoryEncryptedVesselCode.ErrorsFinder;
using static ResCommon.Utility;
using MandatoryEncryptedVesselCode.Constranits;

namespace MandatoryEncryptedVesselCode.Client
{
  public  class MandatoryLEVesselCodeValidator: IMandatoryLEVesselCodeValidator
    {
       
        public MandatoryLEVesselCodeValidator() {
            
         
        }
     

        public  MandatoryCheckError GetValidationResult(string path,int maxErrors)
        {
            DataItemsBuilder builder = new DataItemsBuilder(path);
            var constraintsCheck = GetMandatoryLEVesselCodeCheck();

            List<DataItem> dataItems =  builder.BuildDataItmes(constraintsCheck);
                
            

            ValidationErrorsFinder dataValidator = new ValidationErrorsFinder(dataItems);
            return dataValidator.BuildErrors(constraintsCheck,maxErrors);

        }


        private static IMandatoryFieldCheck GetMandatoryLEVesselCodeCheck()
        {
            return new MandatoryLEVesselCode();
            //var constraints = new List<IMandatoryFieldCheck>();
            //var foundConstraintsClasses = from t in Assembly
            //                         .GetExecutingAssembly()
            //                         .GetTypes()
            //                         .Where(t => typeof(IMandatoryFieldCheck) != t && typeof(IMandatoryFieldCheck).IsAssignableFrom(t))
            //                         select t;



            //if (foundConstraintsClasses.Count() == 0) throw new Exception("no constraints found for mandatory field check");
            //foreach (var item in foundConstraintsClasses)
            //{


            //    constraints.Add((IMandatoryFieldCheck)Activator.CreateInstance(item) as IMandatoryFieldCheck);
            //}

            //return constraints;
        }



    }
}
