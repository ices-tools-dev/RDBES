﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace SchemaValidation
{
    public interface ISchemaValidator
    {

        bool ValidateXml(string xml, string xsd);
        List<SchemaValidationError> GetSchemaValidationErrors();

      
        
    }

}
