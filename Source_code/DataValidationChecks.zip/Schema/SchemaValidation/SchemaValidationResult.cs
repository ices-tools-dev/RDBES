﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchemaValidation
{
    public class SchemaValidationResult
    {

        public SchemaValidationError[] schemaValidationErrors;
        public bool errorsFound;
    }

    public class SchemaValidationError
    {
        public string lineNumer { get; set; }
        //public ErrorType errorType { get; set; }
        //public bool isAttribute { get; set; }
        public string nodeName { get; set; }
        public string nodeValue { get; set; }
        public string errorMessage { get; set; }
        public ErrorType errorType { get; set; }
        public bool attribute { get; set; }
    }

    public enum ErrorType
    {
        None,
        Enumeration,
        Range,
        Pattern,
        DataType,
        MissingNode,
        UnexpectedNode
    }
}
