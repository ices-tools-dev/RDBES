﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;



namespace SchemaValidation
{
    public class SchemaValidator :ISchemaValidator
    {

       
        int _intErrorsCount;
        int MAX_ERROR = 100;
        string _xsd_path { get; set; }
        XmlDocument XmlData;
        public List<SchemaValidationError> ErrorList { get; set; }
        private int _LineNumber;
        XmlReader _rXml;
        int m_intErrorsCount;
        int m_intXmlLineNumberCount;
        //static int _LineNumber;

        private string _FileType { get; set; }
        public string _XmlFile { get; set; }


        public bool ValidateXml(string xml, string xsd)
        {
          //  _FileType = FileType;
            _XmlFile = xml;
            XmlData = new XmlDocument();

            

            try
            {

                ErrorList = new List<SchemaValidationError>();

                // Create the XmlSchemaSet class.
                XmlSchemaSet sc = new XmlSchemaSet();

                sc.XmlResolver = new XmlUrlResolver();
                // Add the schema to the collection.
                sc.Add("", xsd);

                // Set the validation settings.
                XmlReaderSettings settings = new XmlReaderSettings();
                settings.ValidationType = ValidationType.Schema;
                settings.Schemas = sc;
                settings.ValidationEventHandler += new ValidationEventHandler(ValidationCallBack);

              
                string strFileName = xml;
                //XmlData.Save(strFileName);

                XmlParserContext context = new XmlParserContext(null, null, null, XmlSpace.None);
                XmlReader rXml = new XmlTextReader(strFileName);
                //XmlReader rXml = new XmlTextReader(XmlData.OuterXml, System.Xml.XmlNodeType.Document, context);

                // Create the XmlReader object.
                _rXml = XmlReader.Create(rXml, settings);

                

                // Parse the file. 
                while (_rXml.Read())
                {
                    if (_intErrorsCount >= MAX_ERROR - 1)
                        break;

                    if (_rXml.HasAttributes)
                    {
                        m_intXmlLineNumberCount++;

                        int intLn;

                        bool blnLn = Int32.TryParse(_rXml.GetAttribute("ln"), out intLn);
                        

                        if (blnLn)
                            _LineNumber = intLn;
                        else
                            _LineNumber = m_intXmlLineNumberCount;
                    }
                };

                _rXml.Close();

                //	File.Delete(strFileName);

                if (_intErrorsCount > 0)
                    return false;

                return true;
            }
            catch (Exception ex)
            {
                
                throw new Exception("Unexpected exception occurred within Validate method of class XmlValidator."+ex.Message.ToString() +" csv line number:"+_LineNumber.ToString(), ex);
            }

        }
        private void ValidationCallBack(object sender, ValidationEventArgs e)
        {
            switch (e.Severity)
            {
                case XmlSeverityType.Error:

                    string strError = e.Message;


                    SchemaValidationError  es = SetError(strError);


                    if (es.attribute || es.errorType == ErrorType.MissingNode)
                    {
                       // int intLineNumber = _LineNumber + 1;

                        int intLn;
                        bool blnLn = Int32.TryParse(_rXml.GetAttribute("ln"), out intLn);

                        if (blnLn)
                            es.lineNumer = intLn.ToString();
                        es.errorMessage = strError.Split('-')[0];

                      

                    }
                    else
                      
                    es.lineNumer = _LineNumber.ToString();

                    es.errorMessage = strError.Split('-')[0];
                    
                    // 2019:10:30
                    #region add some more text for unexpected node error message

                    if (es.errorType.Equals(ErrorType.UnexpectedNode))
                    {
                        es.errorMessage = "Please check the order of the records according to the hierarchyX.xsd. " + es.errorMessage;
                    }
                    #endregion


                    ErrorList.Add(es);

                    _intErrorsCount++;

                    break;
                case XmlSeverityType.Warning:
                default:
                    break;
            }
        }
        private string strReplaceMinusSignFromError(string strErrorMessage)
        {
            if (!strErrorMessage.Contains("'"))
                return "";

            string str = "";
            bool blnInside = false;

            for (int i = 0; i < strErrorMessage.Length; i++)
            {
                string strChar = strErrorMessage[i].ToString();

                if (strChar.Equals("'"))
                    blnInside = !blnInside;

                if (blnInside && strChar == "-")
                {
                    str += "%";
                    continue;
                }

                str += strChar;
            }

            return str;
        }
        private SchemaValidationError SetError(string strError)
        {
            ErrorType enmErrorType = ErrorType.None;
            string strNodeName = null;
            bool blnIsAttribute = false;
            string strNodeValue = null;

            // Temporary replacing the char '-' to '%', but only if it is used as minus.
            string str = strReplaceMinusSignFromError(strError);
            string[] ary = str.Split(new string[] { "-" }, StringSplitOptions.None);
            string[] ary2 = ary[0].Split(new string[] { " " }, StringSplitOptions.None);

            if (ary.Length == 1)
            {
                if (ary2.Length >= 6 && ary2[0] + " " + ary2[1] + " " + ary2[2] + " " + ary2[4] + " " + ary2[5] == "The required attribute is missing.")
                {
                    enmErrorType = ErrorType.MissingNode;
                    strNodeName = ary2[3];
                    blnIsAttribute = true;
                }

                if (ary2.Length >= 6 && ary2[0] + " " + ary2[2] + " " + ary2[3] + " " + ary2[4] + " " + ary2[5] == "The attribute is not declared.")
                {
                    enmErrorType = ErrorType.UnexpectedNode;
                    strNodeName = ary2[1];
                    blnIsAttribute = true;
                }

                if (ary2.Length >= 6 && ary2[0] + " " + ary2[1] + " " + ary2[3] + " " + ary2[4] + " " + ary2[5] == "The element has incomplete content.")
                {
                    enmErrorType = ErrorType.MissingNode;
                    strNodeName = ary2[11];
                    blnIsAttribute = false;
                }

                if (ary2.Length >= 7 && ary2[0] + " " + ary2[1] + " " + ary2[3] + " " + ary2[4] + " " + ary2[5] + " " + ary2[6] == "The element has invalid child element")
                {
                    enmErrorType = ErrorType.UnexpectedNode;
                    strNodeName = ary2[7];
                    blnIsAttribute = false;
                }
            }

            if (ary.Length > 1 && ary2.Length >= 5)
            {
                string strInvalidNodeType = ary2[0] + " " + ary2[2] + " " + ary2[3] + " " + ary2[4];

                if (strInvalidNodeType == "The attribute is invalid")
                {
                    if (ary.Length == 3)
                    {
                        if (ary[2].Trim().Equals("The Enumeration constraint failed."))
                            enmErrorType = ErrorType.Enumeration;
                        else
                        {
                            if (ary[2].Trim().Equals("The MinInclusive constraint failed.") || ary[2].Trim().Equals("The MaxInclusive constraint failed."))
                                enmErrorType = ErrorType.Range;
                            else
                                enmErrorType = ErrorType.DataType;
                        }

                        strNodeName = ary2[1];
                        blnIsAttribute = true;

                        string[] ary3 = ary[1].Split(new string[] { " " }, StringSplitOptions.None);
                        strNodeValue = ary3[3];
                        if (strNodeValue.Contains("%")) { strNodeValue = strNodeValue.Replace("%", "-"); }
                    }
                    else
                        enmErrorType = ErrorType.UnexpectedNode;
                }

                if (strInvalidNodeType == "The element is invalid")
                {
                    if (ary.Length == 3)
                    {
                        if (ary[2].Trim().Equals("The Enumeration constraint failed."))
                            enmErrorType = ErrorType.Enumeration;
                        else
                        {
                            if (ary[2].Trim().Equals("The Pattern constraint failed."))
                            {
                                enmErrorType = ErrorType.Pattern;
                            }
                            else
                            {
                                if (ary[2].Trim().Equals("The MinInclusive constraint failed.") || ary[2].Trim().Equals("The MaxInclusive constraint failed."))
                                    enmErrorType = ErrorType.Range;
                                else
                                    enmErrorType = ErrorType.DataType;
                            }
                        }

                        strNodeName = ary2[1];
                        blnIsAttribute = false;

                        string[] ary3 = ary[1].Split(new string[] { "'" }, StringSplitOptions.None);
                        
                        strNodeValue = ary3[1].ToString();
                        if (strNodeValue.Contains("%")) { strNodeValue = strNodeValue.Replace("%", "-"); }
                    }
                    else
                    {
                        enmErrorType = ErrorType.UnexpectedNode;

                        strNodeName = ary2[1];
                        blnIsAttribute = false;

                        string[] ary3 = ary[1].Split(new string[] { " " }, StringSplitOptions.None);
                        strNodeValue = ary3[3];
                        if (strNodeValue.Contains("%")) { strNodeValue = strNodeValue.Replace("%", "-"); }
                    }
                }
            }

            string strLastSuggestedCorrectNode = null;
            if (enmErrorType == ErrorType.UnexpectedNode)
                strLastSuggestedCorrectNode = ary2[ary2.Length - 1];
            SchemaValidationError vr = new SchemaValidationError();
            vr.errorType = enmErrorType;
            vr.nodeName = strNodeName;
            vr.attribute = blnIsAttribute;
            vr.nodeValue = strNodeValue;
           
            return vr;
        }

        public List<SchemaValidationError> GetSchemaValidationErrors()
        {
            return ErrorList;
            
        }
    }
    
}
