﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;

namespace ResSchemaGenerator.Enumerations
{
    public class Enumerations
    {
        string path { get; set; }
        public Enumerations(string folderPath)
        {
            this.path = folderPath;
            
        }


        public void CreateEmenrationsXSDs(Dictionary<string, List<string>> allData)
        {


            foreach (var ct in allData.Keys)
            {
                string filepath = this.path + ct.Substring(3).Trim() + ".xsd";

                XmlSchema myschema = new XmlSchema();
                myschema.ElementFormDefault = XmlSchemaForm.Qualified;
                myschema.AttributeFormDefault = XmlSchemaForm.Qualified;

                try
                {

                    var codesByType = allData[ct].AsEnumerable();



                    InsertEnumeratuionsToSchema(myschema, "string", "t" + ct.Substring(3).Trim(), codesByType);
                    createEnumerationXsdFile(myschema, filepath);


                }
                catch (Exception ex)
                {
                  throw new Exception("xsd error loading."+ex.StackTrace + ex);

                }

            }
        }
        void InsertEnumeratuionsToSchema(XmlSchema myschema, string dataTypeAsString, string simpleTypeName, IEnumerable<string> newCodes)
        {
            string msg = "";
            try
            {

                // <xs:simpleType name="SizeType">
                XmlSchemaSimpleType simpleType = new XmlSchemaSimpleType();
                simpleType.Name = simpleTypeName;

                // <xs:restriction base="xs:string">
                XmlSchemaSimpleTypeRestriction restriction = new XmlSchemaSimpleTypeRestriction();
                restriction.BaseTypeName = new XmlQualifiedName(dataTypeAsString, "http://www.w3.org/2001/XMLSchema");
                foreach (var code in newCodes)
                {
                    XmlSchemaEnumerationFacet enumeration = new XmlSchemaEnumerationFacet();
                    enumeration.Value = code;
                    restriction.Facets.Add(enumeration);


                }

                simpleType.Content = restriction;
                myschema.Items.Add(simpleType);

            }

            catch (Exception ex)
            {

               throw new Exception("Error occurred while inserting code in xsd file." + ex.Message);

            }

        }
        void createEnumerationXsdFile(XmlSchema myschema, string filePath)
        {
            FileStream file = new FileStream(filePath, FileMode.Create, FileAccess.ReadWrite);
            XmlTextWriter xwriter = new XmlTextWriter(file, new UTF8Encoding());
            xwriter.Formatting = Formatting.Indented;
            myschema.Write(xwriter);

        }
        static void ValidationCallback(object sender, ValidationEventArgs args)
        {
            if (args.Severity == XmlSeverityType.Warning)
                Console.Write("WARNING: ");
            else if (args.Severity == XmlSeverityType.Error)
                Console.Write("ERROR: ");

            Console.WriteLine(args.Message);
        }

    }
    
}
