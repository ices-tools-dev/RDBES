using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using ResSchemaGenerator.Types.v115.Abstract;

namespace ResSchemaGenerator.XSDs.H6D
{    

    [Serializable]
    [XmlType(TypeName = "RDBESTypeH6D")]
    [XmlRoot(ElementName = "RDBES", IsNullable = false)]
    public class Hierarchy
    {
        public H6D H6D { get; set; }
    }

    public class H6D
    {
        [XmlElement(ElementName = "DE")]
        public DE[] DE { get; set; }

    }

    public class DE : BaseDE
    {
        
        [XmlElement(ElementName = "SD")]
        public SD[] SD { get; set; }
    }

    public class SD : BaseSD
    {
      

        [XmlElement(ElementName = "OS")]
        public OS[] OS { get; set; }
    }

    
    public class OS : BaseOS
    {
        [XmlElement(ElementName = "LE")]
        public LE LE { get; set; }

        [XmlElement(ElementName = "VD")]
        public VD VD { get; set; }

        [XmlElement(ElementName = "FT")]
        public FT[] FT { get; set; }
    }
    public class LE : BaseLE
    {

    }

    public class VD : BaseVD
    {

    }

    public class FT :BaseFT
    {
        
        [XmlElement(ElementName = "SS")]
        public SS[] SS { get; set; }
    }
   
    public class SS : BaseSS
    {
       
        [XmlElement(ElementName = "SA")]
        public SA[] SA { get; set; }
    }
    public class SA : BaseSA
    {
        
    }
}
