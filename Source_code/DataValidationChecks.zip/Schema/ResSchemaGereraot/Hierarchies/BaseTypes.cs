﻿using ResSchemaGenerator.Enums;
using ResSchemaGenerator.Types.v115.Abstract;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Hierarchies
{
    [Serializable]
   // [XmlType(TypeName = "RDBEStYPES")]
   // [XmlRoot(ElementName = "RDBES", IsNullable = false)]
   
    public  class BaseTypes
    {
        
        public BaseBV BaseBV { get; set; }
        public BaseDE BaseDE { get; set; }
        public BaseFM BaseFM { get; set; }
        public BaseFO BaseFO { get; set; }
        public BaseFT BaseFT { get; set; }
        public BaseLE BaseLE { get; set; }
        public BaseLO BaseLO { get; set; }
        public BaseOS BaseOS { get; set; }
        public BaseSA BaseSA { get; set; }
        public BaseSD BaseSD { get; set; }
        public BaseSL BaseSL { get; set; }
        public BaseSS BaseSS { get; set; }
        public BaseTE BaseTE { get; set; }
        public BaseVD BaseVD { get; set; }
        public BaseVS BaseVS { get; set; }

        
        
    }


}
