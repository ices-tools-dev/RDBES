﻿using RDBESWEB;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;


namespace ResSchemaGenerator
{
    public static class SchemaGenerator
    {

        //private static void Main()
        //{
        ////// string baseTypesSchemaPath = @"F:\_LocalStuff\LinqPad Queries\RES\ConverterClientApp\XML\XSD\BaseTypes.xsd";
        ////// string enumeratonFolderPath = @"F:\_LocalStuff\LinqPad Queries\RES\ConverterClientApp\XML\XSD\Enumerators";
        ////// string hierarchiesFolderPath = @"F:\_LocalStuff\LinqPad Queries\RES\ConverterClientApp\XML\XSD\Hierarchies";
        ////include enumerations links to base shcema
        ////// IncludeLookupRefferencesToBaseSchema(enumeratonFolderPath, baseTypesSchemaPath);
        //// base shcema link to all hierarchies
        ////// IncludeBaseSchemaRefToHierarchies(hierarchiesFolderPath, baseTypesSchemaPath);         
        //}

        #region call from sync api
       
        //call from sync api to create a lookup xsd file( for lookup values )
        public static void CreateLookupXsdFile(string namePrefix, string codeType, string lookupFilesFolderPath)
        {

            var fileName = lookupFilesFolderPath + codeType + ".xsd";
            try
            {
                var myschema = new XmlSchema();

                myschema.ElementFormDefault = XmlSchemaForm.Qualified;
                myschema.AttributeFormDefault = XmlSchemaForm.Qualified;

                // <xs:simpleType name="tSizeType">
                var simpleType = new XmlSchemaSimpleType();
                simpleType.Name = namePrefix + codeType;

                // <xs:restriction base="xs:string">
                var restriction = new XmlSchemaSimpleTypeRestriction();
                restriction.BaseTypeName = new XmlQualifiedName("string", "http://www.w3.org/2001/XMLSchema");
                simpleType.Content = restriction;
                myschema.Items.Add(simpleType);
                lock (XsdFileLocker.FileCreateLock)
                {
                    CreateXsdFile(myschema, fileName);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(@"Error occured while creating xsd lookup file for codetype '" + codeType + "'", ex);

            }


        }
        
        //call from sync api to insert a code in lookup xsd file
        public static void InsertCodeToLookUpXsdFile(string xsdPath, string code)
        {
            lock (XsdFileLocker.AddRecordLock)
            {
                XmlSchema newSchema;
                newSchema = AddCodeToXsdFile(xsdPath, code);
                CreateXsdFile(newSchema, xsdPath);
            }

        }

        //call from sync api to update a code in lookup xsd file
        public static void UpdateCodeInLookUpXsdFile(string xsdPath,string oldCode, string newCode)
        {
            lock (XsdFileLocker.UpdateRecordLock)
            {

                XmlSchema newSchema;
                newSchema = UpdateCodeInXsdFile(xsdPath, oldCode, newCode);
                CreateXsdFile(newSchema, xsdPath);
            }

        }

        //call from sync api to delete a code in lookup xsd file
        public static void DeleteCodeFromLookUpXsdFile(string xsdPath, string code)
        {
            lock (XsdFileLocker.DeleterecordLock)
            {

                XmlSchema newSchema;
                newSchema = DeleteCodeFromXsdFile(xsdPath, code);
                CreateXsdFile(newSchema, xsdPath);
            }

        }

        // call from sync api to see if code exists in the file
        public static bool CodeExistsInlookupXsdFile(string xsdPath, string code) => CodeExistsInXsdFile(xsdPath, code);

        #endregion


        #region private methods - not for client to call
        private static void ValidationCallBack(object sender, ValidationEventArgs args)
        {

            if (args.Severity == XmlSeverityType.Warning)
                Console.Write("WARNING: ");
            else if (args.Severity == XmlSeverityType.Error)
                Console.Write("ERROR: ");

            Console.WriteLine(args.Message);
        }
        private static void CreateXsdFile(XmlSchema myschema, string filePath)
        {
          

                using (FileStream file = new FileStream(filePath, FileMode.Create, FileAccess.ReadWrite, FileShare.Read))
                {
                    using (XmlTextWriter xwriter = new XmlTextWriter(file, new UTF8Encoding()))
                    {
                        xwriter.Formatting = Formatting.Indented;
                        myschema.Write(xwriter);
                    }
                }
            
              

        }
        private static XmlSchema AddCodeToXsdFile(string xsdPath,string code)
        {


            XmlSchema myNewSchema = new XmlSchema
            {
                ElementFormDefault = XmlSchemaForm.Qualified,
                AttributeFormDefault = XmlSchemaForm.Qualified
            };
            using (var myreader = XmlReader.Create(xsdPath))
            {
                
                XmlSchemaSet schemaSet = new XmlSchemaSet();
                XmlSchema oldSchema = XmlSchema.Read(myreader, ValidationCallBack);
                
                schemaSet.Add(oldSchema);
                schemaSet.Compile();

                var restrictions = oldSchema.Items.OfType<XmlSchemaSimpleType>()
                    .Where(s => (s.Content is XmlSchemaSimpleTypeRestriction)).ToList();

                var enumValues = restrictions
                .SelectMany(c => ((XmlSchemaSimpleTypeRestriction)c.Content)
                .Facets.OfType<XmlSchemaEnumerationFacet>()).ToList();



                foreach (XmlSchemaType type in oldSchema.SchemaTypes.Values)
                {

                    if (type is XmlSchemaSimpleType)
                    {
                        XmlSchemaSimpleType codeTypeSimpleType = new XmlSchemaSimpleType();
                        codeTypeSimpleType.Name = type.Name;
                        // codeTypeSimpleType = type as XmlSchemaSimpleType;

                        XmlSchemaSimpleTypeRestriction restriction = new XmlSchemaSimpleTypeRestriction();
                        restriction.BaseTypeName = new XmlQualifiedName("string", "http://www.w3.org/2001/XMLSchema");

                        foreach (var oldEnumeration in enumValues)
                        {
                            XmlSchemaEnumerationFacet enumeration = new XmlSchemaEnumerationFacet();
                            enumeration.Value = oldEnumeration.Value;
                            restriction.Facets.Add(enumeration);
                        }

                        var newEnumeration = new XmlSchemaEnumerationFacet();
                        newEnumeration.Value = code; // "newtestValue_" + new Random().Next().ToString();
                        restriction.Facets.Add(newEnumeration);

                        codeTypeSimpleType.Content = restriction;
                        myNewSchema.Items.Add(codeTypeSimpleType);
                    }
                }
                //  schemaSet.RemoveRecursive(oldSchema);
                //  schemaSet.Compile();
                schemaSet.Remove(oldSchema);
                schemaSet.Compile();

            }
            return myNewSchema;
        }

        private static XmlSchema UpdateCodeInXsdFile(string xsdPath,string oldCode, string newCode)
        {


            XmlSchema myNewSchema = new XmlSchema
            {
                ElementFormDefault = XmlSchemaForm.Qualified,
                AttributeFormDefault = XmlSchemaForm.Qualified
            };
            using (var myreader = XmlReader.Create(xsdPath))
            {

                XmlSchemaSet schemaSet = new XmlSchemaSet();
                XmlSchema oldSchema = XmlSchema.Read(myreader, ValidationCallBack);

                schemaSet.Add(oldSchema);
                schemaSet.Compile();

                var restrictions = oldSchema.Items.OfType<XmlSchemaSimpleType>()
                    .Where(s => (s.Content is XmlSchemaSimpleTypeRestriction)).ToList();

                var enumValues = restrictions
                .SelectMany(c => ((XmlSchemaSimpleTypeRestriction)c.Content)
                .Facets.OfType<XmlSchemaEnumerationFacet>()).ToList();



                foreach (XmlSchemaType type in oldSchema.SchemaTypes.Values)
                {

                    if (type is XmlSchemaSimpleType)
                    {
                        XmlSchemaSimpleType codeTypeSimpleType = new XmlSchemaSimpleType();
                        codeTypeSimpleType.Name = type.Name;
                        // codeTypeSimpleType = type as XmlSchemaSimpleType;

                        XmlSchemaSimpleTypeRestriction restriction = new XmlSchemaSimpleTypeRestriction();
                        restriction.BaseTypeName = new XmlQualifiedName("string", "http://www.w3.org/2001/XMLSchema");
                    
                        foreach (var oldEnumeration in enumValues)
                        {
                            XmlSchemaEnumerationFacet enumeration = new XmlSchemaEnumerationFacet();
                            enumeration.Value = oldEnumeration.Value;

                            if (oldEnumeration.Value.Equals(oldCode))
                            {
                                enumeration.Value = newCode;
                            }
                            restriction.Facets.Add(enumeration);
                        }
                                              

                        codeTypeSimpleType.Content = restriction;
                        myNewSchema.Items.Add(codeTypeSimpleType);
                    }
                }
               
                schemaSet.Remove(oldSchema);
                schemaSet.Compile();

            }
            return myNewSchema;
        }

        private static bool CodeExistsInXsdFile(string xsdPath, string oldCode)
        {


            XmlSchema myNewSchema = new XmlSchema
            {
                ElementFormDefault = XmlSchemaForm.Qualified,
                AttributeFormDefault = XmlSchemaForm.Qualified
            };
            using (var myreader = XmlReader.Create(xsdPath))
            {

                XmlSchemaSet schemaSet = new XmlSchemaSet();
                XmlSchema oldSchema = XmlSchema.Read(myreader, ValidationCallBack);

                schemaSet.Add(oldSchema);
             //   schemaSet.Compile();

                var restrictions = oldSchema.Items.OfType<XmlSchemaSimpleType>()
                    .Where(s => (s.Content is XmlSchemaSimpleTypeRestriction)).ToList();

                var enumValues = restrictions
                .SelectMany(c => ((XmlSchemaSimpleTypeRestriction)c.Content)
                .Facets.OfType<XmlSchemaEnumerationFacet>()).ToList();



                foreach (XmlSchemaType type in oldSchema.SchemaTypes.Values)
                {

                    if (type is XmlSchemaSimpleType)
                    {
                     //   XmlSchemaSimpleType codeTypeSimpleType = new XmlSchemaSimpleType();
                      //  codeTypeSimpleType.Name = type.Name;
                        // codeTypeSimpleType = type as XmlSchemaSimpleType;

                     //   XmlSchemaSimpleTypeRestriction restriction = new XmlSchemaSimpleTypeRestriction();
                       // restriction.BaseTypeName = new XmlQualifiedName("string", "http://www.w3.org/2001/XMLSchema");

                        foreach (var oldEnumeration in enumValues)
                        {
                          //  XmlSchemaEnumerationFacet enumeration = new XmlSchemaEnumerationFacet();
                          //  enumeration.Value = oldEnumeration.Value;

                            if (oldEnumeration.Value.Equals(oldCode))
                            {
                                return true; 
                            }
                           // restriction.Facets.Add(enumeration);
                        }


                      //  codeTypeSimpleType.Content = restriction;
                       // myNewSchema.Items.Add(codeTypeSimpleType);
                    }
                }

                
                schemaSet.Compile();

            }
            return false;
        }
        private static XmlSchema DeleteCodeFromXsdFile(string xsdPath, string code)
        {


            XmlSchema myNewSchema = new XmlSchema
            {
                ElementFormDefault = XmlSchemaForm.Qualified,
                AttributeFormDefault = XmlSchemaForm.Qualified
            };
            using (var myreader = XmlReader.Create(xsdPath))
            {

                XmlSchemaSet schemaSet = new XmlSchemaSet();
                XmlSchema oldSchema = XmlSchema.Read(myreader, ValidationCallBack);

                schemaSet.Add(oldSchema);
                schemaSet.Compile();

                var restrictions = oldSchema.Items.OfType<XmlSchemaSimpleType>()
                    .Where(s => (s.Content is XmlSchemaSimpleTypeRestriction)).ToList();

                var enumValues = restrictions
                .SelectMany(c => ((XmlSchemaSimpleTypeRestriction)c.Content)
                .Facets.OfType<XmlSchemaEnumerationFacet>()).ToList();



                foreach (XmlSchemaType type in oldSchema.SchemaTypes.Values)
                {

                    if (type is XmlSchemaSimpleType)
                    {
                        XmlSchemaSimpleType codeTypeSimpleType = new XmlSchemaSimpleType();
                        codeTypeSimpleType.Name = type.Name;
                        // codeTypeSimpleType = type as XmlSchemaSimpleType;

                        XmlSchemaSimpleTypeRestriction restriction = new XmlSchemaSimpleTypeRestriction();
                        restriction.BaseTypeName = new XmlQualifiedName("string", "http://www.w3.org/2001/XMLSchema");

                        foreach (var oldEnumeration in enumValues)
                        {
                            XmlSchemaEnumerationFacet enumeration = new XmlSchemaEnumerationFacet();
                            enumeration.Value = oldEnumeration.Value;

                            if (!oldEnumeration.Value.Equals(code))
                            {
                                restriction.Facets.Add(enumeration);
                            }
                        }


                        codeTypeSimpleType.Content = restriction;
                        myNewSchema.Items.Add(codeTypeSimpleType);
                    }
                }

                schemaSet.Remove(oldSchema);
                schemaSet.Compile();

            }
            return myNewSchema;
        }
        #endregion









        //private static void IncludeLookupRefferencesToBaseSchema(string enumerationdFolderPath, string baseTypesSchemaPath)
        //{


        //    XmlSchemaSet schemaSet = new XmlSchemaSet();
        //    schemaSet.ValidationEventHandler += new ValidationEventHandler(ValidationCallBack);
        //    schemaSet.Add("http://www.w3.org/2001/XMLSchema", baseTypesSchemaPath);
        //    schemaSet.Compile();

        //    XmlSchema schema = null;
        //    foreach (XmlSchema schema1 in schemaSet.Schemas())
        //    {
        //        schema = schema1;
        //    }

        //    //////var allPreviousLookReferrences = schema.Includes;
        //    //////for (var i = 0; i <= allPreviousLookReferrences.Count; i++)
        //    //////{
        //    //////    schema.Includes.RemoveAt(i);
        //    //////}

        //    DirectoryInfo di = new DirectoryInfo(enumerationdFolderPath);
        //    var files = di.GetFiles();
        //    foreach (var f in files)
        //    {

        //        XmlSchemaInclude include = new XmlSchemaInclude();
        //        include.SchemaLocation = f.FullName;
        //        schema.Includes.Add(include);
        //    }


        //    schemaSet.Reprocess(schema);

        //    schemaSet.Compile();
        //    CreateXsdFile(schema, baseTypesSchemaPath);



        //}

        //private static void IncludeBaseSchemaRefToHierarchies(string hierarchiesdFolderPath, string baseTypesSchemaPath)
        //{
        //    XmlSchemaSet schemaSet = new XmlSchemaSet();

        //    DirectoryInfo di = new DirectoryInfo(hierarchiesdFolderPath);
        //    var directories = di.GetDirectories();
        //    foreach (var d in directories)
        //    {
        //        foreach (var f in d.GetFiles())
        //        {
        //            schemaSet.ValidationEventHandler += new ValidationEventHandler(ValidationCallBack);
        //            schemaSet.Add("http://www.w3.org/2001/XMLSchema", f.FullName);
        //            schemaSet.Compile();


        //            XmlSchema schema = null;
        //            foreach (XmlSchema schema1 in schemaSet.Schemas())
        //            {
        //                schema = schema1;
        //            }




        //            XmlSchemaInclude include = new XmlSchemaInclude();
        //            include.SchemaLocation = baseTypesSchemaPath;
        //            schema.Includes.Add(include);
        //            schemaSet.Reprocess(schema);

        //            schemaSet.Compile();
        //            CreateXsdFile(schema, f.FullName);




        //        }

        //    }





        //}

        //private void CreateXSDsForCodeTypes(string folderPath)
        //{
        //    var db = UtilityProvider.GetResUnitOfWork();
        //    var codeTypes = db.TblCodeTypes.GetAll();
        //    foreach (var ct in codeTypes)
        //    { 

        //        string filepath = folderPath + ct.CodeType.Substring(3).Trim() + ".xsd";

        //        XmlSchema myschema = new XmlSchema();
        //        myschema.ElementFormDefault = XmlSchemaForm.Qualified;
        //        myschema.AttributeFormDefault = XmlSchemaForm.Qualified;

        //        try
        //        {

        //            var codes = from c in db.TblCodes.GetAll()
        //                        join t in db.TblCodeTypes.GetAll()
        //                        on c.TblCodeType.TblCodeTypeID equals t.TblCodeTypeID
        //                        where t.CodeType.Equals(ct)
        //                        select c.Code;



        //            InsertValuesToEnumeratuionXsd(myschema, "string", "t" + ct.CodeType.Substring(3).Trim(), codes);
        //            CreateXsdFile(myschema, filepath);


        //        }
        //        catch (Exception ex)
        //        {
        //          throw new Exception("xsd error loading." + ex);

        //        }

        //    }
        //}
        //private void InsertValuesToEnumeratuionXsd(XmlSchema myschema, string dataTypeAsString, string simpleTypeName, IEnumerable<string> newCodes)
        //{

        //    try
        //    {

        //        // <xs:simpleType name="SizeType">
        //        XmlSchemaSimpleType simpleType = new XmlSchemaSimpleType();
        //        simpleType.Name = simpleTypeName;

        //        // <xs:restriction base="xs:string">
        //        XmlSchemaSimpleTypeRestriction restriction = new XmlSchemaSimpleTypeRestriction();
        //        restriction.BaseTypeName = new XmlQualifiedName(dataTypeAsString, "http://www.w3.org/2001/XMLSchema");
        //        foreach (var code in newCodes)
        //        {
        //            XmlSchemaEnumerationFacet enumeration = new XmlSchemaEnumerationFacet();
        //            enumeration.Value = code;
        //            restriction.Facets.Add(enumeration);


        //        }

        //        simpleType.Content = restriction;
        //        myschema.Items.Add(simpleType);

        //    }

        //    catch (Exception ex)
        //    {

        //        throw new Exception("Error occurred while inserting code in xsd file." + ex.Message);

        //    }

        //}
    }
}
