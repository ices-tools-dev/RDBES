﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Enums
{
   
       
        public enum TypeSelectionMethod
        {
        val1 = 1,
        val2 = 2,
        val3 = 3,
        val4 = 4



    }
}
