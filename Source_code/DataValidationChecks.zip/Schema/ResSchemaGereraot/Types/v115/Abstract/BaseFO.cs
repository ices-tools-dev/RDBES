﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public   class  BaseFO
    {
        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }


        public string FOstratification { get; set; }
      public int FOhaulNumber { get; set; }
         public string  FOstratum { get; set; }
      public string FOclustering { get; set; }
         public string  FOclusterName { get; set; }
      public string FOsampler { get; set; }
      public string FOaggregationLevel { get; set; }
      public string FOvalidity { get; set; }
      public string FOcatchReg { get; set; }
         public DateTime? FOstartDate { get; set; }
         public DateTime? FOstartTime { get; set; }
         public DateTime FOendDate { get; set; }
         public DateTime? FOendTime { get; set; }
      public int? FOduration { get; set; }
       public short? FOstartLat { get; set; }
       public short? FOstartLon { get; set; }
       public short? FOstopLat { get; set; }
       public short? FOstopLon { get; set; }
      public string FOeconomicalZone { get; set; }
      public string FOarea { get; set; }
      public string FOrectangle { get; set; }
      public string FOsubpolygon { get; set; }
         public string  FOfunctinalUnit { get; set; }
      public int? FOfishingDepth { get; set; }
      public int? FOwaterDepth { get; set; }
      public string FOnationalCategory { get; set; }
      public string FOmetier5 { get; set; }
      public string FOmetier6 { get; set; }
      public string FOgear { get; set; }
      public int? FOmeshSize { get; set; }
      public int? FOselectionDevice { get; set; }
      public int? FOselectionDeviceMeshSize { get; set; }
      public string FOtargetSpecies { get; set; }
      public int? FOpercCoverageHauling { get; set; }
      public int? FOpercCoverageSorting { get; set; }
      public int? FOtotal { get; set; }
      public int? FOsampled { get; set; }
         public decimal? FOsampProb { get; set; }
         public string  FOselectionMethod { get; set; }
      public string FOselectionMethodCluster { get; set; }
      public int? FOtotalClusters { get; set; }
      public int? FOsampledClusters { get; set; }
         public decimal? FOclustersProb { get; set; }
      public string FOreasonNotSampled { get; set; }

      
    }
}
