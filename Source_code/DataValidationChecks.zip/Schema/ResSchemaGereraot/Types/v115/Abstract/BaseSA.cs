﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public   class  BaseSA
    {


        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        public string  SAnationalCode { get; set; }
         public string  SAstratum { get; set; }
      public string SAspeciesCode { get; set; }
      public string SAcommercialSpecies { get; set; }
      public string SApresentation { get; set; }
      public string SAcatchFraction { get; set; }
      public string SAlandingCategory { get; set; }
      public string SAcommSizeCatScale { get; set; }
      public int? SAcommSizeCat { get; set; }
      public string SAsex { get; set; }
      public string SAunitType { get; set; }
      public int SAliveWt { get; set; }
      public int? SAsampleWeight { get; set; }
         public decimal? SAtotal { get; set; }
         public decimal? SAsampled { get; set; }
         public decimal? SAsampProb { get; set; }
      public string SAselectionMethod { get; set; }
      public string SAlowerHierarchy { get; set; }
      public string SAsampler { get; set; }
      public string SAreasonNotSampledFM { get; set; }
      public string SAreasonNotSampledBV { get; set; }

       
    }
}
