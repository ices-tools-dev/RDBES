﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public   class  BaseLO
    {
        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        public string LOstratification { get; set; }
         public string  LOlocation { get; set; }
         public string  LOstratum { get; set; }
      public string LOclustering { get; set; }
         public string  LOclusterName { get; set; }
      public string LOsampler { get; set; }
      public int? LOtotal { get; set; }
      public int? LOsampled { get; set; }
         public decimal? LOsampProb { get; set; }
      public string LOselectionMethod { get; set; }
      public string LOselectionMethodCluster { get; set; }
      public int? LOtotalClusters { get; set; }
      public int? LOsampledClusters { get; set; }
         public decimal? LOclustersProb { get; set; }
      public string LOreasonNotSampled { get; set; }

        
    }
}
