﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public   class  BaseSS
    {

        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        public string SSstratification { get; set; }
      public int SSspeciesListID { get; set; }
         public string  SScatchFraction { get; set; }
         public string  SSstratum { get; set; }
      public string SSclustering { get; set; }
         public string  SSclusterName { get; set; }
      public string SSsampler { get; set; }
         public string  SSspeciesListName { get; set; }
      public int? SStotal { get; set; }
      public int? SSsampled { get; set; }
      public string SSselectionMethod { get; set; }
      public string SSselectionMethodCluster { get; set; }
      public int? SStotalClusters { get; set; }
      public int? SSsampledClusters { get; set; }
         public decimal? SSclustersProb { get; set; }
      public string SSreasonNotSampled { get; set; }

      
    }
}
