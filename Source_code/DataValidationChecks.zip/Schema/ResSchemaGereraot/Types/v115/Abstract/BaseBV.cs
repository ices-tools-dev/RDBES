﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public   class  BaseBV
    {
      [XmlAttribute(attributeName: "ln")]
      public int ln { get; set; }
      public int BVfishId { get; set; }
      [XmlElement(IsNullable = true)]
      public string  BVstratum { get; set; }
      public string BVtype { get; set; }
      [XmlElement(IsNullable = true)]
      public string  BVvalue { get; set; }
      public string BVunitValue { get; set; }
      [XmlElement(IsNullable = true)]
      public string BVunitScaleList { get; set; }
      [XmlElement(IsNullable = true)]
      public string BVmethod { get; set; }
      public int? BVtotal { get; set; }
      public int? BVsampled { get; set; }
      public decimal? BVsampProb { get; set; }
      public string BVselectionMethod { get; set; }
      [XmlElement(IsNullable = true)]
      public string BVsampler { get; set; }

       
    }
}
