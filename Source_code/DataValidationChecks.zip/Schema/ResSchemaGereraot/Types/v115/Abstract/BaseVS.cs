﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
      public   class  BaseVS

    {

        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        
        
        public string VSstratification { get; set; }
        public string  VSstratum { get; set; }
        public string VSclustering { get; set; }
        public string  VSclusterName { get; set; }
        public string VSsampler { get; set; }
        public int? VStotal { get; set; }
        public int? VSsampled { get; set; }
        public   decimal? VSsampProb { get; set; }
        public string VSselectionMethod { get; set; }
        public string VSselectionMethodCluster { get; set; }
        public int? VStotalClusters { get; set; }
        public int? VSsampledClusters { get; set; }
        public   decimal? VSclustersProb { get; set; }
        public string VSreasonNotSampled { get; set; }

       
    }
}
