﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public   class  BaseTE

    {


        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        public   string  TEstratification { get; set; }
        public   string  TEtimeUnit { get; set; }
        public   string  TEstratum { get; set; }
        public   string  TEclustering { get; set; }
        public   string  TEclusterName { get; set; }
        public   string  TEsampler { get; set; }
        public int TEtotal { get; set; }
        public int TEsampled { get; set; }
        public   decimal TEsampProb { get; set; }
        public   string  TEselectionMethod { get; set; }
        public   string  TEnationalCode { get; set; }
        public   string  TEselectionMethodCluster { get; set; }
        public int? TEtotalClusters { get; set; }
        public int? TEsampledClusters { get; set; }
        public   decimal? TEclustersProb { get; set; }
        public string TEreasonNotSampled { get; set; }

       
    }
}
