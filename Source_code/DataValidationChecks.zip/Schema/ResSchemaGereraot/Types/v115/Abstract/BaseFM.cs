﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public   class  BaseFM
    {
        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        public int FMclassType { get; set; }
         public decimal FMnumberAtUnit { get; set; }
      public string FMtype { get; set; }
      public string FMaccuracy { get; set; }
      public string FMsampler { get; set; }

       
    }
}
