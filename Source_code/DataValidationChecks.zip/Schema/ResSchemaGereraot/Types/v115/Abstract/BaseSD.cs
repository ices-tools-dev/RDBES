﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public abstract  class  BaseSD

    {
        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        public string SDcountry { get; set; }
        public string SDinstitution { get; set; }

       
    }
}
