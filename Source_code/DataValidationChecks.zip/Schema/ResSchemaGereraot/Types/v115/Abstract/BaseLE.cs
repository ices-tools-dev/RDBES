﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public   class  BaseLE

    {
        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        public string LEstratification { get; set; }
      public int LEsequenceNumber { get; set; }
      public int? LEhaulNumber { get; set; }
         public string  LEstratum { get; set; }
      public string LEclustering { get; set; }
         public string  LEclusterName { get; set; }
      public int? LEsampler { get; set; }
      public string LEmixedTrip { get; set; }
      public string LEcatchReg { get; set; }
      public string LElocation { get; set; }
      public string LElocationType { get; set; }
      public string LEcountry { get; set; }
         public DateTime? LEdate { get; set; }
         public DateTime? LEtime { get; set; }
      public string LEeconomicalZone { get; set; }
      public string LEarea { get; set; }
      public string LErectangle { get; set; }
      public string LEsubpolygon { get; set; }
      public string LEfunctinalUnit { get; set; }
      public string LEnationalCategory { get; set; }
      public string LEmetier5 { get; set; }
      public string LEmetier6 { get; set; }
      public string LEgear { get; set; }
      public int? LEmeshSize { get; set; }
      public int? LEselectionDevice { get; set; }
      public int? LEselectionDeviceMeshSize { get; set; }
         public string  LEtargetSpecies { get; set; }
      public int? LEtotal { get; set; }
      public int? LEsampled { get; set; }
         public decimal? EsampProb { get; set; }
      public string LEselectionMethod { get; set; }
      public string LEselectionMethodCluster { get; set; }
      public int? LEtotalClusters { get; set; }
      public int? LEsampledClusters { get; set; }
         public decimal? LEclustersProb { get; set; }
      public string LEreasonNotSampled { get; set; }

        
    }
}
