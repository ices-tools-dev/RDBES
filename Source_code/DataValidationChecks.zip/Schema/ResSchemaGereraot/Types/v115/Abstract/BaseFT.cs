﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public   class  BaseFT
    {


        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        public string  FTnationalCode { get; set; }
         public string FTstratification { get; set; }
         public string  FTstratum { get; set; }
      public string FTclustering { get; set; }
         public string  FTclusterName { get; set; }
      public string FTsampler { get; set; }
      public int? FTnumberOfHauls { get; set; }
      public string FTdepartureLocation { get; set; }
         public string FTdepatureDate { get; set; }
         public string FTdepartureTime { get; set; }
         public string  FTarrivalLocation { get; set; }
         public string FTarrivalDate { get; set; }
         public string FTarrivalTime { get; set; }
      public int? FTtotal { get; set; }
      public int? FTsampled { get; set; }
         public decimal? FTsampProb { get; set; }
      public string FTselectionMethod { get; set; }
      public string FTselectionMethodCluster { get; set; }
      public int? FTtotalClusters { get; set; }
      public int? FTsampledClusters { get; set; }
         public decimal? FTclustersProb { get; set; }
      public string FTreasonNotSampled { get; set; }

      
    }
}
