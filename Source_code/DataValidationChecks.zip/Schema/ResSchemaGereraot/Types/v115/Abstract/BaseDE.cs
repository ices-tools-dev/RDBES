﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
  
    public abstract  class BaseDE
    {
        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }

        [XmlElement(IsNullable = true)]        
        public string DEsamplingScheme { get; set; }

        public int DEyear { get; set; }


        [XmlElement(IsNullable = true)]
        public string DEstratum { get; set; }

        [XmlElement( IsNullable =true)]
        public string DEhierarchyCorrect { get; set; }

        public int DEhierarchy { get; set; }

      

    }
}
