﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
      public   class  BaseVD
    {
        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        public   string  VDencryptedCode { get; set; }
        public string VDhomePort { get; set; }
        public string VDflagCountry { get; set; }
        public int? VDlength { get; set; }
        public string VDlengthCategory { get; set; }
        public int? VDpower { get; set; }
        public int? VDsize { get; set; }
        public string VDsizeUnit { get; set; }
        public int VDtype { get; set; }

       
    }
}
