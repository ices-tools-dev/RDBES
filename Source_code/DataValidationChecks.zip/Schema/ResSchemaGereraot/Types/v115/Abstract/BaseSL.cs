﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public   class  BaseSL

    {
        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        public string  SLlistName { get; set; }
      public string SLspeciesCode { get; set; }
      public string SLcommercialSpecies { get; set; }
         public string  SLcatchFraction { get; set; }
    }
}
