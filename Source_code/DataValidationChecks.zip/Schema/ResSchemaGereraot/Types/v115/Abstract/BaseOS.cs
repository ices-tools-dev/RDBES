﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ResSchemaGenerator.Types.v115.Abstract
{
     public   class  BaseOS

    {
        [XmlAttribute(attributeName: "ln")]
        public int ln { get; set; }
        public string  OSnationalLocationName { get; set; }
         public string OSstratification { get; set; }
      public string OSlocation { get; set; }
         public DateTime OSsamplingDate { get; set; }
         public DateTime? OSsamplingTime { get; set; }
         public string  OSstratum { get; set; }
      public string OSclustering { get; set; }
      public string  OSclusterName { get; set; }
      public string OSsampler { get; set; }
      public string OStimeUnit { get; set; }
      public decimal? OStimeValue { get; set; }
      public int? OStotal { get; set; }
      public int? OSsampled { get; set; }
      public decimal? OSsampProb { get; set; }
      public string OSselectionMethod { get; set; }
      public string OSlocationType { get; set; }
      public string OSselectionMethodCluster { get; set; }
      public int? OStotalClusters { get; set; }
      public int? OSsampledClusters { get; set; }
         public decimal? OSclustersProb { get; set; }
      public string OSreasonNotSampled { get; set; }

       
    }
}
