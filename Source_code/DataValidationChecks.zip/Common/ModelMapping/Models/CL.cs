﻿using DbDataModel.HierarchiesModels;
using ModelMapping;
using ResCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ModelMapping.Models
{
    public class CL : ModelMapping
    {
        public CL() : base() { }
        public override Dictionary<string, FieldElement> FieldsMapping() {

            var cl = new CommercialLanding();
           

            this.AddField(nameof(cl.ClrecordType), "CL");
            this.AddField(nameof(cl.CldataTypeOfScientificWeight), "CLdataTypeOfScientificWeight", Utility.CodeType.DataTypeOfScientificWeight);
            this.AddField(nameof(cl.CldataSourceOfScientificWeight), "CLdataSourceOfScientificWeight", Utility.CodeType.DataSourceOfScientificWeight);
            this.AddField(nameof(cl.ClsamplingScheme), "CLsamplingScheme", Utility.CodeType.SamplingScheme);
            this.AddField(nameof(cl.CldataSourceLandingsValue), "CLdataSourceLandingsValue", Utility.CodeType.DataSourceLandingsValue);
            this.AddField(nameof(cl.CllandingCountry), "CLlandingCountry", Utility.CodeType.ISO_3166);
            this.AddField(nameof(cl.ClvesselFlagCountry), "CLvesselFlagCountry", Utility.CodeType.ISO_3166);
            this.AddField(nameof(cl.Clyear), "CLyear", Utility.CodeType.Year);
            this.AddField(nameof(cl.Clquarter), "CLquarter", Utility.CodeType.Quarter);
            this.AddField(nameof(cl.Clmonth), "CLmonth", Utility.CodeType.Month);
            this.AddField(nameof(cl.Clarea), "CLarea", Utility.CodeType.ICES_Area);
            this.AddField(nameof(cl.ClstatisticalRectangle), "CLstatisticalRectangle", Utility.CodeType.StatRec);
            this.AddField(nameof(cl.ClgsaSubarea), "CLgsaSubarea", Utility.CodeType.Areas_GFCM_GSA);
            this.AddField(nameof(cl.CljurisdictionArea), "CLjurisdictionArea", Utility.CodeType.JurisdictionArea);
            this.AddField(nameof(cl.ClexclusiveEconomicZoneIndicator), "CLexclusiveEconomicZoneIndicator", Utility.CodeType.EEZI);
            this.AddField(nameof(cl.ClspeciesCode), "CLspeciesCode", Utility.CodeType.SpecWoRMS);
            this.AddField(nameof(cl.ClspeciesFaoCode), "CLspeciesFaoCode", Utility.CodeType.SpecASFIS);
            this.AddField(nameof(cl.CllandingCategory), "CLlandingCategory", Utility.CodeType.LandingCategory);
            this.AddField(nameof(cl.ClcatchCategory), "CLcatchCategory", Utility.CodeType.CatchCategory);
            this.AddField(nameof(cl.ClregDisCategory), "CLregDisCategory", Utility.CodeType.RegDisCategory);
            this.AddField(nameof(cl.ClcommercialSizeCategoryScale), "CLcommercialSizeCategoryScale", Utility.CodeType.CommercialSizeCategoryScale);
            this.AddField(nameof(cl.ClcommercialSizeCategory), "CLcommercialSizeCategory", Utility.CodeType.CommercialSizeCategory);
            this.AddField(nameof(cl.ClnationalFishingActivity), "CLnationalFishingActivity", Utility.CodeType.NationalFishingActivity);
            this.AddField(nameof(cl.Clmetier6), "CLmetier6", Utility.CodeType.Metier6_FishingActivity);
            this.AddField(nameof(cl.ClincidentialByCatchMitigationDevice), "CLincidentialByCatchMitigationDevice", Utility.CodeType.BycatchMitigationDevice);
            this.AddField(nameof(cl.CllandingLocation), "CLlandingLocation", Utility.CodeType.Harbour_LOCODE);
            this.AddField(nameof(cl.ClvesselLengthCategory), "CLvesselLengthCategory", Utility.CodeType.RS_VesselLengthCategory);
            this.AddField(nameof(cl.ClfishingTechnique), "CLfishingTechnique", Utility.CodeType.FishingTechnique);
            this.AddField(nameof(cl.CldeepSeaRegulation), "CLdeepSeaRegulation", Utility.CodeType.YesNoFields);
            this.AddField(nameof(cl.ClofficialWeight), "CLofficialWeight");
            this.AddField(nameof(cl.ClscientificWeight), "CLscientificWeight");
            this.AddField(nameof(cl.ClexplainDifference), "CLexplainDifference", Utility.CodeType.DifferenceReason);
            this.AddField(nameof(cl.CltotalOfficialLandingsValue), "CLtotalOfficialLandingsValue");
            this.AddField(nameof(cl.ClnumberOfUniqueVessels), "CLnumberOfUniqueVessels");
            this.AddField(nameof(cl.ClscientificWeightRse), "CLscientificWeightRSE");
            this.AddField(nameof(cl.ClvalueRse), "CLvalueRSE");
            this.AddField(nameof(cl.ClscientificWeightQualitativeBias), "CLscientificWeightQualitativeBias", Utility.CodeType.QualitativeBias);
            this.AddField(nameof(cl.UserId));
            this.AddField(nameof(cl.TimeStamp));

            return this.fieldElements;

        }
    }
}
