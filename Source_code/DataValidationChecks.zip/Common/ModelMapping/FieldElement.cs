﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace ModelMapping
{
    public class FieldElement
    {
        public Utility.CodeType? CodeType { get; set; }       
        
        public string Name { get; set; }

        public string XmlFieldName { get; set; }




    }

   
}
