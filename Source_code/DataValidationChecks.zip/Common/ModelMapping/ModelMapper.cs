﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static ResCommon.Utility;
using ModelMapping.Models;
using System.Reflection;

namespace ModelMapping
{
    public static class ModelMapper
    {
        public static Dictionary<string, FieldElement>  GetMapping(DataType dataType)
        {

          

            
            ModelMapping mp;
            switch (dataType)
            {                    
                case DataType.CL:
                    mp= new CL();
                    break;
                
                default:
                    throw new Exception($"No Mappings found for data type {dataType.ToString()}");
            }
            
            return mp.FieldsMapping();
            
        
        }

       
      
    }
}
