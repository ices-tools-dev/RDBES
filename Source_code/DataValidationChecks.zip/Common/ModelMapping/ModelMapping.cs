﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ModelMapping
{
    public abstract class ModelMapping
    {
        // holds field name as key
        protected Dictionary<string, FieldElement> fieldElements;
        protected ModelMapping() => this.fieldElements = new Dictionary<string, FieldElement>();

        public abstract Dictionary<string, FieldElement> FieldsMapping();



        protected void AddField(string name, string xmlFieldName) => this.fieldElements.Add(name, new FieldElement()
        {
            XmlFieldName = xmlFieldName,
            Name = name,
            CodeType = null
        });

        protected void AddField(string name) => this.fieldElements.Add(name, new FieldElement()
        {
            XmlFieldName = null,
            Name = name,
            CodeType = null
        });
        protected void AddField(string name, string xmlFieldName, Utility.CodeType codeType) => this.fieldElements.Add(name, new FieldElement()
        {

            XmlFieldName = xmlFieldName,
            Name = name,
            CodeType = codeType


        });

    }
}
