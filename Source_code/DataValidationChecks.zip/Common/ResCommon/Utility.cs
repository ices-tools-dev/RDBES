﻿using System;
using System.Collections.Generic;

namespace ResCommon
{
    public static class Utility
    {
        

        public enum CacheKeys
        {
            /// <summary>
            /// All codes of all types
            /// </summary>
            AllCodes = 1,
            /// <summary>
            /// All codes by a specified type
            /// </summary>
            CodesByType = 2



        }
        public enum UpperHierarchy
        {
            H1,
            H2,
            H3,
            H4,
            H5,
            H6,
            H7,
            H8
        }
        public enum LowerHierarchy {
            A,
            B,
            C,
            D
        }
        public enum HierarchyType
        {

            H1,H2,H3,H4,H5,H6,H7,H8,H9,H10,H11,H12,H13,HCL,HCE,HVD,HSL

        }

        public enum DataExportFormat
        {
            UploadFormat,
            TableWithIdsFormat

        }

        public enum CodeType
        {
            Areas_GFCM_GSA,
            BiologicalMeasurementType,
            BycatchMitigationDevice,
            BycatchMitigationDeviceTarget,            
            CommercialSizeCategoryScale,
            DurationSource,
            EDMO,
            GearType,
            Harbour_LOCODE,
            ICES_Area,
            ISO_3166,
            MeasurementCertainty,
            Metier5_FishingActivity,
            Metier6_FishingActivity,
            METOA,
            Month,
            ObservationActivityType,
            ObservationCode,
            ObservationMethod,
            ProductPresentation,
            Quarter,
            ReasonForNotSampling,
            RegDisCategory,
            AccuracyCode,            
            AggregationLevel,
            CatchCategory,
            CatchFraction,
            CatchRegistration,
            Clustering,
            CommercialSizeCategory,
            DataSourceLandingsValue,
            DataSourceOfScientificWeight,
            DataTypeOfScientificWeight,
            EEZI,
            DifferenceReason,
            FishingTechnique,
            ValidityFlag,            
            JurisdictionArea,
            LandingCategory,
            RS_LEfullTripAvailable,
            LocationType,
            LowerHierarchy,
            NationalFishingActivity,
            QualitativeBias,
            RS_Region,
            SamplingScheme,
            RS_SamplingType,
            SEXCO,          
            UpperHierarchy,
            RS_VesselLengthCategory,
            VesselSizeUnit,
            RS_VesselType,
            Sampler,
            SampleType,
            SamplingSchemeType,
            SamplingUnit,
            SelectionDevice,
            SelectionMethod,
            SpecASFIS,
            SpecimensState,
            SpecWoRMS,
            StateOfProcessing,
            StatRec,
            TargetSpecies,
            TimeUnit,
            ValueUnitOrScale,
            Year,
            YesNoFields
        }

        ////    // dictionary contains code type name as in Database

        ////    private static Dictionary<CodeType, string> _dictCodeTypes = new Dictionary<CodeType, string>
        ////{
        ////       // generic type =  Year 
        ////       { CodeType.Year,"Year" },
        ////        // generic type = EDMO
        ////       { CodeType.EDMO,"EDMO" },
        ////        //generic type = StatRec
        ////        { CodeType.StatRec,"StatRec" },
        ////        //generic type GearType
        ////        { CodeType.GearType,"GearType" },
        ////        // generic type ICES_Area
        ////        { CodeType.ICES_Area,"ICES_Area" },
        ////        // generic type SpecWoRMS
        ////        { CodeType.SpecWoRMS,"SpecWoRMS" },
        ////        // generic type ISO_3166
        ////        { CodeType.ISO_3166,"ISO_3166" },
        ////        // generic type TargetSpecies
        ////        { CodeType.TargetSpecies,"TargetSpecies" },
        ////        // generic type YesNoFields
        ////        { CodeType.YesNoFields,"YesNoFields" },

        ////        { CodeType.AccuracyCode,"AccuracyCode" },
        ////        { CodeType.AggregationLevel,"AggregationLevel" },
        ////        { CodeType.BiologicalMeasurementType,"BiologicalMeasurementType" },
        ////        { CodeType.RS_MeasurementEquipment,"RS_MeasurementEquipment" },
        ////        { CodeType.CatchCategory,"CatchCategory" },
        ////        { CodeType.CatchRegistration,"CatchRegistration" },
        ////        { CodeType.Clustering,"Clustering" },
        ////        { CodeType.CommercialSizeCategory,"CommercialSizeCategory" },
        ////        { CodeType.CommercialSizeCategoryScale,"CommercialSizeCategoryScale" },
        ////        { CodeType.RS_EEZ,"RS_EEZ" },
        ////        { CodeType.Metier5_FishingActivity,"Metier5_FishingActivity" },
        ////        { CodeType.Metier6_FishingActivity,"Metier6_FishingActivity" },
        ////        { CodeType.NationalFishingActivity,"NationalFishingActivity" },
        ////        { CodeType.SpecASFIS,"SpecASFIS" },
        ////        { CodeType.ValidityFlag,"ValidityFlag" },
        ////       // 2019 09 10 remove for now function unit field
        ////        // { CodeType.RS_FunctionalUnit,"RS_FunctionalUnit" },
        ////        { CodeType.RS_Harbour,"RS_Harbour" },
        ////        { CodeType.UpperHierarchy,"UpperHierarchy" },
        ////        { CodeType.LandingCategory,"LandingCategory" },
        ////        { CodeType.RS_LEfullTripAvailable,"RS_LEfullTripAvailable" },
        ////        { CodeType.LocationType,"LocationType" },
        ////        { CodeType.LowerHierarchy,"LowerHierarchy" },
        ////        { CodeType.BiologicalMeasurementType,"BiologicalMeasurementType" },
        ////        { CodeType.RS_MethodForMeasurement,"RS_MethodForMeasurement" },
        ////        { CodeType.ProductPresentation,"ProductPresentation" },
        ////        { CodeType.ReasonForNotSampling,"ReasonForNotSampling" },
        ////        { CodeType.RS_Region,"RS_Region" },
        ////        { CodeType.Sampler,"Sampler" },
        ////        { CodeType.SelectionDevice,"SelectionDevice" },
        ////        { CodeType.SelectionMethod,"SelectionMethod" },
        ////        { CodeType.SEXCO,"SEXCO" },
        ////        { CodeType.RS_Stratification,"RS_Stratification" },
        ////        { CodeType.RS_Subpolygon,"RS_Subpolygon" },
        ////        { CodeType.TimeUnit,"TimeUnit" },
        ////        { CodeType.RS_UnitOfValue,"RS_UnitOfValue" },
        ////        { CodeType.RS_UnitScaleList,"RS_UnitScaleList" },
        ////        { CodeType.SamplingUnit,"SamplingUnit" },
        ////        { CodeType.RS_VesselLengthCategory,"RS_VesselLengthCategory" },
        ////        { CodeType.VesselSizeUnit,"VesselSizeUnit" },
        ////        { CodeType.RS_VesselType,"RS_VesselType" },
        ////        { CodeType.ObservationCode,"ObservationCode" },
        ////        { CodeType.ObservationActivityType,"ObservationActivityType" },
        ////        { CodeType.ObservationMethod,"ObservationMethod" },
        ////        { CodeType.CatchFraction,"CatchFraction" },
        ////       { CodeType.DataTypeOfScientificWeight ,"DataTypeOfScientificWeight" },
        ////       {CodeType.DataSourceOfScientificWEigh,"DataSourceOfScientificWEigh" },
        ////       {CodeType.RS_NationalProgram,"RS_NationalProgram" },
        ////       {CodeType.DataSourceLandingsValue,"DataSourceLandingsValue" },
        ////       {CodeType.Month,"Month" },
        ////       {CodeType.Quarter,"Quarter" },
        ////       { CodeType.Areas_GFCM_GSA,"Areas_GFCM_GSA"},
        ////       {CodeType.DifferenceReason,"DifferenceReason" },
        ////       {CodeType.QualitativeBias,"QualitativeBias" },
        ////       { CodeType.RS_MitigationDevice,"RS_MitigationDevice" }
        ////};
        public static string GetCodeTypeNameAsInDB(CodeType codeType)
        {
            
            return codeType.ToString();

            //string result;
            //if (_dictCodeTypes.TryGetValue(codeType, out result))
            //{
            //    return result;
            //}
            //else
            //{
            //    throw new Exception("dictionary has no value for the key'"+codeType.ToString()+"'");
            //}
        }

        public enum ConstraintType
        {
           
                DE1,
                DE2,
                SA1,
                FT1,
                SL1,
                SD1,
                FO1,
                SS1,
                SS2,
                BV1,
                BV2,
                FM1,
                TE1,
                OS1,                
                LE1,
                LE2,
                LE3

        }

        public enum HierarchyBaseDataType
        {
            CS,
            CL,
            CE,
            SL,
            VD
        }
        public static HierarchyBaseDataType MapHierarchyToHierarchyBaseDataType(HierarchyType hierarchyType)
        {
            

            
            switch (hierarchyType)
            {
                case HierarchyType.H1:
                   return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H2:
                    return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H3:
                    return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H4:
                    return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H5:
                    return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H6:
                    return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H7:
                    return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H8:
                    return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H9:
                    return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H10:
                    return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H11:
                    return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H12:
                    return HierarchyBaseDataType.CS;
                    
                case HierarchyType.H13:
                    return HierarchyBaseDataType.CS;
                    

                case HierarchyType.HCL:
                    return HierarchyBaseDataType.CL;
                    
                case HierarchyType.HCE:
                    return HierarchyBaseDataType.CE;
                    
                case HierarchyType.HSL:
                    return HierarchyBaseDataType.SL;
                    
                case HierarchyType.HVD:
                    return HierarchyBaseDataType.VD;
                default: throw new Exception($"no mapping found  between hierarchy {hierarchyType.ToString()} to HierarchyBaseDataType");



            }
            
        }
      
        public enum DataType
        {
            DE,
            SD,
            VD,
            VS,
            FT,
            FO,
            SS,
            SA,
            BV,
            FM,
            LE,
            LO,
            OS,            
            TE,
            CE,
            CL,

            SL,
                //,
            //SLC,
            //SLS
            
            // delete log
            DL,
            // delete log of code fields
            DLCF,
            // delete log of string fields
            DLSF


        }
        public enum RecordType
        {
            DE,
            SD,
            VD,
            VS,
            FT,
            FO,
            SS,
            SA,
            BV,
            FM,
            LE,
            LO,
            OS,
            TE,
            CE,
            CL,
            SL

        }

       

        public static string PasswordSpecialCharacterList()
        {
            return "!#$%&()*+,.:;<=>?@_{|}~";
        }
    }
}

    
    

