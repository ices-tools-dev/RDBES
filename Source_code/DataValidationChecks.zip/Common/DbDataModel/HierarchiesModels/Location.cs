﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
    public partial class Location
    {
     public Location()
        {
            TemporalEvents = new HashSet<TemporalEvent>();
        }

         public int Loid { get; set; }
         public int Sdid { get; set; }
        [ImportOrder(1)] public string LorecordType { get; set; }
        [ImportOrder(2)] public int LosequenceNumber { get; set; }
        [ImportOrder(3)] public int Lostratification { get; set; }
        [ImportOrder(4)] public int Lolocode { get; set; }
        [ImportOrder(5)] public string LolocationName { get; set; }
        [ImportOrder(6)] public int? LolocationType { get; set; }
        [ImportOrder(7)] public string LostratumName { get; set; }
        [ImportOrder(8)] public int Loclustering { get; set; }
        [ImportOrder(9)] public string LoclusterName { get; set; }
        [ImportOrder(10)] public int? Losampler { get; set; }
        [ImportOrder(11)] public int? LonumberTotal { get; set; }
        [ImportOrder(12)] public int? LonumberSampled { get; set; }
        [ImportOrder(13)] public decimal? LoselectionProb { get; set; }
        [ImportOrder(14)] public decimal? LoinclusionProb { get; set; }
        [ImportOrder(15)] public int LoselectionMethod { get; set; }
        [ImportOrder(16)] public string LounitName { get; set; }
        [ImportOrder(17)] public int? LoselectionMethodCluster { get; set; }
        [ImportOrder(18)] public int? LonumberTotalClusters { get; set; }
        [ImportOrder(19)] public int? LonumberSampledClusters { get; set; }
        [ImportOrder(20)] public decimal? LoselectionProbCluster { get; set; }
        [ImportOrder(21)] public decimal? LoinclusionProbCluster { get; set; }
        [ImportOrder(22)] public int Losampled { get; set; }
        [ImportOrder(23)] public int? LoreasonNotSampled { get; set; }

        public virtual SamplingDetails Sd { get; set; }
        public virtual ICollection<TemporalEvent> TemporalEvents { get; set; }
    }
}
