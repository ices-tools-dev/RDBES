﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
     public partial class OnshoreEvent
    {
        public OnshoreEvent()
        {
            FishingTrips = new HashSet<FishingTrip>();
            LandingEvents = new HashSet<LandingEvent>();
            SpeciesSelections = new HashSet<SpeciesSelection>();
        }

         public int Osid { get; set; }
         public int? Sdid { get; set; }
        [ImportOrder(1)] public string OsrecordType { get; set; }
        [ImportOrder(2)] public int OssequenceNumber { get; set; }
        [ImportOrder(3)] public int Osstratification { get; set; }
        [ImportOrder(4)] public int Oslocode { get; set; }
        [ImportOrder(5)] public string OslocationName { get; set; }
        [ImportOrder(6)] public int? OslocationType { get; set; }
        [ImportOrder(7)] public DateTime OssamplingDate { get; set; }
        [ImportOrder(8)] public DateTime? OssamplingTime { get; set; }
        [ImportOrder(9)] public string OsstratumName { get; set; }
        [ImportOrder(10)] public int Osclustering { get; set; }
        [ImportOrder(11)] public string OsclusterName { get; set; }
        [ImportOrder(12)] public int? Ossampler { get; set; }
        [ImportOrder(13)] public int? OstimeUnit { get; set; }
        [ImportOrder(14)] public decimal? OstimeValue { get; set; }
        [ImportOrder(15)] public int? OsnumberTotal { get; set; }
        [ImportOrder(16)] public int? OsnumberSampled { get; set; }
        [ImportOrder(17)] public decimal? OsselectionProb { get; set; }
        [ImportOrder(18)] public decimal? OsinclusionProb { get; set; }
        [ImportOrder(19)] public int OsselectionMethod { get; set; }
        [ImportOrder(20)] public string OsunitName { get; set; }
        [ImportOrder(21)] public int? OsselectionMethodCluster { get; set; }
        [ImportOrder(22)] public int? OsnumberTotalClusters { get; set; }
        [ImportOrder(23)] public int? OsnumberSampledClusters { get; set; }
        [ImportOrder(25)] public decimal? OsselectionProbCluster { get; set; }
        [ImportOrder(26)] public decimal? OsinclusionProbCluster { get; set; }
        [ImportOrder(27)] public int Ossampled { get; set; }
        [ImportOrder(28)] public int? OsreasonNotSampled { get; set; }

        public virtual SamplingDetails Sd { get; set; }
         public virtual ICollection<FishingTrip> FishingTrips { get; set; }
         public virtual ICollection<LandingEvent> LandingEvents { get; set; }
         public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
    }
}
