﻿using System;
using System.Collections.Generic;

namespace DbDataModel.HierarchiesModels
{
    public partial class CommercialEffort
    {
        public int Ceid { get; set; }
        [ImportOrder(1)] public string UserId { get; set; }
        [ImportOrder(2)] public DateTime TimeStamp { get; set; }
        [ImportOrder(3)] public string CerecordType { get; set; }
        [ImportOrder(4)] public int CedataTypeForScientificEffort { get; set; }
        [ImportOrder(5)] public int CedataSourceForScientificEffort { get; set; }
        [ImportOrder(6)] public int? CesamplingScheme { get; set; }
        [ImportOrder(7)] public int CevesselFlagCountry { get; set; }
        [ImportOrder(8)] public int Ceyear { get; set; }
        [ImportOrder(9)] public int Cequarter { get; set; }
        [ImportOrder(10)] public int? Cemonth { get; set; }
        [ImportOrder(11)] public int Cearea { get; set; }
        [ImportOrder(12)] public int CestatisticalRectangle { get; set; }
        [ImportOrder(13)] public int CegsaSubarea { get; set; }
        [ImportOrder(14)] public int? CejurisdictionArea { get; set; }
        [ImportOrder(15)] public int? CeexclusiveEconomicZoneIndicator { get; set; }
        [ImportOrder(16)] public int? CenationalFishingActivity { get; set; }
        [ImportOrder(17)] public int Cemetier6 { get; set; }
        [ImportOrder(18)] public int CeincidentalByCatchMitigationDevice { get; set; }
        [ImportOrder(19)] public int CelandingLocation { get; set; }
        [ImportOrder(20)] public int CevesselLengthCategory { get; set; }
        [ImportOrder(21)] public int? CefishingTechnique { get; set; }
        [ImportOrder(22)] public int? CedeepSeaRegulation { get; set; }
        [ImportOrder(23)] public decimal CenumberOfFractionTrips { get; set; }
        [ImportOrder(24)] public int CenumberOfDominantTrips { get; set; }
        [ImportOrder(25)] public decimal CeofficialDaysAtSea { get; set; }
        [ImportOrder(26)] public decimal CescientificDaysAtSea { get; set; }
        [ImportOrder(27)] public decimal CeofficialFishingDays { get; set; }
        [ImportOrder(28)] public decimal CescientificFishingDays { get; set; }
        [ImportOrder(29)] public int? CeofficialNumberOfHaulsOrSets { get; set; }
        [ImportOrder(30)] public int? CescientificNumberOfHaulsOrSets { get; set; }
        [ImportOrder(31)] public decimal? CeofficialVesselFishingHour { get; set; }
        [ImportOrder(32)] public decimal? CescientificVesselFishingHour { get; set; }
        [ImportOrder(33)] public decimal? CeofficialSoakingMeterHour { get; set; }
        [ImportOrder(34)] public decimal? CescientificSoakingMeterHour { get; set; }
        [ImportOrder(35)] public int CeofficialkWdaysAtSea { get; set; }
        [ImportOrder(36)] public int CescientifickWdaysAtSea { get; set; }
        [ImportOrder(37)] public int CeofficialkWfishingDays { get; set; }
        [ImportOrder(38)] public int CescientifickWfishingDays { get; set; }
        [ImportOrder(39)] public int? CeofficialkWfishingHours { get; set; }
        [ImportOrder(40)] public int? CescientifickWfishingHours { get; set; }
        [ImportOrder(41)] public int CegTdaysAtSea { get; set; }
        [ImportOrder(42)] public int CegTfishingDays { get; set; }
        [ImportOrder(43)] public long? CegTfishingHours { get; set; }
        [ImportOrder(44)] public int CenumberOfUniqueVessels { get; set; }
        [ImportOrder(45)] public int? CescientificFishingDaysRse { get; set; }
        [ImportOrder(46)] public int? CescientificFishingDaysQualitativeBias { get; set; }

    }
}
