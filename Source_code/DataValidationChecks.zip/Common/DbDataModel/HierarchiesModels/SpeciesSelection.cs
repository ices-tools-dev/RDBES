﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
     public partial class SpeciesSelection
    {
        public SpeciesSelection()
        {
            LandingEvents = new HashSet<LandingEvent>();
            Samples = new HashSet<Sample>();
        }

         public int Ssid { get; set; }
         public int? Leid { get; set; }
         public int? Foid { get; set; }
         public int? Teid { get; set; }
         public int? Ftid { get; set; }
         public int Slid { get; set; }
         public int? Osid { get; set; }
        [ImportOrder(1)] public string SsrecordType { get; set; }
        [ImportOrder(1)] public int SssequenceNumber { get; set; }
        [ImportOrder(1)] public int Ssstratification { get; set; }
        [ImportOrder(1)] public int SsobservationActivityType { get; set; }
        [ImportOrder(1)] public int SscatchFraction { get; set; }
        [ImportOrder(1)] public int SsobservationType { get; set; }
        [ImportOrder(1)] public string SsstratumName { get; set; }
        [ImportOrder(1)] public int Ssclustering { get; set; }
        [ImportOrder(1)] public string SsclusterName { get; set; }
        [ImportOrder(1)] public int? Sssampler { get; set; }
        [ImportOrder(1)] public string SsspeciesListName { get; set; }
        [ImportOrder(1)] public int SsuseForCalculateZero { get; set; }
        [ImportOrder(1)] public int? SsnumberTotal { get; set; }
        [ImportOrder(1)] public int? SsnumberSampled { get; set; }
        [ImportOrder(1)] public int? SsselectionProb { get; set; }
        [ImportOrder(1)] public int? SsinclusionProb { get; set; }
        [ImportOrder(1)] public int SsselectionMethod { get; set; }
        [ImportOrder(1)] public string SsunitName { get; set; }
        [ImportOrder(1)] public int? SsselectionMethodCluster { get; set; }
        [ImportOrder(1)] public int? SsnumberTotalClusters { get; set; }
        [ImportOrder(1)] public int? SsnumberSampledClusters { get; set; }
        [ImportOrder(1)] public decimal? SsselectionProbCluster { get; set; }
        [ImportOrder(1)] public decimal? SsinclusionProbCluster { get; set; }
        [ImportOrder(1)] public int Sssampled { get; set; }
        [ImportOrder(1)] public int? SsreasonNotSampled { get; set; }

         public virtual FishingOperation Fo { get; set; }
         public virtual FishingTrip Ft { get; set; }
         public virtual LandingEvent Le { get; set; }
         public virtual OnshoreEvent Os { get; set; }
         public virtual SpeciesList Sl { get; set; }
         public virtual TemporalEvent Te { get; set; }
         public virtual ICollection<LandingEvent> LandingEvents { get; set; }
         public virtual ICollection<Sample> Samples { get; set; }
    }
}
