﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
     public partial class TemporalEvent
    {
     public TemporalEvent()
        {
            FishingTrips = new HashSet<FishingTrip>();
            LandingEvents = new HashSet<LandingEvent>();
            SpeciesSelections = new HashSet<SpeciesSelection>();
            VesselSelections = new HashSet<VesselSelection>();
        }

     public int Teid { get; set; }
     public int Sdid { get; set; }
     public int? Loid { get; set; }
     public int? Vsid { get; set; }
        [ImportOrder(1)] public string TerecordType { get; set; }
        [ImportOrder(2)] public int TesequenceNumber { get; set; }
        [ImportOrder(3)] public int Testratification { get; set; }
        [ImportOrder(4)] public int TetimeUnit { get; set; }
        [ImportOrder(5)] public string TestratumName { get; set; }
        [ImportOrder(6)] public int Teclustering { get; set; }
        [ImportOrder(7)] public string TeclusterName { get; set; }
        [ImportOrder(8)] public int? Tesampler { get; set; }
        [ImportOrder(9)] public int? TenumberTotal { get; set; }
        [ImportOrder(10)] public int? TenumberSampled { get; set; }
        [ImportOrder(11)] public decimal? TeselectionProb { get; set; }
        [ImportOrder(12)] public decimal? TeinclusionProb { get; set; }
        [ImportOrder(13)] public int TeselectionMethod { get; set; }
        [ImportOrder(14)] public string TeunitName { get; set; }
        [ImportOrder(15)] public int? TeselectionMethodCluster { get; set; }
        [ImportOrder(16)] public int? TenumberTotalClusters { get; set; }
        [ImportOrder(17)] public int? TenumberSampledClusters { get; set; }
        [ImportOrder(18)] public decimal? TeselectionProbCluster { get; set; }
        [ImportOrder(19)] public decimal? TeinclusionProbCluster { get; set; }
        [ImportOrder(20)] public int Tesampled { get; set; }
        [ImportOrder(21)] public int? TereasonNotSampled { get; set; }

        public virtual Location Lo { get; set; }
         public virtual SamplingDetails Sd { get; set; }
         public virtual VesselSelection Vs { get; set; }
         public virtual ICollection<FishingTrip> FishingTrips { get; set; }
         public virtual ICollection<LandingEvent> LandingEvents { get; set; }
         public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
         public virtual ICollection<VesselSelection> VesselSelections { get; set; }
    }
}
