﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
     public partial class LandingEvent
    {
         public LandingEvent()
        {
            Samples = new HashSet<Sample>();
            SpeciesSelections = new HashSet<SpeciesSelection>();
        }

         public int Leid { get; set; }
         public int? Osid { get; set; }
        public int? Ftid { get; set; }
        public int? Vsid { get; set; }
        public int? Teid { get; set; }
        public int? Said { get; set; }
        public int? Vdid { get; set; }
        public int? Foid { get; set; }
        public int? Ssid { get; set; }
        [ImportOrder(1)] public string LerecordType { get; set; }
        [ImportOrder(2)] public string LeencryptedVesselCode { get; set; }
        [ImportOrder(3)] public int Lestratification { get; set; }
        [ImportOrder(4)] public int LesequenceNumber { get; set; }
        [ImportOrder(5)] public int? LehaulNumber { get; set; }
        [ImportOrder(6)] public string LestratumName { get; set; }
        [ImportOrder(7)] public int Leclustering { get; set; }
        [ImportOrder(8)] public string LeclusterName { get; set; }
        [ImportOrder(9)] public int? Lesampler { get; set; }
        [ImportOrder(10)] public int LemixedTrip { get; set; }
        [ImportOrder(11)] public int LecatchReg { get; set; }
        [ImportOrder(12)] public int? Lelocode { get; set; }
        [ImportOrder(13)] public string LelocationName { get; set; }
        [ImportOrder(14)] public int? LelocationType { get; set; }
        [ImportOrder(15)] public int Lecountry { get; set; }
        [ImportOrder(16)] public DateTime? Ledate { get; set; }
        [ImportOrder(17)] public DateTime? Letime { get; set; }
        [ImportOrder(18)] public int? LeexclusiveEconomicZoneIndicator { get; set; }
        [ImportOrder(19)] public int Learea { get; set; }
        [ImportOrder(20)] public int? Lerectangle { get; set; }
        [ImportOrder(21)] public int? LegsaSubarea { get; set; }
        [ImportOrder(22)] public int? LejurisdictionArea { get; set; }
        [ImportOrder(23)] public int? LenationalFishingActivity { get; set; }
        [ImportOrder(24)] public int? Lemetier5 { get; set; }
        [ImportOrder(25)] public int Lemetier6 { get; set; }
        [ImportOrder(26)] public int Legear { get; set; }
        [ImportOrder(27)] public int? LemeshSize { get; set; }
        [ImportOrder(28)] public int? LeselectionDevice { get; set; }
        [ImportOrder(29)] public int? LeselectionDeviceMeshSize { get; set; }
        [ImportOrder(31)] public int? LetargetSpecies { get; set; }
        [ImportOrder(32)] public int LemitigationDevice { get; set; }
        [ImportOrder(33)] public int? LegearDimensions { get; set; }
        [ImportOrder(34)] public int? LenumberTotal { get; set; }
        [ImportOrder(35)] public int? LenumberSampled { get; set; }
        [ImportOrder(36)] public decimal? LeselectionProb { get; set; }
        [ImportOrder(37)] public decimal? LeinclusionProb { get; set; }
        [ImportOrder(38)] public int LeselectionMethod { get; set; }
        [ImportOrder(39)] public string LeunitName { get; set; }
        [ImportOrder(40)] public int? LeselectionMethodCluster { get; set; }
        [ImportOrder(41)] public int? LenumberTotalClusters { get; set; }
        [ImportOrder(42)] public int? LenumberSampledClusters { get; set; }
        [ImportOrder(43)] public decimal? LeselectionProbCluster { get; set; }
        [ImportOrder(44)] public decimal? LeinclusionProbCluster { get; set; }
        [ImportOrder(45)] public int Lesampled { get; set; }
        [ImportOrder(46)] public int? LereasonNotSampled { get; set; }
        [ImportOrder(47)] public int? LefullTripAvailable { get; set; }

        public virtual FishingOperation Fo { get; set; }
        public virtual FishingTrip Ft { get; set; }
        public virtual OnshoreEvent Os { get; set; }
        public virtual Sample Sa { get; set; }
        public virtual SpeciesSelection Ss { get; set; }
        public virtual TemporalEvent Te { get; set; }
        public virtual VesselDetails Vd { get; set; }
        public virtual VesselSelection Vs { get; set; }
        public virtual ICollection<Sample> Samples { get; set; }
        public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
    }
}
