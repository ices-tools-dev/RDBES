﻿using System;
using System.Collections.Generic;



namespace DbDataModel.HierarchiesModels
{
    public partial class BiologicalVariable
    {
        public int Bvid { get; set; }
        public int? Said { get; set; }
        public int? Fmid { get; set; }
        [ImportOrder(1)] public string BvrecordType { get; set; }
        [ImportOrder(2)] public string BvnationalUniqueFishId { get; set; }
        [ImportOrder(3)] public int BVstateOfProcessing { get; set; }
        [ImportOrder(4)] public int Bvpresentation { get; set; }
        [ImportOrder(5)] public int Bvstratification { get; set; }
        [ImportOrder(6)] public string BvstratumName { get; set; }
        [ImportOrder(7)] public int BvtypeMeasured { get; set; }
        [ImportOrder(8)] public string BvvalueMeasured { get; set; }
        [ImportOrder(9)] public int BvvalueUnitOrScale { get; set; }
        [ImportOrder(10)] public int? Bvmethod { get; set; }
        [ImportOrder(11)] public int? BvmeasurementEquipment { get; set; }
        [ImportOrder(12)] public int? Bvaccuracy { get; set; }
        [ImportOrder(13)] public int BvcertaintyQualitative { get; set; }
        [ImportOrder(14)] public decimal? BvcertaintyQuantitative { get; set; }
        [ImportOrder(15)] public decimal BvconversionFactorAssessment { get; set; }
        [ImportOrder(16)] public int BvtypeAssessment { get; set; }
        [ImportOrder(17)] public int? BvnumberTotal { get; set; }
        [ImportOrder(18)] public int? BvnumberSampled { get; set; }
        [ImportOrder(19)] public decimal? BvselectionProb { get; set; }
        [ImportOrder(20)] public decimal? BvinclusionProb { get; set; }
        [ImportOrder(21)] public int BvselectionMethod { get; set; }
        [ImportOrder(22)] public string BvunitName { get; set; }
        [ImportOrder(23)] public int? Bvsampler { get; set; }

        public virtual FrequencyMeasure Fm { get; set; }
        public virtual Sample Sa { get; set; }
    }
}
