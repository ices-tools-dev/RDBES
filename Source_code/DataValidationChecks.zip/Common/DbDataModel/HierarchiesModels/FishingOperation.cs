﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
     public partial class FishingOperation
    {
         public FishingOperation()
        {
            FishingTrips = new HashSet<FishingTrip>();
            LandingEvents = new HashSet<LandingEvent>();
            SpeciesSelections = new HashSet<SpeciesSelection>();
        }

         public int Foid { get; set; }
         public int? Ftid { get; set; }
         public int? Sdid { get; set; }
        [ImportOrder(1)] public string ForecordType { get; set; }
        [ImportOrder(2)] public int Fostratification { get; set; }
        [ImportOrder(3)] public int FosequenceNumber { get; set; }
        [ImportOrder(4)] public string FostratumName { get; set; }
        [ImportOrder(5)] public int Foclustering { get; set; }
        [ImportOrder(6)] public string FoclusterName { get; set; }
        [ImportOrder(7)] public int? Fosampler { get; set; }
        [ImportOrder(8)] public int FoaggregationLevel { get; set; }
        [ImportOrder(9)] public int Fovalidity { get; set; }
        [ImportOrder(10)] public int FocatchReg { get; set; }
        [ImportOrder(11)] public DateTime? FostartDate { get; set; }
        [ImportOrder(12)] public DateTime? FostartTime { get; set; }
        [ImportOrder(13)] public DateTime FoendDate { get; set; }
        [ImportOrder(14)] public DateTime? FoendTime { get; set; }
        [ImportOrder(15)] public int? Foduration { get; set; }
        [ImportOrder(16)] public int FodurationSource { get; set; }
        [ImportOrder(17)] public int? FohandlingTime { get; set; }
        [ImportOrder(18)] public decimal? FostartLat { get; set; }
        [ImportOrder(19)] public decimal? FostartLon { get; set; }
        [ImportOrder(20)] public decimal? FostopLat { get; set; }
        [ImportOrder(21)] public decimal? FostopLon { get; set; }
        [ImportOrder(22)] public int? FoexclusiveEconomicZoneIndicator { get; set; }
        [ImportOrder(23)] public int Foarea { get; set; }
        [ImportOrder(24)] public int? Forectangle { get; set; }
        [ImportOrder(25)] public int? FogsaSubarea { get; set; }
        [ImportOrder(26)] public int? FojurisdictionArea { get; set; }
        [ImportOrder(27)] public int? FofishingDepth { get; set; }
        [ImportOrder(28)] public int? FowaterDepth { get; set; }
        [ImportOrder(29)] public int? FonationalFishingActivity { get; set; }
        [ImportOrder(30)] public int? Fometier5 { get; set; }
        [ImportOrder(31)] public int? Fometier6 { get; set; }
        [ImportOrder(32)] public int Fogear { get; set; }
        [ImportOrder(33)] public int? FomeshSize { get; set; }
        [ImportOrder(34)] public int? FoselectionDevice { get; set; }
        [ImportOrder(35)] public int? FoselectionDeviceMeshSize { get; set; }
        [ImportOrder(36)] public int? FotargetSpecies { get; set; }
        [ImportOrder(37)] public int FoincidentalByCatchMitigationDeviceFirst { get; set; }
        [ImportOrder(38)] public int FoincidentalByCatchMitigationDeviceTargetFirst { get; set; }
        [ImportOrder(39)] public int FoincidentalByCatchMitigationDeviceSecond { get; set; }
        [ImportOrder(40)] public int FoincidentalByCatchMitigationDeviceTargetSecond { get; set; }
        [ImportOrder(41)] public int? FogearDimensions { get; set; }
        [ImportOrder(42)] public int FoobservationCode { get; set; }
        [ImportOrder(43)] public int? FonumberTotal { get; set; }
        [ImportOrder(44)] public decimal? FonumberSampled { get; set; }
        [ImportOrder(45)] public decimal? FoselectionProb { get; set; }
        [ImportOrder(46)] public decimal? FoinclusionProb { get; set; }
        [ImportOrder(47)] public int FoselectionMethod { get; set; }
        [ImportOrder(48)] public string FounitName { get; set; }
        [ImportOrder(49)] public int? FoselectionMethodCluster { get; set; }
        [ImportOrder(50)] public int? FonumberTotalClusters { get; set; }
        [ImportOrder(51)] public int? FonumberSampledClusters { get; set; }
        [ImportOrder(52)] public decimal? FoselectionProbCluster { get; set; }
        [ImportOrder(53)] public decimal? FoinclusionProbCluster { get; set; }
        [ImportOrder(54)] public int Fosampled { get; set; }
        [ImportOrder(55)] public int? ForeasonNotSampled { get; set; }

         public virtual FishingTrip Ft { get; set; }
         public virtual SamplingDetails Sd { get; set; }
         public virtual ICollection<FishingTrip> FishingTrips { get; set; }
         public virtual ICollection<LandingEvent> LandingEvents { get; set; }
         public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
    }
}
