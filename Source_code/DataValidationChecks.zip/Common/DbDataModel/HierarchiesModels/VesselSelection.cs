﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
     public partial class VesselSelection
    {
         public VesselSelection()
        {
            FishingTrips = new HashSet<FishingTrip>();
            LandingEvents = new HashSet<LandingEvent>();
            TemporalEvents = new HashSet<TemporalEvent>();
        }

        public int Vsid { get; set; }
        public int? Sdid { get; set; }
        public int? Vdid { get; set; }
        public int? Teid { get; set; }
        [ImportOrder(1)] public string VsrecordType { get; set; }
        [ImportOrder(2)] public int VssequenceNumber { get; set; }
        [ImportOrder(3)] public string VsencryptedVesselCode { get; set; }
        [ImportOrder(4)] public int Vsstratification { get; set; }
        [ImportOrder(5)] public string VsstratumName { get; set; }
        [ImportOrder(6)] public int Vsclustering { get; set; }
        [ImportOrder(7)] public string VsclusterName { get; set; }
        [ImportOrder(8)] public int? Vssampler { get; set; }
        [ImportOrder(9)] public int? VsnumberTotal { get; set; }
        [ImportOrder(10)] public int? VsnumberSampled { get; set; }
        [ImportOrder(11)] public decimal? VsselectionProb { get; set; }
        [ImportOrder(12)] public decimal? VsinclusionProb { get; set; }
        [ImportOrder(13)] public int VsselectionMethod { get; set; }
        [ImportOrder(14)] public string VsunitName { get; set; }
        [ImportOrder(15)] public int? VsselectionMethodCluster { get; set; }
        [ImportOrder(16)] public int? VsnumberTotalClusters { get; set; }
        [ImportOrder(17)] public int? VsnumberSampledClusters { get; set; }
        [ImportOrder(18)] public decimal? VsselectionProbCluster { get; set; }
        [ImportOrder(19)] public decimal? VsinclusionProbCluster { get; set; }
        [ImportOrder(20)] public int Vssampled { get; set; }
        [ImportOrder(21)] public int? VsreasonNotSampled { get; set; }

         public virtual SamplingDetails Sd { get; set; }
         public virtual TemporalEvent Te { get; set; }
         public virtual VesselDetails Vd { get; set; }
         public virtual ICollection<FishingTrip> FishingTrips { get; set; }
         public virtual ICollection<LandingEvent> LandingEvents { get; set; }
         public virtual ICollection<TemporalEvent> TemporalEvents { get; set; }
    }
}
