﻿using System;
using System.Collections.Generic;



namespace DbDataModel.HierarchiesModels
{
     public partial class SamplingDetails
    {
         public SamplingDetails()
        {
            FishingOperations = new HashSet<FishingOperation>();
            FishingTrips = new HashSet<FishingTrip>();
            Locations = new HashSet<Location>();
            OnshoreEvents = new HashSet<OnshoreEvent>();
            TemporalEvents = new HashSet<TemporalEvent>();
            VesselSelections = new HashSet<VesselSelection>();
        }

        public int Sdid { get; set; }
        public int? Deid { get; set; }
        [ImportOrder(1)] public string UserId { get; set; }
        [ImportOrder(2)] public DateTime TimeStamp { get; set; }
        [ImportOrder(3)] public string SdrecordType { get; set; }
        [ImportOrder(4)] public int Sdcountry { get; set; }
        [ImportOrder(5)] public int Sdinstitution { get; set; }

         public virtual Design De { get; set; }
         public virtual ICollection<FishingOperation> FishingOperations { get; set; }
         public virtual ICollection<FishingTrip> FishingTrips { get; set; }
         public virtual ICollection<Location> Locations { get; set; }
         public virtual ICollection<OnshoreEvent> OnshoreEvents { get; set; }
         public virtual ICollection<TemporalEvent> TemporalEvents { get; set; }
         public virtual ICollection<VesselSelection> VesselSelections { get; set; }
    }
}
