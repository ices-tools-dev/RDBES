﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
    public partial class FishingTrip
    {
        public FishingTrip()
        {
            FishingOperations = new HashSet<FishingOperation>();
            LandingEvents = new HashSet<LandingEvent>();
            SpeciesSelections = new HashSet<SpeciesSelection>();
        }

        public int Ftid { get; set; }
        public int? Osid { get; set; }
        public int? Vsid { get; set; }
        public int? Vdid { get; set; }
        public int? Sdid { get; set; }
        public int? Foid { get; set; }
        public int? Teid { get; set; }
        [ImportOrder(1)] public string FtrecordType { get; set; }
        [ImportOrder(2)] public string FtencryptedVesselCode { get; set; }
        [ImportOrder(3)] public string FtsequenceNumber { get; set; }
        [ImportOrder(4)] public int Ftstratification { get; set; }
        [ImportOrder(5)] public string FtstratumName { get; set; }
        [ImportOrder(6)] public int Ftclustering { get; set; }
        [ImportOrder(7)] public string FtclusterName { get; set; }
        [ImportOrder(8)] public int? Ftsampler { get; set; }
        [ImportOrder(9)] public int FtsamplingType { get; set; }
        [ImportOrder(10)] public int? FtnumberOfHaulsOrSets { get; set; }
        [ImportOrder(11)] public int? FtdepartureLocation { get; set; }
        [ImportOrder(12)] public DateTime? FtdepartureDate { get; set; }
        [ImportOrder(13)] public DateTime? FtdepartureTime { get; set; }
        [ImportOrder(14)] public int FtarrivalLocation { get; set; }
        [ImportOrder(15)] public DateTime FtarrivalDate { get; set; }
        [ImportOrder(16)] public DateTime? FtarrivalTime { get; set; }
        [ImportOrder(17)] public int? FtnumberTotal { get; set; }
        [ImportOrder(18)] public int? FtnumberSampled { get; set; }
        [ImportOrder(19)] public decimal? FtselectionProb { get; set; }
        [ImportOrder(20)] public decimal? FtinclusionProb { get; set; }
        [ImportOrder(21)] public int FtselectionMethod { get; set; }
        [ImportOrder(22)] public string FtunitName { get; set; }
        [ImportOrder(23)] public int? FtselectionMethodCluster { get; set; }
        [ImportOrder(24)] public int? FtnumberTotalClusters { get; set; }
        [ImportOrder(25)] public int? FtnumberSampledClusters { get; set; }
        [ImportOrder(26)] public decimal? FtselectionProbCluster { get; set; }
        [ImportOrder(27)] public decimal? FtinclusionProbCluster { get; set; }
        [ImportOrder(28)] public int Ftsampled { get; set; }
        [ImportOrder(29)] public int? FtreasonNotSampled { get; set; }

        public virtual FishingOperation Fo { get; set; }
        public virtual OnshoreEvent Os { get; set; }
        public virtual SamplingDetails Sd { get; set; }
        public virtual TemporalEvent Te { get; set; }
        public virtual VesselDetails Vd { get; set; }
        public virtual VesselSelection Vs { get; set; }
        public virtual ICollection<FishingOperation> FishingOperations { get; set; }
        public virtual ICollection<LandingEvent> LandingEvents { get; set; }
        public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
    }
}
