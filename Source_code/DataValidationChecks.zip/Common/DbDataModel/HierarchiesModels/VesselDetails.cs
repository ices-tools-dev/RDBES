﻿using System;
using System.Collections.Generic;



namespace DbDataModel.HierarchiesModels
{
    public partial class VesselDetails
    {
     public VesselDetails()
        {
            FishingTrips = new HashSet<FishingTrip>();
            LandingEvents = new HashSet<LandingEvent>();
            VesselSelections = new HashSet<VesselSelection>();
        }

         public int Vdid { get; set; }
        [ImportOrder(1)] public string UserId { get; set; }
        [ImportOrder(2)] public DateTime TimeStamp { get; set; }
        [ImportOrder(3)] public string VdrecordType { get; set; }
        [ImportOrder(4)] public string VdencryptedVesselCode { get; set; }
        [ImportOrder(5)] public int Vdyear { get; set; }
        [ImportOrder(6)] public int Vdcountry { get; set; }
        [ImportOrder(7)] public int? VdhomePort { get; set; }
        [ImportOrder(8)] public int VdflagCountry { get; set; }
        [ImportOrder(9)] public decimal? Vdlength { get; set; }
        [ImportOrder(10)] public int VdlengthCategory { get; set; }
        [ImportOrder(11)] public int? Vdpower { get; set; }
        [ImportOrder(12)] public int? Vdtonnage { get; set; }
        [ImportOrder(13)] public int? VdtonUnit { get; set; }

         public virtual ICollection<FishingTrip> FishingTrips { get; set; }
         public virtual ICollection<LandingEvent> LandingEvents { get; set; }
         public virtual ICollection<VesselSelection> VesselSelections { get; set; }
    }
}
