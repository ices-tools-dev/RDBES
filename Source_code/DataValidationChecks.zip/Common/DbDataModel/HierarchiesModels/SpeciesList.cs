﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
    public partial class SpeciesList
    {
      public SpeciesList()
        {
            SpeciesSelections = new HashSet<SpeciesSelection>();
        }

      public int Slid { get; set; }
        [ImportOrder(1)] public string UserId { get; set; }
        [ImportOrder(2)] public DateTime TimeStamp { get; set; }
        [ImportOrder(3)] public string SlrecordType { get; set; }
        [ImportOrder(4)] public int Slcountry { get; set; }
        [ImportOrder(5)] public int Slinstitute { get; set; }
        [ImportOrder(6)] public string SlspeciesListName { get; set; }
        [ImportOrder(7)] public int Slyear { get; set; }
        [ImportOrder(8)] public int SlcatchFraction { get; set; }
        [ImportOrder(9)] public int SlcommercialTaxon { get; set; }
        [ImportOrder(10)] public int SlspeciesCode { get; set; }

         public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
    }
}
