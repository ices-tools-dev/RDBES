﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
     public partial class Design
    {
         public Design()
        {
            SamplingDetails = new HashSet<SamplingDetails>();
        }

        public int Deid { get; set; }
        [ImportOrder(1)] public string UserId { get; set; }
        [ImportOrder(2)] public DateTime TimeStamp { get; set; }
        [ImportOrder(3)] public string DerecordType { get; set; }
        [ImportOrder(4)] public int DesamplingScheme { get; set; }
        [ImportOrder(5)] public int DesamplingSchemeType { get; set; }
        [ImportOrder(6)] public int Deyear { get; set; }
        [ImportOrder(7)] public string DestratumName { get; set; }
        [ImportOrder(8)] public int DehierarchyCorrect { get; set; }
        [ImportOrder(9)] public int Dehierarchy { get; set; }
        [ImportOrder(10)] public int Desampled { get; set; }
        [ImportOrder(11)] public int? DereasonNotSampled { get; set; }

        public virtual ICollection<SamplingDetails> SamplingDetails { get; set; }
    }
}
