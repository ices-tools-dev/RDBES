﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
     public partial class FrequencyMeasure
    {
         public FrequencyMeasure()
        {
            BiologicalVariables = new HashSet<BiologicalVariable>();
        }

         public int Fmid { get; set; }
         public int Said { get; set; }
        [ImportOrder(1)] public string FmrecordType { get; set; }
        [ImportOrder(2)] public int FmstateOfProcessing { get; set; }
        [ImportOrder(3)] public int Fmpresentation { get; set; }
        [ImportOrder(4)] public int FmclassMeasured { get; set; }
        [ImportOrder(5)] public int FmnumberAtUnit { get; set; }
        [ImportOrder(6)] public int FmtypeMeasured { get; set; }
        [ImportOrder(7)] public int? Fmmethod { get; set; }
        [ImportOrder(8)] public int? FmmeasurementEquipment { get; set; }
        [ImportOrder(9)] public int? Fmaccuracy { get; set; }
        [ImportOrder(10)] public decimal FmconversionFactorAssessment { get; set; }
        [ImportOrder(11)] public int FmtypeAssessment { get; set; }
        [ImportOrder(12)] public int? Fmsampler { get; set; }
        [ImportOrder(13)] public decimal? FmaddGrpMeasurement { get; set; }
        [ImportOrder(14)] public int? FmaddGrpMeasurementType { get; set; }

         public virtual Sample Sa { get; set; }
         public virtual ICollection<BiologicalVariable> BiologicalVariables { get; set; }
    }
}
