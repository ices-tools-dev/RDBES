﻿using System;
using System.Collections.Generic;



namespace  DbDataModel.HierarchiesModels
{
     public partial class Sample
    {
        public Sample()
        {
            BiologicalVariables = new HashSet<BiologicalVariable>();
            FrequencyMeasures = new HashSet<FrequencyMeasure>();
            InverseSaparent = new HashSet<Sample>();
            LandingEvents = new HashSet<LandingEvent>();
        }

         public int Said { get; set; }
         public int? SaparentId { get; set; }
        public int Ssid { get; set; }
        public int? Leid { get; set; }
        [ImportOrder(1)] public string SarecordType { get; set; }
        [ImportOrder(2)] public int SasequenceNumber { get; set; }
        [ImportOrder(3)] public int? SaparentSequenceNumber { get; set; }
        [ImportOrder(4)] public int Sastratification { get; set; }
        [ImportOrder(5)] public string SastratumName { get; set; }
        [ImportOrder(6)] public int SaspeciesCode { get; set; }
        [ImportOrder(7)] public int? SaspeciesCodeFao { get; set; }
        [ImportOrder(8)] public int SastateOfProcessing { get; set; }
        [ImportOrder(9)] public int Sapresentation { get; set; }
        [ImportOrder(10)] public int SaspecimensState { get; set; }
        [ImportOrder(11)] public int SacatchCategory { get; set; }
        [ImportOrder(12)] public int? SalandingCategory { get; set; }
        [ImportOrder(13)] public int? SacommSizeCatScale { get; set; }
        [ImportOrder(14)] public int? SacommSizeCat { get; set; }
        [ImportOrder(15)] public int Sasex { get; set; }
        [ImportOrder(16)] public int? SaexclusiveEconomicZoneIndicator { get; set; }
        [ImportOrder(17)] public int? Saarea { get; set; }
        [ImportOrder(18)] public int? Sarectangle { get; set; }
        [ImportOrder(19)] public int? SagsaSubarea { get; set; }
        [ImportOrder(20)] public int? SajurisdictionArea { get; set; }
        [ImportOrder(21)] public int? SanationalFishingActivity { get; set; }
        [ImportOrder(22)] public int? Sametier5 { get; set; }
        [ImportOrder(23)] public int? Sametier6 { get; set; }
        [ImportOrder(24)] public int? Sagear { get; set; }
        [ImportOrder(25)] public int? SameshSize { get; set; }
        [ImportOrder(26)] public int? SaselectionDevice { get; set; }
        [ImportOrder(27)] public int? SaselectionDeviceMeshSize { get; set; }
        [ImportOrder(28)] public int SaunitType { get; set; }
        [ImportOrder(29)] public long? SatotalWeightLive { get; set; }
        [ImportOrder(30)] public int? SasampleWeightLive { get; set; }
        [ImportOrder(31)] public decimal? SanumberTotal { get; set; }
        [ImportOrder(32)] public decimal? SanumberSampled { get; set; }
        [ImportOrder(33)] public decimal? SaselectionProb { get; set; }
        [ImportOrder(34)] public decimal? SainclusionProb { get; set; }
        [ImportOrder(35)] public int SaselectionMethod { get; set; }
        [ImportOrder(36)] public string SaunitName { get; set; }
        [ImportOrder(37)] public int SalowerHierarchy { get; set; }
        [ImportOrder(38)] public int? Sasampler { get; set; }
        [ImportOrder(39)] public int Sasampled { get; set; }
        [ImportOrder(40)] public int? SareasonNotSampledFm { get; set; }
        [ImportOrder(41)] public int? SareasonNotSampledBv { get; set; }
        [ImportOrder(42)] public long? SatotalWeightMeasured { get; set; }
        [ImportOrder(43)] public long? SasampleWeightMeasured { get; set; }
        [ImportOrder(44)] public decimal? SaconversionFactorMeasLive { get; set; }

         public virtual LandingEvent Le { get; set; }
         public virtual Sample Saparent { get; set; }
         public virtual SpeciesSelection Ss { get; set; }
         public virtual ICollection<BiologicalVariable> BiologicalVariables { get; set; }
         public virtual ICollection<FrequencyMeasure> FrequencyMeasures { get; set; }
         public virtual ICollection<Sample> InverseSaparent { get; set; }
         public virtual ICollection<LandingEvent> LandingEvents { get; set; }
    }
}
