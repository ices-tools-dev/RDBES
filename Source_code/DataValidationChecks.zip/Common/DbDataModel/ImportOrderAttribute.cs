﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DbDataModel
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple =false)]
    public class ImportOrderAttribute: Attribute
    {
        public uint Order { get; set; }

        public ImportOrderAttribute(uint order)
        {
            if (order <= 0) throw new Exception("Import Order can not be either 0 or Less than zero");
            this.Order = order;
        }
    }
}
