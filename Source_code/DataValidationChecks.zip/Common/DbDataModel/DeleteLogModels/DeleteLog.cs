﻿using System;
using System.Collections.Generic;



namespace DbDataModel.DeleteLogModels
{
    public partial class DeleteLog
    {
        public DeleteLog()
        {
            DeleteLogCodeFields = new HashSet<DeleteLogCodeField>();
            DeleteLogStringFields = new HashSet<DeleteLogStringField>();
        }

        public long DeleteLogId { get; set; }
       [ImportOrder(1)] public string UserId { get; set; }
        [ImportOrder(2)] public DateTime TimeStamp { get; set; }
        [ImportOrder(3)] public string DataType { get; set; }
        [ImportOrder(4)] public bool Status { get; set; }

        public virtual ICollection<DeleteLogCodeField> DeleteLogCodeFields { get; set; }
        public virtual ICollection<DeleteLogStringField> DeleteLogStringFields { get; set; }
    }
}
