﻿using System;
using System.Collections.Generic;



namespace DbDataModel.DeleteLogModels
{
    public partial class DeleteLogStringField
    {
        public long Id { get; set; }
        [ImportOrder(1)] public long DeleteLogId { get; set; }
        [ImportOrder(2)] public string FieldName { get; set; }
        [ImportOrder(3)] public string FieldData { get; set; }

        public virtual DeleteLog DeleteLog { get; set; }
    }
}
