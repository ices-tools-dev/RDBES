﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace TypeDefinitions.RecordTypes
{
    public interface  IDataRecordType
    {
        string[] Allfields { get; }
       Utility.RecordType RecordType { get; }

    }
}
