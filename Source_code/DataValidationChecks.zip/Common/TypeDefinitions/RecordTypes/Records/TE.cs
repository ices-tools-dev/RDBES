
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class TE : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.TE; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"TEsequenceNumber"
,"TEstratification"
,"TEtimeUnit"
,"TEstratumName"
,"TEclustering"
,"TEclusterName"
,"TEsampler"
,"TEnumberTotal"
,"TEnumberSampled"
,"TEselectionProb"
,"TEinclusionProb"
,"TEselectionMethod"
,"TEunitName"
,"TEselectionMethodCluster"
,"TEnumberTotalClusters"
,"TEnumberSampledClusters"
,"TEselectionProbCluster"
,"TEinclusionProbCluster"
,"TEsampled"
,"TEreasonNotSampled"};}}
			}
			}