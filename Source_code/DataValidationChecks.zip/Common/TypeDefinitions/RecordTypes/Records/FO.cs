
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class FO : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.FO; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"FOstratification"
,"FOsequenceNumber"
,"FOstratumName"
,"FOclustering"
,"FOclusterName"
,"FOsampler"
,"FOaggregationLevel"
,"FOvalidity"
,"FOcatchReg"
,"FOstartDate"
,"FOstartTime"
,"FOendDate"
,"FOendTime"
,"FOduration"
,"FOdurationSource"
,"FOhandlingTime"
,"FOstartLat"
,"FOstartLon"
,"FOstopLat"
,"FOstopLon"
,"FOexclusiveEconomicZoneIndicator"
,"FOarea"
,"FOrectangle"
,"FOgsaSubarea"
,"FOjurisdictionArea"
,"FOfishingDepth"
,"FOwaterDepth"
,"FOnationalFishingActivity"
,"FOmetier5"
,"FOmetier6"
,"FOgear"
,"FOmeshSize"
,"FOselectionDevice"
,"FOselectionDeviceMeshSize"
,"FOtargetSpecies"
,"FOincidentalByCatchMitigationDeviceFirst"
,"FOincidentalByCatchMitigationDeviceTargetFirst"
,"FOincidentalByCatchMitigationDeviceSecond"
,"FOincidentalByCatchMitigationDeviceTargetSecond"
,"FOgearDimensions"
,"FOobservationCode"
,"FOnumberTotal"
,"FOnumberSampled"
,"FOselectionProb"
,"FOinclusionProb"
,"FOselectionMethod"
,"FOunitName"
,"FOselectionMethodCluster"
,"FOnumberTotalClusters"
,"FOnumberSampledClusters"
,"FOselectionProbCluster"
,"FOinclusionProbCluster"
,"FOsampled"
,"FOreasonNotSampled"};}}
			}
			}