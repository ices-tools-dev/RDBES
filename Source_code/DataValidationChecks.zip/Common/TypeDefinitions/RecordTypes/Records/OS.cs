﻿
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class OS : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.OS; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"OSsequenceNumber"
,"OSstratification"
,"OSlocode"
,"OSlocationName"
,"OSlocationType"
,"OSsamplingDate"
,"OSsamplingTime"
,"OSstratumName"
,"OSclustering"
,"OSclusterName"
,"OSsampler"
,"OStimeUnit"
,"OStimeValue"
,"OSnumberTotal"
,"OSnumberSampled"
,"OSselectionProb"
,"OSinclusionProb"
,"OSselectionMethod"
,"OSunitName"
,"OSselectionMethodCluster"
,"OSnumberTotalClusters"
,"OSnumberSampledClusters"
,"OSselectionProbCluster"
,"OSinclusionProbCluster"
,"OSsampled"
,"OSreasonNotSampled"};}}
			}
			}
