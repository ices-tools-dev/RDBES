﻿
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class CL : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.CL; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"CLdataTypeOfScientificWeight"
,"CLdataSourceOfScientificWeight"
,"CLsamplingScheme"
,"CLdataSourceLandingsValue"
,"CLlandingCountry"
,"CLvesselFlagCountry"
,"CLyear"
,"CLquarter"
,"CLmonth"
,"CLarea"
,"CLstatisticalRectangle"
,"CLgsaSubarea"
,"CLjurisdictionArea"
,"CLexclusiveEconomicZoneIndicator"
,"CLspeciesCode"
,"CLspeciesFaoCode"
,"CLlandingCategory"
,"CLcatchCategory"
,"CLregDisCategory"
,"CLcommercialSizeCategoryScale"
,"CLcommercialSizeCategory"
,"CLnationalFishingActivity"
,"CLmetier6"
,"CLincidentialByCatchMitigationDevice"
,"CLlandingLocation"
,"CLvesselLengthCategory"
,"CLfishingTechnique"
,"CLdeepSeaRegulation"
,"CLofficialWeight"
,"CLscientificWeight"
,"CLexplainDifference"
,"CLtotalOfficialLandingsValue"
,"CLnumberOfUniqueVessels"
,"CLscientificWeightRSE"
,"CLvalueRSE"
,"CLscientificWeightQualitativeBias"};}}
			}
			}
