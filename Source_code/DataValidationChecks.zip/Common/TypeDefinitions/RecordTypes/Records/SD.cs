
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class SD : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.SD; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"SDcountry"
,"SDinstitution"};}}
			}
			}