
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class SL : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.SL; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"SLcountry"
,"SLinstitute"
,"SLspeciesListName"
,"SLyear"
,"SLcatchFraction"
,"SLcommercialTaxon"
,"SLspeciesCode"};}}
			}
			}