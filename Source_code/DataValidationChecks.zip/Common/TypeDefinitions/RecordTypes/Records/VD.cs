
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class VD : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.VD; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"VDencryptedVesselCode"
,"VDyear"
,"VDcountry"
,"VDhomePort"
,"VDflagCountry"
,"VDlength"
,"VDlengthCategory"
,"VDpower"
,"VDtonnage"
,"VDtonUnit"};}}
			}
			}