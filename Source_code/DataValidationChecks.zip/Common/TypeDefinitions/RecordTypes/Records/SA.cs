﻿
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class SA : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.SA; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"SAsequenceNumber"
,"SAparentSequenceNumber"
,"SAstratification"
,"SAstratumName"
,"SAspeciesCode"
,"SAspeciesCodeFAO"
,"SAstateOfProcessing"
,"SApresentation"
,"SAspecimensState"
,"SAcatchCategory"
,"SAlandingCategory"
,"SAcommSizeCatScale"
,"SAcommSizeCat"
,"SAsex"
,"SAexclusiveEconomicZoneIndicator"
,"SAarea"
,"SArectangle"
,"SAgsaSubarea"
,"SAjurisdictionArea"
,"SAnationalFishingActivity"
,"SAmetier5"
,"SAmetier6"
,"SAgear"
,"SAmeshSize"
,"SAselectionDevice"
,"SAselectionDeviceMeshSize"
,"SAunitType"
,"SAtotalWeightLive"
,"SAsampleWeightLive"
,"SAnumberTotal"
,"SAnumberSampled"
,"SAselectionProb"
,"SAinclusionProb"
,"SAselectionMethod"
,"SAunitName"
,"SAlowerHierarchy"
,"SAsampler"
,"SAsampled"
,"SAreasonNotSampledFM"
,"SAreasonNotSampledBV"
,"SAtotalWeightMeasured"
,"SAsampleWeightMeasured"
,"SAconversionFactorMeasLive"};}}
			}
			}
