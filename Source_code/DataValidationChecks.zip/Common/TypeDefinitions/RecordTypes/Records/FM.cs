﻿
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class FM : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.FM; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"FMstateOfProcessing"
,"FMpresentation"
,"FMclassMeasured"
,"FMnumberAtUnit"
,"FMtypeMeasured"
,"FMmethod"
,"FMmeasurementEquipment"
,"FMaccuracy"
,"FMconversionFactorAssessment"
,"FMtypeAssessment"
,"FMsampler"
,"FMaddGrpMeasurement"
,"FMaddGrpMeasurementType"};}}
			}
			}
