﻿
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class BV : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.BV; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"BVnationalUniqueFishId"
,"BVstateOfProcessing"
,"BVpresentation"
,"BVstratification"
,"BVstratumName"
,"BVtypeMeasured"
,"BVvalueMeasured"
,"BVvalueUnitOrScale"
,"BVmethod"
,"BVmeasurementEquipment"
,"BVaccuracy"
,"BVcertaintyQualitative"
,"BVceratintyQuantitative"
,"BVconversionFactorAssessment"
,"BVtypeAssessment"
,"BVnumberTotal"
,"BVnumberSampled"
,"BVselectionProb"
,"BVinclusionProb"
,"BVselectionMethod"
,"BVunitName"
,"BVsampler"};}}
			}
			}
