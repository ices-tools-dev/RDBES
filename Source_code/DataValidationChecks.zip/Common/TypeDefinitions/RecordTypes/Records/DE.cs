
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class DE : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.DE; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"DEsamplingScheme"
,"DEsamplingSchemeType"
,"DEyear"
,"DEstratumName"
,"DEhierarchyCorrect"
,"DEhierarchy"
,"DEsampled"
,"DEreasonNotSampled"};}}
			}
			}