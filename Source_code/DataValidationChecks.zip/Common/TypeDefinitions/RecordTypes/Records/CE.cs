﻿
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
    public class CE : IDataRecordType
    {
        public Utility.RecordType RecordType { get { return Utility.RecordType.CE; } }
        public string[] Allfields
        {
            get
            {
                return new string[] { "LN","RecordType"
,"CEdataTypeForScientificEffort"
,"CEdataSourceForScientificEffort"
,"CEsamplingScheme"
,"CEvesselFlagCountry"
,"CEyear"
,"CEquarter"
,"CEmonth"
,"CEarea"
,"CEstatisticalRectangle"
,"CEgsaSubarea"
,"CEjurisdictionArea"
,"CEexclusiveEconomicZoneIndicator"
,"CEnationalFishingActivity"
,"CEmetier6"
,"CEincidentalByCatchMitigationDevice"
,"CElandingLocation"
,"CEvesselLengthCategory"
,"CEfishingTechnique"
,"CEdeepSeaRegulation"
,"CEnumberOfFractionTrips"
,"CEnumberOfDominantTrips"
,"CEofficialDaysAtSea"
,"CEscientificDaysAtSea"
,"CEofficialFishingDays"
,"CEscientificFishingDays"
,"CEofficialNumberOfHaulsOrSets"
,"CEscientificNumberOfHaulsOrSets"
,"CEofficialVesselFishingHour"
,"CEscientificVesselFishingHour"
,"CEofficialSoakingMeterHour"
,"CEscientificSoakingMeterHour"
,"CEofficialkWDaysAtSea"
,"CEscientifickWDaysAtSea"
,"CEofficialkWFishingDays"
,"CEscientifickWFishingDays"
,"CEofficialkWFishingHours"
,"CEscientifickWFishingHours"
,"CEgTDaysAtSea"
,"CEgTFishingDays"
,"CEgTFishingHours"
,"CEnumberOfUniqueVessels"
,"CEscientificFishingDaysRSE"
,"CEscientificFishingDaysQualitativeBias"};
            }
        }
    }
}
