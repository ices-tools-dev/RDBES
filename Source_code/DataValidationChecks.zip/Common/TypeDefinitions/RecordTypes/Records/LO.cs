
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class LO : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.LO; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"LOsequenceNumber"
,"LOstratification"
,"LOlocode"
,"LOlocationName"
,"LOlocationType"
,"LOstratumName"
,"LOclustering"
,"LOclusterName"
,"LOsampler"
,"LOnumberTotal"
,"LOnumberSampled"
,"LOselectionProb"
,"LOinclusionProb"
,"LOselectionMethod"
,"LOunitName"
,"LOselectionMethodCluster"
,"LOnumberTotalClusters"
,"LOnumberSampledClusters"
,"LOselectionProbCluster"
,"LOinclusionProbCluster"
,"LOsampled"
,"LOreasonNotSampled"};}}
			}
			}