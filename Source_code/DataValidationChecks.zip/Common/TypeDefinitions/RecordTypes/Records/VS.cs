
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class VS : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.VS; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"VSsequenceNumber"
,"VSencryptedVesselCode"
,"VSstratification"
,"VSstratumName"
,"VSclustering"
,"VSclusterName"
,"VSsampler"
,"VSnumberTotal"
,"VSnumberSampled"
,"VSselectionProb"
,"VSinclusionProb"
,"VSselectionMethod"
,"VSunitName"
,"VSselectionMethodCluster"
,"VSnumberTotalClusters"
,"VSnumberSampledClusters"
,"VSselectionProbCluster"
,"VSinclusionProbCluster"
,"VSsampled"
,"VSreasonNotSampled"};}}
			}
			}