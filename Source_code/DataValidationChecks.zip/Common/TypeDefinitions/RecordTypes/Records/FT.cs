
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class FT : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.FT; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"FTencryptedVesselCode"
,"FTsequenceNumber"
,"FTstratification"
,"FTstratumName"
,"FTclustering"
,"FTclusterName"
,"FTsampler"
,"FTsamplingType"
,"FTnumberOfHaulsOrSets"
,"FTdepartureLocation"
,"FTdepartureDate"
,"FTdepartureTime"
,"FTarrivalLocation"
,"FTarrivalDate"
,"FTarrivalTime"
,"FTnumberTotal"
,"FTnumberSampled"
,"FTselectionProb"
,"FTinclusionProb"
,"FTselectionMethod"
,"FTunitName"
,"FTselectionMethodCluster"
,"FTnumberTotalClusters"
,"FTnumberSampledClusters"
,"FTselectionProbCluster"
,"FTinclusionProbCluster"
,"FTsampled"
,"FTreasonNotSampled"};}}
			}
			}