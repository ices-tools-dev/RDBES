
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class SS : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.SS; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"SSsequenceNumber"
,"SSstratification"
,"SSobservationActivityType"
,"SScatchFraction"
,"SSobservationType"
,"SSstratumName"
,"SSclustering"
,"SSclusterName"
,"SSsampler"
,"SSspeciesListName"
,"SSuseForCalculateZero"
,"SSnumberTotal"
,"SSnumberSampled"
,"SSselectionProb"
,"SSinclusionProb"
,"SSselectionMethod"
,"SSunitName"
,"SSselectionMethodCluster"
,"SSnumberTotalClusters"
,"SSnumberSampledClusters"
,"SSselectionProbCluster"
,"SSinclusionProbCluster"
,"SSsampled"
,"SSreasonNotSampled"};}}
			}
			}