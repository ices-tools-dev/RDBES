
using ResCommon;
using System;
			using System.Collections.Generic;
			using System.Text;

namespace TypeDefinitions.RecordTypes.Records
{
	public class LE : IDataRecordType
	{
		public Utility.RecordType RecordType { get { return Utility.RecordType.LE; } }
		public string[] Allfields { get { return new string[] { "LN","RecordType"
,"LEencryptedVesselCode"
,"LEstratification"
,"LEsequenceNumber"
,"LEhaulNumber"
,"LEstratumName"
,"LEclustering"
,"LEclusterName"
,"LEsampler"
,"LEmixedTrip"
,"LEcatchReg"
,"LElocode"
,"LElocationName"
,"LElocationType"
,"LEcountry"
,"LEdate"
,"LEtime"
,"LEexclusiveEconomicZoneIndicator"
,"LEarea"
,"LErectangle"
,"LEgsaSubarea"
,"LEjurisdictionArea"
,"LEnationalFishingActivity"
,"LEmetier5"
,"LEmetier6"
,"LEgear"
,"LEmeshSize"
,"LEselectionDevice"
,"LEselectionDeviceMeshSize"
,"LEtargetSpecies"
,"LEmitigationDevice"
,"LEgearDimensions"
,"LEnumberTotal"
,"LEnumberSampled"
,"LEselectionProb"
,"LEinclusionProb"
,"LEselectionMethod"
,"LEunitName"
,"LEselectionMethodCluster"
,"LEnumberTotalClusters"
,"LEnumberSampledClusters"
,"LEselectionProbCluster"
,"LEinclusionProbCluster"
,"LEsampled"
,"LEreasonNotSampled"
,"LEfullTripAvailable"};}}
			}
			}