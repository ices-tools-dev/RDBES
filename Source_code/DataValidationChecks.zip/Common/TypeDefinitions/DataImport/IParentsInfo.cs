﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace TypeDefinitions.DataImport
{
    public interface IParentsInfo
    {
        Dictionary<Utility.DataType, int> ParentsInfo { get; set; }
    }
}
