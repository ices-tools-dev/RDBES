﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Threading.Tasks;

namespace TypeDefinitions.DataImport
{
    public interface IDataLineInfo: IPrimaryKey
    {
    
        int LN { get; set; }
      
        int PLN { get; set; }
    }
}
