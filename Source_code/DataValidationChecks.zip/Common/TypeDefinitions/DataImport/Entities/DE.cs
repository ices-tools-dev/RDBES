﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using DbDataModel.HierarchiesModels;
namespace TypeDefinitions.DataImport
{
   public class DE:Design,IDataLineInfo
    {
        [NotMapped]
        public int LN { get; set; }
        [NotMapped]
        public int PLN { get; set; }
        [NotMapped]
        public int PrimaryKey { get; set; }
    }
}
