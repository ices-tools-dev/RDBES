using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using ResCommon;
using DbDataModel.HierarchiesModels;

namespace TypeDefinitions.DataImport
{
    public partial class SS : SpeciesSelection, IDataLineInfo
        //, IParentsInfo
    {


        [NotMapped]
        public int LN { get; set; }
        [NotMapped]
        public int PLN { get; set; }
        [NotMapped]
        public int PrimaryKey { get; set; }
      
        //[NotMapped]
      //  public Dictionary<Utility.DataType, int> ParentsInfo { get; set; }

    }
}
