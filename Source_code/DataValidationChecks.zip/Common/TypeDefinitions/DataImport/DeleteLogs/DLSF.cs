﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TypeDefinitions.DataImport.DeleteLogs
{
    public class DLSF : DbDataModel.DeleteLogModels.DeleteLogStringField, IDataLineInfo
    {
        [NotMapped]
        public int LN { get; set; }
        [NotMapped]
        public int PLN { get; set; }
        [NotMapped]
        public int PrimaryKey { get; set; }
    }
}
