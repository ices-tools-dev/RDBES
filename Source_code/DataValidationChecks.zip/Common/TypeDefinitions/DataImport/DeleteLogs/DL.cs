﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TypeDefinitions.DataImport.DeleteLogs
{
    public class DL : DbDataModel.DeleteLogModels.DeleteLog, IDataLineInfo
    {
        [NotMapped]
        public int LN { get; set; }
        [NotMapped]
        public int PLN { get; set; }
        [NotMapped]
        public int PrimaryKey { get; set; }
    }
}
