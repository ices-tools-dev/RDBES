﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TypeDefinitions.DataImport
{
    public interface IDeleteKey
    {
        int DeleteKey { get; set; }
    }
}
