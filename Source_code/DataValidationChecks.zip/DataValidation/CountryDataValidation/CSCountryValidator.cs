﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Linq;
using Validator.Interfaces;
using Validator.Models;

namespace Validator
{
    internal class CSCountryValidator : CommonCountryValidator, ICountryReader
    {
      

        public CSCountryValidator(string pathToXml, HashSet<string> allowedCountryCodes)
        {
            this.pathToXml = pathToXml;
            COUNTRY_ELEMENT_NAME = "SDcountry";
            LINE_NUMBER_ATTRIBUTE_NAME = "ln";
            this.allowedCountryCodes = allowedCountryCodes;
            this.countryReader = Read();
        }

        public IEnumerable<CountryRecord> Read()
        {
                using (XmlReader reader = XmlReader.Create(pathToXml))
                {
                    reader.MoveToContent();
                    reader.Read();
                    reader.Read();
                    uint lastLineNo = 0;
                    while (reader.Read())
                    {
                        if (reader.NodeType == XmlNodeType.Element)
                        {
                            string lineNumberAttributeValue = reader.GetAttribute(LINE_NUMBER_ATTRIBUTE_NAME);
                            if (!string.IsNullOrEmpty(lineNumberAttributeValue))
                            {
                                lastLineNo = uint.Parse(lineNumberAttributeValue);
                            }
                            if (reader.Name.Equals(COUNTRY_ELEMENT_NAME, StringComparison.InvariantCultureIgnoreCase))
                            {
                                XElement el = XNode.ReadFrom(reader) as XElement;
                                if (el != null)
                                {
                                    yield return new CountryRecord { LineNumber = lastLineNo, CountryCode = el.Value };
                                }
                            }
                        }
                    }
                }
            }
        }


      

    }

