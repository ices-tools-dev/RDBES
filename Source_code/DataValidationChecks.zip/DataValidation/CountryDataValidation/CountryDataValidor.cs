﻿using System;
using System.Collections.Generic;
using System.Text;
using Validator.Interfaces;
using Validator.Models;

namespace Validator
{
   public class CountryDataValidor : ICountryDataValidor
    {
        

      public   CommonCountryValidator InitValidation(string pathToXml, string allowedCountryCodes, string DataType)
        {
            return CountryValidatorFactory.Create(pathToXml, allowedCountryCodes, DataType);
        }

    public     CountryValidationResult Validate(CommonCountryValidator validator)
        {
            return validator.Validate();
        }
    }
}
