﻿using System.Collections.Generic;
using Validator.Interfaces;

namespace Validator.Models
{
    public class CountryValidationResult : IValidationResult
    {
        public bool IsValid { get; set; }
        public string Message { get; set; }

        public List<CountryRecord> DisallowedCountries = new List<CountryRecord>();
    }
}
