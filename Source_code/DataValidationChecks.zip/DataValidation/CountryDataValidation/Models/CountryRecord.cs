﻿using System;

namespace Validator.Models
{
    public class CountryRecord
    {
        public uint LineNumber { get; set; }
        public string CountryCode{ get; set; }
    }
}
