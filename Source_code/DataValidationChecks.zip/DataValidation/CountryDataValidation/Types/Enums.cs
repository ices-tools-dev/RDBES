﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataSecurity.Types
{
    static class Enums
    {
        public enum DataTypes
        {

           CS=0,CE,CL,SL,VD

        }
    }
}
