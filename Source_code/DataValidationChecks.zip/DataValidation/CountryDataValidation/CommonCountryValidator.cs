﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using Validator.Interfaces;
using Validator.Models;

namespace Validator
{
    public abstract class CommonCountryValidator: IValidator<CountryValidationResult>
    {
        protected string COUNTRY_ELEMENT_NAME { get; set; }
        protected string LINE_NUMBER_ATTRIBUTE_NAME { get; set; }

        private const int MaximumNumberOForeignCountries = 100;
        protected string pathToXml { get; set; }
      //  public int countryReader { get; set; }
       protected HashSet<string> allowedCountryCodes { get; set; }
       protected  IEnumerable<CountryRecord> countryReader   { get; set; }
        // protected ICountryReader countryReader { get; set; }

        public CountryValidationResult Validate()
        {
           
            if (countryReader == null)
                throw new Exception("Country read from file was not set.");

         
            CountryValidationResult result = new CountryValidationResult();
           
            foreach (var item in countryReader)
            {
                if (!allowedCountryCodes.Contains(item.CountryCode))
                {
                    result.DisallowedCountries.Add(item);
                    return result; 
                }
                if (result.DisallowedCountries.Count == MaximumNumberOForeignCountries)
                    break;
            }
           

         
           
            if (!(result.IsValid = (result.DisallowedCountries.Count == 0)))
            {
                result.Message = $"Found: {result.DisallowedCountries.Count} disallowed country codes";
            }
            return result;
        }
   

       
    }
}
