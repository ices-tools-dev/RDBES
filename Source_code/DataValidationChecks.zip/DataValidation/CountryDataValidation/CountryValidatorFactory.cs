﻿using System;
using System.Collections.Generic;
using System.Linq;
using Validator.Interfaces;
using Validator.Models;

namespace Validator
{
    public class CountryValidatorFactory
    {
        public const char ALLOWED_COUNTRIES_SEPARATOR = ','; //CommonCountryValidator
        private static Dictionary<string, string> dataypeMapper = new Dictionary<string, string>()
                                                             {
                                                                  {"H1",  @"CS"},
                                                                  {"H2",  @"CS"},
                                                                  {"H3",  @"CS"},
                                                                  {"H4",  @"CS"},
                                                                  {"H5",  @"CS"},
                                                                  {"H6",  @"CS"},
                                                                  {"H7",  @"CS"},
                                                                  {"H8",  @"CS"},
                                                                  {"H9",  @"CS"},
                                                                  {"H10",  @"CS"},
                                                                  {"H11",  @"CS"},
                                                                  {"H12",  @"CS"},
                                                                 {"H13",  @"CS"},
                                                                  {"HCL",  @"CL"},
                                                                  {"HCE",  @"CE"},
                                                                   {"HSL",  @"SL"},
                                                                  {"HVD",  @"VD"}

                                                             };
        public static CommonCountryValidator Create(string pathToXml, string allowedCountryCodes, string DataType)
        {
            var countryCodesList =new HashSet<string>( (allowedCountryCodes.Split(ALLOWED_COUNTRIES_SEPARATOR, StringSplitOptions.RemoveEmptyEntries).Select(itm => itm.Trim())).AsEnumerable());
            CommonCountryValidator createdInstance;
            string mappedDataType = string.Empty;
            dataypeMapper.TryGetValue(DataType, out mappedDataType);
            switch (mappedDataType)
            {

                case  "CS":
                    createdInstance=new CSCountryValidator(pathToXml, countryCodesList);
                    break;
                case "CE":
                    createdInstance= new  CECountryValidator(pathToXml, countryCodesList);
                    break;
                case "CL":
                    createdInstance= new CLCountryValidator(pathToXml, countryCodesList);
                    break;
                case "SL":
                    createdInstance = new SLCountryValidator(pathToXml, countryCodesList);
                    break;
                case "VD":
                    createdInstance = new VDCountryValidator(pathToXml, countryCodesList);
                    break;
                default:
                    throw new Exception($"Unknown data type {DataType} was submited for country validation");
                    
            }
          return  createdInstance;

         

        }

      
    }
}
