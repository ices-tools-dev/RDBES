﻿namespace Validator.Interfaces
{
    public interface IValidator<T> where T : IValidationResult {
        T Validate();
    }
}
