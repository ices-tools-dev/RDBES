﻿using System;
using System.Collections.Generic;
using System.Text;
using Validator.Models;

namespace Validator.Interfaces
{
   public interface ICountryDataValidor
    {
        CommonCountryValidator InitValidation(string pathToXml, string allowedCountryCodes, string DataType);
        CountryValidationResult  Validate(CommonCountryValidator validator);
    }
}
