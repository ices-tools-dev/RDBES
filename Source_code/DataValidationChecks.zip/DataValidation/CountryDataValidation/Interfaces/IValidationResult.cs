﻿namespace Validator.Interfaces
{
    public interface IValidationResult
    {
        bool IsValid { get; set; }
        string Message { get; set; }
    }
}
