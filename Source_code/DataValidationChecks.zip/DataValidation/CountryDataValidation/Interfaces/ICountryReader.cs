﻿using System.Collections.Generic;
using Validator.Models;

namespace Validator.Interfaces
{
    public interface ICountryReader
    {
        IEnumerable<CountryRecord> Read();
    }
}
