﻿

using System;
using System.Collections.Generic;

using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using Microsoft.Extensions.Configuration;
using ResCommon;
using ResData.Data;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;

namespace DataImport
{
  public  interface IImporter 
    {
 

        void ImportHierarchy(string path, List<CodeWithType> cachedCodes, List<CodeLookup> codeMaps, ApplicationDbContext dbContext, string userId);



    }
}
