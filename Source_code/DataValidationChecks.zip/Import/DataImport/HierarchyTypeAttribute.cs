﻿using ResCommon;
using System;

namespace DataImport
{

    public class HierarchyTypeAttribute : Attribute
    {
        public Utility.HierarchyType HierarchyType { get; set; }

        public HierarchyTypeAttribute(Utility.HierarchyType type)
        {
            HierarchyType = type;
        }

    }
}
