﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;
using static ResCommon.Utility;

namespace DataImport
{
   public static class Mapping
    {
        public static string GetTableKeyField(Utility.DataType dataType)
        {
            string pkey;
            switch (dataType)
            {
                case DataType.CL:
                    pkey = "Clid";
                    break;
                case DataType.CE:
                    pkey = "Ceid";
                    break;
                case DataType.DE:
                    pkey = "Deid";
                    break;
                case DataType.SD:
                    pkey = "Sdid";
                    break;
                case DataType.VD:
                    pkey = "Vdid";
                    break;
                case DataType.VS:
                    pkey = "Vsid";
                    break;
                case DataType.FT:
                    pkey = "Ftid";
                    break;
                case DataType.FO:

                    pkey = "Foid";
                    break;
                case DataType.SS:
                    pkey = "Ssid";
                    break;
                case DataType.SA:
                    pkey = "Said";
                    break;
                case DataType.BV:
                    pkey = "Bvid";
                    break;
                case DataType.FM:
                    pkey = "Fmid";
                    break;
                case DataType.LE:
                    pkey = "Leid";
                    break;
                case DataType.LO:
                    pkey = "Loid";
                    break;
                case DataType.OS:
                    pkey = "Osid";
                    break;
                case DataType.TE:
                    pkey = "Teid";
                    break;
                case DataType.SL:
                    pkey = "Slid";
                    break;
                //case DataType.SLC:
                //    pkey = "Slcid";
                //    break;
                //case DataType.SLS:
                //    pkey = "Sppid";
                //    break;
                default:
                    throw new Exception("primary key for '" + dataType.ToString() + "' is not defined");



            }

            return pkey;
        }
        public static string GetTableName(Utility.DataType dataType)
        {
            string name;
            switch (dataType)
            {
                case DataType.CL:
                    name = "CommercialLanding";
                    break;
                case DataType.CE:
                    name = "CommercialEffort";
                    break;
                case DataType.DE:
                    name = "Design";
                    break;
                case DataType.SD:
                    name = "Sdid";
                    break;
                case DataType.VD:
                    name = "VesselDetails";
                    break;
                case DataType.VS:
                    name = "VesselSelection";
                    break;
                case DataType.FT:
                    name = "FishingTrip";
                    break;
                case DataType.FO:

                    name = "FishingOperation";
                    break;
                case DataType.SS:
                    name = "SpeciesSelection";
                    break;
                case DataType.SA:
                    name = "Sample";
                    break;
                case DataType.BV:
                    name = "BiologicalVariable";
                    break;
                case DataType.FM:
                    name = "FrequencyMeasure";
                    break;
                case DataType.LE:
                    name = "LandingEvent";
                    break;
                case DataType.LO:
                    name = "Location";
                    break;
                case DataType.OS:
                    name = "OnshoreEvent";
                    break;
                case DataType.TE:
                    name = "TemporalEvent";
                    break;
                case DataType.SL:
                    name = "SpeciesList";
                    break;
              
                default:
                    throw new Exception("table '" + dataType.ToString() + "' is not definded");



            }

            return name;
        }

       
    }
}
