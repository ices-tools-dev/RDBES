﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using ResData.Data;
using ResCommon;
using Microsoft.Extensions.Configuration;
//using EFCore.BulkExtensions;

using ResData.Models.CacheData;
using Microsoft.EntityFrameworkCore;
using ResData.Models.KeyLessEntities;
using DataInsert;
using DataDelete.deleter;

using TypeDefinitions.DataImport;
using DataInsert.code;
using DataExtraction.client;
//using DataImport.deleter;



namespace DataImport.hierarchybase
{
     public abstract class HierarchyBase : IImporter
    {
        
        protected DataHierarchy DataHierarchy;
        protected List<Utility.DataType> ExtractorsDataTypes;

        protected string Path  { get; set; }
        protected List<CodeWithType> CachedCodes { get; set; }
        protected List<CodeLookup> CodeLookups { get; set; }
        
        protected ExtractionClient extractionClient;





        protected List<DE> DEs;
        protected List<SD> SDs;
        protected List<VS> VSs;
        protected List<FT> FTs;
        protected List<FO> FOs;
        protected List<SS> SSs;
        protected List<SA> SAs;
        protected List<FM> FMs;
        protected List<BV> BVs;
        protected List<VD> VDs;
        protected List<TE> TEs;
        protected List<OS> OSs;
        protected List<LE> LEs;
        protected List<LO> LOs;

        protected List<CL> CLs;
        protected List<CE> CEs;

        protected List<SL> SLs;
     //   protected List<SLC> SLCs;
     //   protected List<SLS> SLSs;


        protected ApplicationDbContext _dbContext;
        protected IConfigurationRoot _config;
        protected string userId;
        protected int dataUploadCountryId;


        protected HierarchyBase()
        {

            this.DataHierarchy = new DataHierarchy();
            this.ExtractorsDataTypes = new List<Utility.DataType>();

        }

        protected abstract void SpecifyExtractors();
        protected abstract void ImportDataSetup();
        protected abstract List<int> ExtractDeleteKeys();

        protected abstract void SetPrimaryKeysOfExistingRecordsForHierarchy();
        protected abstract Utility.HierarchyType GetHierarchyName();



        // Behavioural DP: Template Method
        public void ImportHierarchy(string path, List<CodeWithType> cachedCodes, List<CodeLookup> codeLookups, ApplicationDbContext dbContext, string userId)
        {

            
            //initilize
            this.Path = path;
            this.CachedCodes = cachedCodes;
            this._dbContext = dbContext;
            this.userId = userId;
            this.CodeLookups = codeLookups;
        //    this.dataUploadCountryId = dataUploadCountryId;


            SpecifyExtractors();
            SettingExtractorsData();



            using (var transaction = _dbContext.Database.BeginTransaction())
            {
                try
                {
                    // four hours
                    _dbContext.Database.SetCommandTimeout(14400);

                    #region code to delete overwrite data found in overwritting check

                    List<int> deleteIds = ExtractDeleteKeys();
                    if (deleteIds != null)
                    {
                        var hierarchyType = GetHierarchyName();

                        var deleteBatchSize = 10000;
                        for (int i = 0; i < deleteIds.Count(); i += deleteBatchSize)
                        {
                            var batchDeleteIds = deleteIds.Skip(i).Take(deleteBatchSize).ToList();
                            string deleteScript = new HierarchyDeleteScriptBiulder().BuildScriptWithWhereClause(hierarchyType, batchDeleteIds);

                            if (!string.IsNullOrWhiteSpace(deleteScript))
                            {
                                var recordsDeleted = this._dbContext.Database.ExecuteSqlRaw(deleteScript);
                            }
                        }
                    }

                    #endregion


                    #region setting primaray keys of already existings records of DE(H1 to H13)

                    SetPrimaryKeysOfExistingRecordsForHierarchy();
                    
                    #endregion

                    #region insert hierarchies data to db 

                    ImportDataSetup();
                    //var insertData = new InsertData(dbContext);
                    //insertData.Process(this.DataHierarchy);

                    var bulkInsert = new BulkInsert(dbContext, 1000);
                    bulkInsert.Process(this.DataHierarchy);

                    #endregion


                    this._dbContext.SaveChanges();
                }
                catch (Exception ex)
                {
                    // var entries = updateExc.Entries;
                    transaction.Rollback();
                  
                    throw ex;
                }

                transaction.Commit();

            }

        }

        protected void SettingExtractorsData()
        {
            try
            {

                extractionClient = new ExtractionClient(this.Path, this.userId, this.dataUploadCountryId, this.CachedCodes, this.CodeLookups);

                foreach (var dt in this.ExtractorsDataTypes)
            {
                
                SetExtractorData(dt, extractionClient);
            }

            }
            catch (Exception ex)
            {

                throw;
            }
        }
        
        private void SetExtractorData(Utility.DataType dt, ExtractionClient extractionClient)
        {

            switch (dt)
            {
                case Utility.DataType.VD:
                    VDs = new List<VD>();
                    VDs = extractionClient.GetTableData(dt,Utility.RecordType.VD) as List<VD>;

                    break;
                case Utility.DataType.CL:
                    CLs = new List<CL>();
                    CLs = extractionClient.GetTableData(dt, Utility.RecordType.CL) as List<CL>;

                    break;
                case Utility.DataType.CE:
                    CEs = new List<CE>();
                    CEs = extractionClient.GetTableData(dt, Utility.RecordType.CE) as List<CE>;

                    break;
                case Utility.DataType.DE:
                    DEs = new List<DE>();
                    DEs = extractionClient.GetTableData(dt, Utility.RecordType.DE) as List<DE>;

                    break;
                case Utility.DataType.SD:
                    SDs = new List<SD>();
                    SDs = extractionClient.GetTableData(dt, Utility.RecordType.SD) as List<SD>;

                    break;

                case Utility.DataType.VS:
                    VSs = new List<VS>();
                    VSs = extractionClient.GetTableData(dt, Utility.RecordType.VS) as List<VS>;
                    break;
                case Utility.DataType.FT:
                    FTs = new List<FT>();
                    FTs = extractionClient.GetTableData(dt, Utility.RecordType.FT) as List<FT>;
                    break;
                case Utility.DataType.FO:
                    FOs = new List<FO>();
                    FOs = extractionClient.GetTableData(dt, Utility.RecordType.FO) as List<FO>;
                    break;
                case Utility.DataType.SS:
                    SSs = new List<SS>();
                    SSs = extractionClient.GetTableData(dt, Utility.RecordType.SS) as List<SS>;
                    break;
                case Utility.DataType.SA:
                    SAs = new List<SA>();
                    SAs = extractionClient.GetTableData(dt, Utility.RecordType.SA) as List<SA>;
                    break;
                case Utility.DataType.BV:
                    BVs = new List<BV>();
                    BVs = extractionClient.GetTableData(dt, Utility.RecordType.BV) as List<BV>;
                    break;
                case Utility.DataType.FM:
                    FMs = new List<FM>();
                    FMs = extractionClient.GetTableData(dt, Utility.RecordType.FM) as List<FM>;
                    break;
                case Utility.DataType.LE:
                    LEs = new List<LE>();
                    LEs = extractionClient.GetTableData(dt, Utility.RecordType.LE) as List<LE>;
                    break;
                case Utility.DataType.LO:
                    LOs = new List<LO>();
                    LOs = extractionClient.GetTableData(dt, Utility.RecordType.LO) as List<LO>;
                    break;
                case Utility.DataType.OS:
                    OSs = new List<OS>();
                    OSs = extractionClient.GetTableData(dt, Utility.RecordType.OS) as List<OS>;
                    break;

                case Utility.DataType.TE:
                    TEs = new List<TE>();
                    TEs = extractionClient.GetTableData(dt, Utility.RecordType.TE) as List<TE>;
                    break;
                case Utility.DataType.SL:
                    SLs = new List<SL>();
                    SLs = extractionClient.GetTableData(dt, Utility.RecordType.SL) as List<SL>;
                    break;
                //case Utility.DataType.SLC:
                //    SLCs = new List<SLC>();
                //    SLCs = extractionClient.GetTableData(dt, Utility.RecordType.SL) as List<SLC>;
                //    break;
                //case Utility.DataType.SLS:
                //    SLSs = new List<SLS>();
                //    SLSs = extractionClient.GetTableData(dt, Utility.RecordType.SL) as List<SLS>;
                //    break;
                default:
                    throw new NotSupportedException($"Data table extractor does not exist for DataType {dt.ToString()}");
            }
        }



    }


}

