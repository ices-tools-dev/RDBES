﻿using DataDelete.deleter;
using ResCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataImport.hierarchybase
{
    public abstract class HierarchyBaseCS : HierarchyBase
    {
        
        protected HierarchyBaseCS()
        { 
        
        }
       

        protected override List<int> ExtractDeleteKeys()
        {
            var sdDeleteIds = SDs.Where(s => s.DeleteKey > 0).Select(s => s.DeleteKey).ToList();
            return sdDeleteIds;
           
            
        }
        protected override void SetPrimaryKeysOfExistingRecordsForHierarchy()
        {
            var allDesInDb = this._dbContext.Design;
            foreach (var item in this.DEs)
            {
                var de = allDesInDb.Where(d =>
                d.DesamplingScheme.Equals(item.DesamplingScheme)
                &&
                d.Deyear.Equals(item.Deyear)
                &&
                d.DestratumName.Equals(item.DestratumName)
                &&
                d.Dehierarchy.Equals(item.Dehierarchy)
                
                ).SingleOrDefault();

                if (de != null)
                    item.PrimaryKey = de.Deid;
            }

          
        }
    }
}
