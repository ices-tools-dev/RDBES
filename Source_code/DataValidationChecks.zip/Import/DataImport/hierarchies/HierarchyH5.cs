﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using ResCommon;

using EFCore.BulkExtensions;
using ResData.Data;
using Microsoft.Extensions.Configuration;
using ResData.Models.CacheData;
using DataImport.hierarchybase;

using DataDelete.deleter;

namespace DataImport.hierarchies
{
    [HierarchyType(Utility.HierarchyType.H5)]
    public class HierarchyH5 : HierarchyBaseCS
    {

        public HierarchyH5()
        {


        }
        protected override Utility.HierarchyType GetHierarchyName()
        {
            return Utility.HierarchyType.H5;
        }

        protected override void SpecifyExtractors()
        {
            ExtractorsDataTypes.Add(Utility.DataType.DE);


            ExtractorsDataTypes.Add(Utility.DataType.SD);
            ExtractorsDataTypes.Add(Utility.DataType.OS);
            ExtractorsDataTypes.Add(Utility.DataType.FT);
            ExtractorsDataTypes.Add(Utility.DataType.LE);
            ExtractorsDataTypes.Add(Utility.DataType.SS);
            ExtractorsDataTypes.Add(Utility.DataType.SA);
            ExtractorsDataTypes.Add(Utility.DataType.FM);
            ExtractorsDataTypes.Add(Utility.DataType.BV);


        }

        protected override void ImportDataSetup()
        {


            this.DataHierarchy
                .AddTableElement(Utility.DataType.DE, DEs, SDs)
                .AddTableElement(Utility.DataType.SD, SDs, OSs)
                .AddTableElement(Utility.DataType.OS, OSs, FTs, LEs)
                .AddTableElement(Utility.DataType.FT, FTs)
                .AddTableElement(Utility.DataType.LE, LEs, SSs)
                .AddTableElement(Utility.DataType.SS, SSs, SAs)
                .AddTableElement(Utility.DataType.SA, SAs, FMs, BVs)
                .AddTableElement(Utility.DataType.FM, FMs, BVs)
                .AddTableElement(Utility.DataType.BV, BVs);
        }
    }
}