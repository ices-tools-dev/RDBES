﻿using DataDelete.deleter;
using DataImport.hierarchybase;

using ResCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataImport.hierarchies
{
    [HierarchyType(Utility.HierarchyType.HCE)]
  public  class HierarchyCE : HierarchyBase
    {
        public HierarchyCE()
        {


        }

        protected override void SpecifyExtractors()
        {
            ExtractorsDataTypes.Add(Utility.DataType.CE);
            
        }
        protected override void ImportDataSetup()
        {


            this.DataHierarchy
            .AddTableElement(Utility.DataType.CE,CEs);
           

        }

        protected override List<int> ExtractDeleteKeys()
        {
          
                var ids = CEs.Where(s => s.DeleteKey > 0).Select(s => s.DeleteKey).ToList();
                return ids;
           


        }

        protected override Utility.HierarchyType GetHierarchyName()
        {
            return Utility.HierarchyType.HCE;
        }

        protected override void SetPrimaryKeysOfExistingRecordsForHierarchy()
        {
            //nothing to set primary for
        }
    }
}
