﻿using DataDelete.deleter;
using DataImport.hierarchybase;

using ResCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataImport.hierarchies
{
    [HierarchyType(Utility.HierarchyType.HVD)]
    public class HierarchyVD : HierarchyBase
    {
        protected override Utility.HierarchyType GetHierarchyName()
        {
            return Utility.HierarchyType.HVD;
        }

        protected override void ImportDataSetup()
        {
            this.DataHierarchy.AddTableElement(Utility.DataType.VD, VDs);
        }

        protected override void SpecifyExtractors()
        {
            ExtractorsDataTypes.Add(Utility.DataType.VD);
        }
        protected override List<int> ExtractDeleteKeys()
        {

            var ids = VDs.Where(s => s.DeleteKey > 0).Select(s => s.DeleteKey).ToList();

            return ids;

        }

        protected override void SetPrimaryKeysOfExistingRecordsForHierarchy()
        {
            //nothing to set primary for
        }
    }
}
