﻿using DataDelete.deleter;
using DataImport.hierarchybase;

using ResCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataImport.hierarchies
{
    [HierarchyType(Utility.HierarchyType.HCL)]
    public class HierarchyCL : HierarchyBase
    {
        public HierarchyCL()
        {


        }

        protected override void SpecifyExtractors()
        {
            ExtractorsDataTypes.Add(Utility.DataType.CL);

        }
        protected override void ImportDataSetup()
        {

            this.DataHierarchy
            .AddTableElement(Utility.DataType.CL, CLs);
        }

        protected override List<int> ExtractDeleteKeys()
        {
           
                var ids = CLs.Where(s => s.DeleteKey > 0).Select(s => s.DeleteKey).ToList();

            return ids;

        }

        protected override Utility.HierarchyType GetHierarchyName()
        {
            return Utility.HierarchyType.HCL;
        }

        protected override void SetPrimaryKeysOfExistingRecordsForHierarchy()
        {
            //nothing to set primary for
        }
    }
}
