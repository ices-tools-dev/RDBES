﻿using DataDelete.deleter;
using DataImport.hierarchybase;

using ResCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataImport.hierarchies
{
    [HierarchyType(Utility.HierarchyType.HSL)]
   public  class HierarchySL : HierarchyBase
    {
        public HierarchySL()
        { }
        protected override void SpecifyExtractors()
        {
            ExtractorsDataTypes.Add(Utility.DataType.SL);
            ////ExtractorsDataTypes.Add(Utility.DataType.SLC);
            ////ExtractorsDataTypes.Add(Utility.DataType.SLS);

        }
        protected override void ImportDataSetup()
        {


            this.DataHierarchy
            .AddTableElement(Utility.DataType.SL, SLs)
            //.AddTableElement(Utility.DataType.SLC, SLCs, SLSs)
            //.AddTableElement(Utility.DataType.SLS, SLSs)
            
            ;
            


        }

        

        protected override Utility.HierarchyType GetHierarchyName()
        {
            return Utility.HierarchyType.HSL;
        }

        protected override List<int> ExtractDeleteKeys()
        {
            var slDeleteIds = SLs.Where(s => s.DeleteKey > 0).Select(s => s.DeleteKey).ToList();
            return slDeleteIds;
        }

        protected override void SetPrimaryKeysOfExistingRecordsForHierarchy()
        {
            //nothing to set primary for
        }
    }
}
