﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;

using Microsoft.Extensions.Configuration;
using ResCommon;
using ResData.Models.CacheData;
using ResData.Data;

namespace DataImport.factory
{
    public static class ImporterFactory 

    {
        private static Dictionary<Utility.HierarchyType, Type> importersTypes = new Dictionary<Utility.HierarchyType, Type>();

        static ImporterFactory()
        {
            IndexImporters();
        }

        public static IImporter CreateImporter(Utility.HierarchyType hierarchyType)
        {
            

            Type importerType = null;
            if (!importersTypes.TryGetValue(hierarchyType, out importerType))
            {
                throw new Exception(string.Format($"Unable to locate data importer for HierarchyType:{hierarchyType}"));
            }

            return (IImporter)Activator.CreateInstance(importerType);

        }
        

        private static void IndexImporters()
        {
            
            var types = ((typeof(ImporterFactory))).GetTypeInfo().Assembly.DefinedTypes
                .Where(t => t.IsClass && t.Namespace == "DataImport.hierarchies")
                .Select(t => new { type = t.UnderlyingSystemType, typeInfo = t })
                .ToList();
            importersTypes = new Dictionary<Utility.HierarchyType, Type>();
            foreach (var t in types)
            {
                var attr = t.typeInfo.GetCustomAttribute<HierarchyTypeAttribute>();
                if (attr != null)
                {
                    importersTypes.Add(attr.HierarchyType, t.type);
                }
            }

        }
    }
}
