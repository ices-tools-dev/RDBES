﻿using DbDataModel;
using ResCommon;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using TypeDefinitions.DataImport;

namespace DataInsert.builder
{
    public static class InsertScriptBuilder
    {
        private static readonly CultureInfo InvariantCulture = CultureInfo.InvariantCulture;
        
        public static  List<string> BuildScriptByBatchSize( IEnumerable<IDataLineInfo> newlyFoundParents, bool haveChildrens, int batchSize, List<PropertyInfo> props, string tableName,string tablePk)
        {
            

            var listScripts = new List<string>();

            for (int i = 0; i < newlyFoundParents.Count(); i += batchSize)
            {
                var items = newlyFoundParents.Skip(i).Take(batchSize);
                var insertScript = GetInsertScript(items,haveChildrens, props,tableName,tablePk);
                listScripts.Add(insertScript);

            }
            return listScripts;

        }

       
       private static string GetInsertScript(IEnumerable<IDataLineInfo> objs, bool haveChildrens, List<PropertyInfo> props, string tableName, string tablePk)
        {
            
            
            var sb = new StringBuilder();
            
            sb.Append("DECLARE @tempPKTable TABLE (ln INT, pk int )");

            foreach (var obj in objs)
            {
               
                sb.Append(" INSERT INTO " + tableName + " ");
                if (haveChildrens)
                {
                    sb.Append(" OUTPUT " + obj.LN + ", INSERTED." + tablePk + " INTO @tempPKTable ");
                }
                sb.Append(" VALUES(" + string.Join(",", props.Select(p => GetPropertyValue(p, obj))) + ") ");
            }

            sb.Append(" select ln,pk from @tempPKTable ");

            return sb.ToString();

        }

      private static  object GetPropertyValue<TSource>(PropertyInfo p, TSource obj)
        {
            if (p.PropertyType == typeof(string))
            {
                return p.GetValue(obj) != null ? "'" + p.GetValue(obj).ToString() + "'" : "NULL";
            }
            else if (p.PropertyType == typeof(DateTime) || p.PropertyType == typeof(DateTime?))
            {
                return p.GetValue(obj) != null ? "CAST('" + ((DateTime)p.GetValue(obj)).ToString("yyyy-MM-dd HH:mm:ss.fff") + "' as datetime)" : "NULL";
            }
            else if (p.PropertyType == typeof(decimal) || p.PropertyType == typeof(decimal?))
            {
                if (p.GetValue(obj) != null)
                {
                    var r = Convert.ToDecimal(p.GetValue(obj), InvariantCulture).ToString(InvariantCulture);
                    return r;
                }
                else
                    return "NULL";
            }
            else if (p.PropertyType == typeof(int) || p.PropertyType == typeof(int?))
            {
                return p.GetValue(obj) ?? "NULL";
            }
            else if (p.PropertyType == typeof(long) || p.PropertyType == typeof(long?))
            {
                return p.GetValue(obj) ?? "NULL";
            }
            else if (p.PropertyType == typeof(bool) || p.PropertyType == typeof(bool?))
            {
                if (p.GetValue(obj) != null)
                {
                    if (p.GetValue(obj).ToString() == "False") return "0";
                    else { return "1"; }
                }
                else
                {
                    return "NULL";
                }
            }
            else
            {
                throw new Exception("data type is not supported for data import");

            }
        }

        

    }
}
