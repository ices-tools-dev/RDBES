﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataInsert
{
    public class DataTableElement
    {
        public Utility.DataType DataType { get; set; }
        public object Parent { get; set; }
        public object[] Childrens { get; set; }


       // public object[] GrandChildrens { get; set; }

    }

   
}
