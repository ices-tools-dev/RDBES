﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataInsert
{
    public class DataHierarchy:IDataHierarchy
    {
        private List<DataTableElement> DataTableElements;

        public DataHierarchy()
        {
            DataTableElements = new List<DataTableElement>();
        }

        public List<DataTableElement> GetHierarchyData()
        {
            return DataTableElements;
        }

        

        public DataHierarchy AddTableElement(Utility.DataType dataType, object parent)
        {
            DataTableElements.Add(new DataTableElement()
            {
                DataType = dataType,

                Parent = parent,
                Childrens = null
                //,
                //GrandChildrens = null
            });
            return this;
        }
      
        public DataHierarchy AddTableElement(Utility.DataType dataType, object parent, params object[] childrens)
        {
            DataTableElements.Add(new DataTableElement()
            {
                DataType = dataType,
                
                Parent = parent,
                Childrens = childrens
                //,
                // GrandChildrens=null


            });
            return this;
        }

        //public DataHierarchy AddTableElement(Utility.DataType dataType, object parent, object[] grandChildrens, params object[] childrens)
        //{
        //    DataTableElements.Add(new DataTableElement()
        //    {
        //        DataType = dataType,

        //        Parent = parent,
        //        Childrens = childrens
        //        //,
        //        //GrandChildrens = grandChildrens


        //    });
        //    return this;
        //}
    }
}
