﻿
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataInsert
{
    public interface IDataHierarchy
    {
        List<DataTableElement> GetHierarchyData();
      
    }
}
