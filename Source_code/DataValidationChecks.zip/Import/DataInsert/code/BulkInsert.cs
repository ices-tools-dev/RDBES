﻿using Microsoft.EntityFrameworkCore;
using ResCommon;
using ResData.Data;
using TypeDefinitions.DataImport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using ResData.Models.KeyLessEntities;

using DataInsert.builder;
using DbDataModel;

namespace DataInsert.code
{
    public class BulkInsert
    {
        readonly ApplicationDbContext Db;
        readonly int BatchSize;

        public BulkInsert(ApplicationDbContext db, int batchSize )
        {
            this.Db = db;
            this.BatchSize = batchSize;
        }

        public void Process(IDataHierarchy dataHierarchy)
        {
            var dataTables = dataHierarchy.GetHierarchyData();
            Insert(dataTables);

        }

       private void Insert(List<DataTableElement> dataTables)
        {
            foreach (var datTab in dataTables)
            {
                var pType = datTab.DataType;
                var primarykey = Mapping.GetTableKeyField(pType);
                var parents = (IEnumerable<IDataLineInfo>)datTab.Parent;


                if (parents.Count() > 0)
                {
                    // new parents 
                    var newlyFoundParents = parents.Where(p => p.PrimaryKey == 0);

                    List<LinePkMapping> LnMappingPks = new List<LinePkMapping>();
                    if (newlyFoundParents.ToList().Count > 0)
                    {
                        var haveChildrens = datTab.Childrens == null ? false : true;
                        var  newLnMappingPks = InsertDataUsingContextByBatchSize(pType, newlyFoundParents,haveChildrens, BatchSize);
                        LnMappingPks.AddRange(newLnMappingPks);
                    }

                    // already existing parents
                    var oldFoundParents = parents.Where(p => p.PrimaryKey > 0).ToList();
                    
                    foreach (var par in oldFoundParents)
                    {
                        LnMappingPks.Add(new LinePkMapping() { ln=par.LN, pk=par.PrimaryKey});
                    }



                    if (datTab.Childrens != null)
                    {
                        foreach (var childElement in datTab.Childrens)
                        {
                            var childs = (IEnumerable<IDataLineInfo>)childElement;
                            if (childs.Count() > 0)
                                this.SetForiegnKeysToChildres(parents, childs, primarykey, LnMappingPks);
                        }
                    }


                }
            }

        }

       

        private List<LinePkMapping> InsertDataUsingContextByBatchSize(Utility.DataType dataType, IEnumerable<IDataLineInfo> newlyFoundParents, bool haveChildrens, int batchSize)
        {
            var firstDataElement = newlyFoundParents.First();
            if (firstDataElement == null)
            {
                throw new Exception("No data found : Can not build Insert script");
            }
            var dataElementType = firstDataElement.GetType();
            var allProps = dataElementType.GetProperties();


            var props = allProps
             .Where(p => Attribute.GetCustomAttribute(p, typeof(ImportOrderAttribute)) != null)
             .OrderBy(p => ((ImportOrderAttribute)Attribute.GetCustomAttribute(p, typeof(ImportOrderAttribute))).Order).ToList();

            if (props.Count() == 0)
            {
                throw new Exception("no properties found marked with ImportOrderAttribute");

            }


            var propsGroupByImportOrderNumber = props.GroupBy(p => ((ImportOrderAttribute)Attribute.GetCustomAttribute(p, typeof(ImportOrderAttribute))).Order);

            if (propsGroupByImportOrderNumber.Any(g => g.Count() > 1))
            {
                throw new Exception("At least one of class property has duplicate order number as value of ImportOrderAttribute");

            }

            var tableName = Mapping.GetTableName(dataType);
            var tablePk = Mapping.GetTableKeyField(dataType);
            
            var scriptByBatchSize = InsertScriptBuilder.BuildScriptByBatchSize(newlyFoundParents,haveChildrens, batchSize,props,tableName,tablePk);
            var LnMappingPks = new List<LinePkMapping>();
            foreach (var insertScript in scriptByBatchSize)
            {
               
                    var lineMapPks = this.Db.LnMappingPk.FromSqlRaw(insertScript).ToList();
                    LnMappingPks.AddRange(lineMapPks);
                
                
                
            }

            return LnMappingPks;
        }


        private void SetForiegnKeysToChildres(IEnumerable<IDataLineInfo> parents, IEnumerable<IDataLineInfo> childs, string primaryKey, List<LinePkMapping> lineMappingPks)
        {


            foreach (var par in parents)
            {
              
                var principalKeyValue = lineMappingPks.Where(m => m.ln == par.LN).First();//.pk;
                if (principalKeyValue == null) { throw new Exception("no primary key found in import transaction"); }

                var subChilds = childs.Where(c => c.PLN.Equals(par.LN)).ToList();
                foreach (var cha in subChilds)
                {
                    cha.GetType().GetProperty(primaryKey).SetValue(cha, principalKeyValue.pk);
                }
                
            }

        }

        //List<LineMappingPk> ImporBySqlCommand(string connectionString, IEnumerable<IDataLineInfo> newlyFoundParents, int batchSize)
        //{
        //    var LnMappingPks = new List<LineMappingPk>();

        //    using (SqlConnection con = new SqlConnection(connectionString))
        //    {
        //        con.Open();
        //        SqlTransaction tran;
        //        tran = con.BeginTransaction("SampleTransaction");
        //        try
        //        {

        //            using (SqlCommand cmd = con.CreateCommand())
        //            {

        //                for (int i = 0; i < newlyFoundParents.Count(); i = i + batchSize)
        //                {
        //                    var items = newlyFoundParents.Skip(i).Take(batchSize);
        //                    var insertScript = ScriptFormatiing.GetCLScript(items);
        //                    cmd.CommandText = insertScript;
        //                    cmd.CommandType = CommandType.Text;
        //                    cmd.CommandTimeout = 0;
        //                    cmd.Transaction = tran;


        //                    SqlDataReader reader = cmd.ExecuteReader();
        //                    try
        //                    {
        //                        while (reader.Read())
        //                        {
        //                            var r = new LineMappingPk() { ln = reader.GetInt32(0), pk = reader.GetInt32(1) };
        //                            LnMappingPks.Add(r);


        //                        }
        //                    }
        //                    finally
        //                    {

        //                        reader.Close();
        //                    }

        //                }


        //            }

        //            tran.Commit();
        //        }
        //        catch (Exception ex)
        //        {

        //            try
        //            {
        //                tran.Rollback();
        //            }
        //            catch (Exception ex2)
        //            {
        //                throw;
        //            }

        //        }
        //    }
        //    return LnMappingPks;
        //}



    }
}


//////////DataTable ConvertToDataTable<TSource>(IEnumerable<TSource> source)
//////////{
//////////    var props = typeof(TSource).GetProperties().Where(p=> !p.Name.Equals("Clid"));
//////////    var dt = new DataTable();
//////////    dt.Columns.AddRange(props.Select(p => new DataColumn(p.Name, Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType)).ToArray());
//////////    source.ToList().ForEach(i => dt.Rows.Add(props.Select(p => p.GetValue(i) ?? DBNull.Value).ToArray()));
//////////    return dt;
//////////}


//////////private void ImportByTableValueParameter(string connectionString, string destinationTable, DataTable data)
//////////{
//////////    data.TableName = "TypCommercialLanding";
//////////    using (SqlConnection con = new SqlConnection(connectionString))
//////////    {
//////////        con.Open();
//////////        using (SqlTransaction tran = con.BeginTransaction())
//////////        {
//////////            using (SqlCommand cmd = con.CreateCommand())
//////////            {


//////////                cmd.CommandText = "insertCL";
//////////                cmd.CommandType = CommandType.StoredProcedure;
//////////                cmd.CommandTimeout = 0;
//////////                cmd.Transaction = tran;
//////////                cmd.Parameters.Add(
//////////                         new SqlParameter()
//////////                         {
//////////                             ParameterName = "@TestTvp",
//////////                             SqlDbType = SqlDbType.Structured,
//////////                             TypeName = "TypCommercialLanding",
//////////                             Value = data,
//////////                         });
//////////                cmd.ExecuteNonQuery();
//////////            }

//////////            tran.Commit();
//////////        }
//////////        con.Close();
//////////    }

//////////}

//////////List<LineMappingPk> ImporBySqlCommand(string connectionString, IEnumerable<IDataLineInfo> newlyFoundParents, int batchSize)
//////////{
//////////    var LnMappingPks = new List<LineMappingPk>();

//////////    using (SqlConnection con = new SqlConnection(connectionString))
//////////    {
//////////        con.Open();
//////////        SqlTransaction tran;
//////////        tran = con.BeginTransaction("SampleTransaction");
//////////        try
//////////        {

//////////            using (SqlCommand cmd = con.CreateCommand())
//////////            {

//////////                for (int i = 0; i < newlyFoundParents.Count(); i = i + batchSize)
//////////                {
//////////                    var items = newlyFoundParents.Skip(i).Take(batchSize);
//////////                    var insertScript = ScriptFormatiing.GetCLScript(items);
//////////                    cmd.CommandText = insertScript;
//////////                    cmd.CommandType = CommandType.Text;
//////////                    cmd.CommandTimeout = 0;
//////////                    cmd.Transaction = tran;


//////////                    SqlDataReader reader = cmd.ExecuteReader();
//////////                    try
//////////                    {
//////////                        while (reader.Read())
//////////                        {
//////////                            var r = new LineMappingPk() { ln = reader.GetInt32(0), pk = reader.GetInt32(1) };
//////////                            LnMappingPks.Add(r);


//////////                        }
//////////                    }
//////////                    finally
//////////                    {

//////////                        reader.Close();
//////////                    }

//////////                }


//////////            }

//////////            tran.Commit();
//////////        }
//////////        catch (Exception ex)
//////////        {

//////////            try
//////////            {
//////////                tran.Rollback();
//////////            }
//////////            catch (Exception ex2)
//////////            {
//////////                throw;
//////////            }

//////////        }
//////////    }
//////////    return LnMappingPks;
//////////}


//////////void ImportByBulkCopy(string connectionString, string destinationTable, DataTable data)
//////////{
//////////    using (SqlConnection con = new SqlConnection(connectionString))
//////////    {
//////////        con.Open();
//////////        using (SqlTransaction tran = con.BeginTransaction())
//////////        {
//////////            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(con,
//////////                SqlBulkCopyOptions.TableLock |
//////////                SqlBulkCopyOptions.FireTriggers |
//////////                SqlBulkCopyOptions.CheckConstraints

//////////            , tran))
//////////            {
//////////                bulkCopy.DestinationTableName = destinationTable;
//////////                bulkCopy.BulkCopyTimeout = 0;

//////////                bulkCopy.BatchSize = 50000;



//////////                bulkCopy.WriteToServer(data);
//////////            }
//////////            tran.Commit();
//////////        }
//////////        con.Close();

//////////    }
//////////}
