﻿

using Microsoft.EntityFrameworkCore;
using ResCommon;
using ResData.Data;
using TypeDefinitions.DataImport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Data.SqlClient;
using System.Data;


namespace DataInsert
{
    public class InsertData
    {
        ApplicationDbContext DbContext;

        public InsertData(ApplicationDbContext db)
        {
            this.DbContext = db;

        }



        public void Process(IDataHierarchy dataHierarchy)
        {
            var dataTables = dataHierarchy.GetHierarchyData();
            Insert(dataTables);

        }



        private void Insert(List<DataTableElement> dataTables)
        {
            foreach (var datTab in dataTables)
            {
                var pType = datTab.DataType;
                var primarykey = Mapping.GetTableKeyField(pType);
                var parents = (IEnumerable<IDataLineInfo>)datTab.Parent;


                if (parents.Count() > 0)
                {
                    var newlyFoundParents = parents.Where(p => p.PrimaryKey == 0);

                    DbContext.AddRange(newlyFoundParents);

                    if (datTab.Childrens != null)
                    {
                        foreach (var childElement in datTab.Childrens)
                        {
                            var childs = (IEnumerable<IDataLineInfo>)childElement;
                            if (childs.Count() > 0)
                                this.SetForiegnKeysToChildres(parents, childs, primarykey);
                        }
                    }
                }
            }
        }

        private void SetForiegnKeysToChildres(IEnumerable<IDataLineInfo> parents, IEnumerable<IDataLineInfo> childs, string primaryKey)
        {


            foreach (var par in parents)
            {
                var subChilds = childs.Where(c => c.PLN.Equals(par.LN)).ToList();

                var principalKeyValue = par.GetType().GetProperty(primaryKey).GetValue(par);

                foreach (var cha in subChilds)
                {
                    cha.GetType().GetProperty(primaryKey).SetValue(cha, principalKeyValue);

                }
            }

        }



        //////// set foriegn key to grand childrends
        //////if (datTab.Childrens != null)
        //////{
        //////    foreach (var childElements in datTab.Childrens)
        //////    {
        //////        var grandChilds = (IEnumerable<IParentsInfo>)childElements;

        //////        var childsByParentType = from gChild in grandChilds
        //////                                      where gChild.ParentsInfo.Keys.Contains(pType)
        //////                                      select gChild;

        //////        if (childsByParentType.Count() > 0)
        //////            this.SetForiegnKeysToChildres(parents, childsByParentType, primarykey);
        //////    }
        //////}

        // set foriegn key to childrends
        ////private void SetForiegnKeysToChildres(IEnumerable<IDataLineInfo> parents, IEnumerable<IParentsInfo> childs, string primaryKey)
        ////{


        ////    foreach (var par in parents)
        ////    {
        ////        var firstLevelChilds = childs.Where(c => c.ParentsInfo.Values.Contains(par.LN)).ToList();
        ////        var principalKeyValue = par.GetType().GetProperty(primaryKey).GetValue(par);

        ////        foreach (var cha in firstLevelChilds)
        ////        {
        ////            cha.GetType().GetProperty(primaryKey).SetValue(cha, principalKeyValue);


        ////        }
        ////    }

        ////}


      
    }

}
