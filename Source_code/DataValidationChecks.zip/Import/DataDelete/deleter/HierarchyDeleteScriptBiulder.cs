﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace DataDelete.deleter
{
    public  class HierarchyDeleteScriptBiulder : IHierarchyDeleteScriptBiulder
    {
        public string BuildScriptWithoutWhereClause(Utility.HierarchyType hierarchyType)
        {
            var builder = LoadHierarchy(hierarchyType);
            return builder.BuildScriptWithoutWhereClause(hierarchyType);
        }

        public string BuildScriptWithWhereClause(Utility.HierarchyType hierarchyType, List<int> ids)
        {
            var builder = LoadHierarchy(hierarchyType);
            return builder.BuildScriptWithWhereClause(hierarchyType,ids);
        }

        //private string GetDeleteScript(Utility.HierarchyType hierarchyType,List<int> ids) {

           


        //}


        private  IHierarchyDeleteScriptBiulder LoadHierarchy(Utility.HierarchyType hierarchyType)
        {
            var hierarchiesClasses = from t in Assembly
                                     .GetExecutingAssembly()
                                     .GetTypes()
                                     .Where(t => typeof(IHierarchyDeleteScriptBiulder) != t && typeof(IHierarchyDeleteScriptBiulder).IsAssignableFrom(t))
                                     select t;


            var foundHierarchy = hierarchiesClasses.Where(c => c.Name.EndsWith(hierarchyType.ToString())).FirstOrDefault();
            if (foundHierarchy == null) throw new Exception($"no class with name '{hierarchyType.ToString() }' is defined to provide delete script" );

            return (IHierarchyDeleteScriptBiulder)Activator.CreateInstance(foundHierarchy) as IHierarchyDeleteScriptBiulder;
        }

       
    }
}
