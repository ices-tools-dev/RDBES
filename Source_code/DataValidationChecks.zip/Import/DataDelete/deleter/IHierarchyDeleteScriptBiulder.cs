﻿using ResCommon;
using System.Collections.Generic;

namespace DataDelete.deleter
{
    public interface IHierarchyDeleteScriptBiulder
    {
        string BuildScriptWithWhereClause(Utility.HierarchyType hierarchyType,List<int> Ids);
        string BuildScriptWithoutWhereClause(Utility.HierarchyType hierarchyType);
    }
}