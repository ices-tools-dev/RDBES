﻿using DataDelete.deleter;
using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataDelete.configuration
{
    public abstract class DeleteScriptBuilderBase : IHierarchyDeleteScriptBiulder
    {
       // protected string Ids;
        protected abstract string GetHierarchyDeleteScript(string commaSeperatedIds,bool includeWhereClause);
        
        public string BuildScriptWithWhereClause(Utility.HierarchyType hierarchyType,List<int> Ids)
        {
            if (Ids.Count <= 0) return null;
           var idsWithCommaAsSeperation = string.Join(",", Ids);
            return GetHierarchyDeleteScript(idsWithCommaAsSeperation, true);
            
        }

        public string BuildScriptWithoutWhereClause(Utility.HierarchyType hierarchyType)
        {
            return GetHierarchyDeleteScript("",false);
        }
    }
}
