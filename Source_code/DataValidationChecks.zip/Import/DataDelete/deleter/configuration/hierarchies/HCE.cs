﻿using DataDelete.configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataDelete.deleter.configuration.hierarchies
{
    public class HCE : DeleteScriptBuilderBase
    {
        protected override string GetHierarchyDeleteScript(string commaSeperatedIds, bool includeWhereClause)
        {
            var deletequery = $@" DELETE FROM [dbo].[CommercialEffort] ";
            string whereClauseText = "";
            if (includeWhereClause)
            {
                whereClauseText = $@" WHERE CEid in ({commaSeperatedIds}) ";
            }

            var query = deletequery + whereClauseText;


            return query;
        }
    }
}
