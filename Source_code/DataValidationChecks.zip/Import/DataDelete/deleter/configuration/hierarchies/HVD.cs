﻿using DataDelete.configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataDelete.deleter.configuration.hierarchies
{
    public class HVD : DeleteScriptBuilderBase
    {
        protected override string GetHierarchyDeleteScript(string commaSeperatedIds, bool includeWhereClause)
        {
           
            string whereClauseText = "";
            if (includeWhereClause)
            {
                 whereClauseText = $@" WHERE vd.VDid in ({commaSeperatedIds}) ";
            }




            return
            $@"
            
                

        -------connected to LE-----------------------------------
        --------------------H4,H5,H8,H12-------------------------
        
        
        DELETE bv
        FROM VesselDetails vd
        JOIN LandingEvent le        on vd.VDid = le.VDid                
        JOIN SpeciesSelection ss  on le.LEid = ss.LEid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN BiologicalVariable bv on sa.SAid = bv.SAid        
		{whereClauseText}

        DELETE bv
        FROM VesselDetails vd
        JOIN LandingEvent le        on vd.VDid = le.VDid               
        JOIN SpeciesSelection ss  on le.LEid = ss.LEid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
        JOIN BiologicalVariable bv on fm.FMid = bv.FMid                 
		{whereClauseText}

        DELETE fm
		FROM VesselDetails vd
		JOIN LandingEvent le        on vd.VDid = le.VDid                  
        JOIN SpeciesSelection ss  on le.LEid = ss.LEid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid               
		{whereClauseText}

        DELETE sa
        FROM VesselDetails vd
		JOIN LandingEvent le        on vd.VDid = le.VDid                
        JOIN SpeciesSelection ss  on le.LEid = ss.LEid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        {whereClauseText}                        
        
        DELETE ss
        FROM VesselDetails vd
        JOIN LandingEvent le        on vd.VDid = le.VDid  
        JOIN SpeciesSelection ss  on le.LEid = ss.LEid
        {whereClauseText}
		-----------------------------------------------

		--------------------H9-------------------------
        
        
        DELETE bv
        FROM VesselDetails vd
        JOIN LandingEvent le       on vd.VDid = le.VDid             
        JOIN[Sample] sa            on le.LEid = sa.LEid
        JOIN BiologicalVariable bv on sa.SAid = bv.SAid        
		{whereClauseText}

        DELETE bv
        FROM VesselDetails vd
        JOIN LandingEvent le        on vd.VDid = le.VDid               
        JOIN[Sample] sa            on le.LEid = sa.LEid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
        JOIN BiologicalVariable bv on fm.FMid = bv.FMid                 
		{whereClauseText}

        DELETE fm
		FROM VesselDetails vd
		JOIN LandingEvent le        on vd.VDid = le.VDid                  
        JOIN[Sample] sa            on le.LEid = sa.LEid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid               
		{whereClauseText}

        DELETE sa
        FROM VesselDetails vd
		JOIN LandingEvent le        on vd.VDid = le.VDid                
        JOIN[Sample] sa            on le.LEid = sa.LEid
        {whereClauseText}                
        

		  
		-------common to H11,H6,H7, and all others   

        DELETE le
        FROM VesselDetails vd
        JOIN LandingEvent le        on vd.VDid = le.VDid  
        {whereClauseText}        
       -------------end connted to LE------------------
        -------------------------------------------------
		
		
		
		-------connected to FT ------------------------
		-------H1,H2,H3,H10, FO path of H6-------------

		DELETE bv
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss  on fo.FOid = ss.FOid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN BiologicalVariable bv on sa.SAid = bv.SAid              
		{whereClauseText}		

		DELETE bv
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss  on fo.FOid = ss.FOid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
        JOIN BiologicalVariable bv on fm.FMid = bv.FMid            
		{whereClauseText}		

        DELETE fm
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss  on fo.FOid = ss.FOid             
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
        {whereClauseText}        

        DELETE sa                
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss  on fo.FOid = ss.FOid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        {whereClauseText}               

        
		DELETE ss
        FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss  on fo.FOid = ss.FOid
        {whereClauseText}        


		DELETE fo
        FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid        
		{whereClauseText}		
		

		---------------------H4--------------------------
		DELETE bv
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN LandingEvent le        on ft.FTid = le.FTid
        JOIN SpeciesSelection ss    on le.LEid = ss.LEid
        JOIN[Sample] sa             on ss.SSid = sa.SSid
        JOIN BiologicalVariable bv  on sa.SAid = bv.SAid              
		{whereClauseText}		

		DELETE bv
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN LandingEvent le        on ft.FTid = le.FTid
        JOIN SpeciesSelection ss    on le.LEid = ss.LEid
        JOIN[Sample] sa             on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm    on sa.SAid = fm.SAid
        JOIN BiologicalVariable bv  on fm.FMid = bv.FMid            
		{whereClauseText}		

        DELETE fm
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN LandingEvent le        on ft.FTid = le.FTid
        JOIN SpeciesSelection ss    on le.LEid = ss.LEid            
        JOIN[Sample] sa             on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm    on sa.SAid = fm.SAid
        {whereClauseText}        

        DELETE sa                
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN LandingEvent le        on ft.FTid = le.FTid
        JOIN SpeciesSelection ss    on le.LEid = ss.LEid
        JOIN[Sample] sa             on ss.SSid = sa.SSid
         {whereClauseText}              

        
		DELETE ss
        FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN LandingEvent le        on ft.FTid = le.FTid
        JOIN SpeciesSelection ss    on le.LEid = ss.LEid
        {whereClauseText}        


		DELETE le
        FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN LandingEvent le        on ft.FTid = le.FTid 
		{whereClauseText}

		-----------LE under FO path of H6---------------

		DELETE bv
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid
		JOIN LandingEvent le        on fo.FOid = le.FOid
        JOIN SpeciesSelection ss    on le.LEid = ss.LEid
        JOIN[Sample] sa             on ss.SSid = sa.SSid
        JOIN BiologicalVariable bv  on sa.SAid = bv.SAid              
		{whereClauseText}		

		DELETE bv
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid
        JOIN LandingEvent le        on fo.FOid = le.FOid
        JOIN SpeciesSelection ss    on le.LEid = ss.LEid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
        JOIN BiologicalVariable bv on fm.FMid = bv.FMid            
		{whereClauseText}		

        DELETE fm
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid
        JOIN LandingEvent le        on fo.FOid = le.FOid
        JOIN SpeciesSelection ss    on le.LEid = ss.LEid         
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
        {whereClauseText}        

        DELETE sa                
		FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid
       JOIN LandingEvent le        on fo.FOid = le.FOid
        JOIN SpeciesSelection ss    on le.LEid = ss.LEid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
         {whereClauseText}              

        
		DELETE ss
        FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid
        JOIN LandingEvent le        on fo.FOid = le.FOid
        JOIN SpeciesSelection ss    on le.LEid = ss.LEid
        {whereClauseText}
                
		DELETE le
        FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid
        JOIN LandingEvent le        on fo.FOid = le.FOid
        {whereClauseText}

		DELETE fo
        FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN FishingOperation fo    on ft.FTid = fo.FTid        
        {whereClauseText}
		---------------------H11------------------------- 

		DELETE le
        FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid
        JOIN LandingEvent le        on ft.FTid = le.FTid
        {whereClauseText}
		  
		------------- H5,H8,H12,H13, and all other------
		DELETE ft
        FROM VesselDetails vd      
		JOIN FishingTrip ft         on vd.VDid = ft.VDid                
        {whereClauseText}                 

		------------------------------------------------ 

		-------end connected to FT ---------------------
     

	    -------connected to VS--------------------------

		
            -------------H1,H3-------------------------
        

        DELETE bv
        FROM VesselDetails vd 
		JOIN VesselSelection vs    on vd.VDid = vs.VDid
        JOIN FishingTrip ft        on vs.VSid = ft.VSid
        JOIN FishingOperation fo   on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss   on fo.FOid = ss.FOid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN BiologicalVariable bv on sa.SAid = bv.SAid
        {whereClauseText}


		DELETE bv
        FROM VesselDetails vd 
		JOIN VesselSelection vs    on vd.VDid = vs.VDid
        JOIN FishingTrip ft        on vs.VSid = ft.VSid
        JOIN FishingOperation fo   on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss   on fo.FOid = ss.FOid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
        JOIN BiologicalVariable bv on fm.FMid = bv.FMid
        {whereClauseText}        


        DELETE fm
        FROM VesselDetails vd 
		JOIN VesselSelection vs    on vd.VDid = vs.VDid
        JOIN FishingTrip ft        on vs.VSid = ft.VSid
        JOIN FishingOperation fo   on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss   on fo.FOid = ss.FOid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
        {whereClauseText}        


        DELETE sa
       FROM VesselDetails vd 
		JOIN VesselSelection vs    on vd.VDid = vs.VDid
        JOIN FishingTrip ft        on vs.VSid = ft.VSid
        JOIN FishingOperation fo   on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss   on fo.FOid = ss.FOid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        {whereClauseText}        
        


		DELETE ss
		FROM VesselDetails vd 
		JOIN VesselSelection vs    on vd.VDid = vs.VDid
        JOIN FishingTrip ft        on vs.VSid = ft.VSid
        JOIN FishingOperation fo   on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss   on fo.FOid = ss.FOid
        {whereClauseText}        


		DELETE fo
        FROM VesselDetails vd 
		JOIN VesselSelection vs    on vd.VDid = vs.VDid
        JOIN FishingTrip ft        on vs.VSid = ft.VSid
        JOIN FishingOperation fo   on ft.FTid = fo.FTid               
        {whereClauseText}         

        
		DELETE ft
        FROM VesselDetails vd 
		JOIN VesselSelection vs    on vd.VDid = vs.VDid
        JOIN FishingTrip ft        on vs.VSid = ft.VSid                
        {whereClauseText}

		   --------------------H10--------------------------
      

        DELETE bv
        FROM Design de 
		JOIN SamplingDetails sd      on de.DEid = sd.DEid      
        JOIN VesselSelection vs      on sd.SDid = vs.SDid
        JOIN TemporalEvent te        on vs.VSid = te.VSid
        JOIN FishingTrip ft          on te.TEid = ft.TEid
        JOIN FishingOperation fo     on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss     on fo.FOid = ss.FOid
        JOIN [Sample] sa             on ss.SSid = sa.SSid
        JOIN BiologicalVariable bv   on sa.SAid = bv.SAid
        {whereClauseText}




        DELETE bv
        FROM Design de 
		JOIN SamplingDetails sd      on de.DEid = sd.DEid      
        JOIN VesselSelection vs      on sd.SDid = vs.SDid
        JOIN TemporalEvent te        on vs.VSid = te.VSid
        JOIN FishingTrip ft          on te.TEid = ft.TEid
        JOIN FishingOperation fo     on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss     on fo.FOid = ss.FOid
        JOIN [Sample] sa             on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm     on sa.SAid = fm.SAid
        JOIN BiologicalVariable bv   on fm.FMid = bv.FMid
        {whereClauseText}    




        DELETE fm
        FROM Design de 
		JOIN SamplingDetails sd      on de.DEid = sd.DEid      
        JOIN VesselSelection vs      on sd.SDid = vs.SDid
        JOIN TemporalEvent te        on vs.VSid = te.VSid
        JOIN FishingTrip ft          on te.TEid = ft.TEid
        JOIN FishingOperation fo     on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss     on fo.FOid = ss.FOid             
        JOIN [Sample] sa             on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm     on sa.SAid = fm.SAid
        {whereClauseText}         




         DELETE sa                
         FROM Design de 
		 JOIN SamplingDetails sd      on de.DEid = sd.DEid      
         JOIN VesselSelection vs      on sd.SDid = vs.SDid
         JOIN TemporalEvent te        on vs.VSid = te.VSid
         JOIN FishingTrip ft          on te.TEid = ft.TEid
         JOIN FishingOperation fo     on ft.FTid = fo.FTid
         JOIN SpeciesSelection ss     on fo.FOid = ss.FOid
         JOIN [Sample] sa             on ss.SSid = sa.SSid
         {whereClauseText}        
        

        
        DELETE ss
        FROM Design de
		JOIN SamplingDetails sd      on de.DEid = sd.DEid      
        JOIN VesselSelection vs      on sd.SDid = vs.SDid
        JOIN TemporalEvent te        on vs.VSid = te.VSid
        JOIN FishingTrip ft          on te.TEid = ft.TEid
        JOIN FishingOperation fo     on ft.FTid = fo.FTid
        JOIN SpeciesSelection ss     on fo.FOid = ss.FOid
        {whereClauseText}         


        DELETE fo
        FROM Design de 
		JOIN SamplingDetails sd      on de.DEid = sd.DEid      
        JOIN VesselSelection vs      on sd.SDid = vs.SDid
        JOIN TemporalEvent te        on vs.VSid = te.VSid
        JOIN FishingTrip ft          on te.TEid = ft.TEid
        JOIN FishingOperation fo     on ft.FTid = fo.FTid                
        {whereClauseText}          

        DELETE ft
        FROM Design de 
		JOIN SamplingDetails sd      on de.DEid = sd.DEid      
        JOIN VesselSelection vs      on sd.SDid = vs.SDid
        JOIN TemporalEvent te		 on vs.VSid = te.VSid
        JOIN FishingTrip ft          on te.TEid = ft.TEid                
        {whereClauseText}         

        DELETE te
        FROM Design de 
		JOIN SamplingDetails sd      on de.DEid = sd.DEid      
        JOIN VesselSelection vs      on sd.SDid = vs.SDid
        JOIN TemporalEvent te    on vs.VSid = te.VSid
        {whereClauseText}        

        DELETE vs
        FROM Design de 
		JOIN SamplingDetails sd      on de.DEid = sd.DEid      
        JOIN VesselSelection vs      on sd.SDid = vs.SDid
        {whereClauseText} 

                
            

	    -------H1,H3 and all other----------------------
		DELETE vs
        FROM VesselDetails vd 
		JOIN VesselSelection vs    on vd.VDid = vs.VDid              
        {whereClauseText}         

  	    -------end connected to VS--------------------

        ----------------------------------------
        DELETE vd
        FROM VesselDetails vd 		
        {whereClauseText}   
        ----------------------------------------



            ";
        }
    }
}
