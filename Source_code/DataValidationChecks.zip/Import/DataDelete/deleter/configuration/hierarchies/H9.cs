﻿using DataDelete.configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataDelete.deleter.configuration.hierarchies
{
    public class H9 : DeleteScriptBuilderBase
    {
        protected override string GetHierarchyDeleteScript(string commaSeperatedIds, bool includeWhereClause)
        {
            string hierarchyCodeIdText = $@"DECLARE @hierarchyCodeId int =  (select top 1 c.tblCodeID from tblCodeType t join tblCode c on t.tblCodeTypeID = c.tblCodeTypeID where t.CodeType like 'UpperHierarchy' and c.Code like '9')";

            string whereClauseText = "";
            if (includeWhereClause)
                whereClauseText = $@" WHERE sd.SDid IN({commaSeperatedIds}) AND de.DEhierarchy = @hierarchyCodeId ";
            else
                whereClauseText = $@" WHERE de.DEhierarchy = @hierarchyCodeId ";

            return
            $@"
                


				--------------------H9--------------------------
			    {hierarchyCodeIdText}

				 DELETE bv
				FROM Design de 
                JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN [Location] lo		    on sd.SDid = lo.SDid
				JOIN TemporalEvent te	    on lo.LOid = te.LOid				                
                JOIN SpeciesSelection ss	on te.TEid = ss.TEid	
                JOIN LandingEvent le	    on ss.SSid = le.SSid
                JOIN [Sample] sa             on le.LEid = sa.LEid
                JOIN BiologicalVariable bv  on sa.SAid = bv.SAid
                {whereClauseText}




				DELETE bv
				FROM Design de 
                JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN [Location] lo		    on sd.SDid = lo.SDid
				JOIN TemporalEvent te	    on lo.LOid = te.LOid				                
                JOIN SpeciesSelection ss	on te.TEid = ss.TEid	
                JOIN LandingEvent le	    on ss.SSid = le.SSid
                JOIN [Sample] sa             on le.LEid = sa.LEid
                JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
                JOIN BiologicalVariable bv on fm.FMid = bv.FMid
                {whereClauseText}




                DELETE fm
				FROM Design de 
                JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN [Location] lo		    on sd.SDid = lo.SDid
				JOIN TemporalEvent te	    on lo.LOid = te.LOid				                
                JOIN SpeciesSelection ss	on te.TEid = ss.TEid
                JOIN LandingEvent le	    on ss.SSid = le.SSid
                JOIN [Sample] sa             on le.LEid = sa.LEid
                JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
                {whereClauseText}


            


                DELETE sa
                FROM Design de 
                JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN [Location] lo		    on sd.SDid = lo.SDid
				JOIN TemporalEvent te	    on lo.LOid = te.LOid				                
                JOIN SpeciesSelection ss	on te.TEid = ss.TEid
                JOIN LandingEvent le	    on ss.SSid = le.SSid
                JOIN [Sample] sa             on le.LEid = sa.LEid
                {whereClauseText}        
				

				
			    DELETE le
                FROM Design de 
                JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN [Location] lo		    on sd.SDid = lo.SDid
				JOIN TemporalEvent te	    on lo.LOid = te.LOid				                
                JOIN SpeciesSelection ss	on te.TEid = ss.TEid
                JOIN LandingEvent le	    on ss.SSid = le.SSid
                
                {whereClauseText} 


				DELETE ss
                FROM Design de 
                JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN [Location] lo		    on sd.SDid = lo.SDid
				JOIN TemporalEvent te	    on lo.LOid = te.LOid				                
                JOIN SpeciesSelection ss	on te.TEid = ss.TEid				
                {whereClauseText}


				DELETE te
                FROM Design de 
                JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN [Location] lo		    on sd.SDid = lo.SDid
				JOIN TemporalEvent te	    on lo.LOid = te.LOid				                
                {whereClauseText}

				DELETE lo
                FROM Design de 
                JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN [Location] lo		    on sd.SDid = lo.SDid				
                {whereClauseText}

              

            ";
        }
    }
}
