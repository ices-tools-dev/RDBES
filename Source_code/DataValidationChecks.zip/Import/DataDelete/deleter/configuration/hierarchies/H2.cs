﻿using DataDelete.configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataDelete.deleter.configuration.hierarchies
{
    public class H2 : DeleteScriptBuilderBase
    {
        protected override string GetHierarchyDeleteScript(string commaSeperatedIds, bool includeWhereClause)
        {
            string hierarchyCodeIdText = $@"DECLARE @hierarchyCodeId int =  (select top 1 c.tblCodeID from tblCodeType t join tblCode c on t.tblCodeTypeID = c.tblCodeTypeID where t.CodeType like 'UpperHierarchy' and c.Code like '2')";

            string whereClauseText = "";
            if (includeWhereClause)
                whereClauseText = $@" WHERE sd.SDid IN({commaSeperatedIds}) AND de.DEhierarchy = @hierarchyCodeId ";
            else
                whereClauseText = $@" WHERE de.DEhierarchy = @hierarchyCodeId ";

            return
            $@"
            --------------------H2-------------------------
    			{hierarchyCodeIdText}

				 DELETE bv
                FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid				
                JOIN FishingTrip ft        on sd.SDid = ft.SDid
                JOIN FishingOperation fo   on ft.FTid = fo.FTid
                JOIN SpeciesSelection ss   on fo.FOid = ss.FOid
                JOIN [Sample] sa            on ss.SSid = sa.SSid
                JOIN BiologicalVariable bv on sa.SAid = bv.SAid
                {whereClauseText}


				DELETE bv
               FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid				
                JOIN FishingTrip ft        on sd.SDid = ft.SDid
                JOIN FishingOperation fo   on ft.FTid = fo.FTid
                JOIN SpeciesSelection ss   on fo.FOid = ss.FOid
                JOIN[Sample] sa            on ss.SSid = sa.SSid
                JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
                JOIN BiologicalVariable bv on fm.FMid = bv.FMid
                {whereClauseText}


                DELETE fm
                FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid				
                JOIN FishingTrip ft        on sd.SDid = ft.SDid
                JOIN FishingOperation fo   on ft.FTid = fo.FTid
                JOIN SpeciesSelection ss   on fo.FOid = ss.FOid
                JOIN[Sample] sa            on ss.SSid = sa.SSid
                JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
                {whereClauseText}


                DELETE sa
                FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid				
                JOIN FishingTrip ft        on sd.SDid = ft.SDid
                JOIN FishingOperation fo   on ft.FTid = fo.FTid
                JOIN SpeciesSelection ss   on fo.FOid = ss.FOid
                JOIN[Sample] sa            on ss.SSid = sa.SSid
                {whereClauseText}        
				


				DELETE ss
                FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid				
                JOIN FishingTrip ft        on sd.SDid = ft.SDid
                JOIN FishingOperation fo   on ft.FTid = fo.FTid
                JOIN SpeciesSelection ss   on fo.FOid = ss.FOid
                {whereClauseText}


				DELETE fo
                FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid				
                JOIN FishingTrip ft        on sd.SDid = ft.SDid
                JOIN FishingOperation fo   on ft.FTid = fo.FTid               
                {whereClauseText}

				
				DELETE ft
                FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid				
                JOIN FishingTrip ft        on sd.SDid = ft.SDid                
                {whereClauseText}


				----------------------------------------------

            ";
        }
    }
}
