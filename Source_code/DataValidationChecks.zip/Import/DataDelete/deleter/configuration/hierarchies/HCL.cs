﻿using DataDelete.configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataDelete.deleter.configuration.hierarchies
{
    public class HCL : DeleteScriptBuilderBase
    {
        protected override string GetHierarchyDeleteScript(string commaSeperatedIds, bool includeWhereClause)
        {
            var deletequery = $@" DELETE FROM [dbo].[CommercialLanding] ";
            string whereClauseText = "";
            if (includeWhereClause)
            {
                 whereClauseText = $@" WHERE CLid in ({commaSeperatedIds}) ";
            }

            var query = deletequery + whereClauseText;


            return query; 
        }
    }
}
