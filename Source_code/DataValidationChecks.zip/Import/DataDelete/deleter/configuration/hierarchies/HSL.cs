﻿using DataDelete.configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataDelete.deleter.configuration.hierarchies
{
    public class HSL : DeleteScriptBuilderBase
    {
        protected override string GetHierarchyDeleteScript(string commaSeperatedIds, bool includeWhereClause)
        {
            

            string whereClauseText="";
            if (includeWhereClause)
            {
                whereClauseText = $@" WHERE sl.SLid IN({commaSeperatedIds})";
            }

            return
           $@"
            --------------------HSL-------------------------

		DELETE bv
        FROM SpeciesList sl                     
        JOIN SpeciesSelection ss   on sl.SLid = ss.SLid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN BiologicalVariable bv on sa.SAid = bv.SAid    
        {whereClauseText}
		

        DELETE bv
        FROM SpeciesList sl                     
        JOIN SpeciesSelection ss   on sl.SLid = ss.SLid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
        JOIN BiologicalVariable bv on fm.FMid = bv.FMid          
        {whereClauseText}
		

        DELETE fm
		FROM SpeciesList sl                     
        JOIN SpeciesSelection ss   on sl.SLid = ss.SLid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid      
        {whereClauseText}
		

        DELETE sa
        FROM SpeciesList sl                     
        JOIN SpeciesSelection ss  on sl.SLid = ss.SLid
        JOIN[Sample] sa            on ss.SSid = sa.SSid
        {whereClauseText}
                                
        
        DELETE ss
        FROM SpeciesList sl                     
        JOIN SpeciesSelection ss  on sl.SLid = ss.SLid
        {whereClauseText}
			   
        
        DELETE sl
        FROM SpeciesList sl                     
        
        {whereClauseText}
                
				----------------------------------------------
"; 
            
        }
    }
}
