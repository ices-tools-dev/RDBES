﻿using DataDelete.configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataDelete.deleter.configuration.hierarchies
{
    public class H4 : DeleteScriptBuilderBase
    {
        protected override string GetHierarchyDeleteScript(string commaSeperatedIds, bool includeWhereClause)
        {
            string hierarchyCodeIdText = $@"DECLARE @hierarchyCodeId int =  (select top 1 c.tblCodeID from tblCodeType t join tblCode c on t.tblCodeTypeID = c.tblCodeTypeID where t.CodeType like 'UpperHierarchy' and c.Code like '4')";

            string whereClauseText = "";
            if (includeWhereClause)
                whereClauseText = $@" WHERE sd.SDid IN({commaSeperatedIds}) AND de.DEhierarchy = @hierarchyCodeId ";
            else
                whereClauseText = $@" WHERE de.DEhierarchy = @hierarchyCodeId ";

            return
            $@"
                

				
				--------------------H4-------------------------
		    	{hierarchyCodeIdText}

				
				 DELETE bv
				FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN OnshoreEvent os		on sd.SDid = os.SDid
				JOIN FishingTrip ft			on os.OSid = ft.OSid
				JOIN LandingEvent le        on ft.FTid = le.FTid                
                JOIN SpeciesSelection ss	on le.LEid = ss.LEid
                JOIN [Sample] sa            on ss.SSid = sa.SSid
                JOIN BiologicalVariable bv on sa.SAid = bv.SAid
                {whereClauseText}




				DELETE bv
				FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN OnshoreEvent os		on sd.SDid = os.SDid
				JOIN FishingTrip ft			on os.OSid = ft.OSid
				JOIN LandingEvent le        on ft.FTid = le.FTid                
                JOIN SpeciesSelection ss	on le.LEid = ss.LEid
                JOIN[Sample] sa            on ss.SSid = sa.SSid
                JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
                JOIN BiologicalVariable bv on fm.FMid = bv.FMid
                {whereClauseText}




                DELETE fm
				FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN OnshoreEvent os		on sd.SDid = os.SDid
				JOIN FishingTrip ft			on os.OSid = ft.OSid
				JOIN LandingEvent le        on ft.FTid = le.FTid                
                JOIN SpeciesSelection ss	on le.LEid = ss.LEid
                JOIN[Sample] sa            on ss.SSid = sa.SSid
                JOIN FrequencyMeasure fm   on sa.SAid = fm.SAid
                {whereClauseText}




                DELETE sa
                FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN OnshoreEvent os		on sd.SDid = os.SDid
				JOIN FishingTrip ft			on os.OSid = ft.OSid
				JOIN LandingEvent le        on ft.FTid = le.FTid                
                JOIN SpeciesSelection ss	on le.LEid = ss.LEid
                JOIN[Sample] sa            on ss.SSid = sa.SSid
                {whereClauseText}        
				

				DELETE ss
                FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN OnshoreEvent os		on sd.SDid = os.SDid
				JOIN FishingTrip ft			on os.OSid = ft.OSid
				JOIN LandingEvent le        on ft.FTid = le.FTid                
                JOIN SpeciesSelection ss	on le.LEid = ss.LEid
                {whereClauseText}

				DELETE le
                FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN OnshoreEvent os		on sd.SDid = os.SDid
				JOIN FishingTrip ft			on os.OSid = ft.OSid
				JOIN LandingEvent le        on ft.FTid = le.FTid                                
                {whereClauseText}

				DELETE ft
                FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN OnshoreEvent os		on sd.SDid = os.SDid
				JOIN FishingTrip ft			on os.OSid = ft.OSid				
                {whereClauseText}

				DELETE os
                FROM Design de JOIN SamplingDetails sd	    on de.DEid = sd.DEid
				JOIN OnshoreEvent os		on sd.SDid = os.SDid				
                {whereClauseText}
            
                 


            ";
        }
    }
}
