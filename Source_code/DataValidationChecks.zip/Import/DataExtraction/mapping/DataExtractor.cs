﻿using ResCommon;
using ResData.Models.CacheData;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

namespace DataExtraction.mapping
{

    public class DataExtractor
    {
        Dictionary<Utility.CodeType, Dictionary<string, int>> codesByTypeDic;

        readonly CultureInfo InvariantCulture = CultureInfo.InvariantCulture;
         Dictionary<string, string> ele;
         string lnErrorMsg = null;
         string tagName = null;

        List<CodeWithType> CachedCodes { get; set; }
        private Dictionary<string,int> GetCodesByType(Utility.CodeType codeType)
        {
            var codeTypeName = Utility.GetCodeTypeNameAsInDB(codeType);// get code type name from dictionary
            var codes = this.CachedCodes.Where(c => c.Type.Equals(codeTypeName)).GroupBy(g => g.Code).Select(s => s.FirstOrDefault());
            var keyValueCollection = codes.ToDictionary(c => c.Code, c => c.Id);
            if (codes.Count() <= 0)
                throw new Exception(string.Format($"No codes found in for ' {codeType.ToString()} ' type"));

            return keyValueCollection;
        }

        public DataExtractor(List<CodeWithType> cachedCodes)
        {

            this.CachedCodes = cachedCodes;
            codesByTypeDic = new Dictionary<Utility.CodeType, Dictionary<string, int>>();
            foreach (Utility.CodeType codeType in Enum.GetValues(typeof(Utility.CodeType)))
            {
                codesByTypeDic.Add(codeType, GetCodesByType(codeType));
            }
        }
        public void SetDataExtractor(Dictionary<string, string> _ele,string tagName)
        {
            this.ele = _ele;
            this.lnErrorMsg = "xml line number : " + GetLineNumber().ToString() + ". ";
            this.tagName = tagName;
        }


        #region test code
        public int GetCodeId(string childName, Utility.CodeType codeType)
        {
            var code = GetStringValue(childName);

            return FindCodeId(codeType, code);

        }
        public int? GetCodeIdOrNull(string childName, Utility.CodeType codeType)
        {
            var code = GetStringValueOrNull(childName);
            if (code == null) return null;
            return FindCodeId(codeType, code);

        }
   //     IQueryable<CodeWithType> codes;
        private int FindCodeId(Utility.CodeType codeType, string code)
        {
          var   codes = codesByTypeDic[codeType];

           // var codeWithType = codes[code];  //.FirstOrDefault(h => h.Code.Equals(code));
            if (!codes.ContainsKey(code))
                throw new Exception($"No id found for the code '{code}' of code type '{codeType.ToString()}'");
            return codes[code];

        }

        #endregion


        public DateTime GetDateTimeValue(string childName)
        {
            var childElement = this.ele.ContainsKey(childName);
            if (!childElement) throw new Exception(this.lnErrorMsg + "No date time value found because Child element '" + childName + "' not found under the parent element '" + tagName + "'");
            return Convert.ToDateTime(this.ele[childName]);

        }
        public DateTime? GetDateTimeValueOrNull(string childName)
        {
            var childElement = this.ele.ContainsKey(childName);
            if (!childElement) return null;
            return Convert.ToDateTime(this.ele[childName]);

        }
        public string GetStringValue(string childName)
        {
            var childElement = this.ele.ContainsKey(childName);
            if (!childElement) throw new Exception(this.lnErrorMsg + "No string value found because Child element '" + childName + "' not found under the parent element '" + tagName + "'");

            return this.ele[childName];
        }
        public string GetStringValueOrNull(string childName)
        {
            var childElement = ele.ContainsKey(childName);
            if (!childElement) return null;
            return this.ele[childName];

        }
        public int? GetIntValueOrNull(string childName)
        {
            var childElement = ele.ContainsKey(childName);
            if (!childElement) return null;
            if (string.IsNullOrWhiteSpace(this.ele[childName])) return null;
            return Convert.ToInt32(this.ele[childName]);
        }
        public int GetIntValue(string childName)
        {
            var childElement = ele.ContainsKey(childName);
            if (!childElement) throw new Exception(this.lnErrorMsg + "Child element '" + childName + "' not found under the parent element '" + tagName + "'");
            if (string.IsNullOrWhiteSpace(this.ele[childName])) throw new Exception(this.lnErrorMsg + "value not found for Child element '" + childName + "' not found under the parent element '" + tagName + "'");
            return Convert.ToInt32(this.ele[childName]);
        }
        public decimal GetDecimalValue(string childName)
        {
            var childElement = ele.ContainsKey(childName);
            if (!childElement) throw new Exception(this.lnErrorMsg + "Child element '" + childName + "' not found under the parent element '" + tagName + "'");
            if (string.IsNullOrWhiteSpace(this.ele[childName])) throw new Exception(this.lnErrorMsg + "value not found for Child element '" + childName + "' not found under the parent element '" + tagName + "'");
            return Convert.ToDecimal(this.ele[childName], InvariantCulture);
        }
        public decimal? GetDecimalValueOrNull(string childName)
        {
            var childElement = ele.ContainsKey(childName);
            if (!childElement) return null;
            if (string.IsNullOrWhiteSpace(this.ele[childName])) return null;
            return Convert.ToDecimal(this.ele[childName], InvariantCulture);
        }

        public long? GetLongValueOrNull(string childName)
        {
            var childElement = ele.ContainsKey(childName);
            if (!childElement) return null;
            if (string.IsNullOrWhiteSpace(this.ele[childName])) return null;
            return Convert.ToInt64(this.ele[childName]);
        }
        public long GetLongValue(string childName)
        {
            var childElement = ele.ContainsKey(childName);
            if (!childElement) throw new Exception(this.lnErrorMsg + "Child element '" + childName + "' not found under the parent element '" + tagName + "'");
            if (string.IsNullOrWhiteSpace(this.ele[childName])) throw new Exception(this.lnErrorMsg + "value not found for Child element '" + childName + "' not found under the parent element '" + tagName + "'");
            return Convert.ToInt64(this.ele[childName]);
        }





        public int GetLineNumber()
        {
            var lineNoElementName = "ln";
            var attrElement = ele.ContainsKey(lineNoElementName);
            if (!attrElement) throw new Exception(this.lnErrorMsg + "No line number attribute found for the xml element");
            return Convert.ToInt32(this.ele[lineNoElementName]);
        }
        public int GetParentLineNumber()
        {
            var parLineNoElementName = "pln";
            var attrElement = ele.ContainsKey(parLineNoElementName);
            if (!attrElement) throw new Exception(this.lnErrorMsg + "No line number attribute found for the xml element");
            return Convert.ToInt32(ele[parLineNoElementName]);
        }

       

       



    }

}


    

