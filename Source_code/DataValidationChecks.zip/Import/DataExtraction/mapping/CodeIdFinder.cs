﻿using ResCommon;
using ResData.Models.CacheData;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataExtraction.mapping
{
    public class CodeIdFinder
    {
        Dictionary<Utility.CodeType, Dictionary<string, int>> codesByTypeDic;

        public    List<CodeWithType> CachedCodes { get; set; }

        public CodeIdFinder(List<CodeWithType> cachedCodes)
        {

            this.CachedCodes = cachedCodes;
            codesByTypeDic = new Dictionary<Utility.CodeType, Dictionary<string, int>>();
            foreach (Utility.CodeType codeType in Enum.GetValues(typeof(Utility.CodeType)))
            {
                codesByTypeDic.Add(codeType, GetCodesByType(codeType));
            }
        }

        public int GetCodeId(string code, Utility.CodeType codeType)
        {
            return FindCodeId(codeType, code);

        }
        public int? GetCodeIdOrNull(string code, Utility.CodeType codeType)
        {
            if (string.IsNullOrWhiteSpace(code)) return null;
            return FindCodeId(codeType, code);

        }

        private int FindCodeId(Utility.CodeType codeType, string code)
        {
            var codes = codesByTypeDic[codeType];

            // var codeWithType = codes[code];  //.FirstOrDefault(h => h.Code.Equals(code));
            if (!codes.ContainsKey(code))
                throw new Exception($"No id found for the code '{code}' of code type '{codeType.ToString()}'");
            return codes[code];

        }



        private Dictionary<string, int> GetCodesByType(Utility.CodeType codeType)
        {
            var codeTypeName = Utility.GetCodeTypeNameAsInDB(codeType);// get code type name from dictionary
            var codes = this.CachedCodes.Where(c => c.Type.Equals(codeTypeName)).GroupBy(g => g.Code).Select(s => s.FirstOrDefault());
            var keyValueCollection = codes.ToDictionary(c => c.Code, c => c.Id);
            if (codes.Count() <= 0)
                throw new Exception(string.Format($"No codes found in for ' {codeType.ToString()} ' type"));

            return keyValueCollection;
        }





        #region by codes
        private int FindCodeId(string code,Dictionary<string,int> codes)
        {
          //  var dic = codes.Distinct().ToDictionary(x => x.Code.Trim(), x => x.Id);
            int? codeId = codes[code];

            //var codeWithType = codes.Where(h => h.Code.Contains(code)).FirstOrDefault();



            if (codeId == null)
                throw new Exception($"No id found for the code '{code}' of code type");
            return codeId.Value;

        }

        public int GetCodeId(string code, Dictionary<string,int> codes)
        {
            return FindCodeId(code,codes);

        }
        public int? GetCodeIdOrNull(string code,Dictionary<string,int> codes)
        {
            if (code == null) return null;
            return FindCodeId(code,codes);

        }
        #endregion
    }
}
