﻿using ResData.Models.KeyLessEntities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataExtraction.mapping
{
    public class LookupFinder
    {
        List<CodeLookup> CodeLookups { get; set; }
        public LookupFinder(List<CodeLookup> codeLookups)
        {
            this.CodeLookups = codeLookups;

           
        }

      

        public int GetVDLookupPrimaryKey( string code, string country, string year)
        {
            string table = "VesselDetails";
            string fieldName = "VDencryptedVesselCode";

            

            var codeMap = FindVDCodeLookup(table, fieldName, code, country, year);

            if (codeMap == null) throw new Exception($"VD lookup not found for the key {code}, {country}, {year}");
            else
                return codeMap.Id.Value;



        }
      
        public int GetSLLookupPrimaryKey(string speciesListCode, string catchFractionCode, string country, string year)
        {
            string table = "SpeciesList";
            string speciesListFieldName = "SLspeciesListName";
            string catchFractionFieldName = "SLcatchFraction";

            var codeMap = FindSLCodeLookup(table, speciesListFieldName, speciesListCode, catchFractionFieldName, catchFractionCode, country, year);

            if (codeMap == null) throw new Exception($"no look up primary key found for the key '{speciesListCode}','{catchFractionCode}','{country}','{year}' in the table '{table}'");
            return codeMap.Id.Value;



        }
     
        
        
        
        private CodeLookup FindVDCodeLookup(string table, string fieldName, string code, string country, string year)
        {

            var codeMap = this.CodeLookups.Where(c =>
               c.DbTable.Equals(table)
            && c.FieldName.Equals(fieldName)
            && c.Code.Equals(code)
            && c.Country.Equals(country)
            && c.Year.Equals(year)

            ).FirstOrDefault();

            return codeMap;
        }

       
        
        private CodeLookup FindSLCodeLookup(string table, string speciesListFieldName, string speciesListCode,string catchFractionFieldName, string catchFractionCode, string country,string year)
        {

            var codeMap = this.CodeLookups.Where(c => 
               c.DbTable.Equals(table) 
            && c.FieldName.Equals(speciesListFieldName) 
            && c.Code.Equals(speciesListCode)
            && c.CatchFractionFieldName.Equals(catchFractionFieldName)
            && c.CatchFractionFieldValue.Equals(catchFractionCode)
            && c.Country.Equals(country)
            && c.Year.Equals(year)
            
            ).FirstOrDefault();

            return codeMap;
        }
    }
}
