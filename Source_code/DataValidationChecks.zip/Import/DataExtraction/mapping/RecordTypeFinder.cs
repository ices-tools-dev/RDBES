﻿using ResCommon;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace DataExtraction.mapping
{
    public class RecordTypeFinder
    {
        protected XDocument XmlData { get; set; }
        public RecordTypeFinder(XDocument xmlData)
        {
            this.XmlData = xmlData;

        }
        public IEnumerable<XElement> GetEntityElements(Utility.RecordType recordType)
        {

            return from childrens in this.XmlData.Descendants(recordType.ToString())
                   select childrens;
        }

    }
}
