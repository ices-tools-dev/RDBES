﻿using ResCommon;
using System;
using System.Globalization;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace DataExtraction.mapping
{
    public class XMLExtractor
    {




        readonly CultureInfo InvariantCulture = CultureInfo.InvariantCulture;

        public XMLExtractor()
        {

        }
       

        
      

        public DateTime GetDateTimeValue(string value)
        {

            return Convert.ToDateTime(value);

        }
        public DateTime? GetDateTimeValueOrNull(string value)
        {

            
            if (value == null)
                return null;
            else
                return Convert.ToDateTime(value);

        }
        public int GetIntValue(string value)
        {
            return Convert.ToInt32(value);
        }
        public int? GetIntValueOrNull(string value)
        {
            
            if (value == null)
                return null;
            else
                return Convert.ToInt32(value);
        }

        public decimal GetDecimalValue(string value)
        {

            return Convert.ToDecimal(value);
        }
        public decimal? GetDecimalValueOrNull(string value)
        {
            
            if (value == null)
                return null;
            else
                return Convert.ToDecimal(value, InvariantCulture);
        }

       





    }


    //public class XMLExtractor
    //{




    //    readonly CultureInfo InvariantCulture = CultureInfo.InvariantCulture;

    //    public XMLExtractor()
    //    {

    //    }
    //    private bool ChildElementFound(XmlReader reader, string childName)
    //    {


    //        var childElement = reader.Read();
    //        if (childElement)
    //            return true;
    //        else
    //            throw new Exception("No value found because Child element '" + childName + "' not found under the parent element ");
    //    }

    //    public string GetStringValue(XmlReader reader, string childName)
    //    {
    //        ChildElementFound(reader, childName);
    //        return reader.ReadElementContentAsString();
    //    }
    //    public string GetStringValueOrNull(XmlReader reader, string childName)
    //    {
    //        var val = GetStringValue(reader, childName);
    //        if (val == null)
    //            return null;
    //        else
    //            return val;



    //    }

    //    public DateTime GetDateTimeValue(XmlReader reader, string childName)
    //    {

    //        return Convert.ToDateTime(GetStringValue(reader, childName));

    //    }
    //    public DateTime? GetDateTimeValueOrNull(XmlReader reader, string childName)
    //    {

    //        var val = GetStringValue(reader, childName);
    //        if (val == null)
    //            return null;
    //        else
    //            return Convert.ToDateTime(val);

    //    }
    //    public int GetIntValue(XmlReader reader, string childName)
    //    {
    //        return Convert.ToInt32(GetStringValue(reader, childName));
    //    }
    //    public int? GetIntValueOrNull(XmlReader reader, string childName)
    //    {
    //        var val = GetStringValue(reader, childName);
    //        if (val == null)
    //            return null;
    //        else
    //            return Convert.ToInt32(val);
    //    }

    //    public decimal GetDecimalValue(XmlReader reader, string childName)
    //    {

    //        return Convert.ToDecimal(GetStringValue(reader, childName), InvariantCulture);
    //    }
    //    public decimal? GetDecimalValueOrNull(XmlReader reader, string childName)
    //    {
    //        var val = GetStringValue(reader, childName);
    //        if (val == null)
    //            return null;
    //        else
    //            return Convert.ToDecimal(val, InvariantCulture);
    //    }

    //    //public int GetLineNumber()
    //    //{
    //    //    if (reader.GetAttribute("ln") == null) throw new Exception(this.lnErrorMsg + "No line number attribute found for the xml element");
    //    //    return Convert.ToInt32(reader.GetAttribute("ln").Value);
    //    //}
    //    //public int GetParentLineNumber()
    //    //{
    //    //    if (reader.Parent.Attribute("ln") == null) throw new Exception(this.lnErrorMsg + "No line number attribute found for the xml element");
    //    //    return Convert.ToInt32(reader.Parent.Attribute("ln").Value);
    //    //}





    //}

}
