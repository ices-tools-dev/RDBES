﻿using ResCommon;
using System;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

namespace DataExtraction.mapping
{

    public class Extractor
    {

        readonly CultureInfo InvariantCulture = CultureInfo.InvariantCulture;
        readonly XElement ele;
        readonly string lnErrorMsg = null;
        public Extractor(XElement _ele)
        {
            this.ele = _ele;
            this.lnErrorMsg = "xml line number : " + GetLineNumber().ToString() + ". ";

        }
        public DateTime GetDateTimeValue(string childName)
        {
            var childElement = this.ele.Element(childName);
            if (childElement == null) throw new Exception(this.lnErrorMsg + "No date time value found because Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
            return Convert.ToDateTime(childElement.Value);

        }
        public DateTime? GetDateTimeValueOrNull(string childName)
        {
            var childElement = this.ele.Element(childName);
            if (childElement == null) return null;
            return Convert.ToDateTime(childElement.Value);

        }
        public string GetStringValue(string childName)
        {
            var childElement = this.ele.Element(childName);
            if (childElement == null) throw new Exception(this.lnErrorMsg + "No string value found because Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");

            return childElement.Value;
        }
        public string GetStringValueOrNull(string childName)
        {
            var childElement = ele.Element(childName);
            if (childElement == null) return null;
            return childElement.Value;

        }
        public int? GetIntValueOrNull(string childName)
        {
            var childElement = ele.Element(childName);
            if (childElement == null) return null;
            if (string.IsNullOrWhiteSpace(childElement.Value)) return null;
            return Convert.ToInt32(childElement.Value);
        }
        public int GetIntValue(string childName)
        {
            var childElement = ele.Element(childName);
            if (childElement == null) throw new Exception(this.lnErrorMsg + "Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
            if (string.IsNullOrWhiteSpace(childElement.Value)) throw new Exception(this.lnErrorMsg + "value not found for Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
            return Convert.ToInt32(childElement.Value);
        }

        public long? GetInt64ValueOrNull(string childName)
        {
            var childElement = ele.Element(childName);
            if (childElement == null) return null;
            if (string.IsNullOrWhiteSpace(childElement.Value)) return null;
            return Convert.ToInt64(childElement.Value);
        }
        public long GetInt64Value(string childName)
        {
            var childElement = ele.Element(childName);
            if (childElement == null) throw new Exception(this.lnErrorMsg + "Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
            if (string.IsNullOrWhiteSpace(childElement.Value)) throw new Exception(this.lnErrorMsg + "value not found for Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
            return Convert.ToInt64(childElement.Value);
        }

        public decimal GetDecimalValue(string childName)
        {
            var childElement = ele.Element(childName);
            if (childElement == null) throw new Exception(this.lnErrorMsg + "Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
            if (string.IsNullOrWhiteSpace(childElement.Value)) throw new Exception(this.lnErrorMsg + "value not found for Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
            return Convert.ToDecimal(childElement.Value, InvariantCulture);
        }
        public decimal? GetDecimalValueOrNull(string childName)
        {
            var childElement = ele.Element(childName);
            if (childElement == null) return null;
            if (string.IsNullOrWhiteSpace(childElement.Value)) return null;
            return Convert.ToDecimal(childElement.Value, InvariantCulture);
        }

        public long? GetLongValueOrNull(string childName)
        {
            var childElement = ele.Element(childName);
            if (childElement == null) return null;
            if (string.IsNullOrWhiteSpace(childElement.Value)) return null;
            return Convert.ToInt64(childElement.Value);
        }
        public long GetLongValue(string childName)
        {
            var childElement = ele.Element(childName);
            if (childElement == null) throw new Exception(this.lnErrorMsg + "Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
            if (string.IsNullOrWhiteSpace(childElement.Value)) throw new Exception(this.lnErrorMsg + "value not found for Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
            return Convert.ToInt64(childElement.Value);
        }

        public int GetLineNumber()
        {
            if (ele.Attribute("ln") == null) throw new Exception(this.lnErrorMsg + "No line number attribute found for the xml element");
            return Convert.ToInt32(ele.Attribute("ln").Value);
        }
        public int GetParentLineNumber()
        {
            if (ele.Parent.Attribute("ln") == null) throw new Exception(this.lnErrorMsg + "No line number attribute found for the xml element");
            return Convert.ToInt32(ele.Parent.Attribute("ln").Value);
        }

        public string GetParentName()
        {
            if (ele.Parent == null) throw new Exception(this.lnErrorMsg + "No parent found of this element");
            return ele.Parent.Name.ToString();
        }

        public int? GetAncesstorLineNumberOrNull(string ancesstorName)
        {
            var ancesstor = ele.Ancestors(ancesstorName.ToString()).FirstOrDefault();
            if (ancesstor == null) return null;
            if (ancesstor.Attribute("ln") == null) throw new Exception(this.lnErrorMsg + "No line number attribute found for the xml element");
            return Convert.ToInt32(ancesstor.Attribute("ln").Value);
        }



    }

}


    //public class Extractor
    //{

    //    readonly CultureInfo InvariantCulture = CultureInfo.InvariantCulture;
    //    readonly XElement ele;
    //    readonly string lnErrorMsg = null;
    //    public Extractor(XElement _ele)
    //    {
    //        this.ele = _ele;
    //        this.lnErrorMsg = "xml line number : " + GetLineNumber().ToString() + ". ";

    //    }
    //    public DateTime GetDateTimeValue(string childName)
    //    {
    //        var childElement = this.ele.Element(childName);
    //        if (childElement == null) throw new Exception(this.lnErrorMsg + "No date time value found because Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
    //        return Convert.ToDateTime(childElement.Value);

    //    }
    //    public DateTime? GetDateTimeValueOrNull(string childName)
    //    {
    //        var childElement = this.ele.Element(childName);
    //        if (childElement == null) return null;
    //        return Convert.ToDateTime(childElement.Value);

    //    }
    //    public string GetStringValue(string childName)
    //    {
    //        var childElement = this.ele.Element(childName);
    //        if (childElement == null) throw new Exception(this.lnErrorMsg + "No value found because Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");

    //        return childElement.Value;
    //    }
    //    public string GetStringValueOrNull(string childName)
    //    {
    //        var childElement = ele.Element(childName);
    //        if (childElement == null) return null;
    //        return childElement.Value;

    //    }
    //    public int? GetIntValueOrNull(string childName)
    //    {
    //        var childElement = ele.Element(childName);
    //        if (childElement == null) return null;
    //        if (string.IsNullOrWhiteSpace(childElement.Value)) return null;
    //        return Convert.ToInt32(childElement.Value);
    //    }
    //    public int GetIntValue(string childName)
    //    {
    //        var childElement = ele.Element(childName);
    //        if (childElement == null) throw new Exception(this.lnErrorMsg + "Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
    //        if (string.IsNullOrWhiteSpace(childElement.Value)) throw new Exception(this.lnErrorMsg + "value not found for Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
    //        return Convert.ToInt32(childElement.Value);
    //    }
    //    public decimal GetDecimalValue(string childName)
    //    {
    //        var childElement = ele.Element(childName);
    //        if (childElement == null) throw new Exception(this.lnErrorMsg + "Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
    //        if (string.IsNullOrWhiteSpace(childElement.Value)) throw new Exception(this.lnErrorMsg + "value not found for Child element '" + childName + "' not found under the parent element '" + ele.Name + "'");
    //        return Convert.ToDecimal(childElement.Value, InvariantCulture);
    //    }
    //    public decimal? GetDecimalValueOrNull(string childName)
    //    {
    //        var childElement = ele.Element(childName);
    //        if (childElement == null) return null;
    //        if (string.IsNullOrWhiteSpace(childElement.Value)) return null;
    //        return Convert.ToDecimal(childElement.Value, InvariantCulture);
    //    }

    //    public int GetLineNumber()
    //    {
    //        if (ele.Attribute("ln") == null) throw new Exception(this.lnErrorMsg + "No line number attribute found for the xml element");
    //        return Convert.ToInt32(ele.Attribute("ln").Value);
    //    }
    //    public int GetParentLineNumber()
    //    {
    //        if (ele.Parent.Attribute("ln") == null) throw new Exception(this.lnErrorMsg + "No line number attribute found for the xml element");
    //        return Convert.ToInt32(ele.Parent.Attribute("ln").Value);
    //    }

    //    public string GetParentName()
    //    {
    //        if (ele.Parent == null) throw new Exception(this.lnErrorMsg + "No parent found of this element");
    //        return ele.Parent.Name.ToString();
    //    }

    //    public int? GetAncesstorLineNumberOrNull(string ancesstorName)
    //    {
    //        var ancesstor = ele.Ancestors(ancesstorName.ToString()).FirstOrDefault();
    //        if (ancesstor == null) return null;
    //        if (ancesstor.Attribute("ln") == null) throw new Exception(this.lnErrorMsg + "No line number attribute found for the xml element");
    //        return Convert.ToInt32(ancesstor.Attribute("ln").Value);
    //    }



    //}

