﻿using ResCommon;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace DataExtraction.mapping
{
    public class XMLRecordFinder
    {
        protected XDocument XmlData { get; set; }
        public string XmlPath;
        public XMLRecordFinder(string path)
        {

            this.XmlData = XDocument.Load(path);
            this.XmlPath = path;

        }
        public IEnumerable<XElement> GetEntityElements(Utility.RecordType recordType)
        {

            return from childrens in this.XmlData.Descendants(recordType.ToString())
                   select childrens;
        }


        public List<Dictionary<string, string>> GetItems(Utility.RecordType recordType)
        {


            List<Dictionary<string, string>> dataItems;
            dataItems = new List<Dictionary<string, string>>();

            using (XmlReader reader = XmlReader.Create(this.XmlPath))
            {
                reader.MoveToContent();

                string pln = ""; //reader.GetAttribute("ln");
                while (reader.ReadToFollowing(recordType.ToString()))
                {
                    string ln = reader.GetAttribute("ln");
                    var dataItem = CreateDataItem(recordType.ToString(), reader.ReadSubtree(), ln, pln);
                    dataItems.Add(dataItem);
                }

            }


            return dataItems;
        }
        private Dictionary<string, string> CreateDataItem(string recordType,XmlReader reader,string ln, string pln)
        {

            var res = new Dictionary<string, string>();


         
            res.Add("ln", ln);
            res.Add("pln", pln);


            SetDataItemKey(recordType,reader, res);

            return res;


        }
        private void SetDataItemKey(string recordType,XmlReader reader, Dictionary<string, string> res)
        {
            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element)
                {
                    var name = reader.Name;
                    if (!name.Equals(recordType))
                    {
                        var val = reader.ReadString();
                        res.Add(name, val);
                    }
                }

            }
        }
    
    
    
    }
}