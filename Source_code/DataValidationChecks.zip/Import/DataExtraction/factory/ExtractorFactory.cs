﻿using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;

namespace DataExtraction.extraction.factory
{
    public static class ExtractorFactory

    {
        private static Dictionary<Utility.DataType, Type> exportersTypes = 
            new Dictionary<Utility.DataType, Type>();

        static ExtractorFactory()
        {
            IndexExtractors();
        }

        //public static IExtractXML CreateXMLExtractor(XDocument xmlData, string userId, List<CodeWithType> cachedCodes, Utility.DataType dataType)
        //{
        //    Type extractorType = null;
        //    if (!exportersTypes.TryGetValue(dataType, out extractorType))
        //    {
        //        throw new Exception(string.Format($"Unable to locate data extractor for HierarchyType:{extractorType}"));
        //    }

        //    return (IExtractXML)Activator.CreateInstance(extractorType, xmlData);

        //}

        public static IExtractEntity CreateEntityExtractor(Utility.DataType dataType)
        {


            Type extractorType = null;
            if (!exportersTypes.TryGetValue(dataType, out extractorType))
            {
                throw new Exception(string.Format($"Unable to locate IExtractEntity for HierarchyType:{extractorType}"));
            }

            return (IExtractEntity)Activator.CreateInstance(extractorType);

        }


        private static void IndexExtractors()
        {

            var types = ((typeof(ExtractorFactory)))
                .GetTypeInfo().Assembly.DefinedTypes
                .Where(t => t.IsClass && t.Namespace == "DataExtraction.extraction")
                .Select(t => new { type = t.UnderlyingSystemType, typeInfo = t })
                .ToList();
            exportersTypes = new Dictionary<Utility.DataType, Type>();
            foreach (var t in types)
            {
                var attr = t.typeInfo.GetCustomAttribute<DataTypeAttribute>();
                if (attr != null)
                {
                    exportersTypes.Add(attr.DataType, t.type);
                }
            }

        }
    }
}
