﻿using DataExtraction.mapping;
using DataPersistence;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using DataExtraction.extraction;
using DataExtraction.extraction.factory;
using TypeDefinitions.DataImport;

namespace DataExtraction.client
{
    public class ExtractionClient
    {
        protected string UserId { get; set; }
        protected int DataUploadCountryId { get; set; }      
        protected string Path;
        protected CodeIdFinder CodeIdFinder { get; set; }
        protected LookupFinder LookupFinder { get; set; }
        protected XMLRecordFinder XmlRecordFinder { get; set; }
        protected PersistedKeysFinder PersistedKeysFinder { get; set; }

        protected Dictionary<Utility.CodeType, Dictionary<string, int>> CodesByTypeDic;

        protected Extractor Extractor;
        protected XMLExtractor XmlExtractor;

        protected IExtractEntity entityExtractor;

       

        public ExtractionClient(string path, string userId, int dataUploadCountryId, List<CodeWithType> cachedCodes, List<CodeLookup> codeLookups)
        {
           

            this.Path = path;
            
            this.UserId = userId;

            this.DataUploadCountryId =dataUploadCountryId;         

            this.XmlExtractor = new XMLExtractor();

            this.CodeIdFinder = new CodeIdFinder(cachedCodes);

            this.XmlRecordFinder = new XMLRecordFinder( path);

            this.LookupFinder = new LookupFinder(codeLookups);

            this.PersistedKeysFinder = new PersistedKeysFinder();

        }
            
        



      



        public object GetTableData(Utility.DataType dataType,Utility.RecordType RecordType)
        {

            this.entityExtractor = ExtractorFactory.CreateEntityExtractor(dataType);
            var data = entityExtractor.GetTableData( RecordType,  this.UserId,  this.XmlRecordFinder,  this.CodeIdFinder,  this.LookupFinder,  this.PersistedKeysFinder);
            return data;
        }
    }
}
