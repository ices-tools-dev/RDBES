﻿using DataExtraction.mapping;
using DataPersistence;
using ResCommon;

namespace DataExtraction.extraction
{
    public interface IExtractEntity
    {
        object GetTableData(Utility.RecordType RecordType, string userId, XMLRecordFinder XMLRecordFinder, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder);
        
    }
}
