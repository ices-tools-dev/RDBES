﻿


using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.SD)]
    internal class ExtractSD : ExtractBase
    {
        public ExtractSD()
            : base() { }



        public override object GetData(IEnumerable<XElement> sds, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<SD> SDs = new List<SD>();
            foreach (var sd in sds)
            {
               var Extractor = new Extractor(sd);
                SD SD = GetSD(sd,RecordType,userId,Extractor,CodeIdFinder,LookupFinder,PersistedKeysFinder);
                SDs.Add(SD);

            }
            elementsExtracted = SDs.Count();
            return SDs;
        }

        private SD GetSD(XElement ele, Utility.RecordType RecordType, string userId, Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {
            var sd = new
            SD();


            sd.SdrecordType = RecordType.ToString();
          
            sd.UserId = userId;
            sd.TimeStamp = DateTime.Now;

            sd.Sdcountry = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SDcountry"), Utility.CodeType.ISO_3166);
            sd.Sdinstitution = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SDinstitution"), Utility.CodeType.EDMO);


            sd.LN = Extractor.GetLineNumber();
            sd.PLN = Extractor.GetParentLineNumber();
            


            // this applies to all CS hierarchies(h1 to h13)
            // if PrimaryKey value is 0 then entity framework will add entity to db
            // if PrimaryKey value is greater than 0 it means the SD record is in db and do not insert record            
            var pk = PersistedKeysFinder.GetPersistedKeyValue(ele, "PrimaryKey");
            sd.PrimaryKey = pk;
            // value of Sdid will be used as foriegn key value in folliwing child(depending on the hierarchy)
            sd.Sdid = pk;

            // delete all records under SD from DB in import module where deletekey value is greater than 0
            sd.DeleteKey = pk;

            return sd;
        
        }
    }

}
