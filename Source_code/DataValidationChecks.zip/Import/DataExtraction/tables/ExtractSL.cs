﻿using DataExtraction.mapping;
using DataExtraction.extraction;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.SL)]
    internal class ExtractSL : ExtractBase
    {
        public ExtractSL()
            : base() { }
        public override object GetData(IEnumerable<XElement> sls, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<SL> SLs = new List<SL>();

            foreach (var sl in sls)
            {

              var  Extractor = new Extractor(sl);
                SL SL = GetSL(sl,RecordType,userId,Extractor,CodeIdFinder,LookupFinder,PersistedKeysFinder);
                SLs.Add(SL);
            }

            elementsExtracted = SLs.Count();

            return SLs;
        }

        private SL GetSL(XElement ele, Utility.RecordType RecordType, string userId, Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {
            var sl = new SL();

            sl.SlrecordType = RecordType.ToString();


            
            sl.Slinstitute = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SLinstitute"), Utility.CodeType.EDMO);
            sl.SlspeciesListName = Extractor.GetStringValue("SLspeciesListName");
            sl.Slyear = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SLyear"), Utility.CodeType.Year);
            sl.SlcatchFraction = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SLcatchFraction"), Utility.CodeType.CatchFraction);

            sl.SlcommercialTaxon = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SLcommercialTaxon"), Utility.CodeType.SpecWoRMS);
            sl.SlspeciesCode = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SLspeciesCode"), Utility.CodeType.SpecWoRMS);


            sl.Slcountry = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SLcountry"), Utility.CodeType.ISO_3166);


            sl.UserId = userId;
            sl.TimeStamp = DateTime.Now;
            sl.LN = Extractor.GetLineNumber();
            sl.PrimaryKey = 0;

            // delete SL record DB in import module where deletekey value is greater than 0
            sl.DeleteKey = PersistedKeysFinder.GetPersistedKeyValue(ele, "PrimaryKey");

            return sl;
        }
    }
}
