﻿
using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.FT)]
    internal class ExtractFT : ExtractBase
    {
        public ExtractFT()
            : base() { }



        public override object GetData(IEnumerable<XElement> fts, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {



            List<FT> FTs = new List<FT>();

            foreach (var ft in fts)
            {
               var Extractor = new Extractor(ft);
                FT FT = GetFT(ft,RecordType, userId, Extractor, CodeIdFinder, LookupFinder, PersistedKeysFinder);
                FTs.Add(FT);
            }

            elementsExtracted = FTs.Count();

            return FTs;
        }

        private FT GetFT(XElement ele, Utility.RecordType RecordType, string userId, Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {
            var ft = new FT();

            //ft.Osid = null;
            //ft.Vsid = null;
            //ft.Vdid = null;
            //ft.Sdid = null;
            //ft.Foid = null;
            //ft.Teid = null;


            ft.FtrecordType = RecordType.ToString();


            
            ft.FtsequenceNumber = Extractor.GetStringValue("FTsequenceNumber");
            ft.Ftstratification = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FTstratification"), Utility.CodeType.YesNoFields);
            ft.FtstratumName = Extractor.GetStringValue("FTstratumName");
            ft.Ftclustering = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FTclustering"), Utility.CodeType.Clustering);
            ft.FtclusterName = Extractor.GetStringValue("FTclusterName");
            ft.Ftsampler = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FTsampler"), Utility.CodeType.Sampler);
            ft.FtsamplingType = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FTsamplingType"), Utility.CodeType.RS_SamplingType);
            ft.FtnumberOfHaulsOrSets = Extractor.GetIntValueOrNull("FTnumberOfHaulsOrSets");
            ft.FtdepartureLocation = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FTdepartureLocation"), Utility.CodeType.Harbour_LOCODE);
            ft.FtdepartureDate = Extractor.GetDateTimeValueOrNull("FTdepartureDate");
            ft.FtdepartureTime = Extractor.GetDateTimeValueOrNull("FTdepartureTime");
            ft.FtarrivalLocation = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FTarrivalLocation"), Utility.CodeType.Harbour_LOCODE);
            ft.FtarrivalDate = Extractor.GetDateTimeValue("FTarrivalDate");
            ft.FtarrivalTime = Extractor.GetDateTimeValueOrNull("FTarrivalTime");
            ft.FtnumberTotal = Extractor.GetIntValueOrNull("FTnumberTotal");
            ft.FtnumberSampled = Extractor.GetIntValueOrNull("FTnumberSampled");
            ft.FtselectionProb = Extractor.GetDecimalValueOrNull("FTselectionProb");
            ft.FtinclusionProb = Extractor.GetDecimalValueOrNull("FTinclusionProb");
            ft.FtselectionMethod = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FTselectionMethod"), Utility.CodeType.SelectionMethod);
            ft.FtunitName = Extractor.GetStringValue("FTunitName");
            ft.FtselectionMethodCluster = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FTselectionMethodCluster"), Utility.CodeType.SelectionMethod);
            ft.FtnumberTotalClusters = Extractor.GetIntValueOrNull("FTnumberTotalClusters");
            ft.FtnumberSampledClusters = Extractor.GetIntValueOrNull("FTnumberSampledClusters");
            ft.FtselectionProbCluster = Extractor.GetDecimalValueOrNull("FTselectionProbCluster");
            ft.FtinclusionProbCluster = Extractor.GetDecimalValueOrNull("FTinclusionProbCluster");
            ft.Ftsampled = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FTsampled"), Utility.CodeType.YesNoFields);
            ft.FtreasonNotSampled = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FTreasonNotSampled"), Utility.CodeType.ReasonForNotSampling);


            var encriptedVesselCode = Extractor.GetStringValue("FTencryptedVesselCode");
            ft.FtencryptedVesselCode = encriptedVesselCode;

            ft.LN = Extractor.GetLineNumber();
            ft.PLN = Extractor.GetParentLineNumber();
            ft.PrimaryKey = 0;







            #region country
            string countryValue = null;
            var countryMainElement = ele.Ancestors("SD").FirstOrDefault();
            if (countryMainElement != null)
            {

                var countryElement = countryMainElement.Element("SDcountry");
                if (countryElement != null)
                    countryValue = countryElement.Value;
            }

            #endregion

            #region year
            string yearValue = null;
            var yearMainElement = ele.Ancestors("DE").FirstOrDefault();
            if (yearMainElement != null)
            {
                var yearElement = yearMainElement.Element("DEyear");
                if (yearElement != null)
                {
                    yearValue = yearElement.Value;
                }
            }

            #endregion

            // lookup id
           
            ft.Vdid = LookupFinder.GetVDLookupPrimaryKey( encriptedVesselCode,countryValue,yearValue);
            ft.PrimaryKey = 0;
            return ft;
        }


    }
}
