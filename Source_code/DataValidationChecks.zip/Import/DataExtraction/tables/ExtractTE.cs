﻿
using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.TE)]
    internal class ExtractTE : ExtractBase
    {
        public ExtractTE()
            : base() { }



        public override object GetData(IEnumerable<XElement> tes, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<TE> TEs = new List<TE>();
            foreach (var te in tes)
            {
                var Extractor = new Extractor(te);
                TE TE = GetTE(RecordType,Extractor,CodeIdFinder);
                TEs.Add(TE);
            }


            elementsExtracted = TEs.Count();

            return TEs;
        }

        private TE GetTE( Utility.RecordType RecordType, Extractor Extractor, CodeIdFinder CodeIdFinder)
        {
            var te = new TE();

            te.TerecordType = RecordType.ToString();


            te.TesequenceNumber = Extractor.GetIntValue("TEsequenceNumber");
            te.Testratification = CodeIdFinder.GetCodeId(Extractor.GetStringValue("TEstratification"), Utility.CodeType.YesNoFields);
            te.TetimeUnit = CodeIdFinder.GetCodeId(Extractor.GetStringValue("TEtimeUnit"), Utility.CodeType.TimeUnit);
            te.TestratumName = Extractor.GetStringValue("TEstratumName");
            te.Teclustering = CodeIdFinder.GetCodeId(Extractor.GetStringValue("TEclustering"), Utility.CodeType.Clustering);
            te.TeclusterName = Extractor.GetStringValue("TEclusterName");
            te.Tesampler = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("TEsampler"), Utility.CodeType.Sampler);
            te.TenumberTotal = Extractor.GetIntValueOrNull("TEnumberTotal");
            te.TenumberSampled = Extractor.GetIntValueOrNull("TEnumberSampled");
            te.TeselectionProb = Extractor.GetDecimalValueOrNull("TEselectionProb");
            te.TeinclusionProb = Extractor.GetDecimalValueOrNull("TEinclusionProb");
            te.TeselectionMethod = CodeIdFinder.GetCodeId(Extractor.GetStringValue("TEselectionMethod"), Utility.CodeType.SelectionMethod);
            te.TeunitName = Extractor.GetStringValue("TEunitName");
            te.TeselectionMethodCluster = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("TEselectionMethodCluster"), Utility.CodeType.SelectionMethod);
            te.TenumberTotalClusters = Extractor.GetIntValueOrNull("TEnumberTotalClusters");
            te.TenumberSampledClusters = Extractor.GetIntValueOrNull("TEnumberSampledClusters");
            te.TeselectionProbCluster = Extractor.GetDecimalValueOrNull("TEselectionProbCluster");
            te.TeinclusionProbCluster = Extractor.GetDecimalValueOrNull("TEinclusionProbCluster");
            te.Tesampled = CodeIdFinder.GetCodeId(Extractor.GetStringValue("TEsampled"), Utility.CodeType.YesNoFields);
            te.TereasonNotSampled = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("TEreasonNotSampled"), Utility.CodeType.ReasonForNotSampling);


            te.LN = Extractor.GetLineNumber();
            te.PLN = Extractor.GetParentLineNumber();
            te.PrimaryKey = 0;



            return te;
        }
    }
}
