﻿

using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.SS)]
    internal class ExtractSS : ExtractBase
    {
        public ExtractSS()
            : base() { }


        public override object GetData(IEnumerable<XElement> sss, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<SS> SSs = new List<SS>();
            foreach (var ss in sss)
            {
             var   Extractor = new Extractor(ss);
                SS SS = GetSS(ss,RecordType,Extractor,CodeIdFinder,LookupFinder);
                SSs.Add(SS);
            }

            elementsExtracted = SSs.Count();
            return SSs;


        }

        private SS GetSS(XElement ele, Utility.RecordType RecordType,  Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder)
        {
            var ss = new SS();

            ss.SsrecordType = RecordType.ToString();



            ss.SssequenceNumber = Extractor.GetIntValue("SSsequenceNumber");
            ss.Ssstratification = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SSstratification"), Utility.CodeType.YesNoFields);
            ss.SsobservationActivityType = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SSobservationActivityType"), Utility.CodeType.ObservationActivityType);



            ss.SssequenceNumber = Extractor.GetIntValue("SSsequenceNumber");
            ss.Ssstratification = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SSstratification"), Utility.CodeType.YesNoFields);
            ss.SsobservationActivityType = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SSobservationActivityType"), Utility.CodeType.ObservationActivityType);
            ss.SscatchFraction = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SScatchFraction"), Utility.CodeType.CatchFraction);
            ss.SsobservationType = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SSobservationType"), Utility.CodeType.ObservationMethod);
            ss.SsstratumName = Extractor.GetStringValue("SSstratumName");
            ss.Ssclustering = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SSclustering"), Utility.CodeType.Clustering);
            ss.SsclusterName = Extractor.GetStringValue("SSclusterName");
            ss.Sssampler = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SSsampler"), Utility.CodeType.Sampler);            
            ss.SsuseForCalculateZero = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SSuseForCalculateZero"), Utility.CodeType.YesNoFields);
            ss.SsnumberTotal = Extractor.GetIntValueOrNull("SSnumberTotal");
            ss.SsnumberSampled = Extractor.GetIntValueOrNull("SSnumberSampled");
            ss.SsselectionProb = Extractor.GetIntValueOrNull("SSselectionProb");
            ss.SsinclusionProb = Extractor.GetIntValueOrNull("SSinclusionProb");
            ss.SsselectionMethod = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SSselectionMethod"), Utility.CodeType.SelectionMethod);
            ss.SsunitName = Extractor.GetStringValue("SSunitName");
            ss.SsselectionMethodCluster = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SSselectionMethodCluster"), Utility.CodeType.SelectionMethod);
            ss.SsnumberTotalClusters = Extractor.GetIntValueOrNull("SSnumberTotalClusters");
            ss.SsnumberSampledClusters = Extractor.GetIntValueOrNull("SSnumberSampledClusters");
            ss.SsselectionProbCluster = Extractor.GetDecimalValueOrNull("SSselectionProbCluster");
            ss.SsinclusionProbCluster = Extractor.GetDecimalValueOrNull("SSinclusionProbCluster");
            ss.Sssampled = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SSsampled"), Utility.CodeType.YesNoFields);
            ss.SsreasonNotSampled = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SSreasonNotSampled"), Utility.CodeType.ReasonForNotSampling);

            var speciesListName = Extractor.GetStringValue("SSspeciesListName");
            ss.SsspeciesListName = speciesListName;

            var catchFraction = Extractor.GetStringValue("SScatchFraction");

            ss.LN = Extractor.GetLineNumber();
            ss.PLN = Extractor.GetParentLineNumber();
            ss.PrimaryKey = 0;

          

           




            #region country
            string countryValue = null;
            var countryMainElement = ele.Ancestors("SD").FirstOrDefault();
            if (countryMainElement != null)
            {

                var countryElement = countryMainElement.Element("SDcountry");
                if (countryElement != null)
                    countryValue = countryElement.Value;
            }

            #endregion

            #region year
            string yearValue = null;
            var yearMainElement = ele.Ancestors("DE").FirstOrDefault();
            if (yearMainElement != null)
            {
                var yearElement = yearMainElement.Element("DEyear");
                if (yearElement != null)
                {
                    yearValue = yearElement.Value;
                }
            }

            #endregion

            // lookup id            
            ss.Slid = LookupFinder.GetSLLookupPrimaryKey(speciesListName,catchFraction,countryValue,yearValue);


            ss.PrimaryKey = 0;

            return ss;

        }

    }
}
