﻿//using DataExtraction.extract;
using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.CE)]
    class ExtractCE : ExtractBase
    {
        public ExtractCE() : base() { }
        public override object GetData(IEnumerable<XElement> ces, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {


            List<CE> CEs = new List<CE>();
            foreach (var ce in ces)
            {

                var Extractor = new Extractor(ce) ;
                CE CE = GetCE(ce,RecordType, userId, Extractor, CodeIdFinder, LookupFinder, PersistedKeysFinder);
                CEs.Add(CE);
            }

            elementsExtracted = CEs.Count();
            return CEs;
        }

        private CE GetCE(XElement ele, Utility.RecordType RecordType, string userId, Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {
            var ce = new CE();

            ce.CerecordType = RecordType.ToString();


            ce.CedataTypeForScientificEffort = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CEdataTypeForScientificEffort"), Utility.CodeType.DataTypeOfScientificWeight);
            ce.CedataSourceForScientificEffort = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CEdataSourceForScientificEffort"), Utility.CodeType.DataSourceOfScientificWeight);
            ce.CesamplingScheme = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CEsamplingScheme"), Utility.CodeType.SamplingScheme);
            ce.CevesselFlagCountry = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CEvesselFlagCountry"), Utility.CodeType.ISO_3166);
            ce.Ceyear = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CEyear"), Utility.CodeType.Year);
            ce.Cequarter = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CEquarter"), Utility.CodeType.Quarter);
            ce.Cemonth = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CEmonth"), Utility.CodeType.Month);
            ce.Cearea = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CEarea"), Utility.CodeType.ICES_Area);
            ce.CestatisticalRectangle = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CEstatisticalRectangle"), Utility.CodeType.StatRec);
            ce.CegsaSubarea = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CEgsaSubarea"), Utility.CodeType.Areas_GFCM_GSA);
            ce.CejurisdictionArea = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CEjurisdictionArea"), Utility.CodeType.JurisdictionArea);
            ce.CeexclusiveEconomicZoneIndicator = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CEexclusiveEconomicZoneIndicator"), Utility.CodeType.EEZI);
            ce.CenationalFishingActivity = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CEnationalFishingActivity"), Utility.CodeType.NationalFishingActivity);
            ce.Cemetier6 = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CEmetier6"), Utility.CodeType.Metier6_FishingActivity);
            ce.CeincidentalByCatchMitigationDevice = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CEincidentalByCatchMitigationDevice"), Utility.CodeType.BycatchMitigationDevice);
            ce.CelandingLocation = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CElandingLocation"), Utility.CodeType.Harbour_LOCODE);
            ce.CevesselLengthCategory = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CEvesselLengthCategory"), Utility.CodeType.RS_VesselLengthCategory);
            ce.CefishingTechnique = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CEfishingTechnique"), Utility.CodeType.FishingTechnique);
            ce.CedeepSeaRegulation = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CEdeepSeaRegulation"), Utility.CodeType.YesNoFields);
            ce.CenumberOfFractionTrips = Extractor.GetDecimalValue("CEnumberOfFractionTrips");
            ce.CenumberOfDominantTrips = Extractor.GetIntValue("CEnumberOfDominantTrips");
            ce.CeofficialDaysAtSea = Extractor.GetDecimalValue("CEofficialDaysAtSea");
            ce.CescientificDaysAtSea = Extractor.GetDecimalValue("CEscientificDaysAtSea");
            ce.CeofficialFishingDays = Extractor.GetDecimalValue("CEofficialFishingDays");
            ce.CescientificFishingDays = Extractor.GetDecimalValue("CEscientificFishingDays");
            ce.CeofficialNumberOfHaulsOrSets = Extractor.GetIntValueOrNull("CEofficialNumberOfHaulsOrSets");
            ce.CescientificNumberOfHaulsOrSets = Extractor.GetIntValueOrNull("CEscientificNumberOfHaulsOrSets");
            ce.CeofficialVesselFishingHour = Extractor.GetDecimalValueOrNull("CEofficialVesselFishingHour");
            ce.CescientificVesselFishingHour = Extractor.GetDecimalValueOrNull("CEscientificVesselFishingHour");
            ce.CeofficialSoakingMeterHour = Extractor.GetDecimalValueOrNull("CEofficialSoakingMeterHour");
            ce.CescientificSoakingMeterHour = Extractor.GetDecimalValueOrNull("CEscientificSoakingMeterHour");
            ce.CeofficialkWdaysAtSea = Extractor.GetIntValue("CEofficialkWDaysAtSea");
            ce.CescientifickWdaysAtSea = Extractor.GetIntValue("CEscientifickWDaysAtSea");
            ce.CeofficialkWfishingDays = Extractor.GetIntValue("CEofficialkWFishingDays");
            ce.CescientifickWfishingDays = Extractor.GetIntValue("CEscientifickWFishingDays");
            ce.CeofficialkWfishingHours = Extractor.GetIntValueOrNull("CEofficialkWFishingHours");
            ce.CescientifickWfishingHours = Extractor.GetIntValueOrNull("CEscientifickWFishingHours");
            ce.CegTdaysAtSea = Extractor.GetIntValue("CEgTDaysAtSea");
            ce.CegTfishingDays = Extractor.GetIntValue("CEgTFishingDays");
            ce.CegTfishingHours = Extractor.GetLongValueOrNull("CEnumberOfUniqueVessels");
            ce.CenumberOfUniqueVessels = Extractor.GetIntValue("CEnumberOfUniqueVessels");
            ce.CescientificFishingDaysRse = Extractor.GetIntValueOrNull("CEscientificFishingDaysRSE");
            ce.CescientificFishingDaysQualitativeBias = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CEscientificFishingDaysQualitativeBias"), Utility.CodeType.QualitativeBias);


            ce.UserId = userId;
            ce.TimeStamp = DateTime.Now;

            ce.LN = Extractor.GetLineNumber();
            ce.PrimaryKey = 0;

            // delete CE record DB in import module where deletekey value is greater than 0
            ce.DeleteKey = PersistedKeysFinder.GetPersistedKeyValue(ele, "PrimaryKey");

            return ce;
        }

    }
}
