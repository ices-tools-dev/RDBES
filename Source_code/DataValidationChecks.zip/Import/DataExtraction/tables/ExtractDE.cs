﻿
using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using TypeDefinitions.DataImport;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.DE)]
    internal class ExtractDE : ExtractBase
    {

        public ExtractDE() 
            : base()
        {


        }


        public override object GetData(IEnumerable<XElement> des, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<DE> DEs = new List<DE>();
            foreach (var de in des)
            {
              var  Extractor = new Extractor(de);
                DE DE = GetDE(de, userId, RecordType,Extractor, CodeIdFinder, LookupFinder, PersistedKeysFinder);
                DEs.Add(DE);
            }
            elementsExtracted = DEs.Count();
            return DEs;
        }

        private DE GetDE(XElement ele,string UserId, Utility.RecordType RecordType, Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder,PersistedKeysFinder PersistedKeysFinder)
        {
            var de = new DE();

            de.DerecordType = RecordType.ToString();


            de.DesamplingScheme = CodeIdFinder.GetCodeId(Extractor.GetStringValue("DEsamplingScheme"), Utility.CodeType.SamplingScheme);
            de.DesamplingSchemeType = CodeIdFinder.GetCodeId(Extractor.GetStringValue("DEsamplingSchemeType"), Utility.CodeType.SamplingSchemeType);
            de.Deyear = CodeIdFinder.GetCodeId(Extractor.GetStringValue("DEyear"), Utility.CodeType.Year);
            de.DestratumName = Extractor.GetStringValue("DEstratumName");
            de.DehierarchyCorrect = CodeIdFinder.GetCodeId(Extractor.GetStringValue("DEhierarchyCorrect"), Utility.CodeType.YesNoFields);
            de.Dehierarchy = CodeIdFinder.GetCodeId(Extractor.GetStringValue("DEhierarchy"), Utility.CodeType.UpperHierarchy);
            de.Desampled = CodeIdFinder.GetCodeId(Extractor.GetStringValue("DEsampled"), Utility.CodeType.YesNoFields);
            de.DereasonNotSampled = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("DEreasonNotSampled"), Utility.CodeType.ReasonForNotSampling);



            de.UserId = UserId;
            de.TimeStamp = DateTime.Now;
            de.LN = Extractor.GetLineNumber();
            // this applies to all CS hierarchies(h1 to h13)
            // if id value is 0 then entity framework will add entity to db
            // if id value is greater than 0 it means the DE record is in db
            // and also it be added as forigen key value to SD
            // import module only add DE record where primary key value is 0. if not zero then do not add to DB 
            var pk = PersistedKeysFinder.GetPersistedKeyValue(ele, "PrimaryKey");
            de.PrimaryKey = pk;

            // value of Deid will be used as foriegn key value in SD in import module
            de.Deid = pk;
            
            

            return de;
        }
    }
}
