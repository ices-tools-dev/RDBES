﻿using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using DataPersistence;

namespace DataExtraction.extraction
{

    [DataType(Utility.DataType.VS)]
    internal class ExtractVS : ExtractBase
    {
        public ExtractVS() : base()
        {
        }

        public override object GetData(IEnumerable<XElement> vss, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<VS> VSs = new List<VS>();

            foreach (var vs in vss)
            {
               var Extractor = new Extractor(vs);
                VS VS = GetVS(vs,RecordType,userId,Extractor,CodeIdFinder,LookupFinder,PersistedKeysFinder);
                VSs.Add(VS);

            }
            elementsExtracted = VSs.Count();
            return VSs;
        }

        private VS GetVS(XElement ele, Utility.RecordType RecordType, string userId, Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {
            var vs = new VS();


            vs.VsrecordType = RecordType.ToString();




            vs.VssequenceNumber = Extractor.GetIntValue("VSsequenceNumber");
            
            vs.Vsstratification = CodeIdFinder.GetCodeId(Extractor.GetStringValue("VSstratification"), Utility.CodeType.YesNoFields);
            vs.VsstratumName = Extractor.GetStringValue("VSstratumName");
            vs.Vsclustering = CodeIdFinder.GetCodeId(Extractor.GetStringValue("VSclustering"), Utility.CodeType.Clustering);
            vs.VsclusterName = Extractor.GetStringValue("VSclusterName");
            vs.Vssampler = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("VSsampler"), Utility.CodeType.Sampler);
            vs.VsnumberTotal = Extractor.GetIntValueOrNull("VSnumberTotal");
            vs.VsnumberSampled = Extractor.GetIntValueOrNull("VSnumberSampled");
            vs.VsselectionProb = Extractor.GetDecimalValueOrNull("VSselectionProb");
            vs.VsinclusionProb = Extractor.GetDecimalValueOrNull("VSinclusionProb");
            vs.VsselectionMethod = CodeIdFinder.GetCodeId(Extractor.GetStringValue("VSselectionMethod"), Utility.CodeType.SelectionMethod);
            vs.VsunitName = Extractor.GetStringValue("VSunitName");
            vs.VsselectionMethodCluster = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("VSselectionMethodCluster"), Utility.CodeType.SelectionMethod);
            vs.VsnumberTotalClusters = Extractor.GetIntValueOrNull("VSnumberTotalClusters");
            vs.VsnumberSampledClusters = Extractor.GetIntValueOrNull("VSnumberSampledClusters");
            vs.VsselectionProbCluster = Extractor.GetDecimalValueOrNull("VSselectionProbCluster");
            vs.VsinclusionProbCluster = Extractor.GetDecimalValueOrNull("VSinclusionProbCluster");
            vs.Vssampled = CodeIdFinder.GetCodeId(Extractor.GetStringValue("VSsampled"), Utility.CodeType.YesNoFields);
            vs.VsreasonNotSampled = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("VSreasonNotSampled"), Utility.CodeType.ReasonForNotSampling);


            var encryptedVesselCode = Extractor.GetStringValue("VSencryptedVesselCode");
            vs.VsencryptedVesselCode = encryptedVesselCode;




            vs.LN = Extractor.GetLineNumber();
            vs.PLN = Extractor.GetParentLineNumber();
            vs.PrimaryKey = 0;


           




            #region country
            string countryValue = null;
            var countryMainElement = ele.Ancestors("SD").FirstOrDefault();
            if (countryMainElement != null)
            {

                var countryElement = countryMainElement.Element("SDcountry");
                if (countryElement != null)
                    countryValue = countryElement.Value;
            }

            #endregion

            #region year
            string yearValue = null;
            var yearMainElement = ele.Ancestors("DE").FirstOrDefault();
            if (yearMainElement != null)
            {
                var yearElement = yearMainElement.Element("DEyear");
                if (yearElement != null)
                {
                    yearValue = yearElement.Value;
                }
            }

            #endregion

            // look id (VD id)
            vs.Vdid = LookupFinder.GetVDLookupPrimaryKey( encryptedVesselCode,countryValue,yearValue);
            vs.PrimaryKey = 0;
            return vs;
        }
    }
}
