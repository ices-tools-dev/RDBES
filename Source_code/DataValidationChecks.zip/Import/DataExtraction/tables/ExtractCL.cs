﻿using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.CL)]
    internal class ExtractCL : ExtractBase
    {
        public ExtractCL() : base() { }
        public override object GetData(IEnumerable<XElement> cls, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {


            List<CL> CLs = new List<CL>();
            foreach (var cl in cls)
            {

               var Extractor = new Extractor(cl);
                CL CL = GetCL(cl,RecordType,userId,Extractor,CodeIdFinder,LookupFinder,PersistedKeysFinder);
                CLs.Add(CL);
            }

            elementsExtracted = CLs.Count();
            return CLs;
        }

        private CL GetCL(XElement ele, Utility.RecordType RecordType, string userId, Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {
            var cl = new
                CL();

            cl.ClrecordType = RecordType.ToString();


           



            cl.CldataTypeOfScientificWeight = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLdataTypeOfScientificWeight"), Utility.CodeType.DataTypeOfScientificWeight);
            cl.CldataSourceOfScientificWeight = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLdataSourceOfScientificWeight"), Utility.CodeType.DataSourceOfScientificWeight);
            cl.ClsamplingScheme = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLsamplingScheme"), Utility.CodeType.SamplingScheme);
            cl.CldataSourceLandingsValue = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLdataSourceLandingsValue"), Utility.CodeType.DataSourceLandingsValue);
            cl.CllandingCountry = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLlandingCountry"), Utility.CodeType.ISO_3166);
            cl.ClvesselFlagCountry = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLvesselFlagCountry"), Utility.CodeType.ISO_3166);
            cl.Clyear = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLyear"), Utility.CodeType.Year);
            cl.Clquarter = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLquarter"), Utility.CodeType.Quarter);
            cl.Clmonth = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLmonth"), Utility.CodeType.Month);
            cl.Clarea = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLarea"), Utility.CodeType.ICES_Area);
            cl.ClstatisticalRectangle = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLstatisticalRectangle"), Utility.CodeType.StatRec);
            cl.ClgsaSubarea = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLgsaSubarea"), Utility.CodeType.Areas_GFCM_GSA);
            cl.CljurisdictionArea = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLjurisdictionArea"), Utility.CodeType.JurisdictionArea);
            cl.ClexclusiveEconomicZoneIndicator = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLexclusiveEconomicZoneIndicator"), Utility.CodeType.EEZI);
            cl.ClspeciesCode = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLspeciesCode"), Utility.CodeType.SpecWoRMS);
            cl.ClspeciesFaoCode = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLspeciesFaoCode"), Utility.CodeType.SpecASFIS);
            cl.CllandingCategory = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLlandingCategory"), Utility.CodeType.LandingCategory);
            cl.ClcatchCategory = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLcatchCategory"), Utility.CodeType.CatchCategory);
            
            cl.ClregDisCategory = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLregDisCategory"), Utility.CodeType.RegDisCategory);

            cl.ClcommercialSizeCategoryScale = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLcommercialSizeCategoryScale"), Utility.CodeType.CommercialSizeCategoryScale);
            cl.ClcommercialSizeCategory = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLcommercialSizeCategory"), Utility.CodeType.CommercialSizeCategory);
            cl.ClnationalFishingActivity = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLnationalFishingActivity"), Utility.CodeType.NationalFishingActivity);
            cl.Clmetier6 = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLmetier6"), Utility.CodeType.Metier6_FishingActivity);
            cl.ClincidentialByCatchMitigationDevice = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLincidentialByCatchMitigationDevice"), Utility.CodeType.BycatchMitigationDevice);
            cl.CllandingLocation = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLlandingLocation"), Utility.CodeType.Harbour_LOCODE);
            cl.ClvesselLengthCategory = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLvesselLengthCategory"), Utility.CodeType.RS_VesselLengthCategory);
            cl.ClfishingTechnique = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLfishingTechnique"), Utility.CodeType.FishingTechnique);
            cl.CldeepSeaRegulation = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLdeepSeaRegulation"), Utility.CodeType.YesNoFields);
            cl.ClofficialWeight = Extractor.GetIntValue("CLofficialWeight");
            cl.ClscientificWeight = Extractor.GetIntValue("CLscientificWeight");
            cl.ClexplainDifference = CodeIdFinder.GetCodeId(Extractor.GetStringValue("CLexplainDifference"), Utility.CodeType.DifferenceReason);
            cl.CltotalOfficialLandingsValue = Extractor.GetIntValue("CLtotalOfficialLandingsValue");
            cl.ClnumberOfUniqueVessels = Extractor.GetIntValue("CLnumberOfUniqueVessels");
            cl.ClscientificWeightRse = Extractor.GetIntValueOrNull("CLscientificWeightRSE");
            cl.ClvalueRse = Extractor.GetIntValueOrNull("CLvalueRSE");
            cl.ClscientificWeightQualitativeBias = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("CLscientificWeightQualitativeBias"), Utility.CodeType.QualitativeBias);




            cl.UserId = userId;
            cl.TimeStamp = DateTime.Now;

            cl.LN = Extractor.GetLineNumber();
            cl.PrimaryKey = 0;
            // delete CL record DB in import module where deletekey value is greater than 0
            cl.DeleteKey = PersistedKeysFinder.GetPersistedKeyValue(ele, "PrimaryKey");
            return cl;
        }
    }
}
