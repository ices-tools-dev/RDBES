﻿

using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.FM)]
    internal class ExtractFM : ExtractBase
    {
        public ExtractFM() 
            : base() { }


        public override object GetData(IEnumerable<XElement> fms, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<FM> FMs = new List<FM>();

            foreach (var fm in fms)
            {

              var  Extractor = new Extractor(fm);
                FM FM = GetFM(RecordType,Extractor,CodeIdFinder,LookupFinder);
                FMs.Add(FM);
            }

            elementsExtracted = FMs.Count();

            return FMs;
        }

        private FM GetFM( Utility.RecordType RecordType, Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder)
        {
            var fm = new FM();

            fm.FmrecordType = RecordType.ToString();



            fm.FmstateOfProcessing = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FMstateOfProcessing"), Utility.CodeType.StateOfProcessing);
            fm.Fmpresentation = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FMpresentation"), Utility.CodeType.ProductPresentation);
            fm.FmclassMeasured = Extractor.GetIntValue("FMclassMeasured");
            fm.FmnumberAtUnit = Extractor.GetIntValue("FMnumberAtUnit");
            fm.FmtypeMeasured = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FMtypeMeasured"), Utility.CodeType.BiologicalMeasurementType);
            fm.Fmmethod = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FMmethod"), Utility.CodeType.SampleType);
            fm.FmmeasurementEquipment = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FMmeasurementEquipment"), Utility.CodeType.METOA);
            fm.Fmaccuracy = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FMaccuracy"), Utility.CodeType.AccuracyCode);
            fm.FmconversionFactorAssessment = Extractor.GetDecimalValue("FMconversionFactorAssessment");
            fm.FmtypeAssessment = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FMtypeAssessment"), Utility.CodeType.BiologicalMeasurementType);
            fm.Fmsampler = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FMsampler"), Utility.CodeType.Sampler);
            fm.FmaddGrpMeasurement = Extractor.GetDecimalValueOrNull("FMaddGrpMeasurement");
            fm.FmaddGrpMeasurementType = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FMaddGrpMeasurementType"), Utility.CodeType.BiologicalMeasurementType);

            fm.LN = Extractor.GetLineNumber();
            fm.PLN = Extractor.GetParentLineNumber();
            fm.PrimaryKey = 0;


           

            return fm;

        }

    }
}
