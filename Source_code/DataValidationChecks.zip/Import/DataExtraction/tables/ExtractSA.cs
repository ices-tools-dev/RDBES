﻿
using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.SA)]
    internal class ExtractSA : ExtractBase
    {

        public ExtractSA()
            : base() { }




        public override object GetData(IEnumerable<XElement> sas, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<SA> SAs = new List<SA>();

            foreach (var sa in sas)
            {


                var Extractor = new Extractor(sa);
                SA SA = GetSA(RecordType,Extractor,CodeIdFinder);
                SAs.Add(SA);

            }
            elementsExtracted = SAs.Count();
            return SAs;
        }

        private SA GetSA( Utility.RecordType RecordType, Extractor Extractor, CodeIdFinder CodeIdFinder)
        {
            var sa = new
              SA();
            
            sa.SarecordType = RecordType.ToString();

            sa.SasequenceNumber = Extractor.GetIntValue("SAsequenceNumber");
            sa.SaparentSequenceNumber = Extractor.GetIntValueOrNull("SAparentSequenceNumber");
            sa.Sastratification = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SAstratification"), Utility.CodeType.YesNoFields);
            sa.SastratumName = Extractor.GetStringValue("SAstratumName");
            sa.SaspeciesCode = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SAspeciesCode"), Utility.CodeType.SpecWoRMS);
            sa.SaspeciesCodeFao = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAspeciesCodeFAO"), Utility.CodeType.SpecASFIS);
            sa.SastateOfProcessing = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SAstateOfProcessing"), Utility.CodeType.StateOfProcessing);
            sa.Sapresentation = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SApresentation"), Utility.CodeType.ProductPresentation);
            sa.SaspecimensState = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SAspecimensState"), Utility.CodeType.SpecimensState);
            sa.SacatchCategory = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SAcatchCategory"), Utility.CodeType.CatchCategory);
            sa.SalandingCategory = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAlandingCategory"), Utility.CodeType.LandingCategory);
            sa.SacommSizeCatScale = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAcommSizeCatScale"), Utility.CodeType.CommercialSizeCategoryScale);
            sa.SacommSizeCat = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAcommSizeCat"), Utility.CodeType.CommercialSizeCategory);
            sa.Sasex = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SAsex"), Utility.CodeType.SEXCO);
            sa.SaexclusiveEconomicZoneIndicator = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAexclusiveEconomicZoneIndicator"), Utility.CodeType.EEZI);
            sa.Saarea = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAarea"), Utility.CodeType.ICES_Area);
            sa.Sarectangle = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SArectangle"), Utility.CodeType.StatRec);
            sa.SagsaSubarea = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValue("SAgsaSubarea"), Utility.CodeType.Areas_GFCM_GSA);
            sa.SajurisdictionArea = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAjurisdictionArea"), Utility.CodeType.JurisdictionArea);
            sa.SanationalFishingActivity = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAnationalFishingActivity"), Utility.CodeType.NationalFishingActivity);
            sa.Sametier5 = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAmetier5"), Utility.CodeType.Metier5_FishingActivity);
            sa.Sametier6 = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAmetier6"), Utility.CodeType.Metier6_FishingActivity);
            sa.Sagear = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAgear"), Utility.CodeType.GearType);
            sa.SameshSize = Extractor.GetIntValueOrNull("SAmeshSize");
            sa.SaselectionDevice = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAselectionDevice"), Utility.CodeType.SelectionDevice);
            sa.SaselectionDeviceMeshSize = Extractor.GetIntValueOrNull("SAselectionDeviceMeshSize");
            sa.SaunitType = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SAunitType"), Utility.CodeType.SamplingUnit);
            sa.SatotalWeightLive = Extractor.GetLongValueOrNull("SAtotalWeightLive");
            sa.SasampleWeightLive = Extractor.GetIntValueOrNull("SAsampleWeightLive");
            sa.SanumberTotal = Extractor.GetDecimalValueOrNull("SAnumberTotal");
            sa.SanumberSampled = Extractor.GetDecimalValueOrNull("SAnumberSampled");
            sa.SaselectionProb = Extractor.GetDecimalValueOrNull("SAselectionProb");
            sa.SainclusionProb = Extractor.GetDecimalValueOrNull("SAinclusionProb");
            sa.SaselectionMethod = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SAselectionMethod"), Utility.CodeType.SelectionMethod);
            sa.SaunitName = Extractor.GetStringValue("SAunitName");
            sa.SalowerHierarchy = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SAlowerHierarchy"), Utility.CodeType.LowerHierarchy);
            sa.Sasampler = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAsampler"), Utility.CodeType.Sampler);
            sa.Sasampled = CodeIdFinder.GetCodeId(Extractor.GetStringValue("SAsampled"), Utility.CodeType.YesNoFields);
            sa.SareasonNotSampledFm = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAreasonNotSampledFM"), Utility.CodeType.ReasonForNotSampling);
            sa.SareasonNotSampledBv = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("SAreasonNotSampledBV"), Utility.CodeType.ReasonForNotSampling);
            sa.SatotalWeightMeasured = Extractor.GetLongValueOrNull("SAtotalWeightMeasured");
            sa.SasampleWeightMeasured = Extractor.GetLongValueOrNull("SAsampleWeightMeasured");
            sa.SaconversionFactorMeasLive = Extractor.GetDecimalValueOrNull("SAconversionFactorMeasLive");



            sa.LN = Extractor.GetLineNumber();
            sa.PLN = Extractor.GetParentLineNumber();
            sa.PrimaryKey = 0;


           

            return sa;
        }
    }
}
