﻿


using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.FO)]
    internal class ExtractFO : ExtractBase
    {
        public ExtractFO()
            : base() { }


        public override object GetData(IEnumerable<XElement> fos, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<FO> FOs = new List<FO>();

            foreach (var fo in fos)
            {

              var  Extractor = new Extractor(fo);
                FO FO = GetFO(RecordType,Extractor,CodeIdFinder);
                FOs.Add(FO);
            }

            elementsExtracted = FOs.Count();

            return FOs;
        }

        private FO GetFO(Utility.RecordType RecordType, Extractor Extractor, CodeIdFinder CodeIdFinder)
        {
            var fo = new
                             FO();

            fo.ForecordType = RecordType.ToString();


            fo.Fostratification = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOstratification"), Utility.CodeType.YesNoFields);
            fo.FosequenceNumber = Extractor.GetIntValue("FOsequenceNumber");
            fo.FostratumName = Extractor.GetStringValue("FOstratumName");
            fo.Foclustering = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOclustering"), Utility.CodeType.Clustering);
            fo.FoclusterName = Extractor.GetStringValue("FOclusterName");
            fo.Fosampler = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOsampler"), Utility.CodeType.Sampler);
            fo.FoaggregationLevel = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOaggregationLevel"), Utility.CodeType.AggregationLevel);
            fo.Fovalidity = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOvalidity"), Utility.CodeType.ValidityFlag);
            fo.FocatchReg = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOcatchReg"), Utility.CodeType.CatchRegistration);
            fo.FostartDate = Extractor.GetDateTimeValueOrNull("FOstartDate");
            fo.FostartTime = Extractor.GetDateTimeValueOrNull("FOstartTime");
            fo.FoendDate = Extractor.GetDateTimeValue("FOendDate");
            fo.FoendTime = Extractor.GetDateTimeValueOrNull("FOendTime");
            fo.Foduration = Extractor.GetIntValueOrNull("FOduration");
            fo.FodurationSource = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOdurationSource"), Utility.CodeType.DurationSource);
            fo.FohandlingTime = Extractor.GetIntValueOrNull("FOhandlingTime");
            fo.FostartLat = Extractor.GetDecimalValueOrNull("FOstartLat");
            fo.FostartLon = Extractor.GetDecimalValueOrNull("FOstartLon");
            fo.FostopLat = Extractor.GetDecimalValueOrNull("FOstopLat");
            fo.FostopLon = Extractor.GetDecimalValueOrNull("FOstopLon");
            fo.FoexclusiveEconomicZoneIndicator = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOexclusiveEconomicZoneIndicator"), Utility.CodeType.EEZI);
            fo.Foarea = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOarea"), Utility.CodeType.ICES_Area);
            fo.Forectangle = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOrectangle"), Utility.CodeType.StatRec);
            fo.FogsaSubarea = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOgsaSubarea"), Utility.CodeType.Areas_GFCM_GSA);
            fo.FojurisdictionArea = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOjurisdictionArea"), Utility.CodeType.JurisdictionArea);
            fo.FofishingDepth = Extractor.GetIntValueOrNull("FOfishingDepth");
            fo.FowaterDepth = Extractor.GetIntValueOrNull("FOwaterDepth");
            fo.FonationalFishingActivity = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOnationalFishingActivity"), Utility.CodeType.NationalFishingActivity);
            fo.Fometier5 = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOmetier5"), Utility.CodeType.Metier5_FishingActivity);
            fo.Fometier6 = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOmetier6"), Utility.CodeType.Metier6_FishingActivity);
            fo.Fogear = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOgear"), Utility.CodeType.GearType);
            fo.FomeshSize = Extractor.GetIntValueOrNull("FOmeshSize");
            fo.FoselectionDevice = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOselectionDevice"), Utility.CodeType.SelectionDevice);
            fo.FoselectionDeviceMeshSize = Extractor.GetIntValueOrNull("FOselectionDeviceMeshSize");
            fo.FotargetSpecies = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOtargetSpecies"), Utility.CodeType.TargetSpecies);
            fo.FoincidentalByCatchMitigationDeviceFirst = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOincidentalByCatchMitigationDeviceFirst"), Utility.CodeType.BycatchMitigationDevice);
            fo.FoincidentalByCatchMitigationDeviceTargetFirst = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOincidentalByCatchMitigationDeviceTargetFirst"), Utility.CodeType.BycatchMitigationDeviceTarget);
            fo.FoincidentalByCatchMitigationDeviceSecond = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOincidentalByCatchMitigationDeviceSecond"), Utility.CodeType.BycatchMitigationDevice);
            fo.FoincidentalByCatchMitigationDeviceTargetSecond = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOincidentalByCatchMitigationDeviceTargetSecond"), Utility.CodeType.BycatchMitigationDeviceTarget);
            fo.FogearDimensions = Extractor.GetIntValueOrNull("FOgearDimensions");
            fo.FoobservationCode = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOobservationCode"), Utility.CodeType.ObservationCode);
            fo.FonumberTotal = Extractor.GetIntValueOrNull("FOnumberTotal");
            fo.FonumberSampled = Extractor.GetIntValueOrNull("FOnumberSampled");
            fo.FoselectionProb = Extractor.GetDecimalValueOrNull("FOselectionProb");
            fo.FoinclusionProb = Extractor.GetDecimalValueOrNull("FOinclusionProb");
            fo.FoselectionMethod = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOselectionMethod"), Utility.CodeType.SelectionMethod);
            fo.FounitName = Extractor.GetStringValue("FOunitName");
            fo.FoselectionMethodCluster = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOselectionMethodCluster"), Utility.CodeType.SelectionMethod);
            fo.FonumberTotalClusters = Extractor.GetIntValueOrNull("FOnumberTotalClusters");
            fo.FonumberSampledClusters = Extractor.GetIntValueOrNull("FOnumberSampledClusters");
            fo.FoselectionProbCluster = Extractor.GetDecimalValueOrNull("FOselectionProbCluster");
            fo.FoinclusionProbCluster = Extractor.GetDecimalValueOrNull("FOinclusionProbCluster");
            fo.Fosampled = CodeIdFinder.GetCodeId(Extractor.GetStringValue("FOsampled"), Utility.CodeType.YesNoFields);
            fo.ForeasonNotSampled = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("FOreasonNotSampled"), Utility.CodeType.ReasonForNotSampling);



            fo.LN = Extractor.GetLineNumber();
            fo.PLN = Extractor.GetParentLineNumber();
            fo.PrimaryKey = 0;



            





            return fo;
        }


    }
}
