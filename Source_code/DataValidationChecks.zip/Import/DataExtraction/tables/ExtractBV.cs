﻿using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.BV)]
    internal class ExtractBV : ExtractBase
    {
        public ExtractBV() : base() { }



        public override object GetData(IEnumerable<XElement> bvs, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {


            List<BV> BVs = new List<BV>();
            foreach (var bv in bvs)
            {

              var  Extractor = new Extractor(bv);
                BV BV = GetBV(RecordType,Extractor,CodeIdFinder,LookupFinder,PersistedKeysFinder);
                BVs.Add(BV);
            }

            elementsExtracted = BVs.Count();
            return BVs;
        }

        private BV GetBV( Utility.RecordType RecordType,  Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            var bv = new BV();





            bv.BvrecordType = RecordType.ToString();



            bv.BvnationalUniqueFishId = Extractor.GetStringValue("BVnationalUniqueFishId");
            bv.BVstateOfProcessing = CodeIdFinder.GetCodeId(Extractor.GetStringValue("BVstateOfProcessing"), Utility.CodeType.StateOfProcessing);
            bv.Bvpresentation = CodeIdFinder.GetCodeId(Extractor.GetStringValue("BVpresentation"), Utility.CodeType.ProductPresentation);
            bv.Bvstratification = CodeIdFinder.GetCodeId(Extractor.GetStringValue("BVstratification"), Utility.CodeType.YesNoFields);
            bv.BvstratumName = Extractor.GetStringValue("BVstratumName");
            bv.BvtypeMeasured = CodeIdFinder.GetCodeId(Extractor.GetStringValue("BVtypeMeasured"), Utility.CodeType.BiologicalMeasurementType);
            bv.BvvalueMeasured = Extractor.GetStringValue("BVvalueMeasured");
            bv.BvvalueUnitOrScale = CodeIdFinder.GetCodeId(Extractor.GetStringValue("BVvalueUnitOrScale"), Utility.CodeType.ValueUnitOrScale);
            bv.Bvmethod = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("BVmethod"), Utility.CodeType.SampleType);
            bv.BvmeasurementEquipment = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("BVmeasurementEquipment"), Utility.CodeType.METOA);
            bv.Bvaccuracy = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("BVaccuracy"), Utility.CodeType.AccuracyCode);
            bv.BvcertaintyQualitative = CodeIdFinder.GetCodeId(Extractor.GetStringValue("BVcertaintyQualitative"), Utility.CodeType.MeasurementCertainty);
            bv.BvcertaintyQuantitative = Extractor.GetDecimalValueOrNull("BVcertaintyQuantitative");
            bv.BvconversionFactorAssessment = Extractor.GetDecimalValue("BVconversionFactorAssessment");
            bv.BvtypeAssessment = CodeIdFinder.GetCodeId(Extractor.GetStringValue("BVtypeAssessment"), Utility.CodeType.BiologicalMeasurementType);
            bv.BvnumberTotal = Extractor.GetIntValueOrNull("BVnumberTotal");
            bv.BvnumberSampled = Extractor.GetIntValueOrNull("BVnumberSampled");
            bv.BvselectionProb = Extractor.GetDecimalValueOrNull("BVselectionProb");
            bv.BvinclusionProb = Extractor.GetDecimalValueOrNull("BVinclusionProb");
            bv.BvselectionMethod = CodeIdFinder.GetCodeId(Extractor.GetStringValue("BVselectionMethod"), Utility.CodeType.SelectionMethod);
            bv.BvunitName = Extractor.GetStringValue("BVunitName");
            bv.Bvsampler = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("BVsampler"), Utility.CodeType.Sampler);


            bv.LN = Extractor.GetLineNumber();
            bv.PLN = Extractor.GetParentLineNumber();
            bv.PrimaryKey = 0;


           
           

            return bv;
        }
    }
}
