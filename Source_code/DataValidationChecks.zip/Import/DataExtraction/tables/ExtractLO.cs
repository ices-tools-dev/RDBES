﻿using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using DataPersistence;

namespace DataExtraction.extraction

{
    [DataType(Utility.DataType.LO)]
    internal class ExtractLO : ExtractBase
    {
        public ExtractLO()
            : base() { }


        public override object GetData(IEnumerable<XElement> los, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<LO> LOs = new List<LO>();

            foreach (var lo in los)
            {
                var Extractor = new Extractor(lo);
                LO LO = GetLO(RecordType,Extractor,CodeIdFinder);
                LOs.Add(LO);
            }
            elementsExtracted = LOs.Count();
            return LOs;
        }

        private LO GetLO( Utility.RecordType RecordType, Extractor Extractor, CodeIdFinder CodeIdFinder )
        {
            var lo = new
                LO();


            lo.LorecordType = RecordType.ToString();

            lo.LosequenceNumber = Extractor.GetIntValue("LOsequenceNumber");
            lo.Lostratification = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LOstratification"), Utility.CodeType.YesNoFields);
            lo.Lolocode = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LOlocode"), Utility.CodeType.Harbour_LOCODE);
            lo.LolocationName = Extractor.GetStringValue("LOlocationName");
            lo.LolocationType = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LOlocationType"), Utility.CodeType.LocationType);
            lo.LostratumName = Extractor.GetStringValue("LOstratumName");
            lo.Loclustering = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LOclustering"), Utility.CodeType.Clustering);
            lo.LoclusterName = Extractor.GetStringValue("LOclusterName");
            lo.Losampler = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LOsampler"), Utility.CodeType.Sampler);
            lo.LonumberTotal = Extractor.GetIntValueOrNull("LOnumberTotal");
            lo.LonumberSampled = Extractor.GetIntValueOrNull("LOnumberSampled");
            lo.LoselectionProb = Extractor.GetDecimalValueOrNull("LOselectionProb");
            lo.LoinclusionProb = Extractor.GetDecimalValueOrNull("LOinclusionProb");
            lo.LoselectionMethod = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LOselectionMethod"), Utility.CodeType.SelectionMethod);
            lo.LounitName = Extractor.GetStringValue("LOunitName");
            lo.LoselectionMethodCluster = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LOselectionMethodCluster"), Utility.CodeType.SelectionMethod);
            lo.LonumberTotalClusters = Extractor.GetIntValueOrNull("LOnumberTotalClusters");
            lo.LonumberSampledClusters = Extractor.GetIntValueOrNull("LOnumberSampledClusters");
            lo.LoselectionProbCluster = Extractor.GetDecimalValueOrNull("LOselectionProbCluster");
            lo.LoinclusionProbCluster = Extractor.GetDecimalValueOrNull("LOinclusionProbCluster");
            lo.Losampled = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LOsampled"), Utility.CodeType.YesNoFields);
            lo.LoreasonNotSampled = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LOreasonNotSampled"), Utility.CodeType.ReasonForNotSampling);


            lo.LN = Extractor.GetLineNumber();
            lo.PLN = Extractor.GetParentLineNumber();
            lo.PrimaryKey = 0;


         


            return lo;
        }
    }
}
