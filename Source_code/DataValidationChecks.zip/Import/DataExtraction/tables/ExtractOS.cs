﻿
using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.OS)]
    internal class ExtractOS : ExtractBase
    {
        public ExtractOS()
            : base() { }


        public override object GetData(IEnumerable<XElement> oss, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<OS> OSs = new List<OS>();
            foreach (var os in oss)
            {

               var Extractor = new Extractor(os);
                OS OS = GetOS(RecordType,Extractor,CodeIdFinder);
                OSs.Add(OS);

            }
            elementsExtracted = OSs.Count();
            return OSs;
        }

        private OS GetOS( Utility.RecordType RecordType, Extractor Extractor, CodeIdFinder CodeIdFinder)
        {
            var os = new
                OS();




            os.OsrecordType = RecordType.ToString();


            os.OssequenceNumber = Extractor.GetIntValue("OSsequenceNumber");
            os.Osstratification = CodeIdFinder.GetCodeId(Extractor.GetStringValue("OSstratification"), Utility.CodeType.YesNoFields);
            os.Oslocode = CodeIdFinder.GetCodeId(Extractor.GetStringValue("OSlocode"), Utility.CodeType.Harbour_LOCODE);
            os.OslocationName = Extractor.GetStringValue("OSlocationName");
            os.OslocationType = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("OSlocationType"), Utility.CodeType.LocationType);
            os.OssamplingDate = Extractor.GetDateTimeValue("OSsamplingDate");
            os.OssamplingTime = Extractor.GetDateTimeValueOrNull("OSsamplingTime");
            os.OsstratumName = Extractor.GetStringValue("OSstratumName");
            os.Osclustering = CodeIdFinder.GetCodeId(Extractor.GetStringValue("OSclustering"), Utility.CodeType.Clustering);
            os.OsclusterName = Extractor.GetStringValue("OSclusterName");
            os.Ossampler = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("OSsampler"), Utility.CodeType.Sampler);
            os.OstimeUnit = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("OStimeUnit"), Utility.CodeType.TimeUnit);
            os.OstimeValue = Extractor.GetDecimalValueOrNull("OStimeValue");
            os.OsnumberTotal = Extractor.GetIntValueOrNull("OSnumberTotal");
            os.OsnumberSampled = Extractor.GetIntValueOrNull("OSnumberSampled");
            os.OsselectionProb = Extractor.GetDecimalValueOrNull("OSselectionProb");
            os.OsinclusionProb = Extractor.GetDecimalValueOrNull("OSinclusionProb");
            os.OsselectionMethod = CodeIdFinder.GetCodeId(Extractor.GetStringValue("OSselectionMethod"), Utility.CodeType.SelectionMethod);
            os.OsunitName = Extractor.GetStringValue("OSunitName");
            os.OsselectionMethodCluster = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("OSselectionMethodCluster"), Utility.CodeType.SelectionMethod);
            os.OsnumberTotalClusters = Extractor.GetIntValueOrNull("OSnumberTotalClusters");
            os.OsnumberSampledClusters = Extractor.GetIntValueOrNull("OSnumberSampledClusters");
            os.OsselectionProbCluster = Extractor.GetDecimalValueOrNull("OSselectionProbCluster");
            os.OsinclusionProbCluster = Extractor.GetDecimalValueOrNull("OSinclusionProbCluster");
            os.Ossampled = CodeIdFinder.GetCodeId(Extractor.GetStringValue("OSsampled"), Utility.CodeType.YesNoFields);
            os.OsreasonNotSampled = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("OSreasonNotSampled"), Utility.CodeType.ReasonForNotSampling);


            os.LN = Extractor.GetLineNumber();
            os.PLN = Extractor.GetParentLineNumber();
            os.PrimaryKey = 0;


       



            return os;
        }

    }
}
