﻿using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.VD)]
    internal class ExtractVD : ExtractBase
    {
        public ExtractVD() 
            : base()
        {
        }

        public override object GetData(IEnumerable<XElement> vds, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {

            List<VD> VDs = new List<VD>();

            foreach (var vd in vds)
            {
               var Extractor = new Extractor(vd);
                VD VD = GetVD(vd,RecordType,userId,Extractor,CodeIdFinder,LookupFinder,PersistedKeysFinder);
                VDs.Add(VD);
            }


            elementsExtracted = VDs.Count();
            return VDs;
        }

        private VD GetVD(XElement ele, Utility.RecordType RecordType, string userId, Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {
            var vd = new VD();


            vd.VdrecordType = RecordType.ToString();


            vd.VdencryptedVesselCode = Extractor.GetStringValue("VDencryptedVesselCode");
            vd.Vdyear = CodeIdFinder.GetCodeId(Extractor.GetStringValue("VDyear"), Utility.CodeType.Year);
            vd.VdhomePort = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("VDhomePort"), Utility.CodeType.Harbour_LOCODE);
            vd.VdflagCountry = CodeIdFinder.GetCodeId(Extractor.GetStringValue("VDflagCountry"), Utility.CodeType.ISO_3166);
            vd.Vdlength = Extractor.GetDecimalValueOrNull("VDlength");
            vd.VdlengthCategory = CodeIdFinder.GetCodeId(Extractor.GetStringValue("VDlengthCategory"), Utility.CodeType.RS_VesselLengthCategory);
            vd.Vdpower = Extractor.GetIntValueOrNull("VDpower");
            vd.Vdtonnage = Extractor.GetIntValueOrNull("VDtonnage");
            vd.VdtonUnit = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("VDtonUnit"), Utility.CodeType.VesselSizeUnit);




            vd.Vdcountry = CodeIdFinder.GetCodeId(Extractor.GetStringValue("VDcountry"), Utility.CodeType.ISO_3166);



            vd.UserId = userId;
            vd.TimeStamp = DateTime.Now;
            vd.LN = Extractor.GetLineNumber();
            vd.PrimaryKey = 0;
            // delete CL record DB in import module where deletekey value is greater than 0
            vd.DeleteKey = PersistedKeysFinder.GetPersistedKeyValue(ele, "PrimaryKey");


            return vd;
        }





    }
}
