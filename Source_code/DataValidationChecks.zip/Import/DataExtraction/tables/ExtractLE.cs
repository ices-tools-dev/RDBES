﻿using DataExtraction.mapping;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using TypeDefinitions.DataImport;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using DataPersistence;

namespace DataExtraction.extraction
{
    [DataType(Utility.DataType.LE)]
    internal class ExtractLE : ExtractBase
    {
        public ExtractLE()
            : base() { }



        public override object GetData(IEnumerable<XElement> les, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {


            List<LE> LEs = new List<LE>();
            foreach (var le in les)
            {


              var  Extractor = new Extractor(le);
                LE LE = GetLE(le,RecordType, userId, Extractor, CodeIdFinder, LookupFinder, PersistedKeysFinder);
                LEs.Add(LE);
            }
            elementsExtracted = LEs.Count();

            return LEs;
        }

        private LE GetLE(XElement ele, Utility.RecordType RecordType, string userId, Extractor Extractor, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {
            var le = new
           LE();

            le.LerecordType = RecordType.ToString();


           
            le.Lestratification = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LEstratification"), Utility.CodeType.YesNoFields);
            le.LesequenceNumber = Extractor.GetIntValue("LEsequenceNumber");
            le.LehaulNumber = Extractor.GetIntValueOrNull("LEhaulNumber");
            le.LestratumName = Extractor.GetStringValue("LEstratumName");
            le.Leclustering = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LEclustering"), Utility.CodeType.Clustering);
            le.LeclusterName = Extractor.GetStringValue("LEclusterName");
            le.Lesampler = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LEsampler"), Utility.CodeType.Sampler);
            le.LemixedTrip = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LEmixedTrip"), Utility.CodeType.YesNoFields);
            le.LecatchReg = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LEcatchReg"), Utility.CodeType.CatchRegistration);
            le.Lelocode = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LElocode"), Utility.CodeType.Harbour_LOCODE);
            le.LelocationName = Extractor.GetStringValue("LElocationName");
            le.LelocationType = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LElocationType"), Utility.CodeType.LocationType);
            le.Lecountry = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LEcountry"), Utility.CodeType.ISO_3166);
            le.Ledate = Extractor.GetDateTimeValueOrNull("LEdate");
            le.Letime = Extractor.GetDateTimeValueOrNull("LEtime");
            le.LeexclusiveEconomicZoneIndicator = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LEexclusiveEconomicZoneIndicator"), Utility.CodeType.EEZI);
            le.Learea = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LEarea"), Utility.CodeType.ICES_Area);
            le.Lerectangle = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LErectangle"), Utility.CodeType.StatRec);
            le.LegsaSubarea = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LEgsaSubarea"), Utility.CodeType.Areas_GFCM_GSA);
            le.LejurisdictionArea = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LEjurisdictionArea"), Utility.CodeType.JurisdictionArea);
            le.LenationalFishingActivity = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LEnationalFishingActivity"), Utility.CodeType.NationalFishingActivity);
            le.Lemetier5 = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LEmetier5"), Utility.CodeType.Metier5_FishingActivity);
            le.Lemetier6 = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LEmetier6"), Utility.CodeType.Metier6_FishingActivity);
            le.Legear = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LEgear"), Utility.CodeType.GearType);
            le.LemeshSize = Extractor.GetIntValueOrNull("LEmeshSize");
            le.LeselectionDevice = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LEselectionDevice"), Utility.CodeType.SelectionDevice);
            le.LeselectionDeviceMeshSize = Extractor.GetIntValueOrNull("LEselectionDeviceMeshSize");
            le.LetargetSpecies = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LEtargetSpecies"), Utility.CodeType.TargetSpecies);
            le.LemitigationDevice = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LEmitigationDevice"), Utility.CodeType.BycatchMitigationDevice);
            le.LegearDimensions = Extractor.GetIntValueOrNull("LEgearDimensions");
            le.LenumberTotal = Extractor.GetIntValueOrNull("LEnumberTotal");
            le.LenumberSampled = Extractor.GetIntValueOrNull("LEnumberSampled");
            le.LeselectionProb = Extractor.GetDecimalValueOrNull("LEselectionProb");
            le.LeinclusionProb = Extractor.GetDecimalValueOrNull("LEinclusionProb");
            le.LeselectionMethod = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LEselectionMethod"), Utility.CodeType.SelectionMethod);
            le.LeunitName = Extractor.GetStringValue("LEunitName");
            le.LeselectionMethodCluster = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LEselectionMethodCluster"), Utility.CodeType.SelectionMethod);
            le.LenumberTotalClusters = Extractor.GetIntValueOrNull("LEnumberTotalClusters");
            le.LenumberSampledClusters = Extractor.GetIntValueOrNull("LEnumberSampledClusters");
            le.LeselectionProbCluster = Extractor.GetDecimalValueOrNull("LEselectionProbCluster");
            le.LeinclusionProbCluster = Extractor.GetDecimalValueOrNull("LEinclusionProbCluster");
            le.Lesampled = CodeIdFinder.GetCodeId(Extractor.GetStringValue("LEsampled"), Utility.CodeType.YesNoFields);
            le.LereasonNotSampled = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LEreasonNotSampled"), Utility.CodeType.ReasonForNotSampling);
            le.LefullTripAvailable = CodeIdFinder.GetCodeIdOrNull(Extractor.GetStringValueOrNull("LEfullTripAvailable"), Utility.CodeType.RS_LEfullTripAvailable);




            
            var encryptedVesselCode = Extractor.GetStringValue("LEencryptedVesselCode");
            le.LeencryptedVesselCode = encryptedVesselCode;

            

            le.LN = Extractor.GetLineNumber();
            le.PLN = Extractor.GetParentLineNumber();
            le.PrimaryKey = 0;

           
         



            #region country
            string countryValue = null;
            var countryMainElement = ele.Ancestors("SD").FirstOrDefault();
            if (countryMainElement != null)
            {

                var countryElement = countryMainElement.Element("SDcountry");
                if (countryElement != null)
                    countryValue = countryElement.Value;
            }

            #endregion

            #region year
            string yearValue=null;
            var yearMainElement = ele.Ancestors("DE").FirstOrDefault();
            if (yearMainElement != null)            
            {
                var yearElement = yearMainElement.Element("DEyear");
                if (yearElement != null)
                {
                    yearValue = yearElement.Value;
                }
            }

            #endregion

            //look id
            if (string.IsNullOrWhiteSpace(encryptedVesselCode))
            {
                le.Vdid = null;
            }
            else
            {
                le.Vdid = LookupFinder.GetVDLookupPrimaryKey(encryptedVesselCode, countryValue, yearValue);
            }
            le.PrimaryKey = 0;
            return le;
        }
    }
}
