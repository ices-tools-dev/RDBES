﻿using DataExtraction.mapping;
using DataPersistence;
using ResCommon;
using ResData.Models.KeyLessEntities;
using ResData.Models.CacheData;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace DataExtraction.extraction
{
    public abstract class ExtractBase : IExtractEntity
    {

        //  protected XDocument XmlData { get; set; }        
        //protected string UserId { get; set; }
        //protected int dataUploadCountryId { get; set; }

        //protected Utility.RecordType RecordType;
        //protected string Path;
        //protected CodeIdFinder CodeIdFinder { get; set; }
        //protected LookupFinder LookupFinder { get; set; }
        //protected XMLRecordFinder XmlRecordFinder { get; set; }
        //protected PersistedKeysFinder PersistedKeysFinder { get; set; }


        //protected XMLExtractor XmlExtractor;


        //protected   Dictionary<Utility.CodeType, Dictionary<string,int>> CodesByTypeDic;
        //private Dictionary<string,int> GetCodesByType(Utility.CodeType codeType, List<CodeWithType> allCodes)
        //{
        //    var codeTypeName = Utility.GetCodeTypeNameAsInDB(codeType);// get code type name from dictionary
        //    var codes = allCodes.Where(c => c.Type.Equals(codeTypeName))
        //        .GroupBy(g => g.Code.Trim()).Select(s => s.FirstOrDefault())
        //        //.Distinct()
        //        .ToDictionary(x => x.Code.Trim(), x => x.Id)
        //        ;

        //    if (codes.Count() <= 0)
        //        throw new Exception(string.Format($"No codes found in for ' {codeType.ToString()} ' type"));

        //    return codes;
        //}


        //protected ExtractBase(string path,string userId,int dataUploadCountryId, List<CodeWithType> cachedCodes, List<CodeLookup> codeLookups)
        //{

        //    CodesByTypeDic = new Dictionary<Utility.CodeType, Dictionary<string,int>>();
        //    foreach (Utility.CodeType codeType in Enum.GetValues(typeof(Utility.CodeType)))
        //    {
        //        CodesByTypeDic.Add(codeType, GetCodesByType(codeType,cachedCodes));
        //    }


        //    this.Path = path;            

        //    this.UserId = userId;

        //    this.dataUploadCountryId = dataUploadCountryId;

        //    this.XmlExtractor = new XMLExtractor();

        //    this.CodeIdFinder = new CodeIdFinder(cachedCodes);

        //    this.XmlRecordFinder = new XMLRecordFinder(XDocument.Load(path));         

        //    this.LookupFinder = new LookupFinder(codeLookups);

        //    this.PersistedKeysFinder = new PersistedKeysFinder();
        //}

        //protected Extractor Extractor;
        protected int xmlElementsFound = 0;
        protected int elementsExtracted = 0;
        protected CultureInfo InvariantCulture = CultureInfo.InvariantCulture;// new CultureInfo("en-US");

        protected ExtractBase() { }


        public abstract object GetData(IEnumerable<XElement> elements, Utility.RecordType RecordType, string userId, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder);



        public object GetTableData(Utility.RecordType RecordType, string userId, XMLRecordFinder XMLRecordFinder, CodeIdFinder CodeIdFinder, LookupFinder LookupFinder, PersistedKeysFinder PersistedKeysFinder)
        {
          

            IEnumerable<XElement> xmlElements;
            xmlElements= XMLRecordFinder.GetEntityElements(RecordType);
            xmlElementsFound = xmlElements.Count();
            var entitiyElements = this.GetData(xmlElements,RecordType,userId,CodeIdFinder,LookupFinder,PersistedKeysFinder);

            if (xmlElementsFound != elementsExtracted) throw new Exception(this.GetType().Name + " extracted elements do not match with found elements:xml elements found:" + xmlElementsFound.ToString() + ". extracted element count:" + elementsExtracted.ToString());

            return entitiyElements;
        }


        
       
        
        //private object ExtractDataUsingXmlReader()
        //{
            

        //    List<object> Rows = new List<object>();

        //    List<List<string>> data = new List<List<string>>();

        //    using (XmlReader reader = XmlReader.Create(this.Path))
        //    {
        //        reader.MoveToContent();

        //        while (reader.Read())
        //        {
        //            if (reader.NodeType == XmlNodeType.Element)
        //            {
        //                string pln = reader.GetAttribute("ln");
        //                while (reader.ReadToFollowing(this.RecordType.ToString()))
        //                {
        //                    string ln = reader.GetAttribute("ln");

        //                    var cl = new List<string>();
        //                    cl.Add(ln);

        //                    SetRowData(reader.ReadSubtree(), ref cl);
        //                    data.Add(cl);

        //                }
        //            }
        //        }


        //    }

            

            

        //    elementsExtracted = Rows.Count();
        //    return Rows;


        //}

        //void SetRowData(XmlReader reader, ref List<string> data)
        //{


        //    while (reader.Read())
        //    {
        //        if (reader.NodeType == XmlNodeType.Text)
        //        {
        //            data.Add(reader.ReadContentAsString());
        //        }
        //    }

        //}



    }
}
