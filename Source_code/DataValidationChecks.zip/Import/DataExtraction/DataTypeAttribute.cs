﻿using ResCommon;
using System;

namespace DataExtraction.extraction
{

    public class DataTypeAttribute : Attribute
    {
        public Utility.DataType DataType { get; set; }

        public DataTypeAttribute(Utility.DataType type)
        {
            DataType = type;
        }

    }
}
