﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace DataPersistence.Base
{
    public abstract class PersistBase : IPersistHierarchy
    {
        protected XDocument XmlData;
        protected Utility.DataType DataType;
      //  protected Type CastType;


        public PersistBase(string xmlPath, Utility.DataType dataType)
        {
            this.XmlData = XDocument.Load(xmlPath);
            this.DataType = dataType;
          //  this.CastType = castType;
        }
        protected abstract void WriteData(object data);

        public void PersistData(string newXmlPath, object data)
        {

            WriteData(data);
            this.XmlData.Save(newXmlPath);
            this.XmlData = null;

        }
    }
}
