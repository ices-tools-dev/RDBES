﻿//using DataOverwriteChecker;
using ResCommon;
using System.Collections.Generic;
using System.Xml.Linq;


namespace DataPersistence.Base
{
    public interface IPersistHierarchy
    {
        void PersistData(string newXmlPath, object data);
        
    }
}