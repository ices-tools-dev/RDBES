﻿//using DataOverwriteChecker;
using ResCommon;
using System.Collections.Generic;
using System.Xml.Linq;
//using Xml2DB_DAL;

namespace DataPersistence
{
    public interface IPersistedKeysFinder
    {
       
       int GetPersistedKeyValue(XElement ele,string attribute);
    }
}