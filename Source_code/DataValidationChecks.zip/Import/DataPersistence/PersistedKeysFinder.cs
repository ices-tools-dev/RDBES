﻿//using DataOverwriteChecker;
using ResCommon;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;


namespace DataPersistence
{
    public class PersistedKeysFinder: IPersistedKeysFinder
    {
        
        public PersistedKeysFinder() {  }

        public int GetPersistedKeyValue(XElement ele,string attribute)
        {
            try
            {

                if (ele.Attribute(attribute) == null) return 0;
                return Convert.ToInt32(ele.Attribute(attribute).Value);


            }
            catch (Exception)
            {

                throw;
            }

        }
      
        
    }
}
