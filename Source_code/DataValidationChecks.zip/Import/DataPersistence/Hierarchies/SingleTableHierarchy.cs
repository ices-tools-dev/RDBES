﻿
using DataPersistence.Base;
using DataPersistence.Client;
using ResCommon;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;



namespace DataPersistence.Hierarchies
{
    internal class SingleTableHierarchy : PersistBase
    {
        public SingleTableHierarchy(string path, Utility.DataType dataType) : base(path,dataType) { }
        //protected override void WriteData( dynamic data)
        //{
        //   // List<SingleTablePersistentKyesInfo> duplicateInfos = data as List<SingleTablePersistentKyesInfo>;
        //    var elements = from e in this.XmlData.Descendants(DataType.ToString())
        //                   select e;
        //    foreach (var item in data)
        //    {
               
        //        var element = elements.Where(e => e.Attribute("ln").Value.Equals(item.LineNo.ToString())).FirstOrDefault();
        //        if (element == null) throw new Exception("No XML element found for the line number" + item.LineNo.ToString());

        //        element.Add(new XAttribute("PrimaryKey", item.PrimayKeyId));


        //    }

            




        //}


        protected override void WriteData(object data)
        {
            // List<SingleTablePersistentKyesInfo> duplicateInfos = data as List<SingleTablePersistentKyesInfo>;
            var elements = from e in this.XmlData.Descendants(DataType.ToString())
                           select e;


            var pkDictionary = new Dictionary<string, string>();

            var pkInfoData = data as List<SingleTablePersistentKyesInfo>;
            foreach (var item in pkInfoData)
            {

                pkDictionary.Add(item.LineNo, item.PrimayKeyId);

            }

            

            foreach (var element in elements)
            {

                var ln = element.Attribute("ln").Value;
                
                if (pkDictionary.ContainsKey(ln))
                {
                    var id = pkDictionary[ln];
                    element.Add(new XAttribute("PrimaryKey", id));
                }

            }



        }

    }
}
