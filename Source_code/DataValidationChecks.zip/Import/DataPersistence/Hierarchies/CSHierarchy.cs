﻿//using DataOverwriteChecker;
using DataPersistence.Base;
using DataPersistence.Client;
using ResCommon;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
//using Xml2DB_DAL;


namespace DataPersistence.Hierarchies
{
    internal class CSHierarchy :  PersistBase
    {
        public CSHierarchy(string path, Utility.DataType dataType) : base(path,dataType) { }
        //protected override void WriteData( dynamic data)
        //{
        //   // List<CSPersistentKyesInfo> duplicateInfos = data as List<CSPersistentKyesInfo>;

        //    var elements = from e in this.XmlData.Descendants(DataType.ToString())
        //                   select e;

        //    foreach (var item in data)
        //    {

        //        var element = elements.Where(e => e.Attribute("ln").Value.Equals(item.LineNo.ToString())).FirstOrDefault();
        //        if (element == null) throw new Exception("No XML element found for the line number" + item.LineNo.ToString());


        //        var sdPrimarykeyAttribute = element.Attributes("PrimaryKey").FirstOrDefault();
        //        if(sdPrimarykeyAttribute==null)
        //        element.Add(new XAttribute("PrimaryKey", item.SDid));


        //        var dePrimarykeyAttribute = element.Parent.Attributes("PrimaryKey").FirstOrDefault();
        //        if (dePrimarykeyAttribute == null)
        //            element.Parent.Add(new XAttribute("PrimaryKey", item.DEid));
        //        else dePrimarykeyAttribute.Value = item.DEid.ToString();



        //    }




        //}

        protected override void WriteData(object data)
        {
            // List<CSPersistentKyesInfo> duplicateInfos = data as List<CSPersistentKyesInfo>;

            var pkDictionary = new Dictionary<string, CSPersistentKyesInfo>();

            var pkInfoData = data as List<CSPersistentKyesInfo>;
            foreach (var item in pkInfoData)
            {

                pkDictionary.Add(item.LineNo, item);

            }


            var elements = from e in this.XmlData.Descendants(DataType.ToString())
                           select e;

            foreach (var element in elements)
            {

                var ln = element.Attribute("ln").Value;

                if (pkDictionary.ContainsKey(ln))
                {
                    var persistenKeyInfo = pkDictionary[ln];
                    var sdPrimarykeyAttribute = element.Attributes("PrimaryKey").FirstOrDefault();
                    if (sdPrimarykeyAttribute == null)
                        element.Add(new XAttribute("PrimaryKey", persistenKeyInfo.SDid));


                    var dePrimarykeyAttribute = element.Parent.Attributes("PrimaryKey").FirstOrDefault();
                    if (dePrimarykeyAttribute == null)
                        element.Parent.Add(new XAttribute("PrimaryKey", persistenKeyInfo.DEid));
                    else dePrimarykeyAttribute.Value = persistenKeyInfo.DEid.ToString();

                }

            }




        }
    }
}
