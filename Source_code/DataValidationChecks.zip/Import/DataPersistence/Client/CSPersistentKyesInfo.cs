﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataPersistence.Client
{
   public class CSPersistentKyesInfo
    {
		
		public string DEid { get; set; }
		public string SDid { get; set; }
		public string LineNo { get; set; }

	}
}
