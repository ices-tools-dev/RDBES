﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataPersistence.Client
{
   public class SingleTablePersistentKyesInfo
    {
        public string PrimayKeyId { get; set; }
        public string LineNo { get; set; }
    }
}
