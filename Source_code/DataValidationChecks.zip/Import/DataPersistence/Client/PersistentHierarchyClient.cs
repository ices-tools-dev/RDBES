﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;
using DataPersistence.Hierarchies;
using DataPersistence.Base;

namespace DataPersistence.Client
{
    public static class PersistentHierarchyClient
    {
       public static PersistBase GetHierarchy(Utility.HierarchyBaseDataType baseDataType,string xmlPath) {

            if (Utility.HierarchyBaseDataType.CS == baseDataType)
                return new CSHierarchy(xmlPath, Utility.DataType.SD);

            else if (Utility.HierarchyBaseDataType.CL == baseDataType )
            {
               
                return new SingleTableHierarchy(xmlPath, Utility.DataType.CL);
            }
            else if (Utility.HierarchyBaseDataType.CE == baseDataType)
            {

                return new SingleTableHierarchy(xmlPath, Utility.DataType.CE);
            }
            else if (Utility.HierarchyBaseDataType.SL == baseDataType)
            {

                return new SingleTableHierarchy(xmlPath, Utility.DataType.SL);
            }
            else if (Utility.HierarchyBaseDataType.VD == baseDataType)
            {

                return new SingleTableHierarchy(xmlPath, Utility.DataType.VD);
            }
            else

                throw new Exception("No Class found that persist data for overwritting ");
        }
        

    }
}
