﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Xml2DB_DAL.CustomModels
{
	public class TableInfo
	{
		public string TableName { get; set; }
		public string IDColumnName { get; set; }

		public string IdWithTablePrefix
		{
			get { return $"{TableName}.{IDColumnName}"; }
		}
	}
}
 
