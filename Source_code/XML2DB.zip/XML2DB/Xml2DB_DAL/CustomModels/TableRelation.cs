﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Xml2DB_DAL.CustomModels
{
	public class TableRelation
	{
		public TableInfo Info = new TableInfo();
		public TableRelation Parent { get; protected set; }
		public TableRelation Child { get; protected set; }

		public string GetSql()
		{
			StringBuilder sbResult = new StringBuilder();
			if (Parent == null)
			{
				sbResult.Append($"{Info.TableName} ");
			}
			if (Child != null)
			{
				sbResult.AppendLine($"INNER JOIN {Child.Info.TableName} ON {Info.IdWithTablePrefix} = {Child.Info.TableName}.{Info.IDColumnName} ");
				sbResult.Append(Child.GetSql());
			}
			return sbResult.ToString();
		}

		public void SetParent(TableRelation parent)
		{
			this.Parent = parent;
			parent.Child = this;
		}
	}
}

/*
Design INNER JOIN SamplingDetails ON Design.DEid=SamplingDetails.DEid
INNER JOIN VesselDetails ON VesselDetails.SDid=SamplingDetails.SDid
INNER JOIN VesselSelection ON VesselDetails.VDid=VesselSelection.VDid
	 */
