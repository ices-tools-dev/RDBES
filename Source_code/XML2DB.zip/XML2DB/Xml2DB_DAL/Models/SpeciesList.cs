﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class SpeciesList : BaseModel, IModelWithUserIdAndTimeStamp
    {
        public SpeciesList()
        {
            SpeciesSelections = new HashSet<SpeciesSelection>();
        }

        public int Slid { get; set; }
        public string UserId { get; set; }
        public DateTime TimeStamp { get; set; }
        public string SlrecordType { get; set; }
        public int Slcountry { get; set; }
        public int Slinstitute { get; set; }
        public string SlspeciesListName { get; set; }
        public int Slyear { get; set; }
        public int SlcatchFraction { get; set; }
        public int SlcommercialTaxon { get; set; }
        public int SlspeciesCode { get; set; }

        public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
    }
}
