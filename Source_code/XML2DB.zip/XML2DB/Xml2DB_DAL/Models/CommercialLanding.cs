﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class CommercialLanding : BaseModel, IModelWithUserIdAndTimeStamp
    {
        public int Clid { get; set; }
        public string UserId { get; set; }
        public DateTime TimeStamp { get; set; }
        public string ClrecordType { get; set; }
        public int CldataTypeOfScientificWeight { get; set; }
        public int CldataSourceOfScientificWeight { get; set; }
        public int? ClsamplingScheme { get; set; }
        public int CldataSourceLandingsValue { get; set; }
        public int CllandingCountry { get; set; }
        public int ClvesselFlagCountry { get; set; }
        public int Clyear { get; set; }
        public int Clquarter { get; set; }
        public int? Clmonth { get; set; }
        public int Clarea { get; set; }
        public int ClstatisticalRectangle { get; set; }
        public int ClgsaSubarea { get; set; }
        public int? CljurisdictionArea { get; set; }
        public int ClexclusiveEconomicZoneIndicator { get; set; }
        public int ClspeciesCode { get; set; }
        public int? ClspeciesFaoCode { get; set; }
        public int CllandingCategory { get; set; }
        public int ClcatchCategory { get; set; }
        public int? ClregDisCategory { get; set; }
        public int? ClcommercialSizeCategoryScale { get; set; }
        public int? ClcommercialSizeCategory { get; set; }
        public int? ClnationalFishingActivity { get; set; }
        public int Clmetier6 { get; set; }
        public int ClincidentialByCatchMitigationDevice { get; set; }
        public int CllandingLocation { get; set; }
        public int ClvesselLengthCategory { get; set; }
        public int? ClfishingTechnique { get; set; }
        public int? CldeepSeaRegulation { get; set; }
        public int ClofficialWeight { get; set; }
        public int ClscientificWeight { get; set; }
        public int ClexplainDifference { get; set; }
        public int CltotalOfficialLandingsValue { get; set; }
        public int ClnumberOfUniqueVessels { get; set; }
        public int? ClscientificWeightRse { get; set; }
        public int? ClvalueRse { get; set; }
        public int? ClscientificWeightQualitativeBias { get; set; }
    }
}
