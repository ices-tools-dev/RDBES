﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class CommercialEffort: BaseModel, IModelWithUserIdAndTimeStamp
    {
        public int Ceid { get; set; }
        public string UserId { get; set; }
        public DateTime TimeStamp { get; set; }
        public string CerecordType { get; set; }
        public int CedataTypeForScientificEffort { get; set; }
        public int CedataSourceForScientificEffort { get; set; }
        public int? CesamplingScheme { get; set; }
        public int CevesselFlagCountry { get; set; }
        public int Ceyear { get; set; }
        public int Cequarter { get; set; }
        public int? Cemonth { get; set; }
        public int Cearea { get; set; }
        public int CestatisticalRectangle { get; set; }
        public int CegsaSubarea { get; set; }
        public int? CejurisdictionArea { get; set; }
        public int? CeexclusiveEconomicZoneIndicator { get; set; }
        public int? CenationalFishingActivity { get; set; }
        public int Cemetier6 { get; set; }
        public int CeincidentalByCatchMitigationDevice { get; set; }
        public int CelandingLocation { get; set; }
        public int CevesselLengthCategory { get; set; }
        public int? CefishingTechnique { get; set; }
        public int? CedeepSeaRegulation { get; set; }
        public decimal CenumberOfFractionTrips { get; set; }
        public int CenumberOfDominantTrips { get; set; }
        public decimal CeofficialDaysAtSea { get; set; }
        public decimal CescientificDaysAtSea { get; set; }
        public decimal CeofficialFishingDays { get; set; }
        public decimal CescientificFishingDays { get; set; }
        public int? CeofficialNumberOfHaulsOrSets { get; set; }
        public int? CescientificNumberOfHaulsOrSets { get; set; }
        public decimal? CeofficialVesselFishingHour { get; set; }
        public decimal? CescientificVesselFishingHour { get; set; }
        public decimal? CeofficialSoakingMeterHour { get; set; }
        public decimal? CescientificSoakingMeterHour { get; set; }
        public int CeofficialkWdaysAtSea { get; set; }
        public int CescientifickWdaysAtSea { get; set; }
        public int CeofficialkWfishingDays { get; set; }
        public int CescientifickWfishingDays { get; set; }
        public int? CeofficialkWfishingHours { get; set; }
        public int? CescientifickWfishingHours { get; set; }
        public int CegTdaysAtSea { get; set; }
        public int CegTfishingDays { get; set; }
        public long? CegTfishingHours { get; set; }
        public int CenumberOfUniqueVessels { get; set; }
        public int? CescientificFishingDaysRse { get; set; }
        public int? CescientificFishingDaysQualitativeBias { get; set; }
    }
}
