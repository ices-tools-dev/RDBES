﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class FishingOperation: BaseModel
    {
        public FishingOperation()
        {
            FishingTrips = new HashSet<FishingTrip>();
            LandingEvents = new HashSet<LandingEvent>();
            SpeciesSelections = new HashSet<SpeciesSelection>();
        }

        public int Foid { get; set; }
        public int? Ftid { get; set; }
        public int? Sdid { get; set; }
        public string ForecordType { get; set; }
        public int Fostratification { get; set; }
        public int FosequenceNumber { get; set; }
        public string FostratumName { get; set; }
        public int Foclustering { get; set; }
        public string FoclusterName { get; set; }
        public int? Fosampler { get; set; }
        public int FoaggregationLevel { get; set; }
        public int Fovalidity { get; set; }
        public int FocatchReg { get; set; }
        public DateTime? FostartDate { get; set; }
        public DateTime? FostartTime { get; set; }
        public DateTime FoendDate { get; set; }
        public DateTime? FoendTime { get; set; }
        public int? Foduration { get; set; }
        public int FodurationSource { get; set; }
        public int? FohandlingTime { get; set; }
        public decimal? FostartLat { get; set; }
        public decimal? FostartLon { get; set; }
        public decimal? FostopLat { get; set; }
        public decimal? FostopLon { get; set; }
        public int? FoexclusiveEconomicZoneIndicator { get; set; }
        public int Foarea { get; set; }
        public int? Forectangle { get; set; }
        public int? FogsaSubarea { get; set; }
        public int? FojurisdictionArea { get; set; }
        public int? FofishingDepth { get; set; }
        public int? FowaterDepth { get; set; }
        public int? FonationalFishingActivity { get; set; }
        public int? Fometier5 { get; set; }
        public int? Fometier6 { get; set; }
        public int Fogear { get; set; }
        public int? FomeshSize { get; set; }
        public int? FoselectionDevice { get; set; }
        public int? FoselectionDeviceMeshSize { get; set; }
        public int? FotargetSpecies { get; set; }
        public int FoincidentalByCatchMitigationDeviceFirst { get; set; }
        public int FoincidentalByCatchMitigationDeviceTargetFirst { get; set; }
        public int FoincidentalByCatchMitigationDeviceSecond { get; set; }
        public int FoincidentalByCatchMitigationDeviceTargetSecond { get; set; }
        public int? FogearDimensions { get; set; }
        public int FoobservationCode { get; set; }
        public int? FonumberTotal { get; set; }
        public decimal? FonumberSampled { get; set; }
        public decimal? FoselectionProb { get; set; }
        public decimal? FoinclusionProb { get; set; }
        public int FoselectionMethod { get; set; }
        public string FounitName { get; set; }
        public int? FoselectionMethodCluster { get; set; }
        public int? FonumberTotalClusters { get; set; }
        public int? FonumberSampledClusters { get; set; }
        public decimal? FoselectionProbCluster { get; set; }
        public decimal? FoinclusionProbCluster { get; set; }
        public int Fosampled { get; set; }
        public int? ForeasonNotSampled { get; set; }

        public virtual FishingTrip Ft { get; set; }
        public virtual SamplingDetail Sd { get; set; }
        public virtual ICollection<FishingTrip> FishingTrips { get; set; }
        public virtual ICollection<LandingEvent> LandingEvents { get; set; }
        public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
    }
}
