﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class TblCode
    {
        public TblCode()
        {
            TblCodeRelTblCodeManies = new HashSet<TblCodeRel>();
            TblCodeRelTblCodeOnes = new HashSet<TblCodeRel>();
        }

        public int TblCodeId { get; set; }
        public int TblCodeTypeId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string User { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public bool? Visibility { get; set; }
        public bool Deprecated { get; set; }
        public string LongDescription { get; set; }

        public virtual TblCodeType TblCodeType { get; set; }
        public virtual ICollection<TblCodeRel> TblCodeRelTblCodeManies { get; set; }
        public virtual ICollection<TblCodeRel> TblCodeRelTblCodeOnes { get; set; }
    }
}
