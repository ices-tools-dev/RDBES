﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class Design: BaseModel, IModelWithUserIdAndTimeStamp
    {
        public Design()
        {
            SamplingDetails = new HashSet<SamplingDetail>();
        }

        public int Deid { get; set; }
        public string UserId { get; set; }
        public DateTime TimeStamp { get; set; }
        public string DerecordType { get; set; }
        public int DesamplingScheme { get; set; }
        public int DesamplingSchemeType { get; set; }
        public int Deyear { get; set; }
        public string DestratumName { get; set; }
        public int DehierarchyCorrect { get; set; }
        public int Dehierarchy { get; set; }
        public int Desampled { get; set; }
        public int? DereasonNotSampled { get; set; }

        public virtual ICollection<SamplingDetail> SamplingDetails { get; set; }
    }
}
