﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class Location: BaseModel
    {
        public Location()
        {
            TemporalEvents = new HashSet<TemporalEvent>();
        }

        public int Loid { get; set; }
        public int Sdid { get; set; }
        public string LorecordType { get; set; }
        public int LosequenceNumber { get; set; }
        public int Lostratification { get; set; }
        public int Lolocode { get; set; }
        public string LolocationName { get; set; }
        public int? LolocationType { get; set; }
        public string LostratumName { get; set; }
        public int Loclustering { get; set; }
        public string LoclusterName { get; set; }
        public int? Losampler { get; set; }
        public int? LonumberTotal { get; set; }
        public int? LonumberSampled { get; set; }
        public decimal? LoselectionProb { get; set; }
        public decimal? LoinclusionProb { get; set; }
        public int LoselectionMethod { get; set; }
        public string LounitName { get; set; }
        public int? LoselectionMethodCluster { get; set; }
        public int? LonumberTotalClusters { get; set; }
        public int? LonumberSampledClusters { get; set; }
        public decimal? LoselectionProbCluster { get; set; }
        public decimal? LoinclusionProbCluster { get; set; }
        public int Losampled { get; set; }
        public int? LoreasonNotSampled { get; set; }

        public virtual SamplingDetail Sd { get; set; }
        public virtual ICollection<TemporalEvent> TemporalEvents { get; set; }
    }
}
