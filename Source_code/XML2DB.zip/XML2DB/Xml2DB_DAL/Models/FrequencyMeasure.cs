﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class FrequencyMeasure : BaseModel
    {
        public FrequencyMeasure()
        {
            BiologicalVariables = new HashSet<BiologicalVariable>();
        }

        public int Fmid { get; set; }
        public int Said { get; set; }
        public string FmrecordType { get; set; }
        public int FmstateOfProcessing { get; set; }
        public int Fmpresentation { get; set; }
        public int FmclassMeasured { get; set; }
        public int FmnumberAtUnit { get; set; }
        public int FmtypeMeasured { get; set; }
        public int? Fmmethod { get; set; }
        public int? FmmeasurementEquipment { get; set; }
        public int? Fmaccuracy { get; set; }
        public decimal FmconversionFactorAssessment { get; set; }
        public int FmtypeAssessment { get; set; }
        public int? Fmsampler { get; set; }
        public decimal? FmaddGrpMeasurement { get; set; }
        public int? FmaddGrpMeasurementType { get; set; }

        public virtual Sample Sa { get; set; }
        public virtual ICollection<BiologicalVariable> BiologicalVariables { get; set; }
    }
}
