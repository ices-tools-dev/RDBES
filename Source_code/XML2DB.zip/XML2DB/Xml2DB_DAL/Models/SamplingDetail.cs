﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class SamplingDetail : BaseModel, IModelWithUserIdAndTimeStamp
    {
        public SamplingDetail()
        {
            FishingOperations = new HashSet<FishingOperation>();
            FishingTrips = new HashSet<FishingTrip>();
            Locations = new HashSet<Location>();
            OnshoreEvents = new HashSet<OnshoreEvent>();
            TemporalEvents = new HashSet<TemporalEvent>();
            VesselSelections = new HashSet<VesselSelection>();
        }

        public int Sdid { get; set; }
        public int? Deid { get; set; }
        public string UserId { get; set; }
        public DateTime TimeStamp { get; set; }
        public string SdrecordType { get; set; }
        public int Sdcountry { get; set; }
        public int Sdinstitution { get; set; }

        public virtual Design De { get; set; }
        public virtual ICollection<FishingOperation> FishingOperations { get; set; }
        public virtual ICollection<FishingTrip> FishingTrips { get; set; }
        public virtual ICollection<Location> Locations { get; set; }
        public virtual ICollection<OnshoreEvent> OnshoreEvents { get; set; }
        public virtual ICollection<TemporalEvent> TemporalEvents { get; set; }
        public virtual ICollection<VesselSelection> VesselSelections { get; set; }
    }
}
