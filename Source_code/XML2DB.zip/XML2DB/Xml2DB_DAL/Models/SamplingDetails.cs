﻿using System;
using System.Collections.Generic;

namespace Xml2DB_DAL.Models
{
    public partial class SamplingDetails : BaseModel, IModelWithUserIdAndTimeStamp
    {
        public SamplingDetails()
        {
            FishingOperation = new HashSet<FishingOperation>();
            FishingTrip = new HashSet<FishingTrip>();
            Location = new HashSet<Location>();
            OnshoreEvent = new HashSet<OnshoreEvent>();
            TemporalEvent = new HashSet<TemporalEvent>();
            VesselSelection = new HashSet<VesselSelection>();
        }

        public int Sdid { get; set; }
        public int? Deid { get; set; }
        public string UserId { get; set; }
        public DateTime TimeStamp { get; set; }
        public string SdrecordType { get; set; }
        public int Sdcountry { get; set; }
        public int Sdinstitution { get; set; }

        public virtual Design De { get; set; }
        public virtual ICollection<FishingOperation> FishingOperation { get; set; }
        public virtual ICollection<FishingTrip> FishingTrip { get; set; }
        public virtual ICollection<Location> Location { get; set; }
        public virtual ICollection<OnshoreEvent> OnshoreEvent { get; set; }
        public virtual ICollection<TemporalEvent> TemporalEvent { get; set; }
        public virtual ICollection<VesselSelection> VesselSelection { get; set; }
    }
}
