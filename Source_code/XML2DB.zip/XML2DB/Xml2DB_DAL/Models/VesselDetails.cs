﻿using System;
using System.Collections.Generic;

namespace Xml2DB_DAL.Models
{
    public partial class VesselDetails : BaseModel, IModelWithUserIdAndTimeStamp
    {
        public VesselDetails()
        {
            FishingTrip = new HashSet<FishingTrip>();
            LandingEvent = new HashSet<LandingEvent>();
            VesselSelection = new HashSet<VesselSelection>();
        }

        public int Vdid { get; set; }
        public string UserId { get; set; }
        public DateTime TimeStamp { get; set; }
        public string VdrecordType { get; set; }
        public string VdencryptedVesselCode { get; set; }
        public int Vdyear { get; set; }
        public int Vdcountry { get; set; }
        public int? VdhomePort { get; set; }
        public int VdflagCountry { get; set; }
        public decimal? Vdlength { get; set; }
        public int VdlengthCategory { get; set; }
        public int? Vdpower { get; set; }
        public int? Vdtonnage { get; set; }
        public int? VdtonUnit { get; set; }

        public virtual ICollection<FishingTrip> FishingTrip { get; set; }
        public virtual ICollection<LandingEvent> LandingEvent { get; set; }
        public virtual ICollection<VesselSelection> VesselSelection { get; set; }
    }
}
