﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class LandingEvent: BaseModel
    {
        public LandingEvent()
        {
            Samples = new HashSet<Sample>();
            SpeciesSelections = new HashSet<SpeciesSelection>();
        }

        public int Leid { get; set; }
        public int? Osid { get; set; }
        public int? Ftid { get; set; }
        public int? Vsid { get; set; }
        public int? Teid { get; set; }
        public int? Said { get; set; }
        public int? Vdid { get; set; }
        public int? Foid { get; set; }
        public int? Ssid { get; set; }
        public string LerecordType { get; set; }
        public string LeencryptedVesselCode { get; set; }
        public int Lestratification { get; set; }
        public int LesequenceNumber { get; set; }
        public int? LehaulNumber { get; set; }
        public string LestratumName { get; set; }
        public int Leclustering { get; set; }
        public string LeclusterName { get; set; }
        public int? Lesampler { get; set; }
        public int LemixedTrip { get; set; }
        public int LecatchReg { get; set; }
        public int? Lelocode { get; set; }
        public string LelocationName { get; set; }
        public int? LelocationType { get; set; }
        public int Lecountry { get; set; }
        public DateTime? Ledate { get; set; }
        public DateTime? Letime { get; set; }
        public int? LeexclusiveEconomicZoneIndicator { get; set; }
        public int Learea { get; set; }
        public int? Lerectangle { get; set; }
        public int? LegsaSubarea { get; set; }
        public int? LejurisdictionArea { get; set; }
        public int? LenationalFishingActivity { get; set; }
        public int? Lemetier5 { get; set; }
        public int Lemetier6 { get; set; }
        public int Legear { get; set; }
        public int? LemeshSize { get; set; }
        public int? LeselectionDevice { get; set; }
        public int? LeselectionDeviceMeshSize { get; set; }
        public int? LetargetSpecies { get; set; }
        public int LemitigationDevice { get; set; }
        public int? LegearDimensions { get; set; }
        public int? LenumberTotal { get; set; }
        public int? LenumberSampled { get; set; }
        public decimal? LeselectionProb { get; set; }
        public decimal? LeinclusionProb { get; set; }
        public int LeselectionMethod { get; set; }
        public string LeunitName { get; set; }
        public int? LeselectionMethodCluster { get; set; }
        public int? LenumberTotalClusters { get; set; }
        public int? LenumberSampledClusters { get; set; }
        public decimal? LeselectionProbCluster { get; set; }
        public decimal? LeinclusionProbCluster { get; set; }
        public int Lesampled { get; set; }
        public int? LereasonNotSampled { get; set; }
        public int? LefullTripAvailable { get; set; }

        public virtual FishingOperation Fo { get; set; }
        public virtual FishingTrip Ft { get; set; }
        public virtual OnshoreEvent Os { get; set; }
        public virtual Sample Sa { get; set; }
        public virtual SpeciesSelection Ss { get; set; }
        public virtual TemporalEvent Te { get; set; }
        public virtual VesselDetail Vd { get; set; }
        public virtual VesselSelection Vs { get; set; }
        public virtual ICollection<Sample> Samples { get; set; }
        public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
    }
}
