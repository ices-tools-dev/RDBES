﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class OnshoreEvent: BaseModel
    {
        public OnshoreEvent()
        {
            FishingTrips = new HashSet<FishingTrip>();
            LandingEvents = new HashSet<LandingEvent>();
            SpeciesSelections = new HashSet<SpeciesSelection>();
        }

        public int Osid { get; set; }
        public int? Sdid { get; set; }
        public string OsrecordType { get; set; }
        public int OssequenceNumber { get; set; }
        public int Osstratification { get; set; }
        public int Oslocode { get; set; }
        public string OslocationName { get; set; }
        public int? OslocationType { get; set; }
        public DateTime OssamplingDate { get; set; }
        public DateTime? OssamplingTime { get; set; }
        public string OsstratumName { get; set; }
        public int Osclustering { get; set; }
        public string OsclusterName { get; set; }
        public int? Ossampler { get; set; }
        public int? OstimeUnit { get; set; }
        public decimal? OstimeValue { get; set; }
        public int? OsnumberTotal { get; set; }
        public int? OsnumberSampled { get; set; }
        public decimal? OsselectionProb { get; set; }
        public decimal? OsinclusionProb { get; set; }
        public int OsselectionMethod { get; set; }
        public string OsunitName { get; set; }
        public int? OsselectionMethodCluster { get; set; }
        public int? OsnumberTotalClusters { get; set; }
        public int? OsnumberSampledClusters { get; set; }
        public decimal? OsselectionProbCluster { get; set; }
        public decimal? OsinclusionProbCluster { get; set; }
        public int Ossampled { get; set; }
        public int? OsreasonNotSampled { get; set; }

        public virtual SamplingDetail Sd { get; set; }
        public virtual ICollection<FishingTrip> FishingTrips { get; set; }
        public virtual ICollection<LandingEvent> LandingEvents { get; set; }
        public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
    }
}
