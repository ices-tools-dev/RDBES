﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Xml2DB_DAL.Models
{
	public interface IModelWithUserIdAndTimeStamp
	{
		string UserId { get; set; }
		DateTime TimeStamp { get; set; }
	}
}
