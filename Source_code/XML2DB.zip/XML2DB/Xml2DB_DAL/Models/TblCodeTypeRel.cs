﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class TblCodeTypeRel
    {
        public TblCodeTypeRel()
        {
            TblCodeRels = new HashSet<TblCodeRel>();
        }

        public int TblCodeTypeRelId { get; set; }
        public int TblCodeTypeParId { get; set; }
        public int TblCodeTypeChdId { get; set; }
        public int Join { get; set; }
        public string User { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public int RelTypeId { get; set; }
        public string Description { get; set; }

        public virtual RelType RelType { get; set; }
        public virtual TblCodeType TblCodeTypeChd { get; set; }
        public virtual TblCodeType TblCodeTypePar { get; set; }
        public virtual ICollection<TblCodeRel> TblCodeRels { get; set; }
    }
}
