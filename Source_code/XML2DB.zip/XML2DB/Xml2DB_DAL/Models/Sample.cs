﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class Sample : BaseModel
    {
        public Sample()
        {
            BiologicalVariables = new HashSet<BiologicalVariable>();
            FrequencyMeasures = new HashSet<FrequencyMeasure>();
            InverseSaparent = new HashSet<Sample>();
            LandingEvents = new HashSet<LandingEvent>();
        }

        public int Said { get; set; }
        public int? SaparentId { get; set; }
        public int Ssid { get; set; }
        public int? Leid { get; set; }
        public string SarecordType { get; set; }
        public int SasequenceNumber { get; set; }
        public int? SaparentSequenceNumber { get; set; }
        public int Sastratification { get; set; }
        public string SastratumName { get; set; }
        public int SaspeciesCode { get; set; }
        public int? SaspeciesCodeFao { get; set; }
        public int SastateOfProcessing { get; set; }
        public int Sapresentation { get; set; }
        public int SaspecimensState { get; set; }
        public int SacatchCategory { get; set; }
        public int? SalandingCategory { get; set; }
        public int? SacommSizeCatScale { get; set; }
        public int? SacommSizeCat { get; set; }
        public int Sasex { get; set; }
        public int? SaexclusiveEconomicZoneIndicator { get; set; }
        public int? Saarea { get; set; }
        public int? Sarectangle { get; set; }
        public int SagsaSubarea { get; set; }
        public int? SajurisdictionArea { get; set; }
        public int? SanationalFishingActivity { get; set; }
        public int? Sametier5 { get; set; }
        public int? Sametier6 { get; set; }
        public int? Sagear { get; set; }
        public int? SameshSize { get; set; }
        public int? SaselectionDevice { get; set; }
        public int? SaselectionDeviceMeshSize { get; set; }
        public int SaunitType { get; set; }
        public long? SatotalWeightLive { get; set; }
        public int? SasampleWeightLive { get; set; }
        public decimal? SanumberTotal { get; set; }
        public decimal? SanumberSampled { get; set; }
        public decimal? SaselectionProb { get; set; }
        public decimal? SainclusionProb { get; set; }
        public int SaselectionMethod { get; set; }
        public string SaunitName { get; set; }
        public int SalowerHierarchy { get; set; }
        public int? Sasampler { get; set; }
        public int Sasampled { get; set; }
        public int? SareasonNotSampledFm { get; set; }
        public int? SareasonNotSampledBv { get; set; }
        public long? SatotalWeightMeasured { get; set; }
        public long? SasampleWeightMeasured { get; set; }
        public decimal? SaconversionFactorMeasLive { get; set; }

        public virtual LandingEvent Le { get; set; }
        public virtual Sample Saparent { get; set; }
        public virtual SpeciesSelection Ss { get; set; }
        public virtual ICollection<BiologicalVariable> BiologicalVariables { get; set; }
        public virtual ICollection<FrequencyMeasure> FrequencyMeasures { get; set; }
        public virtual ICollection<Sample> InverseSaparent { get; set; }
        public virtual ICollection<LandingEvent> LandingEvents { get; set; }
    }
}
