﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class SpeciesSelection: BaseModel
    {
        public SpeciesSelection()
        {
            LandingEvents = new HashSet<LandingEvent>();
            Samples = new HashSet<Sample>();
        }

        public int Ssid { get; set; }
        public int? Leid { get; set; }
        public int? Foid { get; set; }
        public int? Teid { get; set; }
        public int? Ftid { get; set; }
        public int Slid { get; set; }
        public int? Osid { get; set; }
        public string SsrecordType { get; set; }
        public int SssequenceNumber { get; set; }
        public int Ssstratification { get; set; }
        public int SsobservationActivityType { get; set; }
        public int SscatchFraction { get; set; }
        public int SsobservationType { get; set; }
        public string SsstratumName { get; set; }
        public int Ssclustering { get; set; }
        public string SsclusterName { get; set; }
        public int? Sssampler { get; set; }
        public string SsspeciesListName { get; set; }
        public int SsuseForCalculateZero { get; set; }
        public int? SsnumberTotal { get; set; }
        public int? SsnumberSampled { get; set; }
        public int? SsselectionProb { get; set; }
        public int? SsinclusionProb { get; set; }
        public int SsselectionMethod { get; set; }
        public string SsunitName { get; set; }
        public int? SsselectionMethodCluster { get; set; }
        public int? SsnumberTotalClusters { get; set; }
        public int? SsnumberSampledClusters { get; set; }
        public decimal? SsselectionProbCluster { get; set; }
        public decimal? SsinclusionProbCluster { get; set; }
        public int Sssampled { get; set; }
        public int? SsreasonNotSampled { get; set; }

        public virtual FishingOperation Fo { get; set; }
        public virtual FishingTrip Ft { get; set; }
        public virtual LandingEvent Le { get; set; }
        public virtual OnshoreEvent Os { get; set; }
        public virtual SpeciesList Sl { get; set; }
        public virtual TemporalEvent Te { get; set; }
        public virtual ICollection<LandingEvent> LandingEvents { get; set; }
        public virtual ICollection<Sample> Samples { get; set; }
    }
}
