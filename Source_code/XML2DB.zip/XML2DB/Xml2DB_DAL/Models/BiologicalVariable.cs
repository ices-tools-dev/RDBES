﻿#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class BiologicalVariable : BaseModel
    {
        public int Bvid { get; set; }
        public int? Said { get; set; }
        public int? Fmid { get; set; }
        public string BvrecordType { get; set; }
        public string BvnationalUniqueFishId { get; set; }
        public int BvstateOfProcessing { get; set; }
        public int Bvpresentation { get; set; }
        public int Bvstratification { get; set; }
        public string BvstratumName { get; set; }
        public int BvtypeMeasured { get; set; }
        public string BvvalueMeasured { get; set; }
        public int BvvalueUnitOrScale { get; set; }
        public int? Bvmethod { get; set; }
        public int? BvmeasurementEquipment { get; set; }
        public int? Bvaccuracy { get; set; }
        public int BvcertaintyQualitative { get; set; }
        public decimal? BvcertaintyQuantitative { get; set; }
        public decimal BvconversionFactorAssessment { get; set; }
        public int BvtypeAssessment { get; set; }
        public int? BvnumberTotal { get; set; }
        public int? BvnumberSampled { get; set; }
        public decimal? BvselectionProb { get; set; }
        public decimal? BvinclusionProb { get; set; }
        public int BvselectionMethod { get; set; }
        public string BvunitName { get; set; }
        public int? Bvsampler { get; set; }

        public virtual FrequencyMeasure Fm { get; set; }
        public virtual Sample Sa { get; set; }
    }
}
