﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class TemporalEvent : BaseModel
    {
        public TemporalEvent()
        {
            FishingTrips = new HashSet<FishingTrip>();
            LandingEvents = new HashSet<LandingEvent>();
            SpeciesSelections = new HashSet<SpeciesSelection>();
            VesselSelections = new HashSet<VesselSelection>();
        }

        public int Teid { get; set; }
        public int Sdid { get; set; }
        public int? Loid { get; set; }
        public int? Vsid { get; set; }
        public string TerecordType { get; set; }
        public int TesequenceNumber { get; set; }
        public int Testratification { get; set; }
        public int TetimeUnit { get; set; }
        public string TestratumName { get; set; }
        public int Teclustering { get; set; }
        public string TeclusterName { get; set; }
        public int? Tesampler { get; set; }
        public int? TenumberTotal { get; set; }
        public int? TenumberSampled { get; set; }
        public decimal? TeselectionProb { get; set; }
        public decimal? TeinclusionProb { get; set; }
        public int TeselectionMethod { get; set; }
        public string TeunitName { get; set; }
        public int? TeselectionMethodCluster { get; set; }
        public int? TenumberTotalClusters { get; set; }
        public int? TenumberSampledClusters { get; set; }
        public decimal? TeselectionProbCluster { get; set; }
        public decimal? TeinclusionProbCluster { get; set; }
        public int Tesampled { get; set; }
        public int? TereasonNotSampled { get; set; }

        public virtual Location Lo { get; set; }
        public virtual SamplingDetail Sd { get; set; }
        public virtual VesselSelection Vs { get; set; }
        public virtual ICollection<FishingTrip> FishingTrips { get; set; }
        public virtual ICollection<LandingEvent> LandingEvents { get; set; }
        public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
        public virtual ICollection<VesselSelection> VesselSelections { get; set; }
    }
}
