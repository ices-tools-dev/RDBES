﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class FishingTrip: BaseModel
    {
        public FishingTrip()
        {
            FishingOperations = new HashSet<FishingOperation>();
            LandingEvents = new HashSet<LandingEvent>();
            SpeciesSelections = new HashSet<SpeciesSelection>();
        }

        public int Ftid { get; set; }
        public int? Osid { get; set; }
        public int? Vsid { get; set; }
        public int? Vdid { get; set; }
        public int? Sdid { get; set; }
        public int? Foid { get; set; }
        public int? Teid { get; set; }
        public string FtrecordType { get; set; }
        public string FtencryptedVesselCode { get; set; }
        public string FtsequenceNumber { get; set; }
        public int Ftstratification { get; set; }
        public string FtstratumName { get; set; }
        public int Ftclustering { get; set; }
        public string FtclusterName { get; set; }
        public int? Ftsampler { get; set; }
        public int FtsamplingType { get; set; }
        public int? FtnumberOfHaulsOrSets { get; set; }
        public int? FtdepartureLocation { get; set; }
        public DateTime? FtdepartureDate { get; set; }
        public DateTime? FtdepartureTime { get; set; }
        public int FtarrivalLocation { get; set; }
        public DateTime FtarrivalDate { get; set; }
        public DateTime? FtarrivalTime { get; set; }
        public int? FtnumberTotal { get; set; }
        public int? FtnumberSampled { get; set; }
        public decimal? FtselectionProb { get; set; }
        public decimal? FtinclusionProb { get; set; }
        public int FtselectionMethod { get; set; }
        public string FtunitName { get; set; }
        public int? FtselectionMethodCluster { get; set; }
        public int? FtnumberTotalClusters { get; set; }
        public int? FtnumberSampledClusters { get; set; }
        public decimal? FtselectionProbCluster { get; set; }
        public decimal? FtinclusionProbCluster { get; set; }
        public int Ftsampled { get; set; }
        public int? FtreasonNotSampled { get; set; }

        public virtual FishingOperation Fo { get; set; }
        public virtual OnshoreEvent Os { get; set; }
        public virtual SamplingDetail Sd { get; set; }
        public virtual TemporalEvent Te { get; set; }
        public virtual VesselDetail Vd { get; set; }
        public virtual VesselSelection Vs { get; set; }
        public virtual ICollection<FishingOperation> FishingOperations { get; set; }
        public virtual ICollection<LandingEvent> LandingEvents { get; set; }
        public virtual ICollection<SpeciesSelection> SpeciesSelections { get; set; }
    }
}
