﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Xml2DB_DAL.Models
{
	public class BaseModel
	{
		[NotMapped]
		public int LineNo { get; set; }
	}
}
