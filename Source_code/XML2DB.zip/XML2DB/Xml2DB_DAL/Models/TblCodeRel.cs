﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class TblCodeRel
    {
        public int TblCodeOneId { get; set; }
        public int TblCodeManyId { get; set; }
        public string User { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public int TblCodeTypeRelId { get; set; }

        public virtual TblCode TblCodeMany { get; set; }
        public virtual TblCode TblCodeOne { get; set; }
        public virtual TblCodeTypeRel TblCodeTypeRel { get; set; }
    }
}
