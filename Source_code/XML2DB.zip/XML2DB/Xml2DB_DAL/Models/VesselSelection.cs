﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class VesselSelection : BaseModel
    {
        public VesselSelection()
        {
            FishingTrips = new HashSet<FishingTrip>();
            LandingEvents = new HashSet<LandingEvent>();
            TemporalEvents = new HashSet<TemporalEvent>();
        }

        public int Vsid { get; set; }
        public int? Sdid { get; set; }
        public int? Vdid { get; set; }
        public int? Teid { get; set; }
        public string VsrecordType { get; set; }
        public int VssequenceNumber { get; set; }
        public string VsencryptedVesselCode { get; set; }
        public int Vsstratification { get; set; }
        public string VsstratumName { get; set; }
        public int Vsclustering { get; set; }
        public string VsclusterName { get; set; }
        public int? Vssampler { get; set; }
        public int? VsnumberTotal { get; set; }
        public int? VsnumberSampled { get; set; }
        public decimal? VsselectionProb { get; set; }
        public decimal? VsinclusionProb { get; set; }
        public int VsselectionMethod { get; set; }
        public string VsunitName { get; set; }
        public int? VsselectionMethodCluster { get; set; }
        public int? VsnumberTotalClusters { get; set; }
        public int? VsnumberSampledClusters { get; set; }
        public decimal? VsselectionProbCluster { get; set; }
        public decimal? VsinclusionProbCluster { get; set; }
        public int Vssampled { get; set; }
        public int? VsreasonNotSampled { get; set; }

        public virtual SamplingDetail Sd { get; set; }
        public virtual TemporalEvent Te { get; set; }
        public virtual VesselDetail Vd { get; set; }
        public virtual ICollection<FishingTrip> FishingTrips { get; set; }
        public virtual ICollection<LandingEvent> LandingEvents { get; set; }
        public virtual ICollection<TemporalEvent> TemporalEvents { get; set; }
    }
}
