﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class RelType
    {
        public RelType()
        {
            TblCodeTypeRels = new HashSet<TblCodeTypeRel>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public string Xmlnode { get; set; }

        public virtual ICollection<TblCodeTypeRel> TblCodeTypeRels { get; set; }
    }
}
