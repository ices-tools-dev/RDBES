﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Xml2DB_DAL.Models
{
    public partial class TblCodeType
    {
        public TblCodeType()
        {
            TblCodeTypeRelTblCodeTypeChds = new HashSet<TblCodeTypeRel>();
            TblCodeTypeRelTblCodeTypePars = new HashSet<TblCodeTypeRel>();
            TblCodes = new HashSet<TblCode>();
        }

        public int TblCodeTypeId { get; set; }
        public string CodeType { get; set; }
        public string Description { get; set; }
        public string Definition { get; set; }
        public string User { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public int? VerX { get; set; }
        public int? VerY { get; set; }
        public DateTime? VerDate { get; set; }
        public bool? Visibility { get; set; }

        public virtual ICollection<TblCodeTypeRel> TblCodeTypeRelTblCodeTypeChds { get; set; }
        public virtual ICollection<TblCodeTypeRel> TblCodeTypeRelTblCodeTypePars { get; set; }
        public virtual ICollection<TblCode> TblCodes { get; set; }
    }
}
