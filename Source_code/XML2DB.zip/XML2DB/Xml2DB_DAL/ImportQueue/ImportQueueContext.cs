﻿using System;
using Microsoft.EntityFrameworkCore;


namespace Xml2DB_DAL.ImportQueue
{
	public partial class ImportQueueContext : DbContext
	{

		#region Customized code

		public ImportQueueContext(string connection)
		{
			ConnectionString = connection;
		}

		public ImportQueueContext(DbContextOptions<DatabaseContext> options)
			: base(options) { }

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder.UseSqlServer(ConnectionString);
			if (!optionsBuilder.IsConfigured)
			{
				throw new ArgumentException("optionsBuilder is not configured!");
			}
		}
		public string ConnectionString { get; private set; }

		public void CreateTableIfNotExists()
		{
			string sql =
			$@"
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ImportQueue' and xtype='U')
BEGIN

	CREATE TABLE [dbo].[ImportQueue](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[UserId] [nvarchar](450) NOT NULL,
		[FirstName] [nvarchar](500) NULL,
		[LastName] [nvarchar](500) NULL,
		[Email] [nvarchar](500) NOT NULL,
		[Hierarchy] [nvarchar](50) NOT NULL,
		[FilePath] [nvarchar](max) NOT NULL,
		[UploadedFileName] [nvarchar](500) NOT NULL,
		[ShouldCheckForDuplicates] [bit] NOT NULL,
		[AddedAt] [datetime] NOT NULL,
		[ProcessingStartedAt] [datetime] NULL,
		[ProcessingEndedAt] [datetime] NULL,
		[Success] [bit] NULL,
		[Errors] [nvarchar](max) NULL,
	 CONSTRAINT [PK_ImportQueue] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY];
	
	CREATE NONCLUSTERED INDEX [IX_ImportQueue_AddedAt] ON [dbo].[ImportQueue]
	(
		[AddedAt] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY];

	CREATE NONCLUSTERED INDEX [IX_ImportQueue_Hierarchy] ON [dbo].[ImportQueue]
	(
		[Hierarchy] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY];

	CREATE NONCLUSTERED INDEX [IX_ImportQueue_Success] ON [dbo].[ImportQueue]
	(
		[Success] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY];
	
	CREATE NONCLUSTERED INDEX [IX_ImportQueue_UserId] ON [dbo].[ImportQueue]
	(
		[UserId] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY];


END
";
			this.Database.ExecuteSqlRaw(sql);
		}
		#endregion

		public virtual DbSet<ImportQueue> ImportQueue { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

			modelBuilder.Entity<ImportQueue>(entity =>
			{
				entity.ToTable("ImportQueue");

				entity.HasIndex(e => e.AddedAt, "IX_ImportQueue_AddedAt");

				entity.HasIndex(e => e.Hierarchy, "IX_ImportQueue_Hierarchy");

				entity.HasIndex(e => e.Success, "IX_ImportQueue_Success");

				entity.HasIndex(e => e.UserId, "IX_ImportQueue_UserId");

				entity.Property(e => e.AddedAt).HasColumnType("datetime");

				entity.Property(e => e.Email)
					.IsRequired()
					.HasMaxLength(500);

				entity.Property(e => e.FilePath).IsRequired();

				entity.Property(e => e.FirstName).HasMaxLength(500);

				entity.Property(e => e.Hierarchy)
					.IsRequired()
					.HasMaxLength(50);

				entity.Property(e => e.LastName).HasMaxLength(500);

				entity.Property(e => e.ProcessingEndedAt).HasColumnType("datetime");

				entity.Property(e => e.ProcessingStartedAt).HasColumnType("datetime");

				entity.Property(e => e.UploadedFileName)
					.IsRequired()
					.HasMaxLength(500);

				entity.Property(e => e.UserId).IsRequired();
			});

			OnModelCreatingPartial(modelBuilder);
		}

		partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
	}
}
