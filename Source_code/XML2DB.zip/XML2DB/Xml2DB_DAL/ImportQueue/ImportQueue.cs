﻿using System;

namespace Xml2DB_DAL.ImportQueue
{
    public partial class ImportQueue
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Hierarchy { get; set; }
        public string FilePath { get; set; }
        public string UploadedFileName { get; set; }
        public bool ShouldCheckForDuplicates { get; set; }
        public DateTime AddedAt { get; set; }
        public DateTime? ProcessingStartedAt { get; set; }
        public DateTime? ProcessingEndedAt { get; set; }
        public bool? Success { get; set; }
        public string Errors { get; set; }
    }
}
