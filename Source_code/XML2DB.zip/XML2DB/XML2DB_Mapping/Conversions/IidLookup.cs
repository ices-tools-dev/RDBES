﻿using System.Collections.Generic;

namespace XML2DB_Mapping.Conversions
{
	public interface IidLookup
	{
		int GetId(IdLookupType type, string combinedKey);

		string GetSpeciesListKey(int slCountry, string slSpeciesListName, int slYear, int slCatchFraction);
		string GetVesselDetailsKey(int vdCountry, string vdEncryptedVesselCode, int vdYear);
	}
}
