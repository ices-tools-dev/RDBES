﻿namespace XML2DB_Mapping.Conversions
{
	public enum ConversionType : byte
	{
		/// <summary>
		///  No conversion needed - used when database type is string
		/// </summary>
		None = 1,
		/// <summary>
		///  Should convert to the type of the mapped property E.G. int, decimal, etc.
		/// </summary>
		InferFromPropertyType = 2,
		/// <summary>
		///  The value should be extracted from lookup list - string to int
		/// </summary>
		Lookup = 3,
		/// <summary>
		/// This value is an id, coming either from SpeciesList or VesselDetails table, it is extracted by matching the table with several matching fields from the whole hierarchy
		/// </summary>
		IdLookup = 4
	}
}
