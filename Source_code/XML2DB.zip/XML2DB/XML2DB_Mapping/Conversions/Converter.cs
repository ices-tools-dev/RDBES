﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XML2DB_Mapping.Conversions
{
	internal class Converter
	{
		public object Convert(string value, Type toType)
		{
			try
			{
				if (toType == typeof(short))
				{
					return short.Parse(value);
				}
				if (toType == typeof(short?))
				{
					if (string.IsNullOrEmpty(value))
					{
						return null;
					}
					return short.Parse(value);
				}
				if (toType == typeof(int))
				{
					return int.Parse(value);
				}
				if (toType == typeof(int?))
				{
					if (string.IsNullOrEmpty(value))
					{
						return null;
					}
					return int.Parse(value);
				}
				if (toType == typeof(long))
				{
					return long.Parse(value);
				}
				if (toType == typeof(long?))
				{
					if (string.IsNullOrEmpty(value))
					{
						return null;
					}
					return long.Parse(value);
				}
				if (toType == typeof(decimal))
				{
					return decimal.Parse(value);
				}
				if (toType == typeof(decimal?))
				{
					if (string.IsNullOrEmpty(value))
					{
						return null;
					}
					return decimal.Parse(value);
				}
				if (toType == typeof(DateTime))
				{
					return DateTime.Parse(value);
				}
				if (toType == typeof(DateTime?))
				{
					if (string.IsNullOrEmpty(value))
					{
						return null;
					}
					return DateTime.Parse(value);
				}

				throw new NotSupportedException($"No conversion defined for type:'{toType}'");
			}
			catch (System.FormatException excp)
			{
				throw new ConversionException($"Value:'{value}' could not be converted to:'{toType.Name}'", excp);
			}
		}
	}
}