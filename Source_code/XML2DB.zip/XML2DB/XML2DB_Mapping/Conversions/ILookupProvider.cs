﻿namespace XML2DB_Mapping.Conversions
{
    public interface ILookupProvider
    {
		int Lookup(CodeType codeType, string value);
    }
}
