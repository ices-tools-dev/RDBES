﻿
namespace XML2DB_Mapping.Conversions
{
	public enum IdLookupType : byte
	{
		SpeciesList = 1,
		VesselDetails = 2
	}
}
