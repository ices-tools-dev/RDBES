﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XML2DB_Mapping.Conversions
{
    public class ConversionException : Exception
	{
		public ConversionException(string message, Exception innerException) : base (message, innerException){}
	}
}
