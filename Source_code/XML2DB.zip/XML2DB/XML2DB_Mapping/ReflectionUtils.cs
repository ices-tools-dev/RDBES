﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Linq;
using System.Reflection;
using System.Text;
using Xml2DB_DAL.Models;

namespace XML2DB_Mapping
{
	public static class ReflectionUtils
	{
		private static readonly Dictionary<Type, Dictionary<string, PropertyInfo>> propertiesByType =
			new Dictionary<Type, Dictionary<string, PropertyInfo>>();

		private static readonly Dictionary<Type, Dictionary<string, MethodInfo>> addingsByType =
			new Dictionary<Type, Dictionary<string, MethodInfo>>();

		private static readonly Dictionary<string, Type> tableTypes = new Dictionary<string, Type>();

		private static readonly string dbModelsNamespace = typeof(BiologicalVariable).FullName.Replace("BiologicalVariable", "");

		private static Dictionary<string, object> _propertyGettersCache = new Dictionary<string, object>();

		public static object GetPropertyValue(object instance, string propertyName)
		{
			Type targetType = instance.GetType();
			CheckCache(targetType);
			return propertiesByType[targetType][propertyName.ToLower()].GetValue(instance, null);
		}

		public static void SetPropertyValue(object instance, string propertyName, object value)
		{
			Type targetType = instance.GetType();
			CheckCache(targetType);
			try
			{
				propertiesByType[targetType][propertyName.ToLower()].SetValue(instance, value);
			}
            catch (ArgumentException argExcp)
            {
                throw new ArgumentException($"Failed to set property:'{propertyName}' (Type:{propertiesByType[targetType][propertyName.ToLower()].PropertyType.Name}) to value:'{value}' (Type:{((null == value) ? "NUll" : value?.GetType().Name)})", argExcp);
            }
         

            catch (KeyNotFoundException excp)
			{
				throw new KeyNotFoundException($"Failed to find property:'{propertyName}' in entity of type:'{targetType.Name}'", excp);
			}
		}

		public static void AddItemToCollection(object instance, string propertyName, object value)
		{
			Type targetType = instance.GetType();
			CheckCache(targetType);
			var collection = GetPropertyValue(instance, propertyName);
			collection.GetType().GetMethod("Add").Invoke(collection, new[] { value });
		}

		public static object CreateDbRecord(string dbRecordName)
		{
			return Activator.CreateInstance(GetRecordTypeFromCache(dbRecordName));
		}

		public static Type GetPropertyType(Type objectType, string propertyName)
		{
			CheckCache(objectType);
			try
			{
				return propertiesByType[objectType][propertyName.ToLower()].PropertyType;
			}
			catch (KeyNotFoundException excp)
			{
				throw new KeyNotFoundException($"Failed to find property:'{propertyName}' in object type:'{objectType.Name}'", excp);
			}
		}

		public static IEnumerable<T> GetChildRecordsOfType<T>(object instance, string propertyName)
		{
			var value = GetPropertyValue(instance, propertyName.ToLower());
			return (IEnumerable<T>)value;
		}

		/// <summary>
		/// Traverses the object for properties of type ICollection, and returns those properties
		/// </summary>
		/// <param name="instance"></param>
		/// <returns></returns>
		public static List<object> GetObjectChildLists(object instance)
		{
			List<object> result = new List<object>();
			var properties = instance.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)
				.Where(
					prop => prop.PropertyType != typeof(string) &&
					prop.PropertyType.GetInterfaces().Contains(typeof(IEnumerable))
				).ToList();

			foreach (var prop in properties)
			{
				var value = GetPropertyValue(instance, prop.Name);
				if (((IEnumerable)value).GetEnumerator().MoveNext())
				{
					result.Add(value);
				}
			}
			return result;
		}

		public static T CallGenericMethod<T>(object instance, Type genericType, string methodName, object[] parameters)
			where T : class
		{
			return instance.GetType()
					.GetMethod(methodName)
					.MakeGenericMethod(genericType)
					.Invoke(instance, parameters)
					as T;
		}

		private static void CheckCache(Type type)
		{
			if (!propertiesByType.ContainsKey(type))
			{
				CacheProperties(type);
			}
		}

		private static Type GetRecordTypeFromCache(string tableName)
		{
			if (!tableTypes.ContainsKey(tableName))
			{
				tableTypes.Add(tableName, GetRecordType(tableName));
			}
			Type tableType = null;
			if (!tableTypes.TryGetValue(tableName, out tableType))
			{
				throw new Exception(string.Format($"Failed to find table type: '{tableName}'"));
			}
			return tableType;

		}

		private static Type GetRecordType(string recordName)
		{
			string fullTypeName = string.Concat(dbModelsNamespace, recordName);
			var type = typeof(Xml2DB_DAL.Models.BiologicalVariable).Assembly.GetType(fullTypeName);
			if (type == null)
			{
				throw new NotSupportedException($"Cound not find model of type: '{recordName}'");
			}
			return type;
		}

		private static void CacheProperties(Type type)
		{
			Dictionary<string, PropertyInfo> properties = new Dictionary<string, PropertyInfo>();
			addingsByType.Add(type, new Dictionary<string, MethodInfo>());
			var propertyInfos = type.GetProperties(BindingFlags.Instance | BindingFlags.Public);
			foreach (var propertyInfo in propertyInfos)
			{
				properties.Add(propertyInfo.Name.ToLower(), propertyInfo);
				if (typeof(ICollection<>).IsAssignableFrom(propertyInfo.PropertyType))
				{
					addingsByType[type].Add(propertyInfo.Name, properties[propertyInfo.Name].PropertyType.GetMethod("Add"));
				}
			}
			propertiesByType.Add(type, properties);
		}

		private static Func<object, TProperty> GetOrCreatePropertyGetter<TProperty>(object instance, PropertyInfo propertyInfo, Func<Func<object, TProperty>> createGetter)
		{
			object result;
			string key = $"{instance.GetType().Name}.{propertyInfo.Name}";
			if (!_propertyGettersCache.TryGetValue(key, out result))
			{
				result = createGetter();
				_propertyGettersCache.Add(key, result);
			}
			return (Func<object, TProperty>)result;
		}

		private static Func<object, TProperty> CreatePropertyGetter<TProperty>(object instance, PropertyInfo propertyInfo)
		{
			if (instance.GetType() != propertyInfo.DeclaringType)
			{
				throw new ArgumentException($"The provided propertyInfo belongs to type: {propertyInfo.DeclaringType.Name}, while the TObject is:{instance.GetType().Name}");
			}
			var paramExpression = Expression.Parameter(propertyInfo.DeclaringType, "o");
			var memberExpression = Expression.Property(paramExpression, propertyInfo.Name);
			return (Func<object, TProperty>)Expression.Lambda(memberExpression, new[] { paramExpression }).Compile();
		}
	}

}
