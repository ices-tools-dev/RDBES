﻿using System;
using System.Collections.Generic;
using System.Text;
using Xml2DB_DAL;
using XML2DB_Mapping.Conversions;
using XML2DB_Reader;
using System.Linq;
using Xml2DB_DAL.Models;

namespace XML2DB_Mapping
{
	public class Mapper
	{
		private Dictionary<string, ElementMapping> mappings = new Dictionary<string, ElementMapping>();
		private Converter converter = new Converter();
		private readonly ILookupProvider lookupProvider;
		private readonly IidLookup idLookup;
		private Dictionary<string, HierarchyItem> currentHierarchy = new Dictionary<string, HierarchyItem>();
		private List<object> result = new List<object>();

		private SamplingDetail currentSD = null;
		private Design currentDE = null;

		public Mapper(List<ElementMapping> elementMapings, ILookupProvider lookupProvider, IidLookup idLookup)
		{
			foreach (var mapping in elementMapings)
			{
				mappings.Add(mapping.ElementName, mapping);
			}
			this.lookupProvider = lookupProvider;
			this.idLookup = idLookup;
		}

		/// <summary>
		/// Processes the provided list of elements using the according mappings and fills them to database records
		/// </summary>
		/// <param name="xmlElements"></param>
		/// <param name="context"></param>
		/// <param name="lookup"></param>
		/// <returns></returns>
		public List<object> MapToObjects(List<Element> xmlElements)
		{
			result.Clear();
			foreach (var element in xmlElements)
			{
				var mapping = mappings[element.Name];
				ConvertToHierarchicalObject(element, mapping);
			}
			return result;
		}

		public object ConvertToFlatObject<T>(Element element, ElementMapping mapping)
		{
			object instance = ReflectionUtils.CreateDbRecord(mapping.ObjectTypeName);
			FillProperties(instance, element, mapping);
			return instance;
		}

		private void ConvertToHierarchicalObject(Element element, ElementMapping mapping, HierarchyItem parent = null)
		{
			object instance = ReflectionUtils.CreateDbRecord(mapping.ObjectTypeName);
			if (instance.GetType() == typeof(Design))
			{
				currentDE = instance as Design;
			}
			if (instance.GetType() == typeof(SamplingDetail))
			{
				currentSD = instance as SamplingDetail;
			}

			FillProperties(instance, element, mapping);

			HierarchyItem thisItem = PutInHierarchy(instance, mapping, parent);
			ConvertChildsToObjects(element, mapping, thisItem);
		}

		private void FillProperties(object instance, Element element, ElementMapping mapping)
		{
			if (!mapping.FieldMappingsTypesSet)
			{
				FillObjectTypes(instance.GetType(), mapping);
			}
			object valueForRecord = null;
			foreach (var fieldMapping in mapping.FieldMappings.Values)
			{
				try
				{
					valueForRecord = GetValueForMapping(element, fieldMapping, instance);
				}
				catch (KeyNotFoundException excp)
				{
					throw new Exception($"Failed to find mapping for field:'{fieldMapping.FieldName}' of XML element:'{element.Name}'", excp);
				}
				ReflectionUtils.SetPropertyValue(instance, fieldMapping.PropertyName, valueForRecord);
			}
		}

		private void ConvertChildsToObjects(Element element, ElementMapping mapping, HierarchyItem parent)
		{
			foreach (var childElement in element.ChildElements)
			{
				var childMapping = mapping.GetChildMapping(childElement.Name);
				try
				{
					ConvertToHierarchicalObject(childElement, childMapping, parent);
				}
				catch (Exception excp)
				{
					throw new Exception($"{System.Reflection.MethodBase.GetCurrentMethod().Name} failed for element:'{childElement.Name}'", excp);
				}
			}
		}

		private HierarchyItem PutInHierarchy(object instance, ElementMapping mapping, HierarchyItem parent)
		{
			HierarchyItem hierarchyItem = new HierarchyItem { ObjectInstance = instance, Name = mapping.ObjectTypeName };
			if (parent == null && mapping.ParentSetting.DiscoveryApproach == ParentDiscoveryOption.Default)
			{
				mapping.ParentSetting.DiscoveryApproach = ParentDiscoveryOption.NoParent;
			}

			switch (mapping.ParentSetting.DiscoveryApproach)
			{
				case ParentDiscoveryOption.NoParent:
					AddOrReplaceTopItem(hierarchyItem);
					break;
				case ParentDiscoveryOption.Default:
					if (parent != null)
					{
						parent.SetChild(hierarchyItem);
						ReflectionUtils.AddItemToCollection(parent.ObjectInstance, mapping.ParentSetting.ParentPropertyName, hierarchyItem.ObjectInstance);
					}
					break;
				case ParentDiscoveryOption.ByName:
					foreach (string name in mapping.ParentSetting.ParentNames)
					{
						SetParentByName(mapping, hierarchyItem, name);
					}
					break;
			}
			if (hierarchyItem.Parent == null)
			{
				result.Add(instance);
			}
			return hierarchyItem;
		}

		private void SetParentByName(ElementMapping mapping, HierarchyItem item, string name)
		{
			var parent = FindItemByName(name);
			if (parent == null)
			{
				throw new Exception($"Failed to find parent object with name '{name}' for item: '{item.Name}' (mapping :{mapping.ElementName} to {mapping.ObjectTypeName})");
			}
			parent.SetChild(item);
			ReflectionUtils.AddItemToCollection(parent.ObjectInstance, mapping.ObjectTypeName, item.ObjectInstance);
		}

		private void AddOrReplaceTopItem(HierarchyItem item)
		{
			if (currentHierarchy.ContainsKey(item.Name))
			{
				currentHierarchy[item.Name] = item;
			}
			else
			{
				currentHierarchy.Add(item.Name, item);
			}
		}

		private HierarchyItem FindItemByName(string name)
		{
			if (currentHierarchy.ContainsKey(name))
			{
				return currentHierarchy[name];
			}
			HierarchyItem result = null;
			foreach (HierarchyItem item in currentHierarchy.Values)
			{
				result = result ?? item.FindChildByName(name);
				if (result != null)
				{
					break;
				}
			}
			return result;
		}

		private object GetValueForMapping(Element element, FieldMapping mapping, object currentItem = null)
		{
			try
			{
				switch (mapping.ConversionType)
				{
					case ConversionType.None:
						return element.Fields[mapping.FieldName].Value;
					case ConversionType.InferFromPropertyType:
						return converter.Convert(element.Fields[mapping.FieldName].Value, mapping.PropertyType);
					case ConversionType.Lookup:
						if (element.Fields[mapping.FieldName].Value == null)
						{
							return null;
						}
						return lookupProvider.Lookup(mapping.LookupCodeType, element.Fields[mapping.FieldName].Value);
					case ConversionType.IdLookup:
						return GetIdLookupValue(mapping.IdLookupType, currentItem);
					default:
						throw new NotImplementedException($"Conversion type:{mapping.ConversionType} is not supported");

				}
			}
			catch (Exception excp)
			{
				throw new ConversionException($"Conversion failed for field:'{mapping.FieldName}'", excp);
			}
		}

		private int? GetIdLookupValue(IdLookupType type, object currentItem)
		{
			switch (type)
			{
				case IdLookupType.SpeciesList:
					return (GetSlId(currentItem));
				case IdLookupType.VesselDetails:
					return (GetVdId(currentItem));
			}
			throw new NotSupportedException($"IdLookupType.{type} is not supported!");
		}

		private int GetSlId(object currentItem)
		{
			if (currentItem.GetType() != typeof(SpeciesSelection))
			{
				throw new NotSupportedException($"SlId functionality is expected to work only with items of type: {typeof(SpeciesSelection).Name} while provided parameter is of type: {currentItem.GetType().Name}");
			}
			string slkey = idLookup.GetSpeciesListKey(currentSD.Sdcountry, ((SpeciesSelection)currentItem).SsspeciesListName, currentDE.Deyear, ((SpeciesSelection)currentItem).SscatchFraction);
			return idLookup.GetId(IdLookupType.SpeciesList, slkey);
		}

		private int? GetVdId(object currentItem)
		{
			string encryptedVesselCode;
			switch (currentItem.GetType().Name)
			{
				case nameof(FishingTrip):
					encryptedVesselCode = (currentItem as FishingTrip).FtencryptedVesselCode;
					break;
				case nameof(LandingEvent):
					encryptedVesselCode = (currentItem as LandingEvent).LeencryptedVesselCode;
					// LE records are allowed to have empty encryptedVesselCode for some cases.
					if (string.IsNullOrEmpty(encryptedVesselCode))
					{
						return null;
					}
					break;
				case nameof(VesselSelection):
					encryptedVesselCode = (currentItem as VesselSelection).VsencryptedVesselCode;
					break;
				default:
					throw new NotSupportedException($"Not supported type: {currentItem.GetType().Name}");
			}
			string vdkey = idLookup.GetVesselDetailsKey(currentSD.Sdcountry, encryptedVesselCode, currentDE.Deyear);
			return idLookup.GetId(IdLookupType.VesselDetails, vdkey);
		}

		private void FillObjectTypes(Type type, ElementMapping mapping)
		{
			foreach (var fieldMapping in mapping.FieldMappings.Values.Where(mpng => mpng.ConversionType == ConversionType.InferFromPropertyType))
			{
				fieldMapping.PropertyType = ReflectionUtils.GetPropertyType(type, fieldMapping.PropertyName);
			}
			mapping.FieldMappingsTypesSet = true;
		}

		private class HierarchyItem
		{
			public HierarchyItem Parent { get; set; }
			public Dictionary<string, HierarchyItem> Childs = new Dictionary<string, HierarchyItem>();
			public string Name { get; set; }
			public object ObjectInstance { get; set; }

			public void SetChild(HierarchyItem item)
			{
				item.Parent = this;
				if (Childs.ContainsKey(item.Name))
				{
					Childs[Name] = item;
				}
				else
				{
					Childs.Add(item.Name, item);
				}
			}

			public void SetParent(HierarchyItem item)
			{
				item.SetChild(this);
			}

			public HierarchyItem FindChildByName(string name)
			{
				if (Childs.ContainsKey(name))
				{
					return Childs[name];
				}
				HierarchyItem result = null;
				foreach (var childItem in Childs.Values)
				{
					result = result ?? childItem.FindChildByName(name);
					if (result != null)
					{
						break;
					}
				}
				return result;
			}
		}

	}
}
