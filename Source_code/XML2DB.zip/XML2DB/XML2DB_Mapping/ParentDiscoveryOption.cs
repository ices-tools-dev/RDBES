﻿namespace XML2DB_Mapping
{
	public enum ParentDiscoveryOption : byte
	{
		NoParent = 1,
		/// <summary>
		/// Set the parent using default logic => last object above the current one in the hierarchy
		/// </summary>
		Default = 2,
		/// <summary>
		/// Look for parent by name
		/// </summary>
		ByName	= 3
	}
}
