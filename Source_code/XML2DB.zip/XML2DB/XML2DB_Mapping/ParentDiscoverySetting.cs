﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XML2DB_Mapping
{
    public class ParentDiscoverySetting
    {
		public ParentDiscoveryOption DiscoveryApproach { get; set; } = ParentDiscoveryOption.Default;
		public List<string> ParentNames { get; set; } = new List<string>();

		/// <summary>
		/// Name of the property in the parent which contains this object instance e.g.: SamplingDetails of Design
		/// </summary>
		public string ParentPropertyName { get; set; }
	}
}
