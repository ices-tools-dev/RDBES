﻿using System.Collections.Generic;
using System.Collections;

namespace XML2DB_Mapping
{
	/// <summary>
	/// Represents mapping between an XML element and an object (which is usually, but not necessary an EF model)
	/// </summary>
	public class ElementMapping
	{
		public Dictionary<string, ElementMapping> ChildElmentsMappings = new();
		public ElementMapping ParentElement { get; set; }

		public readonly Dictionary<string, FieldMapping> FieldMappings = new();

		public ElementMapping(
			string elementName,
			string objectTypeName,
			string tableName,
			List<FieldMapping> fields,
			List<ElementMapping> childs = null,
			ParentDiscoverySetting parentSetting = null)
		{
			this.ElementName = elementName;
			this.ObjectTypeName = objectTypeName;
			this.TableName = string.IsNullOrEmpty(tableName) ? objectTypeName : tableName;
			this.ParentSetting = parentSetting ?? new ParentDiscoverySetting { ParentPropertyName = objectTypeName };
			foreach (var fieldMapping in fields)
			{
				FieldMappings.Add(fieldMapping.FieldName, fieldMapping);
			}

			if (childs != null)
			{
				foreach (var child in childs)
				{
					ChildElmentsMappings.Add(child.ElementName, child);
					child.ParentElement = this;
				}
			}
		}

		public ElementMapping AddChilds(params ElementMapping[] childDefinitions)
		{
			foreach (var childDefinition in childDefinitions)
			{
				this.ChildElmentsMappings.Add(childDefinition.ElementName, childDefinition);
				childDefinition.ParentElement = this;

			}
			return this;
		}

		public ElementMapping SetParentDiscovery(ParentDiscoverySetting parentSetting)
		{
			this.ParentSetting = parentSetting;
			return this;
		}

		public void AddChild(ElementMapping child)
		{
			ChildElmentsMappings.Add(child.ElementName, child);
		}

		public string ElementName { get; protected set; }

		public string ObjectTypeName { get; set; }
		public string TableName { get; protected set; }

		public ParentDiscoverySetting ParentSetting { get; protected set; }

		internal bool FieldMappingsTypesSet { get; set; }

		public ElementMapping GetChildMapping(string name)
		{
			try
			{
				return ChildElmentsMappings[name];
			}
			catch (KeyNotFoundException)
			{
				throw new KeyNotFoundException($"Failed to find mapping for xml element: '{name}'");
			}

		}
	}
}
