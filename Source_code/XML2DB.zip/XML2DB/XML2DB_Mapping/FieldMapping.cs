﻿using System;
using System.Collections.Generic;
using System.Text;
using XML2DB_Mapping.Conversions;

namespace XML2DB_Mapping
{
	public class FieldMapping
	{
		public FieldMapping(string fieldName, string propertyName, ConversionType conversionType = ConversionType.None, CodeType lookupCodeType = CodeType.NoCode)
		{
			FieldName = fieldName;
			PropertyName = propertyName;
			ConversionType = conversionType;
			LookupCodeType = lookupCodeType;
		}
		public FieldMapping(string propertyName, IdLookupType idLookupType)
		{
			FieldName = propertyName;
			PropertyName = propertyName;
			ConversionType = ConversionType.IdLookup;
			IdLookupType = idLookupType;
		}

		public string FieldName { get; private set; }
		public string PropertyName { get; private set; }
		public ConversionType ConversionType { get; private set; }
		public CodeType LookupCodeType { get; private set; }

		public IdLookupType IdLookupType { get; private set; }
		internal Type PropertyType { get; set; }
	}
}
