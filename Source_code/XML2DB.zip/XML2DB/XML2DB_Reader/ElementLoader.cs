﻿using System;
using System.Xml;
using XML2DB_Reader.Definitions;

namespace XML2DB_Reader
{
	internal class ElementLoader
	{
		private FieldLoader fieldLoader = new FieldLoader();

		public Element LoadElement(XmlElement xmlElement, ElementDefinition definition)
		{
			Element result = new Element(definition.Name);

			LoadChildElements(xmlElement, result, definition);
			LoadFields(xmlElement, result, definition);

			return result;
		}


		private void LoadChildElements(XmlElement xmlElement, Element element, ElementDefinition definition)
		{ 
			foreach(var childElementDefinition in definition.ChildElementsDefinitions)
			{
				foreach(XmlElement childXmlElement in xmlElement.ChildNodes)
				{
					if(childElementDefinition.Name.Equals(childXmlElement.Name, StringComparison.InvariantCultureIgnoreCase))
					{
						element.ChildElements.Add(LoadElement(childXmlElement, childElementDefinition));
					}
				}
			}
		}

		private void LoadFields(XmlElement xmlElement, Element element, ElementDefinition definition)
		{ 
			foreach(var fieldDefinition in definition.FieldDefinitions)
			{
				var field = fieldLoader.LoadField(xmlElement, fieldDefinition);
				try
				{
					element.Fields.Add(field.Name, field);
				}
				catch(ArgumentException excp)
				{ 
					throw new ArgumentException($"A field with name:'{field.Name}' has already been added to '{element.Name}'", excp);
				}
			}			
		}

	}
}
