﻿using System;
using System.Collections.Generic;
using System.Text;
using XML2DB_Reader.Definitions;
using System.Xml;
using System.Xml.Linq;

namespace XML2DB_Reader
{
	public class Reader : IReader
	{
		private XmlReader _reader;
		private Dictionary<string, ElementDefinition> elementDefinitions = new Dictionary<string, ElementDefinition>();
		private XmlDocument _xmlDocument = new XmlDocument();
		private ElementLoader _elementLoader = new ElementLoader();
		private ElementDefinition _definition;

		public Reader(string pathToXml, XmlDefinition xmlDefinition, string elementName)
		{
			foreach (var elementDefinition in xmlDefinition.ElementDefinitions)
			{
				this.elementDefinitions.Add(elementDefinition.Name.ToLower(), elementDefinition);
			}
			if (!elementDefinitions.TryGetValue(elementName.ToLower(), out _definition))
			{
				throw new Exception(string.Format("Missing definition for xml element with name: '{0}'", elementName));
			}

			_reader = XmlReader.Create(pathToXml);
			_reader.MoveToContent();
			while(string.IsNullOrEmpty(_reader.Name) || !_reader.Name.Equals(elementName))
				_reader.Read();

		}

		public bool Finished { get; private set; }

		public Element Read()
		{
			if (Finished) return null;
			var xmlElement = _xmlDocument.ReadNode(_reader) as XmlElement;
			while (_reader.NodeType != XmlNodeType.Element && _reader.Read()); // skip new lines
			if (xmlElement == null)
			{
				Finished = true;
				return null;
			}
			return _elementLoader.LoadElement(xmlElement, _definition);
		}
	}
}
