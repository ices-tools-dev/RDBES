﻿using System;
using System.Xml;
using System.Xml.Linq;
using System.Linq;
using XML2DB_Reader.Definitions;

namespace XML2DB_Reader {
	public class FieldLoader {
		public Field LoadField(XmlElement element, FieldDefinition definition)
		{
			Field result = new Field(definition.Name);
			switch (definition.Type) 
			{
				case FieldXmlType.Attribute:
					result.Value = element.GetAttribute(definition.Name);
				break;

				case FieldXmlType.Constant:
					result.Value = definition.ConstantValue;
				break;

				case FieldXmlType.Element:
					var childElement = element.SelectSingleNode(definition.Name);
					if(childElement != null)
					{
						result.Value = childElement.InnerText;
					}
				break;

				default:
					throw new NotSupportedException(string.Format("Type:'{0}' is not supported", definition.Type));
			}
			return result;
		}
	}
}
