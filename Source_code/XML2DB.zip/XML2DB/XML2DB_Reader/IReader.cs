﻿namespace XML2DB_Reader
{
	public interface IReader
	{
		Element Read();
		bool Finished { get; }
	}
}
