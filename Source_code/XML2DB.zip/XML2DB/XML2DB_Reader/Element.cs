﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XML2DB_Reader
{
    public class Element
    {
		public Element(string name)
		{
			this.Name = name;
		}

		public List<Element> ChildElements = new List<Element>();
		public Dictionary<string, Field> Fields = new Dictionary<string, Field>();

		public string Name { get; private set; }
	}
}
