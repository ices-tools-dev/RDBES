﻿using System;
using System.Xml;

namespace XML2DB_Reader
{
	internal static class Extensions
	{
		public static XmlElement FindRootElementByName(this XmlDocument xmlDocument, string name)
		{
			XmlElement current = xmlDocument.DocumentElement;
			while(true)
			{
				if(current.Name.Equals(name, StringComparison.InvariantCultureIgnoreCase))
				{
					return current;
				}
				if(current.ChildNodes.Count != 1)
				{
					throw new Exception($"Failed to find element: '{name}' inside XML");
				}
				current = (XmlElement)current.FirstChild;
			}
		}
	}
}
