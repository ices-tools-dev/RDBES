﻿using System;

namespace XML2DB_Reader {
	public class Field
	{
		public Field(string name)
		{
			this.Name = name;
		}

		public string Value { get; set; }
		public string Name { get; private set; }
	}
}
