﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using XML2DB_Reader.Definitions;

namespace XML2DB_Reader
{
	public class Loader
	{
		private XmlDocument xmlDocument;
		private Dictionary<string, ElementDefinition> elementDefinitions = new Dictionary<string, ElementDefinition>();

		private ElementLoader elementLoader = new ElementLoader();
		private string rootElementName = string.Empty;

		public Loader(string pathToXmlFile, XmlDefinition xmlDefinition)
		{ 
			xmlDocument = new XmlDocument();
			xmlDocument.Load(pathToXmlFile);
			foreach(var elementDefinition in xmlDefinition.ElementDefinitions)
			{
				this.elementDefinitions.Add(elementDefinition.Name.ToLower(), elementDefinition);
			}
			this.rootElementName = xmlDefinition.RootElementName;
		}


		public List<Element> ReadAll()
		{
			List<Element> result = new List<Element>();
			XmlElement rootElement = xmlDocument.FindRootElementByName(this.rootElementName);
			foreach (XmlElement xmlElement in rootElement)
			{
				ElementDefinition definition;
				if(elementDefinitions.TryGetValue(xmlElement.Name.ToLower(), out definition))
				{
					result.Add(elementLoader.LoadElement(xmlElement, definition));
				}
				else
				{
					throw new Exception(string.Format("Missing definition for xml element with name: '{0}'", xmlElement.Name));
				}
			}
			return result;
		}

	}
}
