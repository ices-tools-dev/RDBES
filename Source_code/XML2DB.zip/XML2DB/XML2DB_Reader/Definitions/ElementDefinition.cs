﻿using System;
using System.Collections.Generic;

namespace XML2DB_Reader.Definitions
{
    public class ElementDefinition
    {
		public List<ElementDefinition> ChildElementsDefinitions=new List<ElementDefinition>();
		public List<FieldDefinition> FieldDefinitions = new List<FieldDefinition>();

		public string Name { get; set; }

		public ElementDefinition AddChilds(params ElementDefinition[] childDefinitions)
		{
			foreach(var childDefinition in childDefinitions)
			{
				this.ChildElementsDefinitions.Add(childDefinition);
			}
			return this;
		}
    }
}
