﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XML2DB_Reader.Definitions
{
	public abstract class XmlDefinition
	{
		public string RootElementName { get { return this.RecordType; } }
		public List<ElementDefinition> ElementDefinitions { get; protected set; }

		public XmlDefinition()
		{
			ElementDefinitions = new List<ElementDefinition>();
		}

		public void AddNestedDefinitions(params ElementDefinition[] definitions)
		{
			ElementDefinition current = null;
			bool isFirst = true;
			foreach (var elementDefinition in definitions)
			{
				if (current != null)
				{
					current.ChildElementsDefinitions.Add(elementDefinition);
				}
				current = elementDefinition;
				if (isFirst)
				{
					this.ElementDefinitions.Add(current);
				}
				isFirst = false;
			}
		}

		// add record type for all elements and subelements
		protected void SetUpRecordTypes()
		{
			foreach (var definition in ElementDefinitions)
			{
				SetUpRecordType(definition);
			}
		}

		protected void SetUpRecordType(ElementDefinition definition)
		{
			definition.FieldDefinitions.Add(new FieldDefinition("RecordType", FieldXmlType.Constant, definition.Name));
			foreach (var child in definition.ChildElementsDefinitions)
			{
				SetUpRecordType(child);
			}
		}


		protected virtual string RecordType { get { return this.GetType().Name; } }

	}
}
