﻿namespace XML2DB_Reader.Definitions 
{
	public enum FieldXmlType : byte 
	{
		Attribute = 1,
		Element = 2,
		/// <summary>
		/// Special case, when we need to have a constant value which will not be read from the XML
		/// </summary>
		Constant = 3
	}
}
