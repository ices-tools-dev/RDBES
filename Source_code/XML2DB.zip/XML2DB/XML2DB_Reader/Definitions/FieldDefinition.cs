﻿namespace XML2DB_Reader.Definitions
{
    public class FieldDefinition
    {
		public FieldDefinition(string name, FieldXmlType type = FieldXmlType.Element, string constantValue = "")
		{
			this.ConstantValue = constantValue;
			this.Name = name;
			this.Type = type;
		}

		public string ConstantValue { get; private set; }
		public string Name { get; private set; }
		public FieldXmlType Type { get; private set; }
	}
}
