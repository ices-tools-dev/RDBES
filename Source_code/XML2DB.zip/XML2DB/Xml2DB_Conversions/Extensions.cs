﻿using System.Collections.Generic;
using XML2DB_Reader.Definitions;

namespace Xml2DB_Conversions
{
	internal static class Extensions
    {
		public static void AddMultiple(this List<FieldDefinition> list, FieldXmlType type, params string[] names)
		{ 
			foreach(string name in names)
			{
				list.Add(new FieldDefinition(name, type));
			}
		}
    }
}
