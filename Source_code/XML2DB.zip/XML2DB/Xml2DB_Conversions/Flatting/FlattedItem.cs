﻿namespace Xml2DB_Conversions.Flatting
{
	/// <summary>
	/// Reperesents a single element from a flattened hierarchy with its respective level
	/// </summary>
	internal  class FlattedItem
	{
		public int Level { get; set; }
		public string Name { get; set; }
		public object Content { get; set; }

		public override string ToString()
		{
			return $"{Name}({Level})";
		}
	}
}
