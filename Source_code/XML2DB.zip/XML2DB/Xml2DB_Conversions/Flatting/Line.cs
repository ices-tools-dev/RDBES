﻿using System.Collections.Generic;

namespace Xml2DB_Conversions.Flatting
{
	/// <summary>
	/// represents a single line of a flattened hierarchy
	/// </summary>
	internal class Line : Dictionary<string, FlattedItem>
	{
		public Line Clone(int untilLevel)
		{
			Line cloned = new Line();
			foreach (FlattedItem item in this.Values)
			{
				if (item.Level < untilLevel)
				{
					cloned.Add(item.Name, item);
				}
			}
			return cloned;
		}

		public void Add(FlattedItem item)
		{
			this.Add(item.Name, item);
		}

		public override string ToString()
		{
			return string.Join(',', this.Values);
		}
	}
}
