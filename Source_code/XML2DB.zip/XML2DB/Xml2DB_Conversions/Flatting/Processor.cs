﻿using System.Collections;
using System.Collections.Generic;
using System.Text;
using XML2DB_Mapping;

namespace Xml2DB_Conversions.Flatting
{
	internal static class Processor
	{
		/// <summary>
		/// flatten hierarchy into a flat list 
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		internal static IEnumerable<Line> FlattenHierarchy(IEnumerable<object> input)
		{
			List<Line> result = new List<Line>();
			foreach (var inputItem in input)
			{
				Line line = new Line();
				FlattedItem item = new FlattedItem { Level = 0, Name = inputItem.GetType().Name, Content = inputItem };
				line.Add(item);
				result.Add(line);
				FlattenChilds(item, result);
			}
			return result;
		}

		public static string ShowAsString(List<Line> lines)
		{
			StringBuilder sbresult = new StringBuilder();
			foreach (Line line in lines)
			{
				sbresult.AppendLine(line.ToString());
			}
			return sbresult.ToString();
		}

		private static void FlattenChilds(FlattedItem parent, List<Line> lines)
		{
			int currentLevel = parent.Level + 1;
			bool isFirstInList = true;
			foreach (var childList in ReflectionUtils.GetObjectChildLists(parent.Content))
			{
				foreach (var child in (IEnumerable)childList)
				{
					FlattedItem item = new FlattedItem { Level = currentLevel, Name = child.GetType().Name, Content = child };
					Line currentLine;
					if (isFirstInList)
					{
						currentLine = lines[lines.Count - 1];
						isFirstInList = false;
					}
					else
					{
						currentLine = lines[lines.Count - 1].Clone(currentLevel);
						lines.Add(currentLine);
					}
					currentLine.Add(item);
					FlattenChilds(item, lines);
				}
			}

		}


	}
}
