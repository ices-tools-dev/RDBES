﻿using System;
using System.Collections.Generic;
using System.Text;
using Xml2DB_DAL.Models;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.IdLookup
{
	public class IdLookup : IidLookup
	{
		private Dictionary<IdLookupType, Dictionary<string, int>> indexedContent;
		public class SLItem
		{
			public int Slid { get; set; }
			public int Slcountry { get; set; }
			public string SlspeciesListName { get; set; }

			public int Slyear { get; set; }
			public int SlcatchFraction { get; set; }
		}

		public IdLookup(IEnumerable<SLItem> slItems, IEnumerable<VesselDetail> vdItems)
		{
			indexedContent = new Dictionary<IdLookupType, Dictionary<string, int>>();
			LoadSamplingDetailsContent(slItems);
			LoadVesselDetailsContent(vdItems);
		}

		public int GetId(IdLookupType type, string combinedKey)
		{
			if (!indexedContent.ContainsKey(type))
			{
				throw new InvalidOperationException($"There is no loaded content for type: {type}");
			}
			int result;
			if (indexedContent[type].TryGetValue(combinedKey, out result))
			{
				return result;
			}
			throw new InvalidOperationException($"Failed to find id for type: {type} and combined key: {combinedKey}");
		}

		public string GetSpeciesListKey(int slCountry, string slSpeciesListName, int slYear, int slCatchFraction)
		{
			return $"{slCountry}|{slSpeciesListName}|{slYear}|{slCatchFraction}";
		}

		public string GetVesselDetailsKey(int vdCountry, string vdEncryptedVesselCode, int vdYear)
		{
			return $"{vdCountry}|{vdEncryptedVesselCode}|{vdYear}";
		}

		private void LoadSamplingDetailsContent(IEnumerable<SLItem> slItems)
		{
			Dictionary<string, int> slContent = new Dictionary<string, int>();
			indexedContent.Add(IdLookupType.SpeciesList, slContent);
			foreach (var sl in slItems)
			{
				slContent.Add(GetSpeciesListKey(sl.Slcountry,sl.SlspeciesListName, sl.Slyear, sl.SlcatchFraction), sl.Slid);
			}
		}

		private void LoadVesselDetailsContent(IEnumerable<VesselDetail> vdItems)
		{
			Dictionary<string, int> vdContent = new Dictionary<string, int>();
			indexedContent.Add(IdLookupType.VesselDetails, vdContent);
			foreach (var vd in vdItems)
			{
				vdContent.Add(GetVesselDetailsKey(vd.Vdcountry, vd.VdencryptedVesselCode, vd.Vdyear), vd.Vdid);
			}
		}

	}
}
