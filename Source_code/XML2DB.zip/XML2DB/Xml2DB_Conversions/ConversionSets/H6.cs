﻿using System;
using Xml2DB_DAL;
using Xml2DB_DAL.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Linq.Expressions;

namespace Xml2DB_Conversions.ConversionSets {
	public class H6 : ConversionSet
	{
		public H6()
		{
			this.XmlSet = new XmlMappings.XmlSets.H6();
			this.Mapping = new DbMappings.MappingSets.H6();
		}

        public override Design LoadFromDb(DatabaseContext context, Expression<Func<Design, bool>> predicate)
        {
            var dbRecord = context.Designs
                .Include(a => a.SamplingDetails)
                    .ThenInclude(a => a.OnshoreEvents)
                        .ThenInclude(a => a.FishingTrips)
                            .ThenInclude(a => a.FishingOperations)
                                .ThenInclude(a => a.LandingEvents)
                .Include(a => a.SamplingDetails)
                    .ThenInclude(a => a.OnshoreEvents)
                        .ThenInclude(a => a.FishingTrips)
                            .ThenInclude(a => a.FishingOperations)
                                .ThenInclude(a => a.SpeciesSelections)
                                    .ThenInclude(a => a.Samples)
                                        .ThenInclude(a => a.BiologicalVariables)
                .Include(a => a.SamplingDetails)
                    .ThenInclude(a => a.OnshoreEvents)
                        .ThenInclude(a => a.FishingTrips)
                            .ThenInclude(a => a.FishingOperations)
                                .ThenInclude(a => a.SpeciesSelections)
                                    .ThenInclude(a => a.Samples)
                                        .ThenInclude(a => a.FrequencyMeasures)
                                                .ThenInclude(a => a.BiologicalVariables)
                .Include(a => a.SamplingDetails)
                    .ThenInclude(a => a.OnshoreEvents)
                        .ThenInclude(a => a.FishingTrips)
                            .ThenInclude(a => a.SpeciesSelections)
                                .ThenInclude(a => a.Samples)
                                    .ThenInclude(a => a.BiologicalVariables)

                .Include(a => a.SamplingDetails)
                    .ThenInclude(a => a.OnshoreEvents)
                        .ThenInclude(a => a.FishingTrips)
                            .ThenInclude(a => a.SpeciesSelections)
                                .ThenInclude(a => a.Samples)
                                    .ThenInclude(a => a.FrequencyMeasures)
                                        .ThenInclude(a => a.BiologicalVariables)
                .Where(predicate)
                .Select(d => d)
                .SingleOrDefault();
            return dbRecord;
        }

    }
}
