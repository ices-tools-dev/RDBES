﻿namespace Xml2DB_Conversions.ConversionSets
{
	public class HCL : ConversionSet
    {
        public HCL()
        {
            this.XmlSet = new XmlMappings.XmlSets.HCL();
            this.Mapping = new DbMappings.MappingSets.HCL();
        }


    }
}
