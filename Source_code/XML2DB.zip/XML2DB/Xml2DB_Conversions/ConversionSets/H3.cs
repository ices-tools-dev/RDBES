﻿using System;
using Xml2DB_DAL;
using Xml2DB_DAL.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Linq.Expressions;

namespace Xml2DB_Conversions.ConversionSets {
	public class H3 : ConversionSet
	{
		public H3()
		{
			this.XmlSet = new XmlMappings.XmlSets.H3();
			this.Mapping = new DbMappings.MappingSets.H3();
		}

		public override Design LoadFromDb(DatabaseContext context, Expression<Func<Design, bool>> predicate)
		{
			var dbRecord = context.Designs
				.Include(a => a.SamplingDetails)
					.ThenInclude(a => a.TemporalEvents)
						.ThenInclude(a => a.VesselSelections)
							.ThenInclude(a => a.FishingTrips)
								.ThenInclude(a => a.FishingOperations)
									.ThenInclude(a => a.SpeciesSelections)
										.ThenInclude(a => a.Samples)
											.ThenInclude(a => a.BiologicalVariables)
				.Include(a => a.SamplingDetails)
					.ThenInclude(a => a.TemporalEvents)
						.ThenInclude(a => a.VesselSelections)
							.ThenInclude(a => a.FishingTrips)
								.ThenInclude(a => a.FishingOperations)
									.ThenInclude(a => a.SpeciesSelections)
										.ThenInclude(a => a.Samples)
											.ThenInclude(a => a.FrequencyMeasures)
												.ThenInclude(a => a.BiologicalVariables)
				.Where(predicate)
				.Select(d => d)
				.SingleOrDefault();
			return dbRecord;
		}
	}
}
