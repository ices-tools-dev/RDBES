﻿namespace Xml2DB_Conversions.ConversionSets
{
    public class HVD  : ConversionSet
    {
        public HVD()
        {
            this.XmlSet = new XmlMappings.XmlSets.HVD();
            this.Mapping = new DbMappings.MappingSets.HVD();
        }

    }
}
