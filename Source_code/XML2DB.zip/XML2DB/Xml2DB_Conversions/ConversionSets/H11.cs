﻿using System;
using Xml2DB_DAL;
using Xml2DB_DAL.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Linq.Expressions;

namespace Xml2DB_Conversions.ConversionSets {

	public class H11 : ConversionSet
	{
		public H11()
		{
			this.XmlSet = new XmlMappings.XmlSets.H11();
			this.Mapping = new DbMappings.MappingSets.H11();
		}

		public override Design LoadFromDb(DatabaseContext context, Expression<Func<Design, bool>> predicate)
		{
			var dbRecord = context.Designs
				.Include(a => a.SamplingDetails)
					.ThenInclude(a => a.Locations)
						.ThenInclude(a => a.TemporalEvents)
							.ThenInclude(a => a.FishingTrips)
								.ThenInclude(a => a.LandingEvents)
				.Include(a => a.SamplingDetails)
					.ThenInclude(a => a.Locations)
						.ThenInclude(a => a.TemporalEvents)
							.ThenInclude(a => a.FishingTrips)
								.ThenInclude(a => a.SpeciesSelections)
									.ThenInclude(a => a.Samples)
										.ThenInclude(a => a.BiologicalVariables)
				.Include(a => a.SamplingDetails)
					.ThenInclude(a => a.Locations)
						.ThenInclude(a => a.TemporalEvents)
							.ThenInclude(a => a.FishingTrips)
								.ThenInclude(a => a.SpeciesSelections)
									.ThenInclude(a => a.Samples)
										.ThenInclude(a => a.FrequencyMeasures)
											.ThenInclude(a => a.BiologicalVariables)
				.Where(predicate)
				.Select(d => d)
				.SingleOrDefault();
			return dbRecord;
		}

	}
}
