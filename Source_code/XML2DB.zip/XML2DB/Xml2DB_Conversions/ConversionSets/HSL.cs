﻿namespace Xml2DB_Conversions.ConversionSets
{
    public class HSL  : ConversionSet
    {
        public HSL()
        {
            this.XmlSet = new XmlMappings.XmlSets.HSL();
            this.Mapping = new DbMappings.MappingSets.HSL();
        }

    }
}
