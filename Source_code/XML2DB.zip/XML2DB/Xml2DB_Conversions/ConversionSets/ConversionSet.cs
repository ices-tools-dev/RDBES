﻿using System;
using System.Linq.Expressions;
using System.Reflection;
using Xml2DB_Conversions.DbMappings.MappingSets;
using Xml2DB_DAL;
using Xml2DB_DAL.Models;
using XML2DB_Reader.Definitions;

namespace Xml2DB_Conversions.ConversionSets
{
	public abstract class ConversionSet
	{
		public XmlDefinition XmlSet{get; protected set;}
		public MappingSet Mapping{get; protected set;}
		public virtual Design LoadFromDb(DatabaseContext context, Expression<Func<Design, bool>> predicate) { return null; }

		public static ConversionSet GetByHierarchyName(string hierarchyName)
		{
			Assembly assembly = typeof(ConversionSet).Assembly;
			string typeName = $"{typeof(ConversionSet).Namespace}.{hierarchyName}";
			Type type = assembly.GetType(typeName);
			if (type == null)
			{
				throw new Exception($"Failed to find class '{typeName}'");
			}
			if (!typeof(ConversionSet).IsAssignableFrom(type))
			{
				throw new Exception($"'{typeName}' is not inheriting from {typeof(ConversionSet).FullName}");
			}
			return (ConversionSet)Activator.CreateInstance(type);
		}
	}
}
