﻿namespace Xml2DB_Conversions.ConversionSets
{
    public class HCE : ConversionSet
    {
        public HCE()
        {
            this.XmlSet = new XmlMappings.XmlSets.HCE();
            this.Mapping = new DbMappings.MappingSets.HCE();
        }

    }
}
