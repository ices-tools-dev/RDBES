﻿using XML2DB_Reader.Definitions;
using Xml2DB_ConversionDefinitions.XmlMappings.XmlElements;

namespace Xml2DB_Conversions
{
    static class Helper
    {
        public static ElementDefinition[]  CreateSecondaryLevel()
        {
            ElementDefinition[] result = new ElementDefinition[2] {
                new BV(),
                new FM().AddChilds(new BV()),
            };

            return result;
        }

    }
}
