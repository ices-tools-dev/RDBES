﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Xml2DB_Conversions
{
	public class DebugUtils
	{
		public static Action<string> LogAction { get; set; } = (string message) => Debug.WriteLine(message);
		public static void MeasureTime(string operationName, Action action)
		{
			Stopwatch sw = new Stopwatch();
			sw.Start();
			action.Invoke();
			sw.Stop();
			LogAction($"[{operationName}] : {sw.Elapsed.TotalSeconds} seconds");
		}
		
		public static async Task MeasureTimeAsync(string operationName, Func<Task> action)
		{
			Stopwatch sw = new Stopwatch();
			sw.Start();
			await action.Invoke();
			sw.Stop();
			LogAction($"[{operationName}] : {sw.Elapsed.TotalSeconds} seconds");
		}


	}
}
