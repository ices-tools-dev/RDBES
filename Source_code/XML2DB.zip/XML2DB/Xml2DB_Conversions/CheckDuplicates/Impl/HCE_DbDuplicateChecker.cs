﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Xml2DB_Conversions.CheckDuplicates.ResultTypes;
using Xml2DB_DAL;

namespace Xml2DB_Conversions.CheckDuplicates.Impl
{
    class HCE_DbDuplicateChecker : DbDuplicateCheckerBase<HCE_DuplicateInfo>
    {
        public HCE_DbDuplicateChecker(DatabaseContext context) : base(context) { }

        protected override string TableName => "CommercialEffort";
        protected override string IDColumnName => "CEid";

        public override async Task<List<HCE_DuplicateInfo>> Check(IEnumerable<object> recordsToCheck)
        {
            var adjustedRecords = DuplicatesCheckerHelper.ExtractInfoForFlatDuplicatesCheck<HCE_DuplicateInfo>("HCE", recordsToCheck);
            return await CheckTyped(adjustedRecords);
        }


    }
}
