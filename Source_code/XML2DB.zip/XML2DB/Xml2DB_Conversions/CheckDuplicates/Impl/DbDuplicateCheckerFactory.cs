﻿using System;
using Xml2DB_Conversions.ConversionSets;
using Xml2DB_DAL;

namespace Xml2DB_Conversions.CheckDuplicates.Impl
{
    public class DbDuplicateCheckerFactory : IDbDuplicateCheckerFactory
    {
        public IDbDuplicateChecker<TResult> CreateDbDuplicateChecker<TResult>(DatabaseContext context, string hierarchyName)
        {
            switch (hierarchyName)
            {
                case nameof(HCE):
                    return new HCE_DbDuplicateChecker(context) as IDbDuplicateChecker<TResult>;
                case nameof(HCL):
                    return new HCL_DbDuplicateChecker(context) as IDbDuplicateChecker<TResult>;
                case nameof(HSL):
                    return new HSL_DbDuplicateChecker(context) as IDbDuplicateChecker<TResult>;
                case nameof(HVD):
                    return new HVD_DbDuplicateChecker(context) as IDbDuplicateChecker<TResult>;
                case nameof(H1):
                case nameof(H2):
                case nameof(H3):
                case nameof(H4):
                case nameof(H5):
                case nameof(H6):
                case nameof(H7):
                case nameof(H8):
                case nameof(H9):
                case nameof(H10):
                case nameof(H11):
                case nameof(H12):
                case nameof(H13):
                    return new HCS_DbDuplicateChecker(context, hierarchyName) as IDbDuplicateChecker<TResult>;

                default:
                    throw new NotSupportedException($"Unrecognized hierarchy: {hierarchyName}");
            }
        }


    }


}
