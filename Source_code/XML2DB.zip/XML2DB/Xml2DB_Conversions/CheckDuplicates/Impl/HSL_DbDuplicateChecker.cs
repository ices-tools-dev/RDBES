﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Xml2DB_Conversions.CheckDuplicates.ResultTypes;
using Xml2DB_DAL;

namespace Xml2DB_Conversions.CheckDuplicates.Impl
{
	class HSL_DbDuplicateChecker : DbDuplicateCheckerBase<HSL_DuplicateInfo>
	{
		public HSL_DbDuplicateChecker(DatabaseContext context) : base(context) { }

		protected override string TableName => "SpeciesList";
		protected override string IDColumnName => "SLid";

		public override async Task<List<HSL_DuplicateInfo>> Check(IEnumerable<object> recordsToCheck)
		{
			var adjustedRecords = DuplicatesCheckerHelper.ExtractInfoForDuplicatesCheck<HSL_DuplicateInfo>("HSL", recordsToCheck);
			return await CheckTyped(adjustedRecords);
		}


	}
}
