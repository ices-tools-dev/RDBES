﻿using Dapper;
using FastMember;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xml2DB_Conversions.CheckDuplicates.ResultTypes;
using Xml2DB_DAL;

namespace Xml2DB_Conversions.CheckDuplicates.Impl
{
	public abstract class DbDuplicateCheckerBase<TResult> : IDbDuplicateChecker<TResult> where TResult : DuplicateInfoBase, new()
	{
		public const int DB_COMMAND_TIMEOUT_SECONDS = 120;
		protected readonly DatabaseContext _context;
		protected const string TEMP_TABLE_NAME = "#tmpDuplicates";
		protected static readonly TResult resultInstance = new TResult();

		public DbDuplicateCheckerBase(DatabaseContext context)
		{
			_context = context;
		}

		protected virtual string CreateTempTableSql()
		{
			return
$@"
CREATE TABLE {TEMP_TABLE_NAME}(
	[ID] [int] IDENTITY(1,1) NOT NULL primary key,
	{resultInstance.GetColumnNamesTempTableSql()},
	[LineNo]	INT NOT NULL
)";
		}

		protected virtual void SetupColumnMappings(SqlBulkCopy sqlBulkCopy)
		{
			foreach (var columnInfo in resultInstance.GetColumnAttributes().Where(ci => ci.IsIncludedInDuplicateCheckSet))
			{
				sqlBulkCopy.ColumnMappings.Add(columnInfo.ColumnName, columnInfo.ColumnName);
			}
		}

		protected virtual string TableName { get; }
		protected virtual string IDColumnName { get; }

		public abstract Task<List<TResult>> Check(IEnumerable<object> recordsToCheck);

		protected virtual async Task<List<TResult>> CheckTyped<T>(IEnumerable<T> recordsToCheck)
		{
			using (var conn = new SqlConnection(_context.ConnectionString))
			{
				conn.Open();
				await Save(recordsToCheck, conn);
				return await LoadDuplicates(conn);
			}
		}

		private async Task Save<T>(IEnumerable<T> items, SqlConnection conn)
		{
			await DebugUtils.MeasureTimeAsync($"{this.GetType().Name}.Save",
				async () =>
					{
						new SqlCommand(CreateTempTableSql(), conn).ExecuteNonQuery();
						using (var bulkCopy = new SqlBulkCopy(conn))
						{
							bulkCopy.BulkCopyTimeout = 10;
							bulkCopy.BatchSize = 500;
							bulkCopy.DestinationTableName = TEMP_TABLE_NAME;
							SetupColumnMappings(bulkCopy);
							bulkCopy.ColumnMappings.Add("LineNo", "LineNo");
							bulkCopy.EnableStreaming = true;
							using (var dataReader = ObjectReader.Create(items))
							{
								await bulkCopy.WriteToServerAsync(dataReader);
							}
						}
					}
				);
		}

		private async Task<List<TResult>> LoadDuplicates(SqlConnection conn)
		{
			string sql = QueryForDuplicatesChecking;
			List<TResult> result = null;
			await DebugUtils.MeasureTimeAsync($"{this.GetType().Name}.LoadDuplicates",
				async () =>
				{
					result = (await conn.QueryAsync<TResult>(sql, null, null, DB_COMMAND_TIMEOUT_SECONDS, null)).ToList();

				});
			return result;
		}

		protected virtual string QueryForDuplicatesChecking
		{
			get
			{
				string columnsCommaSeparated = resultInstance.GetColumnsCommaSeparated();
				string sql =
	$@"
SELECT {columnsCommaSeparated},
{TableName}.{IDColumnName}

INTO #tmpSelection
	
FROM {TableName}

GROUP BY 
{columnsCommaSeparated},
{IDColumnName}
;

SELECT 
{resultInstance.GetColumnsForSelectStatement("#tmpSelection")}
{IDColumnName},
{TEMP_TABLE_NAME}.[LineNo]
FROM #tmpSelection
INNER JOIN {TEMP_TABLE_NAME}
ON {GetSqlWithTableNames()}
";
				return sql;
			}
		}

		protected string GetSqlWithTableNames()
		{
			StringBuilder sbResult = new StringBuilder();
			foreach (var columnInfo in resultInstance.GetColumnAttributes().Where(ci => ci.IsIncludedInDuplicateCheckSet))
			{
				if (sbResult.Length > 0)
				{
					sbResult.Append("AND ");
				}
				MakeEquation(sbResult, columnInfo.ColumnName, columnInfo.TypeDefinition);
			}
			return sbResult.ToString();
		}

		protected void MakeEquation(StringBuilder sb, string columnName, string typeDefinition)
		{
			if (typeDefinition.Equals(Constants.INT_NULL))
			{
				sb.AppendLine($"((#tmpSelection.{columnName} IS NULL AND {TEMP_TABLE_NAME}.{columnName} IS NULL) OR (#tmpSelection.{columnName} =  {TEMP_TABLE_NAME}.{columnName}))");
			}
			else
			{
				sb.AppendLine($"#tmpSelection.{columnName} = {TEMP_TABLE_NAME}.{columnName}");
			}
		}

	}
}
