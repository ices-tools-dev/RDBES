﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Xml2DB_Conversions.CheckDuplicates.ResultTypes;
using Xml2DB_DAL;

namespace Xml2DB_Conversions.CheckDuplicates.Impl
{
	class HVD_DbDuplicateChecker : DbDuplicateCheckerBase<HVD_DuplicateInfo>
	{
		public HVD_DbDuplicateChecker(DatabaseContext context) : base(context) { }


		protected override string TableName => "VesselDetails";
		protected override string IDColumnName => "VDid";

		public override async Task<List<HVD_DuplicateInfo>> Check(IEnumerable<object> recordsToCheck)
		{
			var adjustedRecords = DuplicatesCheckerHelper.ExtractInfoForDuplicatesCheck<HVD_DuplicateInfo>("HVD", recordsToCheck);
			return await CheckTyped(adjustedRecords);
		}


	}
}
