﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Xml2DB_Conversions.CheckDuplicates.ResultTypes;
using Xml2DB_DAL;

namespace Xml2DB_Conversions.CheckDuplicates.Impl
{
	class HCL_DbDuplicateChecker : DbDuplicateCheckerBase<HCL_DuplicateInfo>
	{
		public HCL_DbDuplicateChecker(DatabaseContext context) : base(context) { }

		protected override string TableName => "CommercialLanding";

		protected override string IDColumnName => "CLid";

		public override async Task<List<HCL_DuplicateInfo>> Check(IEnumerable<object> recordsToCheck)
		{
			var adjustedRecords = DuplicatesCheckerHelper.ExtractInfoForFlatDuplicatesCheck<HCL_DuplicateInfo>("HCL", recordsToCheck);
			return await CheckTyped(adjustedRecords);
		}
	}
}
