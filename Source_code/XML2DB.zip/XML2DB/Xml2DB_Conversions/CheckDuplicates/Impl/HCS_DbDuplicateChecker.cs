﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xml2DB_Conversions.CheckDuplicates.ResultTypes;
using Xml2DB_Conversions.ConversionSets;
using Xml2DB_DAL;
using Xml2DB_DAL.CustomModels;
using XML2DB_Mapping;

namespace Xml2DB_Conversions.CheckDuplicates.Impl
{
	/// <summary>
	/// Covers hierarchies H1-13 
	/// </summary>
	class HCS_DbDuplicateChecker : DbDuplicateCheckerBase<HCS_DuplicateInfo>
	{
		private readonly string _hierarchyName;
		public HCS_DbDuplicateChecker(DatabaseContext context, string hierarhyName) : base(context)
		{
			_hierarchyName = hierarhyName;
		}


		protected override string QueryForDuplicatesChecking
		{
			get
			{
				var relatedTables = ConstructRelatedTables();
				string columnsCommaSeparated = resultInstance.GetColumnsCommaSeparated();

				string sql =
	$@"
SELECT {columnsCommaSeparated},
Design.DEid,
SamplingDetails.SDid

INTO #tmpSelection

FROM {relatedTables.GetSql()}

GROUP BY 
{columnsCommaSeparated},
Design.DEid, SamplingDetails.SDid
;

SELECT {resultInstance.GetColumnsForSelectStatement("#tmpSelection")}
DEid, SDid,
{TEMP_TABLE_NAME}.[LineNo]
FROM #tmpSelection
INNER JOIN {TEMP_TABLE_NAME}
ON {GetSqlWithTableNames()}
";
				return sql;
			}
		}

		public override async Task<List<HCS_DuplicateInfo>> Check(IEnumerable<object> recordsToCheck)
		{
			var adjustedRecords = DuplicatesCheckerHelper.ExtractInfoForDuplicatesCheck<HCS_DuplicateInfo>(_hierarchyName, recordsToCheck);
			return await CheckTyped(adjustedRecords);
		}

		private TableRelation ConstructRelatedTables()
		{
			TableRelation lastTable = null;
			var conversionSet = ConversionSet.GetByHierarchyName(_hierarchyName);
			// iterate all objects in the mappings list until the last column in the list is discovered, then 
			string fieldToFind = resultInstance.GetColumnAttributes().Last().ColumnName.Replace("[", string.Empty).Replace("]", string.Empty);

			var mappingWithLastField = FindInList(conversionSet.Mapping.ElementMappings, fieldToFind);

			if (mappingWithLastField == null)
			{
				throw new Exception($"Could not find column: '{fieldToFind}' in the hierarchy.");
			}
			// field is found, now construct the chain by going from the bootom ot the list to the top
			lastTable = new TableRelation();
			lastTable.Info.TableName = mappingWithLastField.TableName;
			lastTable.Info.IDColumnName = string.Concat(mappingWithLastField.ElementName, "Id");
			AppendParent(lastTable, mappingWithLastField.ParentElement);

			TableRelation firstTable = lastTable;
			while (firstTable.Parent != null)
			{
				firstTable = firstTable.Parent;
			}
			return firstTable;
		}


		private ElementMapping FindInList(List<ElementMapping> mappings, string propertyNameToFind)
		{
			foreach (var mapping in mappings)
			{
				if (mapping.FieldMappings.Values.Where(val => val.PropertyName.Equals(propertyNameToFind, StringComparison.InvariantCultureIgnoreCase)).Count() > 0)
				{
					return mapping;
				}
				var fromChildResult = FindInList(mapping.ChildElmentsMappings.Values.ToList(), propertyNameToFind);
				if (fromChildResult != null)
				{
					return fromChildResult;
				}
			}
			return null;
		}

		private void AppendParent(TableRelation table, ElementMapping mapping)
		{
			TableRelation parent = new TableRelation();
			parent.Info.TableName = mapping.TableName;
			parent.Info.IDColumnName = string.Concat(mapping.ElementName, "Id");
			table.SetParent(parent);
			if (mapping.ParentElement != null)
			{
				AppendParent(table.Parent, mapping.ParentElement);
			}
		}

	}
}
