﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Xml2DB_Conversions.CheckDuplicates.Impl
{
	internal class Constants
	{
		public const string INT_NOT_NULL = "INT NOT NULL";
		public const string INT_NULL = "INT NULL";
	}
}
