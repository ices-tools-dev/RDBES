﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Xml2DB_Conversions.CheckDuplicates.Impl
{
	internal class DbColumnInformationAttribute : Attribute
	{
		public string ColumnName { get; set; }
		public string TypeDefinition { get; set; }
		/// <summary>
		/// Indicates that this column is tblCode related, and we need not the tblCodeId, which is contained in this column, 
		/// but the actual value of the related 'Code' field from tblCode table
		/// </summary>
		public bool UseCode { get; set; }

		/// <summary>
		///  Indicates that this column is of the duplicate check set
		/// </summary>
		public bool IsIncludedInDuplicateCheckSet { get; set; }

		public DbColumnInformationAttribute(bool isIncludedInDuplicateCheckSet = true, string typeDefinition = null, string columName = "", bool useCode = false)
		{
			IsIncludedInDuplicateCheckSet = isIncludedInDuplicateCheckSet;
			TypeDefinition = typeDefinition;
			ColumnName = columName;
			UseCode = useCode;
		}
	}
}
