﻿using System;
using System.Collections.Generic;
using Xml2DB_Conversions.Flatting;
using Xml2DB_DAL.Models;
using XML2DB_Mapping;

namespace Xml2DB_Conversions.CheckDuplicates
{
    public static class DuplicatesCheckerHelper
    {
        private static readonly Dictionary<string, List<DuplicatesSingleItemValues>> duplicateSettings = new();

        static DuplicatesCheckerHelper()
        {
            LoadDuplicateSettings();
        }

        public static IEnumerable<TResult> ExtractInfoForDuplicatesCheck<TResult>(string hierarchyName, IEnumerable<object> dataObjects)
            where TResult : class, new()
        {
            var valuesToExtract = duplicateSettings[hierarchyName];
            var flattenedData = Processor.FlattenHierarchy(dataObjects);
            var existingCombinations = new HashSet<int>();
            foreach (var line in flattenedData)
            {
                var newRecord = new TResult();
                foreach (var setting in valuesToExtract)
                {
                    var currentObject = line[setting.TypeName];
                    if (currentObject != null)
                    {
                        foreach (var propertyName in setting.PropertiesToGet)
                        {
                            TransferValue(newRecord, currentObject.Content, propertyName);
                        }
                    }
                }
                if (!existingCombinations.Contains(newRecord.GetHashCode()))
                {
                    existingCombinations.Add(newRecord.GetHashCode());
                    yield return newRecord;
                }
            }
        }

        public static IEnumerable<TResult> ExtractInfoForFlatDuplicatesCheck<TResult>(string hierarchyName, IEnumerable<object> dataObjects)
            where TResult : class, new()
        {
            var valuesToExtract = duplicateSettings[hierarchyName];
            foreach (var dataObject in dataObjects)
            {
                var newRecord = new TResult();
                foreach (var setting in valuesToExtract)
                {
                    foreach (var propertyName in setting.PropertiesToGet)
                    {
                        TransferValue(newRecord, dataObject, propertyName);
                    }
                }
                yield return newRecord;
            }
        }

        private static bool TransferValue(object record, object model, string propertyName)
        {
            try
            {
                ReflectionUtils.SetPropertyValue(record, propertyName, ReflectionUtils.GetPropertyValue(model, propertyName));
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static void LoadDuplicateSettings()
        {
            for (int i = 1; i < 14; i++)
            {
                string hierarchyName = $"H{i}";
                duplicateSettings.Add(hierarchyName, GetSettingForHierarchy(hierarchyName));
            }
            duplicateSettings.Add("HCE", GetSettingForHierarchy("HCE"));
            duplicateSettings.Add("HCL", GetSettingForHierarchy("HCL"));
            duplicateSettings.Add("HSL", GetSettingForHierarchy("HSL"));
            duplicateSettings.Add("HVD", GetSettingForHierarchy("HVD"));
        }

        private static List<DuplicatesSingleItemValues> GetSettingForHierarchy(string hierarchyName)
        {
            var result = new List<DuplicatesSingleItemValues>();
            switch (hierarchyName)
            {
                case "H1":
                case "H2":
                case "H3":
                case "H4":
                case "H5":
                case "H6":
                case "H7":
                case "H8":
                case "H9":
                case "H10":
                case "H11":
                case "H12":
                case "H13":
                    var de = new DuplicatesSingleItemValues()
                    {
                        TypeName = nameof(Design),
                        PropertiesToGet = new List<string>
                        {
                            "DEsamplingScheme",
                            "DEyear",
                            "DEstratumName",
                            "DEhierarchy"
                        }
                    };
                    var sd = new DuplicatesSingleItemValues()
                    {
                        TypeName = nameof(SamplingDetail),
                        PropertiesToGet = new List<string>
                        {
                            "SDcountry",
                            "SDinstitution",
                            "LineNo"
                        }
                    };
                    result.Add(de);
                    result.Add(sd);
                    break;
                case "HCE":
                    var ce = new DuplicatesSingleItemValues()
                    {

                        TypeName = nameof(CommercialEffort),
                        PropertiesToGet = new List<string>
                        {
                            "CEdataTypeForScientificEffort",
                            "CEdataSourceForScientificEffort",
                            "CEsamplingScheme",
                            "CEvesselFlagCountry",
                            "CEyear",
                            "CEquarter",
                            "CEmonth",
                            "CEarea",
                            "CEstatisticalRectangle",
                            "CEgsaSubarea",
                            "CEexclusiveEconomicZoneIndicator",
                            "CEnationalFishingActivity",
                            "CEmetier6",
                            "CEincidentalByCatchMitigationDevice",
                            "CElandingLocation",
                            "CEvesselLengthCategory",
                            "CEfishingTechnique",
                            "CEdeepSeaRegulation",
                            "CEjurisdictionArea",
                            "LineNo"
                        }
                    };
                    result.Add(ce);
                    break;

                case "HCL":
                    var cl = new DuplicatesSingleItemValues()
                    {
                        TypeName = nameof(CommercialLanding),
                        PropertiesToGet = new List<string>
                        {
                            "CLdataTypeOfScientificWeight",
                            "CLdataSourceOfScientificWeight",
                            "CLsamplingScheme",
                            "CLdataSourceLandingsValue",
                            "CLlandingCountry",
                            "CLvesselFlagCountry",
                            "CLyear",
                            "CLquarter",
                            "CLmonth",
                            "CLarea",
                            "CLstatisticalRectangle",
                            "CLgsaSubarea",
                            "CLjurisdictionArea",
                            "CLexclusiveEconomicZoneIndicator",
                            "CLspeciesCode",
                            "CLspeciesFaoCode",
                            "CLlandingCategory",
                            "CLcatchCategory",
                            "CLregDisCategory",
                            "CLcommercialSizeCategoryScale",
                            "CLcommercialSizeCategory",
                            "CLnationalFishingActivity",
                            "CLmetier6",
                            "CLincidentialByCatchMitigationDevice",
                            "CLlandingLocation",
                            "CLvesselLengthCategory",
                            "CLfishingTechnique",
                            "CLdeepSeaRegulation",
                            "LineNo"
                        }
                    };
                    result.Add(cl);
                    break;

                case "HSL":
                    var sl = new DuplicatesSingleItemValues()
                    {
                        TypeName = nameof(SpeciesList),
                        PropertiesToGet = new List<string>
                        {
                            "SLcountry",
                            "SLspeciesListName",
                            "SLyear",
                            "SLcatchFraction",
                            "SLcommercialTaxon",
                            "SLspeciesCode",
                            "LineNo"
                        }
                    };
                    result.Add(sl);
                    break;

                case "HVD":
                    var vd = new DuplicatesSingleItemValues()
                    {
                        TypeName = nameof(VesselDetail),
                        PropertiesToGet = new List<string>
                        {
                            "VDCountry",
                            "VDencryptedVesselCode",
                            "VDyear",
                            "VDflagCountry",
                            "LineNo"
                        }
                    };
                    result.Add(vd);
                    break;
                default:
                    throw new NotSupportedException($"hierarchy: '{hierarchyName}' is not supported");
            }
            return result;
        }

    }
}

