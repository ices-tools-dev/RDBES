﻿using System.Collections.Generic;

namespace Xml2DB_Conversions.CheckDuplicates
{
	public class DuplicatesSingleItemValues
	{
		public string TypeName { get; set; }

		public List<string> PropertiesToGet { get; set; }
	}
}
