﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Xml2DB_Conversions.CheckDuplicates
{
	public interface IDbDuplicateChecker<TResult>
    {
        Task<List<TResult>> Check(IEnumerable<object> recordsToCheck);

    }
}
