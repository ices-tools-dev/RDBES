﻿using Xml2DB_Conversions.CheckDuplicates.Impl;

namespace Xml2DB_Conversions.CheckDuplicates.ResultTypes
{
	public class HSL_DuplicateInfo : DuplicateInfoBase
	{
		[DbColumnInformation]
		public int SLcountry { get; set; }

		[DbColumnInformation(false, "", "SLcountry", true)]
		public string SLcountryCode { get; set; }

		[DbColumnInformation(true, "NVARCHAR(100) NOT NULL")]
		public string SLspeciesListName { get; set; }

		[DbColumnInformation] 
		public int SLyear { get; set; }

		[DbColumnInformation(false, "", "SLyear", true)]
		public string SLyearCode { get; set; }

		[DbColumnInformation] 
		public int SLcatchFraction { get; set; }

		[DbColumnInformation(false, "", "SLcatchFraction", true)]
		public string SLcatchFractionCode { get; set; }

		[DbColumnInformation] 
		public int SLcommercialTaxon { get; set; }

		[DbColumnInformation(false, "", "SLcommercialTaxon", true)]
		public string SLcommercialTaxonCode { get; set; }


		[DbColumnInformation] 
		public int SLspeciesCode { get; set; }

		[DbColumnInformation(false, "", "SLspeciesCode", true)]
		public string SLspeciesCodeCode { get; set; }

		public int SLid { get; set; }
		
		public int LineNo { get; set; } = 0;


		public override string ToString()
		{
			return $@"
SLcountry = {SLcountryCode}
SLspeciesListName = {SLspeciesListName}
SLyear = {SLyearCode}
SLcatchFraction = {SLcatchFractionCode}
SLcommercialTaxon = {SLcommercialTaxonCode}
SLspeciesCode = {SLspeciesCodeCode}
SLid = {SLid}
LineNo = {LineNo}
";
		}
	}

}
