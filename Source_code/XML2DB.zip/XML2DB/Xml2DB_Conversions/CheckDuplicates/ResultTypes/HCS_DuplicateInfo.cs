﻿using Xml2DB_Conversions.CheckDuplicates.Impl;

namespace Xml2DB_Conversions.CheckDuplicates.ResultTypes
{
	public class HCS_DuplicateInfo : DuplicateInfoBase
	{

		[DbColumnInformation]
		public int DEsamplingScheme { get; set; }

		[DbColumnInformation(false, "", "DEsamplingScheme", true)]
		public string DEsamplingSchemeCode { get; set; }

		[DbColumnInformation(false)]
		public int DEsamplingSchemeType { get; set; }


		[DbColumnInformation(false, "", "DEsamplingSchemeType", true)]
		public string DEsamplingSchemeTypeCode { get; set; }


		[DbColumnInformation]
		public int DEyear { get; set; }

		[DbColumnInformation(false, "", "DEyear", true)]
		public int DEyearCode { get; set; }


		[DbColumnInformation(true, "NVARCHAR(100) NOT NULL")]
		public string DEstratumName { get; set; }

		[DbColumnInformation]
		public int DEhierarchy { get; set; }

		[DbColumnInformation(false, "", "DEhierarchy", true)]
		public string DEhierarchyCode { get; set; }


		[DbColumnInformation(false)]
		public int DEhierarchyCorrect { get; set; }


		[DbColumnInformation(false, "", "DEhierarchyCorrect", true)]
		public string DEhierarchyCorrectCode { get; set; }

		[DbColumnInformation]
		public int SDcountry { get; set; }

		[DbColumnInformation(false, "", "SDcountry", true)]
		public string SDcountryCode { get; set; }

		[DbColumnInformation]
		public int SDinstitution { get; set; }

		[DbColumnInformation(false, "", "SDinstitution", true)]
		public string SDinstitutionCode { get; set; }

		public int DEid { get; set; }

		public int SDid { get; set; }
		public int LineNo { get; set; } = 0;


		public override string ToString()
		{
			return $@"
DEsamplingScheme = {DEsamplingSchemeCode}
DEsamplingSchemeType = {DEsamplingSchemeTypeCode}
DEyear = {DEyearCode}
DEstratumName = {DEstratumName}
DEhierarchyCorrect = {DEhierarchyCorrectCode}
DEhierarchy = {DEhierarchyCode}
SDcountry = {SDcountryCode}
SDinstitution = {SDinstitutionCode}
DEid = {DEid}
SDid = {SDid}
LineNo = {LineNo}
";
		}


	}

}
