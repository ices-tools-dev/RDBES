﻿using System.Linq;
using Xml2DB_Conversions.CheckDuplicates.Impl;

namespace Xml2DB_Conversions.CheckDuplicates.ResultTypes
{
	public class HCE_DuplicateInfo : DuplicateInfoBase
	{

		[DbColumnInformation]
		public int CEdataTypeForScientificEffort { get; set; }

		[DbColumnInformation]
		public int CEdataSourceForScientificEffort { get; set; }

		[DbColumnInformation]
		public int? CEsamplingScheme { get; set; }

		[DbColumnInformation]
		public int CEvesselFlagCountry { get; set; }

		[DbColumnInformation] 
		public int CEyear { get; set; }

		[DbColumnInformation]
		public int CEquarter { get; set; }

		[DbColumnInformation]
		public int? CEmonth { get; set; }

		[DbColumnInformation]
		public int CEarea { get; set; }

		[DbColumnInformation]
		public int CEstatisticalRectangle { get; set; }

		[DbColumnInformation]
		public int CEgsaSubarea { get; set; }

		[DbColumnInformation]
		public int? CEexclusiveEconomicZoneIndicator { get; set; }

		[DbColumnInformation]
		public int? CEnationalFishingActivity { get; set; }

		[DbColumnInformation]
		public int CEmetier6 { get; set; }

		[DbColumnInformation] 
		public int CEincidentalByCatchMitigationDevice { get; set; }

		[DbColumnInformation] 
		public int CElandingLocation { get; set; }

		[DbColumnInformation] 
		public int CEvesselLengthCategory { get; set; }

		[DbColumnInformation]
		public int? CEfishingTechnique { get; set; }

		[DbColumnInformation]
		public int? CEdeepSeaRegulation { get; set; }

		[DbColumnInformation]
		public int? CEjurisdictionArea { get; set; }

		public int CEid { get; set; }
		public int LineNo { get; set; } = 0;


		public override string ToString()
		{
			return $@"
CEdataTypeForScientificEffort = {CEdataTypeForScientificEffort}
CEdataSourceForScientificEffort = {CEdataSourceForScientificEffort}
CEsamplingScheme = {CEsamplingScheme}
CEvesselFlagCountry = {CEvesselFlagCountry}
CEyear = {CEyear}
CEquarter = {CEquarter}
CEmonth ={CEmonth}
CEarea = {CEarea}
CEstatisticalRectangle = {CEstatisticalRectangle}
CEgsaSubarea = {CEgsaSubarea}
CEexclusiveEconomicZoneIndicator = {CEexclusiveEconomicZoneIndicator}
CEnationalFishingActivity = {CEnationalFishingActivity}
CEmetier6 = {CEmetier6}
CEincidentalByCatchMitigationDevice = {CEincidentalByCatchMitigationDevice}
CElandingLocation = {CElandingLocation}
CEvesselLengthCategory = {CEvesselLengthCategory}
CEfishingTechnique = {CEfishingTechnique}
CEdeepSeaRegulation = {CEdeepSeaRegulation}
CEjurisdictionArea = {CEjurisdictionArea}
CEid = {CEid}
LineNo = {LineNo}
";
		}


	}

}
