﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xml2DB_Conversions.CheckDuplicates.Impl;

namespace Xml2DB_Conversions.CheckDuplicates.ResultTypes
{
	public abstract class DuplicateInfoBase
	{
		protected string toStringFormatString = string.Empty;
		protected string columnNamesTempTableSql = string.Empty;
		internal List<DbColumnInformationAttribute> cachedAttributes = new List<DbColumnInformationAttribute>();
		public override int GetHashCode()
		{
			StringBuilder sb = new StringBuilder();
			var properties = this.GetType().GetProperties(System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public);
			foreach (var prop in properties)
			{
				sb.Append(prop.GetValue(this));
			}
			return sb.ToString().GetHashCode();
		}

		public virtual string GetColumnNamesTempTableSql()
		{
			if (string.IsNullOrEmpty(columnNamesTempTableSql))
			{
				if (cachedAttributes.Count == 0)
				{
					LoadAttributes();
				}
				StringBuilder sbResult = new StringBuilder();
				foreach (var columnInfo in cachedAttributes.Where(ci => ci.IsIncludedInDuplicateCheckSet))
				{
					if (sbResult.Length > 0)
					{
						sbResult.Append(",\n");
					}
					sbResult.Append($"[{columnInfo.ColumnName}] {columnInfo.TypeDefinition}");
				}
				sbResult.Append("\n");
				columnNamesTempTableSql = sbResult.ToString();
			}
			return columnNamesTempTableSql;
		}


		internal List<DbColumnInformationAttribute> GetColumnAttributes()
		{
			if (cachedAttributes.Count == 0)
			{
				LoadAttributes();
			}
			return cachedAttributes;
		}

		internal string GetColumnsCommaSeparated()
		{
			if (cachedAttributes.Count == 0)
			{
				LoadAttributes();
			}
			return string.Join(',', cachedAttributes.Where(attr => !attr.UseCode).Select(column => column.ColumnName).ToArray());
		}

		internal string GetColumnsForSelectStatement(string tableName)
		{
			if (cachedAttributes.Count == 0)
			{
				LoadAttributes();
			}
			StringBuilder sbResult = new StringBuilder();
			foreach (var attr in cachedAttributes)
			{
				if (attr.UseCode)
				{
					sbResult.AppendLine($"(SELECT tblCode.Code FROM tblCode WHERE tblCode.tblCodeID={tableName}.{attr.ColumnName}) AS {attr.ColumnName}Code,");
				}
				else
				{
					sbResult.AppendLine($"{tableName}.{attr.ColumnName},");
				}
			}
			return sbResult.ToString();
		}

		protected void LoadAttributes()
		{
			var propertiesWithAttributes = this.GetType().GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance)
					.Where(p => p.GetCustomAttributes(typeof(DbColumnInformationAttribute), true).Length > 0)
					.Select(p => new { Property = p, Attribute = (p.GetCustomAttributes(typeof(DbColumnInformationAttribute), true).Single() as DbColumnInformationAttribute) })
					.ToList();
			foreach (var prop in propertiesWithAttributes)
			{
				if (string.IsNullOrEmpty(prop.Attribute.ColumnName))
				{
					prop.Attribute.ColumnName = prop.Property.Name;
				}
				if (!prop.Attribute.UseCode && string.IsNullOrEmpty(prop.Attribute.TypeDefinition))
				{
					prop.Attribute.TypeDefinition = GetTypeDefinition(prop.Property.PropertyType);
				}
				cachedAttributes.Add(prop.Attribute);
			}
		}

		private string GetTypeDefinition(Type type)
		{
			if (Nullable.GetUnderlyingType(type) != null)
			{
				return Constants.INT_NULL;
			}
			switch (type.Name)
			{
				case "Int32":
					return Constants.INT_NOT_NULL;
				default:
					throw new NotSupportedException($"Type: {type.Name}");
			}

		}
	}
}
