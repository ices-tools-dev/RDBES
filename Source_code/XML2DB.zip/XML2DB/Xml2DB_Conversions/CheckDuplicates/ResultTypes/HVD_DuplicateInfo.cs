﻿using Xml2DB_Conversions.CheckDuplicates.Impl;

namespace Xml2DB_Conversions.CheckDuplicates.ResultTypes
{
	public class HVD_DuplicateInfo : DuplicateInfoBase
	{
		[DbColumnInformation]
		public int VDCountry { get; set; }
		
		[DbColumnInformation(true, "NVARCHAR(100) NOT NULL")]
		public string VDencryptedVesselCode { get; set; }
		
		[DbColumnInformation]
		public int VDyear { get; set; }

		[DbColumnInformation]
		public int VDflagCountry { get; set; }

		public int VDid { get; set; }

		public int LineNo { get; set; } = 0;


		public override string ToString()
		{
			return $@"

VDCountry = {VDCountry}
VDencryptedVesselCode = {VDencryptedVesselCode}
VDyear = {VDyear}
VDflagCountry = {VDflagCountry}
VDid = {VDid}
LineNo = {LineNo}
";
		}
	}

}
