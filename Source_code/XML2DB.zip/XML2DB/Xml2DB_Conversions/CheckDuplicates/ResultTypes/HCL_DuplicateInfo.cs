﻿using Xml2DB_Conversions.CheckDuplicates.Impl;

namespace Xml2DB_Conversions.CheckDuplicates.ResultTypes
{
	public class HCL_DuplicateInfo : DuplicateInfoBase
	{
		[DbColumnInformation]
		public int CLdataTypeOfScientificWeight { get; set; }

		[DbColumnInformation]
		public int CLdataSourceOfScientificWeight { get; set; }

		[DbColumnInformation]
		public int? CLsamplingScheme { get; set; }

		[DbColumnInformation]
		public int CLdataSourceLandingsValue { get; set; }

		[DbColumnInformation]
		public int CLlandingCountry { get; set; }

		[DbColumnInformation]
		public int CLvesselFlagCountry { get; set; }

		[DbColumnInformation] 
		public int CLyear { get; set; }


		[DbColumnInformation]
		public int CLquarter { get; set; }
		
		[DbColumnInformation] 
		public int? CLmonth { get; set; }
		
		[DbColumnInformation]
		public int CLarea { get; set; }


		[DbColumnInformation]
		public int CLstatisticalRectangle { get; set; }

		[DbColumnInformation]
		public int? CLgsaSubarea { get; set; }

		[DbColumnInformation]
		public int? CLjurisdictionArea { get; set; }

		[DbColumnInformation] 
		public int? CLexclusiveEconomicZoneIndicator { get; set; }


		[DbColumnInformation] 
		public int CLspeciesCode { get; set; }

		[DbColumnInformation]
		public int? CLspeciesFaoCode { get; set; }


		[DbColumnInformation]
		public int CLlandingCategory { get; set; }

		[DbColumnInformation] 
		public int CLcatchCategory { get; set; }

		[DbColumnInformation]
		public int? CLregDisCategory { get; set; }

		[DbColumnInformation] 
		public int? CLcommercialSizeCategoryScale { get; set; }

		[DbColumnInformation] 
		public int? CLcommercialSizeCategory { get; set; }

		[DbColumnInformation]
		public int? CLnationalFishingActivity { get; set; }

		[DbColumnInformation] 
		public int CLmetier6 { get; set; }

		[DbColumnInformation]
		public int CLincidentialByCatchMitigationDevice { get; set; }


		[DbColumnInformation]
		public int CLlandingLocation { get; set; }

		[DbColumnInformation]
		public int CLvesselLengthCategory { get; set; }


		[DbColumnInformation]
		public int? CLfishingTechnique { get; set; }

		[DbColumnInformation]
		public int? CLdeepSeaRegulation { get; set; }

		public int CLid { get; set; }
		public int LineNo { get; set; } = 0;


		public override string ToString()
		{
			return $@"
CLdataTypeOfScientificWeight = {CLdataTypeOfScientificWeight}
CLdataSourceOfScientificWeight = {CLdataSourceOfScientificWeight}
CLsamplingScheme = {CLsamplingScheme}
CLdataSourceLandingsValue = {CLdataSourceLandingsValue}
CLlandingCountry = {CLlandingCountry}
CLvesselFlagCountry = {CLvesselFlagCountry}
CLyear = {CLyear}
CLquarter = {CLquarter}
CLmonth = {CLmonth}
CLarea = {CLarea}
CLstatisticalRectangle = {CLstatisticalRectangle}
CLgsaSubarea = {CLgsaSubarea}
CLjurisdictionArea = {CLjurisdictionArea}
CLexclusiveEconomicZoneIndicator = {CLexclusiveEconomicZoneIndicator}
CLspeciesCode = {CLspeciesCode}
CLspeciesFaoCode = {CLspeciesFaoCode}
CLlandingCategory = {CLlandingCategory}
CLcatchCategory = {CLcatchCategory}
CLregDisCategory = {CLregDisCategory}
CLcommercialSizeCategoryScale = {CLcommercialSizeCategoryScale}
CLcommercialSizeCategory = {CLcommercialSizeCategory}
CLnationalFishingActivity = {CLnationalFishingActivity}
CLmetier6 = {CLmetier6}
CLincidentialByCatchMitigationDevice = {CLincidentialByCatchMitigationDevice}
CLlandingLocation = {CLlandingLocation}
CLvesselLengthCategory = {CLvesselLengthCategory}
CLfishingTechnique = {CLfishingTechnique}
CLdeepSeaRegulation = {CLdeepSeaRegulation}
CLid = {CLid}
LineNo = {LineNo}
";
		}
	}

}