﻿using Xml2DB_DAL;

namespace Xml2DB_Conversions.CheckDuplicates
{
    public interface IDbDuplicateCheckerFactory
    {
        IDbDuplicateChecker<TResult> CreateDbDuplicateChecker<TResult>(DatabaseContext context, string hierarchyName);
    }
}
