﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
	internal class VS : ElementDefinition
	{
		public VS()
		{
			this.Name = "VS";
			this.FieldDefinitions.AddMultiple
			(
				FieldXmlType.Element,
				"VSsequenceNumber",
				"VSencryptedVesselCode",
				"VSstratification",
				"VSstratumName",
				"VSclustering",
				"VSclusterName",
				"VSsampler",
				"VSnumberTotal",
				"VSnumberSampled",
				"VSselectionProb",
				"VSinclusionProb",
				"VSselectionMethod",
				"VSunitName",
				"VSselectionMethodCluster",
				"VSnumberTotalClusters",
				"VSnumberSampledClusters",
				"VSselectionProbCluster",
				"VSinclusionProbCluster",
				"VSsampled",
				"VSreasonNotSampled" 
			);
		}
	}
}
