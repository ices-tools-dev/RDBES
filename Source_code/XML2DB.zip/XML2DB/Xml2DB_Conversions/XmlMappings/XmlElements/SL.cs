﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
	internal class SL : ElementDefinition
	{
		public SL()
		{ 
			this.Name = "SL";
			this.FieldDefinitions.AddMultiple
			(
				FieldXmlType.Element,
                "SLcountry",
                "SLinstitute",
                "SLspeciesListName",
                "SLyear",
                "SLcatchFraction",
                "SLcommercialTaxon",
                "SLspeciesCode" 
            );
        }
	}
}
