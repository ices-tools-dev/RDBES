﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
    internal class FM : ElementDefinition
    {
        public FM()
        {
            this.Name = "FM";
            this.FieldDefinitions.AddMultiple
            (
                FieldXmlType.Element,
                "FMstateOfProcessing",
                "FMpresentation",
                "FMclassMeasured",
                "FMnumberAtUnit",
                "FMtypeMeasured",
                "FMmethod",
                "FMmeasurementEquipment",
                "FMaccuracy",
                "FMconversionFactorAssessment",
                "FMtypeAssessment",
                "FMsampler",
                "FMaddGrpMeasurement",
                "FMaddGrpMeasurementType"
            );
        }
    }
}
