﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
	internal class LO : ElementDefinition
	{
		public LO()
		{
			this.Name = "LO";
			this.FieldDefinitions.AddMultiple
			(
				 FieldXmlType.Element,
				 "LOsequenceNumber",
				 "LOstratification",
				 "LOlocode",
				 "LOlocationName",
				 "LOlocationType",
				 "LOstratumName",
				 "LOclustering",
				 "LOclusterName",
				 "LOsampler",
				 "LOnumberTotal",
				 "LOnumberSampled",
				 "LOselectionProb",
				 "LOinclusionProb",
				 "LOselectionMethod",
				 "LOunitName",
				 "LOselectionMethodCluster",
				 "LOnumberTotalClusters",
				 "LOnumberSampledClusters",
				 "LOselectionProbCluster",
				 "LOinclusionProbCluster",
				 "LOsampled",
				 "LOreasonNotSampled" 
			);
		}
	}
}
