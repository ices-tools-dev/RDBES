﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
	internal class DE : ElementDefinition
	{
		public DE()
		{ 
			this.Name = "DE";
			this.FieldDefinitions.AddMultiple
			(
				FieldXmlType.Element,
				"DEsamplingScheme",
				"DEsamplingSchemeType",
				"DEyear",
				"DEstratumName",
				"DEhierarchyCorrect",
				"DEhierarchy",
				"DEsampled",
				"DEreasonNotSampled"
			);
		}
	}
}
