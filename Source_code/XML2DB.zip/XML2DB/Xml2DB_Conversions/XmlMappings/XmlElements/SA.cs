﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
    internal class SA : ElementDefinition
    {
        public SA()
        {
            this.Name = "SA";
            this.FieldDefinitions.AddMultiple
            (
                FieldXmlType.Element,
                "SAsequenceNumber",
                "SAparentSequenceNumber",
                "SAstratification",
                "SAstratumName",
                "SAspeciesCode",
                "SAspeciesCodeFAO",
                "SAstateOfProcessing",
                "SApresentation",
                "SAspecimensState",
                "SAcatchCategory",
                "SAlandingCategory",
                "SAcommSizeCatScale",
                "SAcommSizeCat",
                "SAsex",
                "SAexclusiveEconomicZoneIndicator",
                "SAarea",
                "SArectangle",
                "SAgsaSubarea",
                "SAjurisdictionArea",
                "SAnationalFishingActivity",
                "SAmetier5",
                "SAmetier6",
                "SAgear",
                "SAmeshSize",
                "SAselectionDevice",
                "SAselectionDeviceMeshSize",
                "SAunitType",
                "SAtotalWeightLive",
                "SAsampleWeightLive",
                "SAnumberTotal",
                "SAnumberSampled",
                "SAselectionProb",
                "SAinclusionProb",
                "SAselectionMethod",
                "SAunitName",
                "SAlowerHierarchy",
                "SAsampler",
                "SAsampled",
                "SAreasonNotSampledFM",
                "SAreasonNotSampledBV",
                "SAtotalWeightMeasured",
                "SAsampleWeightMeasured",
                "SAconversionFactorMeasLive"
            );
        }
    }
}
