﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
	class VD : ElementDefinition
	{
		public VD()
		{
			this.Name = "VD";
			this.FieldDefinitions.AddMultiple
			(
				FieldXmlType.Element,
                "VDencryptedVesselCode",
                "VDyear",
                "VDcountry",
                "VDhomePort",
                "VDflagCountry",
                "VDlength",
                "VDlengthCategory",
                "VDpower",
                "VDtonnage",
                "VDtonUnit" 
            );
		}
	}
}
