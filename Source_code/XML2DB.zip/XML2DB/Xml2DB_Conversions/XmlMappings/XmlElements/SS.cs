﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
    internal class SS : ElementDefinition
    {
        public SS()
        {
            this.Name = "SS";
            this.FieldDefinitions.AddMultiple
            (
                FieldXmlType.Element,
                "SSsequenceNumber",
                "SSstratification",
                "SSobservationActivityType",
                "SScatchFraction",
                "SSobservationType",
                "SSstratumName",
                "SSclustering",
                "SSclusterName",
                "SSsampler",
                "SSspeciesListName",
                "SSuseForCalculateZero",
                "SSnumberTotal",
                "SSnumberSampled",
                "SSselectionProb",
                "SSinclusionProb",
                "SSselectionMethod",
                "SSunitName",
                "SSselectionMethodCluster",
                "SSnumberTotalClusters",
                "SSnumberSampledClusters",
                "SSselectionProbCluster",
                "SSinclusionProbCluster",
                "SSsampled",
                "SSreasonNotSampled"
           );
        }
    }
}
