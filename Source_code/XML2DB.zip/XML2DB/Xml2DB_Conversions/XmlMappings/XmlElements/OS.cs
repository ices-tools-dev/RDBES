﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
	internal class OS : ElementDefinition
	{
		public OS()
		{
			this.Name = "OS";
			this.FieldDefinitions.AddMultiple
			(
				 FieldXmlType.Element,
				 "OSsequenceNumber",
				 "OSstratification",
				 "OSlocode",
				 "OSlocationName",
				 "OSlocationType",
				 "OSsamplingDate",
				 "OSsamplingTime",
				 "OSstratumName",
				 "OSclustering",
				 "OSclusterName",
				 "OSsampler",
				 "OStimeUnit",
				 "OStimeValue",
				 "OSnumberTotal",
				 "OSnumberSampled",
				 "OSselectionProb",
				 "OSinclusionProb",
				 "OSselectionMethod",
				 "OSunitName",
				 "OSselectionMethodCluster",
				 "OSnumberTotalClusters",
				 "OSnumberSampledClusters",
				 "OSselectionProbCluster",
				 "OSinclusionProbCluster",
				 "OSsampled",
				 "OSreasonNotSampled" 
			);
		}
	}
}
