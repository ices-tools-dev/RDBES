﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
    internal class CE : ElementDefinition
    {
        public CE()
        {
            this.Name = nameof(CE);
            this.FieldDefinitions.AddMultiple
            (
                 FieldXmlType.Element,
                 "CEdataTypeForScientificEffort",
                 "CEdataSourceForScientificEffort",
                 "CEsamplingScheme",
                 "CEvesselFlagCountry",
                 "CEyear",
                 "CEquarter",
                 "CEmonth",
                 "CEarea",
                 "CEstatisticalRectangle",
                 "CEgsaSubarea",
                 "CEjurisdictionArea",
                 "CEexclusiveEconomicZoneIndicator",
                 "CEnationalFishingActivity",
                 "CEmetier6",
                 "CEincidentalByCatchMitigationDevice",
                 "CElandingLocation",
                 "CEvesselLengthCategory",
                 "CEfishingTechnique",
                 "CEdeepSeaRegulation",
                 "CEnumberOfFractionTrips",
                 "CEnumberOfDominantTrips",
                 "CEofficialDaysAtSea",
                 "CEscientificDaysAtSea",
                 "CEofficialFishingDays",
                 "CEscientificFishingDays",
                 "CEofficialNumberOfHaulsOrSets",
                 "CEscientificNumberOfHaulsOrSets",
                 "CEofficialVesselFishingHour",
                 "CEscientificVesselFishingHour",
                 "CEofficialSoakingMeterHour",
                 "CEscientificSoakingMeterHour",
                 "CEofficialkWDaysAtSea",
                 "CEscientifickWDaysAtSea",
                 "CEofficialkWFishingDays",
                 "CEscientifickWFishingDays",
                 "CEofficialkWFishingHours",
                 "CEscientifickWFishingHours",
                 "CEgTDaysAtSea",
                 "CEgTFishingDays",
                 "CEgTFishingHours",
                 "CEnumberOfUniqueVessels",
                 "CEscientificFishingDaysRSE",
                 "CEscientificFishingDaysQualitativeBias"
               );
        }
    }
}
