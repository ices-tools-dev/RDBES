﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
    internal class BV : ElementDefinition
    {
        public BV()
        {
            this.Name = "BV";
            this.FieldDefinitions.AddMultiple
            (
                 FieldXmlType.Element,
                 "BVnationalUniqueFishId",
                 "BVstateOfProcessing",
                 "BVpresentation",
                 "BVstratification",
                 "BVstratumName",
                 "BVtypeMeasured",
                 "BVvalueMeasured",
                 "BVvalueUnitOrScale",
                 "BVmethod",
                 "BVmeasurementEquipment",
                 "BVaccuracy",
                 "BVcertaintyQualitative",
                 "BVcertaintyQuantitative",
                 "BVconversionFactorAssessment",
                 "BVtypeAssessment",
                 "BVnumberTotal",
                 "BVnumberSampled",
                 "BVselectionProb",
                 "BVinclusionProb",
                 "BVselectionMethod",
                 "BVunitName",
                 "BVsampler"
            );
        }
    }
}
