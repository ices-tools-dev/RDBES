﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
    internal class CL : ElementDefinition
    {
        public CL()
        {
            this.Name = nameof(CL);
            this.FieldDefinitions.AddMultiple
            (
                 FieldXmlType.Element,
                 "CLdataTypeOfScientificWeight",
                 "CLdataSourceOfScientificWeight",
                 "CLsamplingScheme",
                 "CLdataSourceLandingsValue",
                 "CLlandingCountry",
                 "CLvesselFlagCountry",
                 "CLyear",
                 "CLquarter",
                 "CLmonth",
                 "CLarea",
                 "CLstatisticalRectangle",
                 "CLgsaSubarea",
                 "CLjurisdictionArea",
                 "CLexclusiveEconomicZoneIndicator",
                 "CLspeciesCode",
                 "CLspeciesFaoCode",
                 "CLlandingCategory",
                 "CLcatchCategory",
                 "CLregDisCategory",
                 "CLcommercialSizeCategoryScale",
                 "CLcommercialSizeCategory",
                 "CLnationalFishingActivity",
                 "CLmetier6",
                 "CLincidentialByCatchMitigationDevice",
                 "CLlandingLocation",
                 "CLvesselLengthCategory",
                 "CLfishingTechnique",
                 "CLdeepSeaRegulation",
                 "CLofficialWeight",
                 "CLscientificWeight",
                 "CLexplainDifference",
                 "CLtotalOfficialLandingsValue",
                 "CLnumberOfUniqueVessels",
                 "CLscientificWeightRSE",
                 "CLvalueRSE",
                 "CLscientificWeightQualitativeBias"
            );
        }
    }
}