﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
	internal class FO : ElementDefinition
	{
		public FO()
		{
			this.Name = "FO";
			this.FieldDefinitions.AddMultiple
			(
				FieldXmlType.Element,
                "FOstratification",
                "FOsequenceNumber",
                "FOstratumName",
                "FOclustering",
                "FOclusterName",
                "FOsampler",
                "FOaggregationLevel",
                "FOvalidity",
                "FOcatchReg",
                "FOstartDate",
                "FOstartTime",
                "FOendDate",
                "FOendTime",
                "FOduration",
                "FOdurationSource",
                "FOhandlingTime",
                "FOstartLat",
                "FOstartLon",
                "FOstopLat",
                "FOstopLon",
                "FOexclusiveEconomicZoneIndicator",
                "FOarea",
                "FOrectangle",
                "FOgsaSubarea",
                "FOjurisdictionArea",
                "FOfishingDepth",
                "FOwaterDepth",
                "FOnationalFishingActivity",
                "FOmetier5",
                "FOmetier6",
                "FOgear", 
                "FOmeshSize",
                "FOselectionDevice",
                "FOselectionDeviceMeshSize",
                "FOtargetSpecies",
                "FOincidentalByCatchMitigationDeviceFirst",
                "FOincidentalByCatchMitigationDeviceTargetFirst",
                "FOincidentalByCatchMitigationDeviceSecond",
                "FOincidentalByCatchMitigationDeviceTargetSecond",
                "FOgearDimensions",
                "FOobservationCode",
                "FOnumberTotal",
                "FOnumberSampled",
                "FOselectionProb",
                "FOinclusionProb",
                "FOselectionMethod",
                "FOunitName",
                "FOselectionMethodCluster",
                "FOnumberTotalClusters",
                "FOnumberSampledClusters",
                "FOselectionProbCluster",
                "FOinclusionProbCluster",
                "FOsampled",
                "FOreasonNotSampled"
               );
		}
	}
}
