﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
	internal class FT : ElementDefinition
	{
		public FT()
		{
			this.Name = "FT";
			this.FieldDefinitions.AddMultiple
			(
				FieldXmlType.Element,
					"FTencryptedVesselCode",
					"FTsequenceNumber",
					"FTstratification",
					"FTstratumName",
					"FTclustering",
					"FTclusterName",
					"FTsampler",
					"FTsamplingType",
					"FTnumberOfHaulsOrSets",
					"FTdepartureLocation",
					"FTdepartureDate",
					"FTdepartureTime",
					"FTarrivalLocation",
					"FTarrivalDate",
					"FTarrivalTime",
					"FTnumberTotal",
					"FTnumberSampled",
					"FTselectionProb",
					"FTinclusionProb",
					"FTselectionMethod",
					"FTunitName",
					"FTselectionMethodCluster",
					"FTnumberTotalClusters",
					"FTnumberSampledClusters",
					"FTselectionProbCluster",
					"FTinclusionProbCluster",
					"FTsampled",
					"FTreasonNotSampled" 
			   );
		}
	}
}
