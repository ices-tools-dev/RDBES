﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements
{
	internal class TE : ElementDefinition
	{
		public TE()
		{
			this.Name = "TE";
			this.FieldDefinitions.AddMultiple
			(
				FieldXmlType.Element,
                "TEsequenceNumber",
                "TEstratification",
                "TEtimeUnit",
                "TEstratumName",
                "TEclustering",
                "TEclusterName",
                "TEsampler",
                "TEnumberTotal",
                "TEnumberSampled",
                "TEselectionProb",
                "TEinclusionProb",
                "TEselectionMethod",
                "TEunitName",
                "TEselectionMethodCluster",
                "TEnumberTotalClusters",
                "TEnumberSampledClusters",
                "TEselectionProbCluster",
                "TEinclusionProbCluster",
                "TEsampled",
                "TEreasonNotSampled"
            );
		}
	}
}
