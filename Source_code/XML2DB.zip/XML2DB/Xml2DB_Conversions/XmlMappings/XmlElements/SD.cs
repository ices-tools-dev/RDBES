﻿using Xml2DB_Conversions;
using XML2DB_Reader.Definitions;

namespace Xml2DB_ConversionDefinitions.XmlMappings.XmlElements 
{
	internal class SD : ElementDefinition
	{
		public SD()
		{
			this.Name = "SD";
			this.FieldDefinitions.AddMultiple
			(
				FieldXmlType.Element,
				"SDcountry", 
				"SDinstitution"
			);
		}
	}
}
