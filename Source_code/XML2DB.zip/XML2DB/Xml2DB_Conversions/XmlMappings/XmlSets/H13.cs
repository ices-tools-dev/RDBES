﻿using Xml2DB_ConversionDefinitions.XmlMappings.XmlElements;
using XML2DB_Reader.Definitions;

namespace Xml2DB_Conversions.XmlMappings.XmlSets
{
	class H13 : XmlDefinition
	{
		public H13()
		{

            this.ElementDefinitions.Add
            (
                new DE().AddChilds
                (
                    new SD().AddChilds
                    (
                        new FO().AddChilds
                        (
                            new FT(),
                            new SS().AddChilds
                            (
                                new SA().AddChilds
                                (
                                    Helper.CreateSecondaryLevel()
                                )
                            )
                        )
                    )
                )
            );


            this.SetUpRecordTypes();
		}

	}
}
