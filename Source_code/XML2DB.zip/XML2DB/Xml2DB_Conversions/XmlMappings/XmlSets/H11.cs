﻿using Xml2DB_ConversionDefinitions.XmlMappings.XmlElements;
using XML2DB_Reader.Definitions;

namespace Xml2DB_Conversions.XmlMappings.XmlSets
{
    class H11 : XmlDefinition
    {
        public H11()
        {
            this.ElementDefinitions.Add
            (
                new DE().AddChilds
                (
                    new SD().AddChilds
                    (
                        new LO().AddChilds
                        (
                            new TE().AddChilds
                            (
                                new FT().AddChilds
                                (
                                    new LE(),
                                    new SS().AddChilds
                                    (
                                        new SA().AddChilds
                                        (
                                            Helper.CreateSecondaryLevel()
                                        )
                                    )
                                )

                            )
                        )
                    )
                )
            );

            this.SetUpRecordTypes();
        }
        


    }
}
