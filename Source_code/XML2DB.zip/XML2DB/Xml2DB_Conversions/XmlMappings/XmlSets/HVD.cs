﻿using Xml2DB_ConversionDefinitions.XmlMappings.XmlElements;
using XML2DB_Reader.Definitions;

namespace Xml2DB_Conversions.XmlMappings.XmlSets
{
    class HVD : XmlDefinition
    {
        public HVD()
        {

            this.ElementDefinitions.Add
            (
                new VD()
            );

            this.SetUpRecordTypes();
        }
        protected override string RecordType { get { return nameof(HVD); } }


    }
}
