﻿using Xml2DB_ConversionDefinitions.XmlMappings.XmlElements;
using XML2DB_Reader.Definitions;

namespace Xml2DB_Conversions.XmlMappings.XmlSets
{
    class H5 : XmlDefinition
    {
        public H5()
        {

            this.ElementDefinitions.Add
            (
                new DE().AddChilds
                (
                    new SD().AddChilds
                    (
                        new OS().AddChilds
                        (
                            new FT(),
                            new LE().AddChilds
                            (
                                new SS().AddChilds
                                (
                                    new SA().AddChilds
                                    (
                                        Helper.CreateSecondaryLevel()
                                    )
                                )
                            )
                        )
                    )
                )
            );

            this.SetUpRecordTypes();
        }


    }
}
