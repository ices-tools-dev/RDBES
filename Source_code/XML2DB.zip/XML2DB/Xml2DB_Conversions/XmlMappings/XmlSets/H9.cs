﻿using Xml2DB_ConversionDefinitions.XmlMappings.XmlElements;
using XML2DB_Reader.Definitions;

namespace Xml2DB_Conversions.XmlMappings.XmlSets
{
    class H9 : XmlDefinition
    {
        public H9()
        {
            this.ElementDefinitions.Add
            (
                new DE().AddChilds
                (
                    new SD().AddChilds
                    (
                        new LO().AddChilds
                        (
                             new TE().AddChilds
                             (
                                 new LE().AddChilds
                                 (
                                     new SS().AddChilds
                                     (
                                        new SA().AddChilds
                                        (
                                            Helper.CreateSecondaryLevel()
                                        )
                                    )
                                 )
                            )
                        )
                    )
                )
            );

            this.SetUpRecordTypes();
        }
        


    }
}
