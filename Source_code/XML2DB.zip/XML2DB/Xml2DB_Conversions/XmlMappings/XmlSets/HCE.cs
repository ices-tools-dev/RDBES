﻿using Xml2DB_ConversionDefinitions.XmlMappings.XmlElements;
using XML2DB_Reader.Definitions;

namespace Xml2DB_Conversions.XmlMappings.XmlSets
{
    class HCE : XmlDefinition
    {
        public HCE()
        {

            this.ElementDefinitions.Add
            (
                new CE()
            );

            this.SetUpRecordTypes();
        }
        protected override string RecordType { get { return nameof(HCE); } }


    }
}
