﻿using Xml2DB_ConversionDefinitions.XmlMappings.XmlElements;
using XML2DB_Reader.Definitions;

namespace Xml2DB_Conversions.XmlMappings.XmlSets
{
    class H1 : XmlDefinition
    {
        public H1()
        {

            this.ElementDefinitions.Add
            (
                new DE().AddChilds
                (
                    new SD().AddChilds
                    (
                        new VS().AddChilds
                        (
                            new FT().AddChilds
                            (
                                new FO().AddChilds
                                (
                                    new SS().AddChilds
                                    (
                                        new SA().AddChilds
                                        (
                                            Helper.CreateSecondaryLevel()
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            );

            this.SetUpRecordTypes();
        }
        protected override string RecordType { get { return "H1"; } }


    }
}
