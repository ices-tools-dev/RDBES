﻿using Xml2DB_ConversionDefinitions.XmlMappings.XmlElements;
using XML2DB_Reader.Definitions;

namespace Xml2DB_Conversions.XmlMappings.XmlSets
{
    class H6 : XmlDefinition
    {
        public H6()
        {
            this.ElementDefinitions.Add
            (
                new DE().AddChilds
                (
                    new SD().AddChilds
                    (
                        new OS().AddChilds
                        (
                            new FT().AddChilds
                            (
                                new FO().AddChilds
                                (
                                    new LE(),
                                    new SS().AddChilds
                                    (
                                        new SA().AddChilds
                                        (
                                            Helper.CreateSecondaryLevel()
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            );

            this.SetUpRecordTypes();
        }
        


    }
}
