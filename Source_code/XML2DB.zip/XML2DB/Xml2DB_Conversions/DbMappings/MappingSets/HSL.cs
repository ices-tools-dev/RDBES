﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
	internal class HSL : MappingSet
	{
		public HSL()
		{
			this.ElementMappings.Add
			(
				new SL()
			);

		}
	}
}
