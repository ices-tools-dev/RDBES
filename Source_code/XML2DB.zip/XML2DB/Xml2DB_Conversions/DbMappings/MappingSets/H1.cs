﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
	internal class H1 : MappingSet
    {
        public H1()
        {
            this.ElementMappings.Add
            (
                new DE().AddChilds
                (
                    new SD().AddChilds
                    (
                        new VS().AddChilds
                        (
                            new FT().AddChilds
                            (
                                new FO().AddChilds
                                (
                                    new SS().AddChilds
                                    (
                                        new SA().AddChilds
                                        (
                                            CreateSecondaryLevel()
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            );

        }
    }
}
