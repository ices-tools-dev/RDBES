﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
	internal class H11 : MappingSet
	{
		public H11()
		{
			this.ElementMappings.Add
			(
				new DE().AddChilds
				(
					new SD().AddChilds
					(
						new LO().AddChilds
						(
							new TE().AddChilds
							(
								new FT().AddChilds
								(
									new LE(),
									new SS().AddChilds
									(
										new SA().AddChilds
										(
											CreateSecondaryLevel()
										)
									)
								)

							)
						)
					)
				)
			);

		}
	}
}

