﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
	internal class H7 : MappingSet
    {
        public H7()
        {
            this.ElementMappings.Add
            (
                new DE().AddChilds
                (
					new SD().AddChilds
					(
						new OS().AddChilds
						(
							new LE(),
							new SS().AddChilds
							(
								new SA().AddChilds
								(
									CreateSecondaryLevel()
								)
							)
						)
					)
				)
            );

		}
    }
}

