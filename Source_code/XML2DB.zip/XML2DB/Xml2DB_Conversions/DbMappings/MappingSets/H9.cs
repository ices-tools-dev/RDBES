﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
	internal class H9 : MappingSet
	{
		public H9()
		{
			this.ElementMappings.Add
			(
				new DE().AddChilds
				(
					new SD().AddChilds
					(
						new LO().AddChilds
						(
							new TE().AddChilds
							(
								new SS().AddChilds
								(
									new LE().AddChilds
									(
										new SA().AddChilds
										(
											CreateSecondaryLevel()
										)
									)
								 )
							)
						)
					)
				)
			);

		}
	}
}

