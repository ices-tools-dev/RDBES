﻿using System.Collections.Generic;
using Xml2DB_Conversions.DbMappings.MappingElements;
using XML2DB_Mapping;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
	/// <summary>
	/// Represents a set of mappings matching specific XML structure
	/// </summary>
	public abstract class MappingSet
    {
		public List<ElementMapping> ElementMappings {get; protected set;}

		public MappingSet()
		{
			ElementMappings = new List<ElementMapping>();
		}

		public void AddNestedMappings(params ElementMapping[] mappings)
		{
			ElementMapping current = null;
			bool isFirst = true;
			foreach(var mapping in mappings)
			{
				if(current != null)
				{
					current.AddChild(mapping);
				}
				current = mapping;
				if(isFirst)
				{
					this.ElementMappings.Add(current);
				}
				isFirst =false;
			}
		}

		protected ElementMapping[] CreateSecondaryLevel()
		{
			ElementMapping[] result = new ElementMapping[2] {
				new BV(),
				new FM().AddChilds(new BV()),
			};

			return result;
		}
    }
}
