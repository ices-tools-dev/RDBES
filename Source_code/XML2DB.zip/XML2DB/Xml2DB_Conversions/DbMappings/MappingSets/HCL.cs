﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
    internal class HCL : MappingSet
    {
        public HCL()
        {
            this.ElementMappings.Add
            (
                new CL()
            );

        }
    }
}
