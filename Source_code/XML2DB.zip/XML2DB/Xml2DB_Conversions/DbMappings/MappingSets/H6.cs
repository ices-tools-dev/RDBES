﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
    internal class H6 : MappingSet
    {
        public H6()
        {
            this.ElementMappings.Add
            (
                new DE().AddChilds
                (
                    new SD().AddChilds
                    (
                        new OS().AddChilds
                        (
                            new FT().AddChilds
                            (
                                new FO().AddChilds
                                (
                                    new LE(),
                                    new SS().AddChilds
                                    (
                                        new SA().AddChilds
                                        (
                                            CreateSecondaryLevel()
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            );

        }
    }
}

