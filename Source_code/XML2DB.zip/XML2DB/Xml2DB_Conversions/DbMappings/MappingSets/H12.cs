﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
	internal class H12 : MappingSet
	{
		public H12()
		{
			this.ElementMappings.Add
			(
				new DE().AddChilds
				(
					new SD().AddChilds
					(
						new LO().AddChilds
						(
							new TE().AddChilds
							(
								new FT(),
								new LE().AddChilds
								(
									new SS().AddChilds
									(
										new SA().AddChilds
										(
											CreateSecondaryLevel()
										)
									)
								)
							)
						)
					)
				)
			);

		}
	}
}

