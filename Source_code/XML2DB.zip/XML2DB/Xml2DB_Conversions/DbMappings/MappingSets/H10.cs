﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
	internal class H10 : MappingSet
	{
		public H10()
		{
			this.ElementMappings.Add
			(
                new DE().AddChilds
                (
                    new SD().AddChilds
                    (
                        new VS().AddChilds
                        (
                            new TE().AddChilds
                            (
                                new FT().AddChilds
                                (
                                    new FO().AddChilds
                                    (
                                        new SS().AddChilds
                                        (
                                            new SA().AddChilds
                                            (
                                                CreateSecondaryLevel()
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            );

		}
	}
}

