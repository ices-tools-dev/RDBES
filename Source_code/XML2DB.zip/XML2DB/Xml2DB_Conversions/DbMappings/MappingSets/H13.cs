﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
	internal class H13 : MappingSet
	{
		public H13()
		{
			this.ElementMappings.Add
			(
				new DE().AddChilds
				(
					new SD().AddChilds
					(
						new FO().AddChilds
						(
							new FT(),
							new SS().AddChilds
							(
								new SA().AddChilds
								(
									CreateSecondaryLevel()
								)
							)
						)
					)
				)
			);


		}
	}
}

