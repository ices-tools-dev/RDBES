﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
    internal class HVD : MappingSet
    {
        public HVD()
        {
            this.ElementMappings.Add
            (
                new VD()
            );

        }
    }
}
