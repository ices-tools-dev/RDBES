﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
    internal class HCE : MappingSet
    {
        public HCE()
        {
            this.ElementMappings.Add
            (
                new CE()
            );

        }
    }
}
