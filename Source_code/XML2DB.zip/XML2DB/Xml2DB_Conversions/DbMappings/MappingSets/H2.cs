﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
	internal class H2 : MappingSet
    {
        public H2()
        {
            this.ElementMappings.Add
            (
                new DE().AddChilds
                (
					new SD().AddChilds
					(
						new FT().AddChilds
						(
							new FO().AddChilds
							(
								new SS().AddChilds
								(
									new SA().AddChilds
									(
										CreateSecondaryLevel()
									)
								)
							)
						)
					)
				)
			);
        }
    }
}



