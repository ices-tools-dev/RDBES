﻿using Xml2DB_Conversions.DbMappings.MappingElements;

namespace Xml2DB_Conversions.DbMappings.MappingSets
{
	internal class H8 : MappingSet
	{
		public H8()
		{
			this.ElementMappings.Add
			(
				new DE().AddChilds
				(
					new SD().AddChilds
					(
						new TE().AddChilds
						(
							new VS().AddChilds
							(
								new FT(),
								new LE().AddChilds
								(
									new SS().AddChilds
									(
										new SA().AddChilds
										(
											CreateSecondaryLevel()
										)
									)
								)
							)
						)
					)
				)
			);

		}
	}
}

