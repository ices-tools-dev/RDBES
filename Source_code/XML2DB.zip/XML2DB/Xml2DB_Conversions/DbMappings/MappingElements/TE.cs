﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
    internal class TE : ElementMapping
    {
        public TE() :
            base(
                elementName: "TE",
                objectTypeName: nameof(TemporalEvent),
                tableName: null,
                fields: new System.Collections.Generic.List<FieldMapping>
                {
                        new FieldMapping("RecordType",                          nameof(TemporalEvent.TerecordType)),
                        new FieldMapping("TEsequenceNumber",                    nameof(TemporalEvent.TesequenceNumber), ConversionType.InferFromPropertyType),
                        new FieldMapping("TEstratification",                    nameof(TemporalEvent.Testratification), ConversionType.Lookup, CodeType.YesNoFields),
                        new FieldMapping("TEtimeUnit",                          nameof(TemporalEvent.TetimeUnit), ConversionType.Lookup, CodeType.TimeUnit),
                        new FieldMapping("TEstratumName",                       nameof(TemporalEvent.TestratumName)),
                        new FieldMapping("TEclustering",                        nameof(TemporalEvent.Teclustering), ConversionType.Lookup, CodeType.RS_Clustering),
                        new FieldMapping("TEclusterName",                       nameof(TemporalEvent.TeclusterName)),
                        new FieldMapping("TEsampler",                           nameof(TemporalEvent.Tesampler), ConversionType.Lookup, CodeType.Sampler),
                        new FieldMapping("TEnumberTotal",                       nameof(TemporalEvent.TenumberTotal), ConversionType.InferFromPropertyType),
                        new FieldMapping("TEnumberSampled",                     nameof(TemporalEvent.TenumberSampled), ConversionType.InferFromPropertyType),
                        new FieldMapping("TEselectionProb",                     nameof(TemporalEvent.TeselectionProb), ConversionType.InferFromPropertyType),
                        new FieldMapping("TEinclusionProb",                     nameof(TemporalEvent.TeinclusionProb), ConversionType.InferFromPropertyType),
                        new FieldMapping("TEselectionMethod",                   nameof(TemporalEvent.TeselectionMethod), ConversionType.Lookup, CodeType.SelectionMethod),
                        new FieldMapping("TEunitName",                          nameof(TemporalEvent.TeunitName)),
                        new FieldMapping("TEselectionMethodCluster",            nameof(TemporalEvent.TeselectionMethodCluster), ConversionType.Lookup, CodeType.SelectionMethod),
                        new FieldMapping("TEnumberTotalClusters",               nameof(TemporalEvent.TenumberTotalClusters), ConversionType.InferFromPropertyType),
                        new FieldMapping("TEnumberSampledClusters",             nameof(TemporalEvent.TenumberSampledClusters), ConversionType.InferFromPropertyType),
                        new FieldMapping("TEselectionProbCluster",              nameof(TemporalEvent.TeselectionProbCluster), ConversionType.InferFromPropertyType),
                        new FieldMapping("TEinclusionProbCluster",              nameof(TemporalEvent.TeinclusionProbCluster), ConversionType.InferFromPropertyType),
                        new FieldMapping("TEsampled",                           nameof(TemporalEvent.Tesampled), ConversionType.Lookup, CodeType.YesNoFields),
                        new FieldMapping("TEreasonNotSampled",                  nameof(TemporalEvent.TereasonNotSampled), ConversionType.Lookup, CodeType.ReasonForNotSampling)

                })
        {
            this.ParentSetting.ParentPropertyName = nameof(VesselSelection.TemporalEvents);
        }
    }
}