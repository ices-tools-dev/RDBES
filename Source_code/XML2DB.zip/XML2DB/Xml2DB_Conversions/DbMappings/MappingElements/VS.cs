﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
    internal class VS : ElementMapping
    {
        public VS() :
            base(
                elementName: "VS",
                objectTypeName: nameof(VesselSelection),
                tableName: null,
                fields: new System.Collections.Generic.List<FieldMapping>
                {
                    new FieldMapping("RecordType",                      nameof(VesselSelection.VsrecordType)),
                    new FieldMapping("VSsequenceNumber",                nameof(VesselSelection.VssequenceNumber), ConversionType.InferFromPropertyType),
                    new FieldMapping("VSencryptedVesselCode",           nameof(VesselSelection.VsencryptedVesselCode)),
                    new FieldMapping("VSstratification",                nameof(VesselSelection.Vsstratification), ConversionType.Lookup, CodeType.YesNoFields),
                    new FieldMapping("VSstratumName",                   nameof(VesselSelection.VsstratumName)),
                    new FieldMapping("VSclustering",                    nameof(VesselSelection.Vsclustering), ConversionType.Lookup, CodeType.RS_Clustering),
                    new FieldMapping("VSclusterName",                   nameof(VesselSelection.VsclusterName)),
                    new FieldMapping("VSsampler",                       nameof(VesselSelection.Vssampler), ConversionType.Lookup, CodeType.Sampler),
                    new FieldMapping("VSnumberTotal",                   nameof(VesselSelection.VsnumberTotal), ConversionType.InferFromPropertyType),
                    new FieldMapping("VSnumberSampled",                 nameof(VesselSelection.VsnumberSampled), ConversionType.InferFromPropertyType),
                    new FieldMapping("VSselectionProb",                 nameof(VesselSelection.VsselectionProb), ConversionType.InferFromPropertyType),
                    new FieldMapping("VSinclusionProb",                 nameof(VesselSelection.VsinclusionProb), ConversionType.InferFromPropertyType),
                    new FieldMapping("VSselectionMethod",               nameof(VesselSelection.VsselectionMethod), ConversionType.Lookup, CodeType.SelectionMethod),
                    new FieldMapping("VSunitName",                      nameof(VesselSelection.VsunitName)),
                    new FieldMapping("VSselectionMethodCluster",        nameof(VesselSelection.VsselectionMethodCluster), ConversionType.Lookup, CodeType.SelectionMethod),
                    new FieldMapping("VSnumberTotalClusters",           nameof(VesselSelection.VsnumberTotalClusters), ConversionType.InferFromPropertyType),
                    new FieldMapping("VSnumberSampledClusters",         nameof(VesselSelection.VsnumberSampledClusters), ConversionType.InferFromPropertyType),
                    new FieldMapping("VSselectionProbCluster",          nameof(VesselSelection.VsselectionProbCluster), ConversionType.InferFromPropertyType),
                    new FieldMapping("VSinclusionProbCluster",          nameof(VesselSelection.VsinclusionProbCluster), ConversionType.InferFromPropertyType),
                    new FieldMapping("VSsampled",                       nameof(VesselSelection.Vssampled), ConversionType.Lookup, CodeType.YesNoFields),
                    new FieldMapping("VSreasonNotSampled",              nameof(VesselSelection.VsreasonNotSampled), ConversionType.Lookup, CodeType.ReasonForNotSampling),
                    new FieldMapping("VDid",                            IdLookupType.VesselDetails)
                })
        {
            this.ParentSetting.ParentPropertyName = nameof(SamplingDetail.VesselSelections);
        }
    }
}

