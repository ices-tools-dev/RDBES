﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
    internal class SA : ElementMapping
    {
        public SA() :
            base(
                elementName: "SA",
                objectTypeName: nameof(Sample),
                tableName: null,
                fields: new System.Collections.Generic.List<FieldMapping>
                {
                    new FieldMapping("RecordType",                          nameof(Sample.SarecordType)),
                    new FieldMapping("SAsequenceNumber",                    nameof(Sample.SasequenceNumber), ConversionType.InferFromPropertyType),
                    new FieldMapping("SAparentSequenceNumber",              nameof(Sample.SaparentSequenceNumber), ConversionType.InferFromPropertyType),
                    new FieldMapping("SAstratification",                    nameof(Sample.Sastratification), ConversionType.Lookup, CodeType.YesNoFields),
                    new FieldMapping("SAstratumName",                       nameof(Sample.SastratumName)),
                    new FieldMapping("SAspeciesCode",                       nameof(Sample.SaspeciesCode), ConversionType.Lookup, CodeType.SpecWoRMS),
                    new FieldMapping("SAspeciesCodeFAO",                    nameof(Sample.SaspeciesCodeFao), ConversionType.Lookup, CodeType.SpecASFIS),
                    new FieldMapping("SAstateOfProcessing",                 nameof(Sample.SastateOfProcessing), ConversionType.Lookup, CodeType.StateOfProcessing),
                    new FieldMapping("SApresentation",                      nameof(Sample.Sapresentation), ConversionType.Lookup, CodeType.Presentation),
                    new FieldMapping("SAspecimensState",                    nameof(Sample.SaspecimensState), ConversionType.Lookup, CodeType.SpecimensState),
                    new FieldMapping("SAcatchCategory",                     nameof(Sample.SacatchCategory), ConversionType.Lookup, CodeType.RS_CatchCategory),
                    new FieldMapping("SAlandingCategory",                   nameof(Sample.SalandingCategory), ConversionType.Lookup, CodeType.RS_LandingCategory),
                    new FieldMapping("SAcommSizeCatScale",                  nameof(Sample.SacommSizeCatScale), ConversionType.Lookup, CodeType.CommercialSizeCategoryScale),
                    new FieldMapping("SAcommSizeCat",                       nameof(Sample.SacommSizeCat), ConversionType.Lookup, CodeType.RS_CommercialSizeCategory),
                    new FieldMapping("SAsex",                               nameof(Sample.Sasex), ConversionType.Lookup, CodeType.RS_Sex),
                    new FieldMapping("SAexclusiveEconomicZoneIndicator",    nameof(Sample.SaexclusiveEconomicZoneIndicator), ConversionType.Lookup, CodeType.RS_EEZI),
                    new FieldMapping("SAarea",                              nameof(Sample.Saarea), ConversionType.Lookup, CodeType.ICES_Area),
                    new FieldMapping("SArectangle",                         nameof(Sample.Sarectangle), ConversionType.Lookup, CodeType.StatRec),
                    new FieldMapping("SAgsaSubarea",                        nameof(Sample.SagsaSubarea), ConversionType.Lookup, CodeType.Areas_GFCM_GSA),
                    new FieldMapping("SAjurisdictionArea",                  nameof(Sample.SajurisdictionArea), ConversionType.Lookup, CodeType.RS_JurisdictionArea),
                    new FieldMapping("SAnationalFishingActivity",           nameof(Sample.SanationalFishingActivity), ConversionType.Lookup, CodeType.RS_NationalFishingActivity),
                    new FieldMapping("SAmetier5",                           nameof(Sample.Sametier5), ConversionType.Lookup, CodeType.Metier5_FishingActivity),
                    new FieldMapping("SAmetier6",                           nameof(Sample.Sametier6), ConversionType.Lookup, CodeType.Metier6_FishingActivity),
                    new FieldMapping("SAgear",                              nameof(Sample.Sagear), ConversionType.Lookup, CodeType.GearType),
                    new FieldMapping("SAmeshSize",                          nameof(Sample.SameshSize), ConversionType.InferFromPropertyType),
                    new FieldMapping("SAselectionDevice",                   nameof(Sample.SaselectionDevice), ConversionType.Lookup, CodeType.SelectionDevice),
                    new FieldMapping("SAselectionDeviceMeshSize",           nameof(Sample.SaselectionDeviceMeshSize), ConversionType.InferFromPropertyType),
                    new FieldMapping("SAunitType",                          nameof(Sample.SaunitType), ConversionType.Lookup, CodeType.SamplingUnit),
                    new FieldMapping("SAtotalWeightLive",                   nameof(Sample.SatotalWeightLive), ConversionType.InferFromPropertyType),
                    new FieldMapping("SAsampleWeightLive",                  nameof(Sample.SasampleWeightLive), ConversionType.InferFromPropertyType),
                    new FieldMapping("SAnumberTotal",                       nameof(Sample.SanumberTotal), ConversionType.InferFromPropertyType),
                    new FieldMapping("SAnumberSampled",                     nameof(Sample.SanumberSampled), ConversionType.InferFromPropertyType),
                    new FieldMapping("SAselectionProb",                     nameof(Sample.SaselectionProb), ConversionType.InferFromPropertyType),
                    new FieldMapping("SAinclusionProb",                     nameof(Sample.SainclusionProb), ConversionType.InferFromPropertyType),
                    new FieldMapping("SAselectionMethod",                   nameof(Sample.SaselectionMethod), ConversionType.Lookup, CodeType.SelectionMethod),
                    new FieldMapping("SAunitName",                          nameof(Sample.SaunitName)),
                    new FieldMapping("SAlowerHierarchy",                    nameof(Sample.SalowerHierarchy), ConversionType.Lookup, CodeType.RS_LowerHierarchy),
                    new FieldMapping("SAsampler",                           nameof(Sample.Sasampler), ConversionType.Lookup, CodeType.Sampler),
                    new FieldMapping("SAsampled",                           nameof(Sample.Sasampled), ConversionType.Lookup, CodeType.YesNoFields),
                    new FieldMapping("SAreasonNotSampledFM",                nameof(Sample.SareasonNotSampledFm), ConversionType.Lookup, CodeType.ReasonForNotSampling),
                    new FieldMapping("SAreasonNotSampledBV",                nameof(Sample.SareasonNotSampledBv), ConversionType.Lookup, CodeType.ReasonForNotSampling),
                    new FieldMapping("SAtotalWeightMeasured",               nameof(Sample.SatotalWeightMeasured),ConversionType.InferFromPropertyType ),
                    new FieldMapping("SAsampleWeightMeasured",              nameof(Sample.SasampleWeightMeasured),ConversionType.InferFromPropertyType ),
                    new FieldMapping("SAconversionFactorMeasLive",          nameof(Sample.SaconversionFactorMeasLive), ConversionType.InferFromPropertyType)
                })
        {
            this.ParentSetting.ParentPropertyName = nameof(SpeciesSelection.Samples);
        }
    }
}
