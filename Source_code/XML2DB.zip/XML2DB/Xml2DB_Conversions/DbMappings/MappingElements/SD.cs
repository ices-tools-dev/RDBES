﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
	internal class SD : ElementMapping
	{
		public SD() :
			base(
				elementName: "SD",
				objectTypeName: nameof(SamplingDetail),
				tableName: "SamplingDetails",
				fields: new System.Collections.Generic.List<FieldMapping>
				{
					new FieldMapping("RecordType",     nameof(SamplingDetail.SdrecordType)),
					new FieldMapping("SDcountry",      nameof(SamplingDetail.Sdcountry), ConversionType.Lookup, CodeType.ISO_3166),
					new FieldMapping("SDinstitution",  nameof(SamplingDetail.Sdinstitution), ConversionType.Lookup, CodeType.EDMO)
				})
		{
			this.ParentSetting.ParentPropertyName = nameof(Design.SamplingDetails);
		}
	}
}
