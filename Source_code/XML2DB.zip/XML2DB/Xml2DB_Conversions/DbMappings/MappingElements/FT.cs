﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
	internal class FT : ElementMapping
	{
		public FT() :
			base(
				elementName: "FT",
				objectTypeName: nameof(FishingTrip),
				tableName: null,
				fields: new System.Collections.Generic.List<FieldMapping>
				{
					new FieldMapping("RecordType",                      nameof(FishingTrip.FtrecordType)),
					new FieldMapping("FTencryptedVesselCode",           nameof(FishingTrip.FtencryptedVesselCode)),
					new FieldMapping("FTsequenceNumber",                nameof(FishingTrip.FtsequenceNumber)),
					new FieldMapping("FTstratification",                nameof(FishingTrip.Ftstratification), ConversionType.Lookup, CodeType.YesNoFields),
					new FieldMapping("FTstratumName",                   nameof(FishingTrip.FtstratumName)),
					new FieldMapping("FTclustering",                    nameof(FishingTrip.Ftclustering), ConversionType.Lookup, CodeType.RS_Clustering),
					new FieldMapping("FTclusterName",                   nameof(FishingTrip.FtclusterName)),
					new FieldMapping("FTsampler",                       nameof(FishingTrip.Ftsampler), ConversionType.Lookup, CodeType.Sampler),
					new FieldMapping("FTsamplingType",                  nameof(FishingTrip.FtsamplingType), ConversionType.Lookup, CodeType.RS_SamplingType),
					new FieldMapping("FTnumberOfHaulsOrSets",           nameof(FishingTrip.FtnumberOfHaulsOrSets), ConversionType.InferFromPropertyType),
					new FieldMapping("FTdepartureLocation",             nameof(FishingTrip.FtdepartureLocation), ConversionType.Lookup, CodeType.Harbour_LOCODE),
					new FieldMapping("FTdepartureDate",                 nameof(FishingTrip.FtdepartureDate), ConversionType.InferFromPropertyType),
					new FieldMapping("FTdepartureTime",                 nameof(FishingTrip.FtdepartureTime), ConversionType.InferFromPropertyType),
					new FieldMapping("FTarrivalLocation",               nameof(FishingTrip.FtarrivalLocation), ConversionType.Lookup, CodeType.Harbour_LOCODE),
					new FieldMapping("FTarrivalDate",                   nameof(FishingTrip.FtarrivalDate), ConversionType.InferFromPropertyType),
					new FieldMapping("FTarrivalTime",                   nameof(FishingTrip.FtarrivalTime), ConversionType.InferFromPropertyType),
					new FieldMapping("FTnumberTotal",                   nameof(FishingTrip.FtnumberTotal), ConversionType.InferFromPropertyType),
					new FieldMapping("FTnumberSampled",                 nameof(FishingTrip.FtnumberSampled), ConversionType.InferFromPropertyType),
					new FieldMapping("FTselectionProb",                 nameof(FishingTrip.FtselectionProb), ConversionType.InferFromPropertyType),
					new FieldMapping("FTinclusionProb",                 nameof(FishingTrip.FtinclusionProb), ConversionType.InferFromPropertyType),
					new FieldMapping("FTselectionMethod",               nameof(FishingTrip.FtselectionMethod), ConversionType.Lookup, CodeType.SelectionMethod),
					new FieldMapping("FTunitName",                      nameof(FishingTrip.FtunitName)),
					new FieldMapping("FTselectionMethodCluster",        nameof(FishingTrip.FtselectionMethodCluster), ConversionType.Lookup, CodeType.SelectionMethod),
					new FieldMapping("FTnumberTotalClusters",           nameof(FishingTrip.FtnumberTotalClusters), ConversionType.InferFromPropertyType),
					new FieldMapping("FTnumberSampledClusters",         nameof(FishingTrip.FtnumberSampledClusters), ConversionType.InferFromPropertyType),
					new FieldMapping("FTselectionProbCluster",          nameof(FishingTrip.FtselectionProbCluster), ConversionType.InferFromPropertyType),
					new FieldMapping("FTinclusionProbCluster",          nameof(FishingTrip.FtinclusionProbCluster), ConversionType.InferFromPropertyType),
					new FieldMapping("FTsampled",                       nameof(FishingTrip.Ftsampled), ConversionType.Lookup, CodeType.YesNoFields),
					new FieldMapping("FTreasonNotSampled",              nameof(FishingTrip.FtreasonNotSampled), ConversionType.Lookup, CodeType.ReasonForNotSampling),
					new FieldMapping("VDid",							IdLookupType.VesselDetails)
			})
		{
			this.ParentSetting.ParentPropertyName = nameof(VesselSelection.FishingTrips);
		}
	}
}
