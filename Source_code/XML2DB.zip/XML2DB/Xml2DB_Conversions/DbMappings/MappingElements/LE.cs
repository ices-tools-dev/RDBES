﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
	internal class LE : ElementMapping
	{
		public LE() :
			base(
				elementName: "LE",
				objectTypeName: nameof(LandingEvent),
				tableName: null,
				fields: new System.Collections.Generic.List<FieldMapping>
				{
					new FieldMapping("RecordType",							nameof(LandingEvent.LerecordType)),
					new FieldMapping("LEencryptedVesselCode",				nameof(LandingEvent.LeencryptedVesselCode)),
					new FieldMapping("LEstratification",					nameof(LandingEvent.Lestratification), ConversionType.Lookup, CodeType.YesNoFields),
					new FieldMapping("LEsequenceNumber",					nameof(LandingEvent.LesequenceNumber), ConversionType.InferFromPropertyType),
					new FieldMapping("LEhaulNumber",						nameof(LandingEvent.LehaulNumber), ConversionType.InferFromPropertyType),
					new FieldMapping("LEstratumName",						nameof(LandingEvent.LestratumName)),
					new FieldMapping("LEclustering",						nameof(LandingEvent.Leclustering), ConversionType.Lookup, CodeType.RS_Clustering),
					new FieldMapping("LEclusterName",						nameof(LandingEvent.LeclusterName)),
					new FieldMapping("LEsampler",							nameof(LandingEvent.Lesampler), ConversionType.Lookup, CodeType.Sampler),
					new FieldMapping("LEmixedTrip",							nameof(LandingEvent.LemixedTrip), ConversionType.Lookup, CodeType.YesNoFields),
					new FieldMapping("LEcatchReg",							nameof(LandingEvent.LecatchReg), ConversionType.Lookup, CodeType.RS_CatchRegistration),
					new FieldMapping("LElocode",							nameof(LandingEvent.Lelocode), ConversionType.Lookup, CodeType.Harbour_LOCODE),
					new FieldMapping("LElocationName",						nameof(LandingEvent.LelocationName)),
					new FieldMapping("LElocationType",						nameof(LandingEvent.LelocationType), ConversionType.Lookup, CodeType.RS_LocationType),
					new FieldMapping("LEcountry",							nameof(LandingEvent.Lecountry), ConversionType.Lookup, CodeType.ISO_3166),
					new FieldMapping("LEdate",								nameof(LandingEvent.Ledate), ConversionType.InferFromPropertyType),
					new FieldMapping("LEtime",								nameof(LandingEvent.Letime), ConversionType.InferFromPropertyType),
					new FieldMapping("LEexclusiveEconomicZoneIndicator",	nameof(LandingEvent.LeexclusiveEconomicZoneIndicator), ConversionType.Lookup, CodeType.RS_EEZI),
					new FieldMapping("LEarea",								nameof(LandingEvent.Learea), ConversionType.Lookup, CodeType.ICES_Area),
					new FieldMapping("LErectangle",							nameof(LandingEvent.Lerectangle), ConversionType.Lookup, CodeType.StatRec),
					new FieldMapping("LEgsaSubarea",						nameof(LandingEvent.LegsaSubarea), ConversionType.Lookup, CodeType.Areas_GFCM_GSA),
					new FieldMapping("LEjurisdictionArea",					nameof(LandingEvent.LejurisdictionArea), ConversionType.Lookup, CodeType.RS_JurisdictionArea),
					new FieldMapping("LEnationalFishingActivity",			nameof(LandingEvent.LenationalFishingActivity), ConversionType.Lookup, CodeType.RS_NationalFishingActivity),
					new FieldMapping("LEmetier5",							nameof(LandingEvent.Lemetier5), ConversionType.Lookup, CodeType.Metier5_FishingActivity),
					new FieldMapping("LEmetier6",							nameof(LandingEvent.Lemetier6), ConversionType.Lookup, CodeType.Metier6_FishingActivity),
					new FieldMapping("LEgear",								nameof(LandingEvent.Legear), ConversionType.Lookup, CodeType.GearType),
					new FieldMapping("LEmeshSize",							nameof(LandingEvent.LemeshSize), ConversionType.InferFromPropertyType),
					new FieldMapping("LEselectionDevice",					nameof(LandingEvent.LeselectionDevice), ConversionType.Lookup, CodeType.SelectionDevice),
					new FieldMapping("LEselectionDeviceMeshSize",			nameof(LandingEvent.LeselectionDeviceMeshSize), ConversionType.InferFromPropertyType),
					new FieldMapping("LEtargetSpecies",						nameof(LandingEvent.LetargetSpecies), ConversionType.Lookup, CodeType.TargetSpecies),
					new FieldMapping("LEmitigationDevice",					nameof(LandingEvent.LemitigationDevice), ConversionType.Lookup, CodeType.BycatchMitigationDevice),
					new FieldMapping("LEgearDimensions",					nameof(LandingEvent.LegearDimensions), ConversionType.InferFromPropertyType),
					new FieldMapping("LEnumberTotal",						nameof(LandingEvent.LenumberTotal), ConversionType.InferFromPropertyType),
					new FieldMapping("LEnumberSampled",						nameof(LandingEvent.LenumberSampled), ConversionType.InferFromPropertyType),
					new FieldMapping("LEselectionProb",						nameof(LandingEvent.LeselectionProb), ConversionType.InferFromPropertyType),
					new FieldMapping("LEinclusionProb",						nameof(LandingEvent.LeinclusionProb), ConversionType.InferFromPropertyType),
					new FieldMapping("LEselectionMethod",					nameof(LandingEvent.LeselectionMethod), ConversionType.Lookup, CodeType.SelectionMethod),
					new FieldMapping("LEunitName",							nameof(LandingEvent.LeunitName)),
					new FieldMapping("LEselectionMethodCluster",			nameof(LandingEvent.LeselectionMethodCluster), ConversionType.Lookup, CodeType.SelectionMethod),
					new FieldMapping("LEnumberTotalClusters",				nameof(LandingEvent.LenumberTotalClusters), ConversionType.InferFromPropertyType),
					new FieldMapping("LEnumberSampledClusters",				nameof(LandingEvent.LenumberSampledClusters), ConversionType.InferFromPropertyType),
					new FieldMapping("LEselectionProbCluster",				nameof(LandingEvent.LeselectionProbCluster), ConversionType.InferFromPropertyType),
					new FieldMapping("LEinclusionProbCluster",				nameof(LandingEvent.LeinclusionProbCluster), ConversionType.InferFromPropertyType),
					new FieldMapping("LEsampled",							nameof(LandingEvent.Lesampled), ConversionType.Lookup, CodeType.YesNoFields),
					new FieldMapping("LEreasonNotSampled",					nameof(LandingEvent.LereasonNotSampled), ConversionType.Lookup, CodeType.ReasonForNotSampling),
					new FieldMapping("LEfullTripAvailable",					nameof(LandingEvent.LefullTripAvailable), ConversionType.Lookup, CodeType.RS_LEfullTripAvailable),
					new FieldMapping("VDid",								IdLookupType.VesselDetails)
				})
			{
				this.ParentSetting.ParentPropertyName = nameof(TemporalEvent.LandingEvents);
			}
	}
}
