﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
    internal class OS : ElementMapping
    {
        public OS() :
            base(
                elementName: "OS",
                objectTypeName: nameof(OnshoreEvent),
                tableName: null,
                fields: new System.Collections.Generic.List<FieldMapping>
                {
                    new FieldMapping("RecordType",                      nameof(OnshoreEvent.OsrecordType)),
                    new FieldMapping("OSsequenceNumber",                nameof(OnshoreEvent.OssequenceNumber), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSstratification",                nameof(OnshoreEvent.Osstratification), ConversionType.Lookup, CodeType.YesNoFields),
                    new FieldMapping("OSlocode",                        nameof(OnshoreEvent.Oslocode), ConversionType.Lookup, CodeType.Harbour_LOCODE),
                    new FieldMapping("OSlocationName",                  nameof(OnshoreEvent.OslocationName)),
                    new FieldMapping("OSlocationType",                  nameof(OnshoreEvent.OslocationType), ConversionType.Lookup, CodeType.RS_LocationType),
                    new FieldMapping("OSsamplingDate",                  nameof(OnshoreEvent.OssamplingDate), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSsamplingTime",                  nameof(OnshoreEvent.OssamplingTime), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSstratumName",                   nameof(OnshoreEvent.OsstratumName)),
                    new FieldMapping("OSclustering",                    nameof(OnshoreEvent.Osclustering), ConversionType.Lookup, CodeType.RS_Clustering),
                    new FieldMapping("OSclusterName",                   nameof(OnshoreEvent.OsclusterName)),
                    new FieldMapping("OSsampler",                       nameof(OnshoreEvent.Ossampler), ConversionType.Lookup, CodeType.Sampler),
                    new FieldMapping("OStimeUnit",                      nameof(OnshoreEvent.OstimeUnit), ConversionType.Lookup, CodeType.TimeUnit),
                    new FieldMapping("OStimeValue",                     nameof(OnshoreEvent.OstimeValue), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSnumberTotal",                   nameof(OnshoreEvent.OsnumberTotal), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSnumberSampled",                 nameof(OnshoreEvent.OsnumberSampled), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSselectionProb",                 nameof(OnshoreEvent.OsselectionProb), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSinclusionProb",                 nameof(OnshoreEvent.OsinclusionProb), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSselectionMethod",               nameof(OnshoreEvent.OsselectionMethod), ConversionType.Lookup, CodeType.SelectionMethod),
                    new FieldMapping("OSunitName",                      nameof(OnshoreEvent.OsunitName)),
                    new FieldMapping("OSselectionMethodCluster",        nameof(OnshoreEvent.OsselectionMethodCluster), ConversionType.Lookup, CodeType.SelectionMethod),
                    new FieldMapping("OSnumberTotalClusters",           nameof(OnshoreEvent.OsnumberTotalClusters), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSnumberSampledClusters",         nameof(OnshoreEvent.OsnumberSampledClusters), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSselectionProbCluster",          nameof(OnshoreEvent.OsselectionProbCluster), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSinclusionProbCluster",          nameof(OnshoreEvent.OsinclusionProbCluster), ConversionType.InferFromPropertyType),
                    new FieldMapping("OSsampled",                       nameof(OnshoreEvent.Ossampled), ConversionType.Lookup, CodeType.YesNoFields),
                    new FieldMapping("OSreasonNotSampled",              nameof(OnshoreEvent.OsreasonNotSampled), ConversionType.Lookup, CodeType.ReasonForNotSampling)
                })
        {
            this.ParentSetting.ParentPropertyName = nameof(SamplingDetail.OnshoreEvents);
        }
    }
}
