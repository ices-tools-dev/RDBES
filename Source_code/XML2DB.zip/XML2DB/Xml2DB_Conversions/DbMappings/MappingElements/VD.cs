﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
    internal class VD : ElementMapping
    {
        public VD() :
            base(
                elementName: "VD",
                objectTypeName: nameof(VesselDetail),
                tableName: "VesselDetails",
                fields: new System.Collections.Generic.List<FieldMapping>
                {
                    new FieldMapping("RecordType",                  nameof(VesselDetail.VdrecordType)),
                    new FieldMapping("VDencryptedVesselCode",       nameof(VesselDetail.VdencryptedVesselCode)),
                    new FieldMapping("VDyear",                      nameof(VesselDetail.Vdyear), ConversionType.Lookup, CodeType.Year),
                    new FieldMapping("VDcountry",                   nameof(VesselDetail.Vdcountry), ConversionType.Lookup, CodeType.ISO_3166),
                    new FieldMapping("VDhomePort",                  nameof(VesselDetail.VdhomePort), ConversionType.Lookup, CodeType.Harbour_LOCODE),
                    new FieldMapping("VDflagCountry",               nameof(VesselDetail.VdflagCountry), ConversionType.Lookup, CodeType.ISO_3166),
                    new FieldMapping("VDlength",                    nameof(VesselDetail.Vdlength), ConversionType.InferFromPropertyType),
                    new FieldMapping("VDlengthCategory",            nameof(VesselDetail.VdlengthCategory), ConversionType.Lookup, CodeType.RS_VesselLengthCategory),
                    new FieldMapping("VDpower",                     nameof(VesselDetail.Vdpower), ConversionType.InferFromPropertyType),
                    new FieldMapping("VDtonnage",                   nameof(VesselDetail.Vdtonnage), ConversionType.InferFromPropertyType),
                    new FieldMapping("VDtonUnit",                   nameof(VesselDetail.VdtonUnit), ConversionType.Lookup, CodeType.RS_VesselSizeUnit)
                })
        { }
    }
}
