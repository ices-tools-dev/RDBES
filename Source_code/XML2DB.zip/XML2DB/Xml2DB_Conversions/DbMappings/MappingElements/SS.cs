﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
    internal class SS : ElementMapping
    {
        public SS() :
            base(
                elementName: "SS",
                objectTypeName: nameof(SpeciesSelection),
                tableName: null,
                fields: new System.Collections.Generic.List<FieldMapping>
                {
                    new FieldMapping("RecordType",                      nameof(SpeciesSelection.SsrecordType)),
                    new FieldMapping("SSsequenceNumber",                nameof(SpeciesSelection.SssequenceNumber), ConversionType.InferFromPropertyType),
                    new FieldMapping("SSstratification",                nameof(SpeciesSelection.Ssstratification), ConversionType.Lookup, CodeType.YesNoFields),
                    new FieldMapping("SSobservationActivityType",       nameof(SpeciesSelection.SsobservationActivityType), ConversionType.Lookup, CodeType.ObservationActivityType),
                    new FieldMapping("SScatchFraction",                 nameof(SpeciesSelection.SscatchFraction), ConversionType.Lookup, CodeType.RS_CatchFraction),
                    new FieldMapping("SSobservationType",               nameof(SpeciesSelection.SsobservationType), ConversionType.Lookup, CodeType.ObservationMethod),
                    new FieldMapping("SSstratumName",                   nameof(SpeciesSelection.SsstratumName)),
                    new FieldMapping("SSclustering",                    nameof(SpeciesSelection.Ssclustering), ConversionType.Lookup, CodeType.RS_Clustering),
                    new FieldMapping("SSclusterName",                   nameof(SpeciesSelection.SsclusterName)),
                    new FieldMapping("SSsampler",                       nameof(SpeciesSelection.Sssampler), ConversionType.Lookup, CodeType.Sampler),
                    new FieldMapping("SSspeciesListName",               nameof(SpeciesSelection.SsspeciesListName)),
                    new FieldMapping("SSuseForCalculateZero",           nameof(SpeciesSelection.SsuseForCalculateZero), ConversionType.Lookup, CodeType.YesNoFields),
                    new FieldMapping("SSnumberTotal",                   nameof(SpeciesSelection.SsnumberTotal), ConversionType.InferFromPropertyType),
                    new FieldMapping("SSnumberSampled",                 nameof(SpeciesSelection.SsnumberSampled), ConversionType.InferFromPropertyType),
                    new FieldMapping("SSselectionProb",                 nameof(SpeciesSelection.SsselectionProb), ConversionType.InferFromPropertyType),
                    new FieldMapping("SSinclusionProb",                 nameof(SpeciesSelection.SsinclusionProb), ConversionType.InferFromPropertyType),
                    new FieldMapping("SSselectionMethod",               nameof(SpeciesSelection.SsselectionMethod), ConversionType.Lookup, CodeType.SelectionMethod),
                    new FieldMapping("SSunitName",                      nameof(SpeciesSelection.SsunitName)),
                    new FieldMapping("SSselectionMethodCluster",        nameof(SpeciesSelection.SsselectionMethodCluster), ConversionType.Lookup, CodeType.SelectionMethod),
                    new FieldMapping("SSnumberTotalClusters",           nameof(SpeciesSelection.SsnumberTotalClusters), ConversionType.InferFromPropertyType),
                    new FieldMapping("SSnumberSampledClusters",         nameof(SpeciesSelection.SsnumberSampledClusters), ConversionType.InferFromPropertyType),
                    new FieldMapping("SSselectionProbCluster",          nameof(SpeciesSelection.SsselectionProbCluster), ConversionType.InferFromPropertyType),
                    new FieldMapping("SSinclusionProbCluster",          nameof(SpeciesSelection.SsinclusionProbCluster), ConversionType.InferFromPropertyType),
                    new FieldMapping("SSsampled",                       nameof(SpeciesSelection.Sssampled), ConversionType.Lookup, CodeType.YesNoFields),
                    new FieldMapping("SSreasonNotSampled",              nameof(SpeciesSelection.SsreasonNotSampled), ConversionType.Lookup, CodeType.ReasonForNotSampling),
                    new FieldMapping("SLid",                            IdLookupType.SpeciesList)

                })
        {
            this.ParentSetting.ParentPropertyName = nameof(FishingOperation.SpeciesSelections);
        }
    }
}
