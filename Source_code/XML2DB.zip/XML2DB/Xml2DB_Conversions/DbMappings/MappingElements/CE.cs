﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
    internal class CE : ElementMapping
    {
        public CE() :
             base(
                  elementName: nameof(CE),
                  objectTypeName: nameof(CommercialEffort),
                  tableName: null,
                  fields: new System.Collections.Generic.List<FieldMapping>
                  {

                        new FieldMapping("RecordType",                              nameof(CommercialEffort.CerecordType)),
                        new FieldMapping("CEdataTypeForScientificEffort",           nameof(CommercialEffort.CedataTypeForScientificEffort), ConversionType.Lookup, CodeType.RS_DataTypeOfScientificWE),
                        new FieldMapping("CEdataSourceForScientificEffort",         nameof(CommercialEffort.CedataSourceForScientificEffort), ConversionType.Lookup, CodeType.RS_DataSourceOfScientificWE),
                        new FieldMapping("CEsamplingScheme",                        nameof(CommercialEffort.CesamplingScheme), ConversionType.Lookup, CodeType.RS_SamplingScheme),
                        new FieldMapping("CEvesselFlagCountry",                     nameof(CommercialEffort.CevesselFlagCountry), ConversionType.Lookup, CodeType.ISO_3166),
                        new FieldMapping("CEyear",                                  nameof(CommercialEffort.Ceyear), ConversionType.Lookup, CodeType.Year),
                        new FieldMapping("CEquarter",                               nameof(CommercialEffort.Cequarter), ConversionType.Lookup, CodeType.Quarter),
                        new FieldMapping("CEmonth",                                 nameof(CommercialEffort.Cemonth), ConversionType.Lookup, CodeType.Month),
                        new FieldMapping("CEarea",                                  nameof(CommercialEffort.Cearea), ConversionType.Lookup, CodeType.ICES_Area),
                        new FieldMapping("CEstatisticalRectangle",                  nameof(CommercialEffort.CestatisticalRectangle), ConversionType.Lookup, CodeType.StatRec),
                        new FieldMapping("CEgsaSubarea",                            nameof(CommercialEffort.CegsaSubarea), ConversionType.Lookup, CodeType.Areas_GFCM_GSA),
                        new FieldMapping("CEjurisdictionArea",                      nameof(CommercialEffort.CejurisdictionArea), ConversionType.Lookup, CodeType.RS_JurisdictionArea),
                        new FieldMapping("CEexclusiveEconomicZoneIndicator",        nameof(CommercialEffort.CeexclusiveEconomicZoneIndicator), ConversionType.Lookup, CodeType.RS_EEZI),
                        new FieldMapping("CEnationalFishingActivity",               nameof(CommercialEffort.CenationalFishingActivity), ConversionType.Lookup, CodeType.RS_NationalFishingActivity),
                        new FieldMapping("CEmetier6",                               nameof(CommercialEffort.Cemetier6), ConversionType.Lookup, CodeType.Metier6_FishingActivity),
                        new FieldMapping("CEincidentalByCatchMitigationDevice",     nameof(CommercialEffort.CeincidentalByCatchMitigationDevice), ConversionType.Lookup, CodeType.BycatchMitigationDevice),
                        new FieldMapping("CElandingLocation",                       nameof(CommercialEffort.CelandingLocation), ConversionType.Lookup, CodeType.Harbour_LOCODE),
                        new FieldMapping("CEvesselLengthCategory",                  nameof(CommercialEffort.CevesselLengthCategory), ConversionType.Lookup, CodeType.RS_VesselLengthCategory),
                        new FieldMapping("CEfishingTechnique",                      nameof(CommercialEffort.CefishingTechnique), ConversionType.Lookup, CodeType.RS_FishingTechnique),
                        new FieldMapping("CEdeepSeaRegulation",                     nameof(CommercialEffort.CedeepSeaRegulation), ConversionType.Lookup, CodeType.YesNoFields),
                        new FieldMapping("CEnumberOfFractionTrips",                 nameof(CommercialEffort.CenumberOfFractionTrips), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEnumberOfDominantTrips",                 nameof(CommercialEffort.CenumberOfDominantTrips), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEofficialDaysAtSea",                     nameof(CommercialEffort.CeofficialDaysAtSea), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEscientificDaysAtSea",                   nameof(CommercialEffort.CescientificDaysAtSea), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEofficialFishingDays",                   nameof(CommercialEffort.CeofficialFishingDays), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEscientificFishingDays",                 nameof(CommercialEffort.CescientificFishingDays), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEofficialNumberOfHaulsOrSets",           nameof(CommercialEffort.CeofficialNumberOfHaulsOrSets), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEscientificNumberOfHaulsOrSets",         nameof(CommercialEffort.CescientificNumberOfHaulsOrSets), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEofficialVesselFishingHour",             nameof(CommercialEffort.CeofficialVesselFishingHour), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEscientificVesselFishingHour",           nameof(CommercialEffort.CescientificVesselFishingHour), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEofficialSoakingMeterHour",              nameof(CommercialEffort.CeofficialSoakingMeterHour), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEscientificSoakingMeterHour",            nameof(CommercialEffort.CescientificSoakingMeterHour), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEofficialkWDaysAtSea",                   nameof(CommercialEffort.CeofficialkWdaysAtSea), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEscientifickWDaysAtSea",                 nameof(CommercialEffort.CescientifickWdaysAtSea), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEofficialkWFishingDays",                 nameof(CommercialEffort.CeofficialkWfishingDays), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEscientifickWFishingDays",               nameof(CommercialEffort.CescientifickWfishingDays), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEofficialkWFishingHours",                nameof(CommercialEffort.CeofficialkWfishingHours), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEscientifickWFishingHours",              nameof(CommercialEffort.CescientifickWfishingHours), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEgTDaysAtSea",                           nameof(CommercialEffort.CegTdaysAtSea), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEgTFishingDays",                         nameof(CommercialEffort.CegTfishingDays), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEgTFishingHours",                        nameof(CommercialEffort.CegTfishingHours), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEnumberOfUniqueVessels",                 nameof(CommercialEffort.CenumberOfUniqueVessels), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEscientificFishingDaysRSE",              nameof(CommercialEffort.CescientificFishingDaysRse), ConversionType.InferFromPropertyType),
                        new FieldMapping("CEscientificFishingDaysQualitativeBias",  nameof(CommercialEffort.CescientificFishingDaysQualitativeBias), ConversionType.Lookup, CodeType.RS_QualitativeBias)
                  })
        { }
    }
}
