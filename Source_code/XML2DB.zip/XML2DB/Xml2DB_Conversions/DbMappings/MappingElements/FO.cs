﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
	internal class FO : ElementMapping
	{
		public FO() :
			base(
				elementName: "FO",
				objectTypeName: nameof(FishingOperation),
				tableName: null,
				fields: new System.Collections.Generic.List<FieldMapping>
				{
					new FieldMapping("RecordType",                                          nameof(FishingOperation.ForecordType)),
					new FieldMapping("FOstratification",                                    nameof(FishingOperation.Fostratification), ConversionType.Lookup, CodeType.YesNoFields),
					new FieldMapping("FOsequenceNumber",                                    nameof(FishingOperation.FosequenceNumber), ConversionType.InferFromPropertyType),
					new FieldMapping("FOstratumName",                                       nameof(FishingOperation.FostratumName)),
					new FieldMapping("FOclustering",                                        nameof(FishingOperation.Foclustering), ConversionType.Lookup, CodeType.RS_Clustering),
					new FieldMapping("FOclusterName",                                       nameof(FishingOperation.FoclusterName)),
					new FieldMapping("FOsampler",                                           nameof(FishingOperation.Fosampler), ConversionType.Lookup, CodeType.Sampler),
					new FieldMapping("FOaggregationLevel",                                  nameof(FishingOperation.FoaggregationLevel), ConversionType.Lookup, CodeType.RS_AggregationLevel),
					new FieldMapping("FOvalidity",                                          nameof(FishingOperation.Fovalidity), ConversionType.Lookup, CodeType.RS_FishingValidity),
					new FieldMapping("FOcatchReg",                                          nameof(FishingOperation.FocatchReg), ConversionType.Lookup, CodeType.RS_CatchRegistration),
					new FieldMapping("FOstartDate",                                         nameof(FishingOperation.FostartDate), ConversionType.InferFromPropertyType),
					new FieldMapping("FOstartTime",                                         nameof(FishingOperation.FostartTime), ConversionType.InferFromPropertyType),
					new FieldMapping("FOendDate",                                           nameof(FishingOperation.FoendDate), ConversionType.InferFromPropertyType),
					new FieldMapping("FOendTime",                                           nameof(FishingOperation.FoendTime), ConversionType.InferFromPropertyType),
					new FieldMapping("FOduration",                                          nameof(FishingOperation.Foduration), ConversionType.InferFromPropertyType),
					new FieldMapping("FOdurationSource",                                    nameof(FishingOperation.FodurationSource), ConversionType.Lookup, CodeType.DurationSource),
					new FieldMapping("FOhandlingTime",                                      nameof(FishingOperation.FohandlingTime), ConversionType.InferFromPropertyType),
					new FieldMapping("FOstartLat",                                          nameof(FishingOperation.FostartLat), ConversionType.InferFromPropertyType),
					new FieldMapping("FOstartLon",                                          nameof(FishingOperation.FostartLon), ConversionType.InferFromPropertyType),
					new FieldMapping("FOstopLat",                                           nameof(FishingOperation.FostopLat), ConversionType.InferFromPropertyType),
					new FieldMapping("FOstopLon",                                           nameof(FishingOperation.FostopLon), ConversionType.InferFromPropertyType),
					new FieldMapping("FOexclusiveEconomicZoneIndicator",                    nameof(FishingOperation.FoexclusiveEconomicZoneIndicator), ConversionType.Lookup, CodeType.RS_EEZI),
					new FieldMapping("FOarea",                                              nameof(FishingOperation.Foarea), ConversionType.Lookup, CodeType.ICES_Area),
					new FieldMapping("FOrectangle",                                         nameof(FishingOperation.Forectangle), ConversionType.Lookup, CodeType.StatRec),
					new FieldMapping("FOgsaSubarea",                                        nameof(FishingOperation.FogsaSubarea), ConversionType.Lookup, CodeType.Areas_GFCM_GSA),
					new FieldMapping("FOjurisdictionArea",                                  nameof(FishingOperation.FojurisdictionArea), ConversionType.Lookup, CodeType.RS_JurisdictionArea),
					new FieldMapping("FOfishingDepth",                                      nameof(FishingOperation.FofishingDepth), ConversionType.InferFromPropertyType),
					new FieldMapping("FOwaterDepth",                                        nameof(FishingOperation.FowaterDepth), ConversionType.InferFromPropertyType),
					new FieldMapping("FOnationalFishingActivity",                           nameof(FishingOperation.FonationalFishingActivity), ConversionType.Lookup, CodeType.RS_NationalFishingActivity),
					new FieldMapping("FOmetier5",                                           nameof(FishingOperation.Fometier5), ConversionType.Lookup, CodeType.Metier5_FishingActivity),
					new FieldMapping("FOmetier6",                                           nameof(FishingOperation.Fometier6), ConversionType.Lookup, CodeType.Metier6_FishingActivity),
					new FieldMapping("FOgear",                                              nameof(FishingOperation.Fogear), ConversionType.Lookup, CodeType.GearType),
					new FieldMapping("FOmeshSize",                                          nameof(FishingOperation.FomeshSize), ConversionType.InferFromPropertyType),
					new FieldMapping("FOselectionDevice",                                   nameof(FishingOperation.FoselectionDevice), ConversionType.Lookup, CodeType.SelectionDevice),
					new FieldMapping("FOselectionDeviceMeshSize",                           nameof(FishingOperation.FoselectionDeviceMeshSize), ConversionType.InferFromPropertyType),
					new FieldMapping("FOtargetSpecies",                                     nameof(FishingOperation.FotargetSpecies), ConversionType.Lookup, CodeType.TargetSpecies),
					new FieldMapping("FOincidentalByCatchMitigationDeviceFirst",            nameof(FishingOperation.FoincidentalByCatchMitigationDeviceFirst), ConversionType.Lookup, CodeType.BycatchMitigationDevice),
					new FieldMapping("FOincidentalByCatchMitigationDeviceTargetFirst",      nameof(FishingOperation.FoincidentalByCatchMitigationDeviceTargetFirst), ConversionType.Lookup, CodeType.BycatchMitigationDeviceTarget),
					new FieldMapping("FOincidentalByCatchMitigationDeviceSecond",           nameof(FishingOperation.FoincidentalByCatchMitigationDeviceSecond), ConversionType.Lookup, CodeType.BycatchMitigationDevice),
					new FieldMapping("FOincidentalByCatchMitigationDeviceTargetSecond",     nameof(FishingOperation.FoincidentalByCatchMitigationDeviceTargetSecond), ConversionType.Lookup, CodeType.BycatchMitigationDeviceTarget),
					new FieldMapping("FOgearDimensions",                                    nameof(FishingOperation.FogearDimensions), ConversionType.InferFromPropertyType),
					new FieldMapping("FOobservationCode",                                   nameof(FishingOperation.FoobservationCode), ConversionType.Lookup, CodeType.ObservationCode),
					new FieldMapping("FOnumberTotal",                                       nameof(FishingOperation.FonumberTotal), ConversionType.InferFromPropertyType),
					new FieldMapping("FOnumberSampled",                                     nameof(FishingOperation.FonumberSampled), ConversionType.InferFromPropertyType),
					new FieldMapping("FOselectionProb",                                     nameof(FishingOperation.FoselectionProb), ConversionType.InferFromPropertyType),
					new FieldMapping("FOinclusionProb",                                     nameof(FishingOperation.FoinclusionProb), ConversionType.InferFromPropertyType),
					new FieldMapping("FOselectionMethod",                                   nameof(FishingOperation.FoselectionMethod), ConversionType.Lookup, CodeType.SelectionMethod),
					new FieldMapping("FOunitName",                                          nameof(FishingOperation.FounitName)),
					new FieldMapping("FOselectionMethodCluster",                            nameof(FishingOperation.FoselectionMethodCluster), ConversionType.Lookup, CodeType.SelectionMethod),
					new FieldMapping("FOnumberTotalClusters",                               nameof(FishingOperation.FonumberTotalClusters), ConversionType.InferFromPropertyType),
					new FieldMapping("FOnumberSampledClusters",                             nameof(FishingOperation.FonumberSampledClusters), ConversionType.InferFromPropertyType),
					new FieldMapping("FOselectionProbCluster",                              nameof(FishingOperation.FoselectionProbCluster), ConversionType.InferFromPropertyType),
					new FieldMapping("FOinclusionProbCluster",                              nameof(FishingOperation.FoinclusionProbCluster), ConversionType.InferFromPropertyType),
					new FieldMapping("FOsampled",                                           nameof(FishingOperation.Fosampled), ConversionType.Lookup, CodeType.YesNoFields),
					new FieldMapping("FOreasonNotSampled",                                  nameof(FishingOperation.ForeasonNotSampled), ConversionType.Lookup, CodeType.ReasonForNotSampling)
			})
		{
			this.ParentSetting.ParentPropertyName = nameof(FishingTrip.FishingOperations);
		}
	}
}
