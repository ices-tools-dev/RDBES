﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
	internal class FM : ElementMapping
	{
		public FM() :
			 base(
				  elementName: "FM",
				  objectTypeName: nameof(FrequencyMeasure),
				  tableName: null,
				  fields: new System.Collections.Generic.List<FieldMapping>
				  {
						new FieldMapping("RecordType",						nameof(FrequencyMeasure.FmrecordType)),
						new FieldMapping("FMstateOfProcessing",				nameof(FrequencyMeasure.FmstateOfProcessing), ConversionType.Lookup, CodeType.StateOfProcessing),
						new FieldMapping("FMpresentation",					nameof(FrequencyMeasure.Fmpresentation), ConversionType.Lookup, CodeType.Presentation),
						new FieldMapping("FMclassMeasured",					nameof(FrequencyMeasure.FmclassMeasured), ConversionType.InferFromPropertyType),
						new FieldMapping("FMnumberAtUnit",					nameof(FrequencyMeasure.FmnumberAtUnit), ConversionType.InferFromPropertyType),
						new FieldMapping("FMtypeMeasured",					nameof(FrequencyMeasure.FmtypeMeasured), ConversionType.Lookup, CodeType.BiologicalMeasurementType),
						new FieldMapping("FMmethod",						nameof(FrequencyMeasure.Fmmethod), ConversionType.Lookup, CodeType.SampleType),
						new FieldMapping("FMmeasurementEquipment",			nameof(FrequencyMeasure.FmmeasurementEquipment), ConversionType.Lookup, CodeType.METOA),
						new FieldMapping("FMaccuracy",						nameof(FrequencyMeasure.Fmaccuracy), ConversionType.Lookup, CodeType.RS_AccuracyCode),
						new FieldMapping("FMconversionFactorAssessment",	nameof(FrequencyMeasure.FmconversionFactorAssessment), ConversionType.InferFromPropertyType),
						new FieldMapping("FMtypeAssessment",				nameof(FrequencyMeasure.FmtypeAssessment), ConversionType.Lookup, CodeType.BiologicalMeasurementType),
						new FieldMapping("FMsampler",						nameof(FrequencyMeasure.Fmsampler), ConversionType.Lookup, CodeType.Sampler),
						new FieldMapping("FMaddGrpMeasurement",				nameof(FrequencyMeasure.FmaddGrpMeasurement), ConversionType.InferFromPropertyType),
						new FieldMapping("FMaddGrpMeasurementType",			nameof(FrequencyMeasure.FmaddGrpMeasurementType), ConversionType.Lookup, CodeType.BiologicalMeasurementType)

				  })
			{
				this.ParentSetting.ParentPropertyName = nameof(Sample.FrequencyMeasures);
			}
	}
}
