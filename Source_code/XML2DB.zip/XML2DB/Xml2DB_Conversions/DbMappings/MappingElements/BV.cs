﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{


    internal class BV : ElementMapping
    {
        public BV() :
             base(
                  elementName: "BV",
                  objectTypeName: nameof(BiologicalVariable),
                  tableName: null,
                  fields: new System.Collections.Generic.List<FieldMapping>
                  {
                        new FieldMapping("RecordType",                      nameof(BiologicalVariable.BvrecordType)),
                        new FieldMapping("BVnationalUniqueFishId",          nameof(BiologicalVariable.BvnationalUniqueFishId)),
                        new FieldMapping("BVstateOfProcessing",             nameof(BiologicalVariable.BvstateOfProcessing), ConversionType.Lookup, CodeType.StateOfProcessing),
                        new FieldMapping("BVpresentation",                  nameof(BiologicalVariable.Bvpresentation), ConversionType.Lookup, CodeType.Presentation),
                        new FieldMapping("BVstratification",                nameof(BiologicalVariable.Bvstratification), ConversionType.Lookup, CodeType.YesNoFields),
                        new FieldMapping("BVstratumName",                   nameof(BiologicalVariable.BvstratumName)),
                        new FieldMapping("BVtypeMeasured",                  nameof(BiologicalVariable.BvtypeMeasured), ConversionType.Lookup, CodeType.BiologicalMeasurementType),
                        new FieldMapping("BVvalueMeasured",                 nameof(BiologicalVariable.BvvalueMeasured)),
                        new FieldMapping("BVvalueUnitOrScale",              nameof(BiologicalVariable.BvvalueUnitOrScale), ConversionType.Lookup, CodeType.ValueUnitOrScale),
                        new FieldMapping("BVmethod",                        nameof(BiologicalVariable.Bvmethod), ConversionType.Lookup, CodeType.SampleType),
                        new FieldMapping("BVmeasurementEquipment",          nameof(BiologicalVariable.BvmeasurementEquipment), ConversionType.Lookup, CodeType.METOA),
                        new FieldMapping("BVaccuracy",                      nameof(BiologicalVariable.Bvaccuracy), ConversionType.Lookup, CodeType.RS_AccuracyCode),
                        new FieldMapping("BVcertaintyQualitative",          nameof(BiologicalVariable.BvcertaintyQualitative), ConversionType.Lookup, CodeType.MeasurementCertainty),
                        new FieldMapping("BVcertaintyQuantitative",         nameof(BiologicalVariable.BvcertaintyQuantitative), ConversionType.InferFromPropertyType),
                        new FieldMapping("BVconversionFactorAssessment",    nameof(BiologicalVariable.BvconversionFactorAssessment), ConversionType.InferFromPropertyType),
                        new FieldMapping("BVtypeAssessment",                nameof(BiologicalVariable.BvtypeAssessment), ConversionType.Lookup, CodeType.BiologicalMeasurementType),
                        new FieldMapping("BVnumberTotal",                   nameof(BiologicalVariable.BvnumberTotal), ConversionType.InferFromPropertyType),
                        new FieldMapping("BVnumberSampled",                 nameof(BiologicalVariable.BvnumberSampled), ConversionType.InferFromPropertyType),
                        new FieldMapping("BVselectionProb",                 nameof(BiologicalVariable.BvselectionProb), ConversionType.InferFromPropertyType),
                        new FieldMapping("BVinclusionProb",                 nameof(BiologicalVariable.BvinclusionProb), ConversionType.InferFromPropertyType),
                        new FieldMapping("BVselectionMethod",               nameof(BiologicalVariable.BvselectionMethod), ConversionType.Lookup, CodeType.SelectionMethod),
                        new FieldMapping("BVunitName",                      nameof(BiologicalVariable.BvunitName)),
                        new FieldMapping("BVsampler",                       nameof(BiologicalVariable.Bvsampler), ConversionType.Lookup, CodeType.Sampler)
                  })
        {
            this.ParentSetting.ParentPropertyName = nameof(FrequencyMeasure.BiologicalVariables);
        }
    }
}
