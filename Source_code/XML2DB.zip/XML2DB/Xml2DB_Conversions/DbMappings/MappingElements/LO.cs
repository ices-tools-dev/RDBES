﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
	internal class LO : ElementMapping
	{
		public LO() :
			base(
				elementName: "LO",
				objectTypeName: nameof(Location),
				tableName: null,
				fields: new System.Collections.Generic.List<FieldMapping>
				{
					new FieldMapping("RecordType",						nameof(Location.LorecordType)),
					new FieldMapping("LOsequenceNumber",				nameof(Location.LosequenceNumber), ConversionType.InferFromPropertyType),
					new FieldMapping("LOstratification",				nameof(Location.Lostratification), ConversionType.Lookup, CodeType.YesNoFields),
					new FieldMapping("LOlocode",						nameof(Location.Lolocode), ConversionType.Lookup, CodeType.Harbour_LOCODE),
					new FieldMapping("LOlocationName",					nameof(Location.LolocationName)),
					new FieldMapping("LOlocationType",					nameof(Location.LolocationType), ConversionType.Lookup, CodeType.RS_LocationType),
					new FieldMapping("LOstratumName",					nameof(Location.LostratumName)),
					new FieldMapping("LOclustering",					nameof(Location.Loclustering), ConversionType.Lookup, CodeType.RS_Clustering),
					new FieldMapping("LOclusterName",					nameof(Location.LoclusterName)),
					new FieldMapping("LOsampler",						nameof(Location.Losampler), ConversionType.Lookup, CodeType.Sampler),
					new FieldMapping("LOnumberTotal",					nameof(Location.LonumberTotal), ConversionType.InferFromPropertyType),
					new FieldMapping("LOnumberSampled",					nameof(Location.LonumberSampled), ConversionType.InferFromPropertyType),
					new FieldMapping("LOselectionProb",					nameof(Location.LoselectionProb), ConversionType.InferFromPropertyType),
					new FieldMapping("LOinclusionProb",					nameof(Location.LoinclusionProb), ConversionType.InferFromPropertyType),
					new FieldMapping("LOselectionMethod",				nameof(Location.LoselectionMethod), ConversionType.Lookup, CodeType.SelectionMethod),
					new FieldMapping("LOunitName",						nameof(Location.LounitName)),
					new FieldMapping("LOselectionMethodCluster",		nameof(Location.LoselectionMethodCluster), ConversionType.Lookup, CodeType.SelectionMethod),
					new FieldMapping("LOnumberTotalClusters",			nameof(Location.LonumberTotalClusters), ConversionType.InferFromPropertyType),
					new FieldMapping("LOnumberSampledClusters",			nameof(Location.LonumberSampledClusters), ConversionType.InferFromPropertyType),
					new FieldMapping("LOselectionProbCluster",			nameof(Location.LoselectionProbCluster), ConversionType.InferFromPropertyType),
					new FieldMapping("LOinclusionProbCluster",			nameof(Location.LoinclusionProbCluster), ConversionType.InferFromPropertyType),
					new FieldMapping("LOsampled",						nameof(Location.Losampled), ConversionType.Lookup, CodeType.YesNoFields),
					new FieldMapping("LOreasonNotSampled",				nameof(Location.LoreasonNotSampled), ConversionType.Lookup, CodeType.ReasonForNotSampling)
				})
		{
			this.ParentSetting.ParentPropertyName = nameof(SamplingDetail.Locations);
		}
	}
}

