﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
	internal class DE : ElementMapping
	{
		public DE() :
			base(
				elementName: "DE",
				objectTypeName: nameof(Design),
				tableName: null,
				fields: new System.Collections.Generic.List<FieldMapping>
				{
					new FieldMapping("RecordType",                  nameof(Design.DerecordType)),
					new FieldMapping("DEsamplingScheme",			nameof(Design.DesamplingScheme), ConversionType.Lookup, CodeType.RS_SamplingScheme),
					new FieldMapping("DEsamplingSchemeType",		nameof(Design.DesamplingSchemeType), ConversionType.Lookup, CodeType.SamplingSchemeType),
					new FieldMapping("DEyear",						nameof(Design.Deyear), ConversionType.Lookup, CodeType.Year),
					new FieldMapping("DEstratumName",				nameof(Design.DestratumName)),
					new FieldMapping("DEhierarchyCorrect",			nameof(Design.DehierarchyCorrect), ConversionType.Lookup, CodeType.YesNoFields),
					new FieldMapping("DEhierarchy",					nameof(Design.Dehierarchy), ConversionType.Lookup, CodeType.RS_UpperHierarchy),
					new FieldMapping("DEsampled",					nameof(Design.Desampled), ConversionType.Lookup, CodeType.YesNoFields),
					new FieldMapping("DEreasonNotSampled",			nameof(Design.DereasonNotSampled), ConversionType.Lookup, CodeType.ReasonForNotSampling)

				},
				parentSetting: new ParentDiscoverySetting { DiscoveryApproach = ParentDiscoveryOption.NoParent }
			){ }
	}
}
