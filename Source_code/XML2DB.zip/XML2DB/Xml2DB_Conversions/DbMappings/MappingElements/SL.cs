﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
    internal class SL : ElementMapping
    {
        public SL() :
            base(
                elementName: "SL",
                objectTypeName: nameof(SpeciesList),
                tableName: null,
                fields: new System.Collections.Generic.List<FieldMapping>
                {
                        new FieldMapping("RecordType",                  nameof(SpeciesList.SlrecordType)),
                        new FieldMapping("SLcountry",                   nameof(SpeciesList.Slcountry), ConversionType.Lookup, CodeType.ISO_3166),
                        new FieldMapping("SLinstitute",                 nameof(SpeciesList.Slinstitute), ConversionType.Lookup, CodeType.EDMO),
                        new FieldMapping("SLspeciesListName",           nameof(SpeciesList.SlspeciesListName)),
                        new FieldMapping("SLyear",                      nameof(SpeciesList.Slyear), ConversionType.Lookup, CodeType.Year),
                        new FieldMapping("SLcatchFraction",             nameof(SpeciesList.SlcatchFraction), ConversionType.Lookup, CodeType.RS_CatchFraction),
                        new FieldMapping("SLcommercialTaxon",           nameof(SpeciesList.SlcommercialTaxon), ConversionType.Lookup, CodeType.SpecWoRMS),
                        new FieldMapping("SLspeciesCode",               nameof(SpeciesList.SlspeciesCode), ConversionType.Lookup, CodeType.SpecWoRMS)

                })
        { }
    }

}
