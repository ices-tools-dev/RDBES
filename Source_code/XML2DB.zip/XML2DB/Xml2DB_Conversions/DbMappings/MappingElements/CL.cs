﻿using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;

namespace Xml2DB_Conversions.DbMappings.MappingElements

{
    internal class CL : ElementMapping
    {
        public CL() :
            base(
                elementName: nameof(CL),
                objectTypeName: nameof(CommercialLanding),
                tableName: null,
                fields: new System.Collections.Generic.List<FieldMapping>
                {

                        new FieldMapping("RecordType",                              nameof(CommercialLanding.ClrecordType)),
                        new FieldMapping("CLdataTypeOfScientificWeight",            nameof(CommercialLanding.CldataTypeOfScientificWeight), ConversionType.Lookup, CodeType.RS_DataTypeOfScientificWE),
                        new FieldMapping("CLdataSourceOfScientificWeight",          nameof(CommercialLanding.CldataSourceOfScientificWeight), ConversionType.Lookup, CodeType.RS_DataSourceOfScientificWE),
                        new FieldMapping("CLsamplingScheme",                        nameof(CommercialLanding.ClsamplingScheme), ConversionType.Lookup, CodeType.RS_SamplingScheme),
                        new FieldMapping("CLdataSourceLandingsValue",               nameof(CommercialLanding.CldataSourceLandingsValue), ConversionType.Lookup, CodeType.RS_DataSourceLandingsValue),
                        new FieldMapping("CLlandingCountry",                        nameof(CommercialLanding.CllandingCountry), ConversionType.Lookup, CodeType.ISO_3166),
                        new FieldMapping("CLvesselFlagCountry",                     nameof(CommercialLanding.ClvesselFlagCountry), ConversionType.Lookup, CodeType.ISO_3166),
                        new FieldMapping("CLyear",                                  nameof(CommercialLanding.Clyear), ConversionType.Lookup, CodeType.Year),
                        new FieldMapping("CLquarter",                               nameof(CommercialLanding.Clquarter), ConversionType.Lookup, CodeType.Quarter),
                        new FieldMapping("CLmonth",                                 nameof(CommercialLanding.Clmonth), ConversionType.Lookup, CodeType.Month),
                        new FieldMapping("CLarea",                                  nameof(CommercialLanding.Clarea), ConversionType.Lookup, CodeType.ICES_Area),
                        new FieldMapping("CLstatisticalRectangle",                  nameof(CommercialLanding.ClstatisticalRectangle), ConversionType.Lookup, CodeType.StatRec),
                        new FieldMapping("CLgsaSubarea",                            nameof(CommercialLanding.ClgsaSubarea), ConversionType.Lookup, CodeType.Areas_GFCM_GSA),
                        new FieldMapping("CLjurisdictionArea",                      nameof(CommercialLanding.CljurisdictionArea), ConversionType.Lookup, CodeType.RS_JurisdictionArea),
                        new FieldMapping("CLexclusiveEconomicZoneIndicator",        nameof(CommercialLanding.ClexclusiveEconomicZoneIndicator), ConversionType.Lookup, CodeType.RS_EEZI),
                        new FieldMapping("CLspeciesCode",                           nameof(CommercialLanding.ClspeciesCode), ConversionType.Lookup, CodeType.SpecWoRMS),
                        new FieldMapping("CLspeciesFaoCode",                        nameof(CommercialLanding.ClspeciesFaoCode), ConversionType.Lookup, CodeType.SpecASFIS),
                        new FieldMapping("CLlandingCategory",                       nameof(CommercialLanding.CllandingCategory), ConversionType.Lookup, CodeType.RS_LandingCategory),
                        new FieldMapping("CLcatchCategory",                         nameof(CommercialLanding.ClcatchCategory), ConversionType.Lookup, CodeType.RS_CatchCategory),
                        new FieldMapping("CLregDisCategory",                        nameof(CommercialLanding.ClregDisCategory), ConversionType.Lookup, CodeType.RegDisCategory),
                        new FieldMapping("CLcommercialSizeCategoryScale",           nameof(CommercialLanding.ClcommercialSizeCategoryScale), ConversionType.Lookup, CodeType.CommercialSizeCategoryScale),
                        new FieldMapping("CLcommercialSizeCategory",                nameof(CommercialLanding.ClcommercialSizeCategory), ConversionType.Lookup, CodeType.RS_CommercialSizeCategory),
                        new FieldMapping("CLnationalFishingActivity",               nameof(CommercialLanding.ClnationalFishingActivity), ConversionType.Lookup, CodeType.RS_NationalFishingActivity),
                        new FieldMapping("CLmetier6",                               nameof(CommercialLanding.Clmetier6), ConversionType.Lookup, CodeType.Metier6_FishingActivity),
                        new FieldMapping("CLincidentialByCatchMitigationDevice",    nameof(CommercialLanding.ClincidentialByCatchMitigationDevice), ConversionType.Lookup, CodeType.BycatchMitigationDevice),
                        new FieldMapping("CLlandingLocation",                       nameof(CommercialLanding.CllandingLocation), ConversionType.Lookup, CodeType.Harbour_LOCODE),
                        new FieldMapping("CLvesselLengthCategory",                  nameof(CommercialLanding.ClvesselLengthCategory), ConversionType.Lookup, CodeType.RS_VesselLengthCategory),
                        new FieldMapping("CLfishingTechnique",                      nameof(CommercialLanding.ClfishingTechnique), ConversionType.Lookup, CodeType.RS_FishingTechnique),
                        new FieldMapping("CLdeepSeaRegulation",                     nameof(CommercialLanding.CldeepSeaRegulation), ConversionType.Lookup, CodeType.YesNoFields),
                        new FieldMapping("CLofficialWeight",                        nameof(CommercialLanding.ClofficialWeight), ConversionType.InferFromPropertyType),
                        new FieldMapping("CLscientificWeight",                      nameof(CommercialLanding.ClscientificWeight), ConversionType.InferFromPropertyType),
                        new FieldMapping("CLexplainDifference",                     nameof(CommercialLanding.ClexplainDifference), ConversionType.Lookup, CodeType.RS_ExplainDifference),
                        new FieldMapping("CLtotalOfficialLandingsValue",            nameof(CommercialLanding.CltotalOfficialLandingsValue), ConversionType.InferFromPropertyType),
                        new FieldMapping("CLnumberOfUniqueVessels",                 nameof(CommercialLanding.ClnumberOfUniqueVessels), ConversionType.InferFromPropertyType),
                        new FieldMapping("CLscientificWeightRSE",                   nameof(CommercialLanding.ClscientificWeightRse), ConversionType.InferFromPropertyType),
                        new FieldMapping("CLvalueRSE",                              nameof(CommercialLanding.ClvalueRse), ConversionType.InferFromPropertyType),
                        new FieldMapping("CLscientificWeightQualitativeBias",       nameof(CommercialLanding.ClscientificWeightQualitativeBias), ConversionType.Lookup, CodeType.RS_QualitativeBias)
                })
        { }
    }
}
