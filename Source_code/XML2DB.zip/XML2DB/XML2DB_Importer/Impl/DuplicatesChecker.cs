﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xml2DB_Conversions;
using Xml2DB_Conversions.CheckDuplicates;
using Xml2DB_Conversions.CheckDuplicates.ResultTypes;
using Xml2DB_Conversions.ConversionSets;
using Xml2DB_Conversions.IdLookup;
using Xml2DB_DAL;
using Xml2DB_DAL.Models;
using XML2DB_Mapping;
using XML2DB_Mapping.Conversions;
using XML2DB_Reader;
using XML2DB_Reader.Definitions;

namespace XML2DB_Importer.Impl
{
	public class DuplicatesChecker : IDuplicatesChecker
	{
		public const int DB_COMMAND_TIMEOUT_MINUTES = 60;
		private readonly DatabaseContext context;
		private readonly IDbDuplicateCheckerFactory dbDuplicateCheckerFactory;
		private readonly ILookupProvider lookupProvider;
		private readonly IidLookup idLookup;

		public DuplicatesChecker(DatabaseContext context, IDbDuplicateCheckerFactory factory, ILookupProvider lookupProvider = null, IidLookup idLookup = null)
		{
			this.context = context;
			context.Database.SetCommandTimeout(TimeSpan.FromMinutes(DB_COMMAND_TIMEOUT_MINUTES));
			this.dbDuplicateCheckerFactory = factory;
			if (lookupProvider == null)
			{
				var provider = new LookupProvider();
				provider.Load(context);
				lookupProvider = provider;
			}
			this.lookupProvider = lookupProvider;
			if (idLookup == null)
			{
				var slItems = Utils.GetSLItems(context);
				var vdItems = context.VesselDetails.ToList();
				idLookup = new IdLookup(slItems, vdItems);
			}
			this.idLookup = idLookup;
		}

		public async Task<IEnumerable<TResult>> CheckFoDuplicates<TResult>(string pathToXml, string hierarchyName)
		{
			var conversionSet = ConversionSet.GetByHierarchyName(hierarchyName);
			AjdustXmlDefinition(conversionSet.XmlSet.ElementDefinitions);
			
			switch (hierarchyName)
			{
				case "HCE":
					return await CheckFoDuplicatesWithReader<TResult, CommercialEffort>(pathToXml, hierarchyName, conversionSet);
				case "HCL":
					return await CheckFoDuplicatesWithReader<TResult, CommercialLanding>(pathToXml, hierarchyName, conversionSet);
				default:
					break;
			}

			// load xml
			List<Element> elements = null;
			DebugUtils.MeasureTime("Loading Xml",
				() =>  elements = LoadXml(pathToXml, conversionSet.XmlSet)
			);
			/// map xml to the db models
			List<object> mappedContent = MapContent(elements, conversionSet.Mapping.ElementMappings);
			/// use factory to create respective DB duplicate checker for the given hierarchy name
			IDbDuplicateChecker<TResult> dbDuplicatesChecker = dbDuplicateCheckerFactory.CreateDbDuplicateChecker<TResult>(context, hierarchyName);
			/// now use the checker to find duplicates in db
			return await dbDuplicatesChecker.Check(mappedContent);
		}

		private async Task<IEnumerable<TResult>> CheckFoDuplicatesWithReader<TResult, TDbType>(string pathToXml, string hierarchyName, ConversionSet conversionSet) where TDbType : class
		{
			var reader = new Reader(pathToXml, conversionSet.XmlSet, conversionSet.XmlSet.ElementDefinitions[0].Name);
			AjdustMappings(conversionSet.Mapping.ElementMappings);
			Mapper mapper = new Mapper(conversionSet.Mapping.ElementMappings, lookupProvider, idLookup);
			var enumerableReader = MakeEnumerable<TDbType>(reader, mapper, conversionSet.Mapping.ElementMappings[0]);
			/// use factory to create respective DB duplicate checker for the given hierarchy name
			IDbDuplicateChecker<TResult> dbDuplicatesChecker = dbDuplicateCheckerFactory.CreateDbDuplicateChecker<TResult>(context, hierarchyName);
			/// now use the checker to find duplicates in db
			return await dbDuplicatesChecker.Check(enumerableReader);
		}

		public IEnumerable<T> MakeEnumerable<T>(IReader reader, Mapper mapper, ElementMapping mapping) where T : class
		{
			while (!reader.Finished)
			{
				var element = reader.Read();
				if (element == null)
					break;
				var result = mapper.ConvertToFlatObject<T>(element, mapping) as T;
				yield return result;
			}
		}

		private void AjdustXmlDefinition(List<ElementDefinition> definitions)
		{
			foreach (var definition in definitions)
			{
				definition.FieldDefinitions.Add(new FieldDefinition(name: "ln", type: FieldXmlType.Attribute));
				AjdustXmlDefinition(definition.ChildElementsDefinitions);
			}
		}

		private void AjdustMappings(List<ElementMapping> mappings)
		{
			foreach (var mapping in mappings)
			{
				FieldMapping lineNoMapping = new FieldMapping("ln", "LineNo", ConversionType.InferFromPropertyType);
				mapping.FieldMappings.Add(lineNoMapping.FieldName, lineNoMapping);
				AjdustMappings(mapping.ChildElmentsMappings.Values.ToList());
			}
		}

		private List<object> MapContent(List<Element> elements, List<ElementMapping> mappings)
		{
			AjdustMappings(mappings);
			Mapper mapper = new Mapper(mappings, lookupProvider, idLookup);
			return mapper.MapToObjects(elements);
		}

		private List<Element> LoadXml(string pathToXml, XmlDefinition xmlDefinition)
		{
			Loader loader = new Loader(pathToXml, xmlDefinition);
			return loader.ReadAll();
		}



		public async Task<IEnumerable<object>> CheckFoDuplicatesNonTyped(string pathToXml, string hierarchyName)
		{
			switch (hierarchyName)
			{
				case nameof(HCE):
					return await CheckFoDuplicates<HCE_DuplicateInfo>(pathToXml, hierarchyName);
				case nameof(HCL):
					return await CheckFoDuplicates<HCL_DuplicateInfo>(pathToXml, hierarchyName);
				case nameof(HSL):
					return await CheckFoDuplicates<HSL_DuplicateInfo>(pathToXml, hierarchyName);
				case nameof(HVD):
					return await CheckFoDuplicates<HVD_DuplicateInfo>(pathToXml, hierarchyName);

				case nameof(H1):
				case nameof(H2):
				case nameof(H3):
				case nameof(H4):
				case nameof(H5):
				case nameof(H6):
				case nameof(H7):
				case nameof(H8):
				case nameof(H9):
				case nameof(H10):
				case nameof(H11):
				case nameof(H12):
				case nameof(H13):
					return await CheckFoDuplicates<HCS_DuplicateInfo>(pathToXml, hierarchyName);
				default:
					throw new NotSupportedException($"Unrecognized hierarchy: {hierarchyName}");
			}
		}
	}
}
