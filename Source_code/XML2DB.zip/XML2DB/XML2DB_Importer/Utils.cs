﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Xml2DB_Conversions.IdLookup;
using Xml2DB_DAL;
using Xml2DB_DAL.Models;

namespace XML2DB_Importer
{
	internal static class Utils
	{
		public static Expression<Func<Design, bool>> MakePredicate(Design item)
		{
			return (Design de) =>
					de.DesamplingScheme == item.DesamplingScheme
					&& de.Deyear == item.Deyear
					&& de.DestratumName == item.DestratumName
					&& de.Dehierarchy == item.Dehierarchy;
		}

		public static Expression<Func<SamplingDetail, bool>> MakePredicate(SamplingDetail item)
		{
			return (SamplingDetail sd) =>
					sd.Sdcountry == item.Sdcountry
					&& sd.Sdinstitution == item.Sdinstitution;
		}

		public static Func<CommercialEffort, bool> MakePredicate(CommercialEffort item)
		{
			return (CommercialEffort ce) =>
					ce.CedataTypeForScientificEffort == item.CedataTypeForScientificEffort
					&& ce.CedataSourceForScientificEffort == item.CedataSourceForScientificEffort
					//&& ce.CenationalProgramBehScientificEffort == item.CenationalProgramBehScientificEffort
					&& ce.CevesselFlagCountry == item.CevesselFlagCountry
					&& ce.Ceyear == item.Ceyear
					&& ce.Cequarter == item.Cequarter
					&& ce.Cemonth == item.Cemonth
					&& ce.Cearea == item.Cearea
					&& ce.CestatisticalRectangle == item.CestatisticalRectangle
					&& ce.CegsaSubarea == item.CegsaSubarea
					&& ce.CeexclusiveEconomicZoneIndicator == item.CeexclusiveEconomicZoneIndicator
					&& ce.CenationalFishingActivity == item.CenationalFishingActivity
					&& ce.Cemetier6 == item.Cemetier6
					&& ce.CeincidentalByCatchMitigationDevice == item.CeincidentalByCatchMitigationDevice
					&& ce.CelandingLocation == item.CelandingLocation
					&& ce.CevesselLengthCategory == item.CevesselLengthCategory
					&& ce.CefishingTechnique == item.CefishingTechnique
					&& ce.CedeepSeaRegulation == item.CedeepSeaRegulation
					&& ce.CejurisdictionArea == item.CejurisdictionArea;
		}

		public static Func<CommercialLanding, bool> MakePredicate(CommercialLanding item)
		{
			return (CommercialLanding cl) =>
					cl.CldataTypeOfScientificWeight == item.CldataTypeOfScientificWeight
					&& cl.CldataSourceOfScientificWeight == item.CldataSourceOfScientificWeight
					&& cl.CldataSourceLandingsValue == item.CldataSourceLandingsValue
					&& cl.CllandingCountry == item.CllandingCountry
					&& cl.ClvesselFlagCountry == item.ClvesselFlagCountry
					&& cl.Clyear == item.Clyear
					&& cl.Clquarter == item.Clquarter
					&& cl.Clmonth == item.Clmonth
					&& cl.Clarea == item.Clarea
					&& cl.ClstatisticalRectangle == item.ClstatisticalRectangle
					&& cl.ClgsaSubarea == item.ClgsaSubarea
					&& cl.CljurisdictionArea == item.CljurisdictionArea
					&& cl.ClexclusiveEconomicZoneIndicator == item.ClexclusiveEconomicZoneIndicator
					&& cl.ClspeciesCode == item.ClspeciesCode
					&& cl.ClspeciesFaoCode == item.ClspeciesFaoCode
					&& cl.CllandingCategory == item.CllandingCategory
					&& cl.ClcatchCategory == item.ClcatchCategory
					&& cl.ClregDisCategory == item.ClregDisCategory
					&& cl.ClcommercialSizeCategoryScale == item.ClcommercialSizeCategoryScale
					&& cl.ClcommercialSizeCategory == item.ClcommercialSizeCategory
					&& cl.ClnationalFishingActivity == item.ClnationalFishingActivity
					&& cl.Clmetier6 == item.Clmetier6
					&& cl.CllandingLocation == item.CllandingLocation
					&& cl.ClvesselLengthCategory == item.ClvesselLengthCategory
					&& cl.ClsamplingScheme == item.ClsamplingScheme
					&& cl.ClincidentialByCatchMitigationDevice == item.ClincidentialByCatchMitigationDevice
					&& cl.ClfishingTechnique == item.ClfishingTechnique
					&& cl.CldeepSeaRegulation == item.CldeepSeaRegulation;
		}

		public static Expression<Func<SpeciesList, bool>> MakePredicate(SpeciesList item)
		{
			return (SpeciesList sl) =>
					sl.Slcountry == item.Slcountry
					&& sl.SlspeciesListName == item.SlspeciesListName
					&& sl.Slyear == item.Slyear
					&& sl.SlcatchFraction == item.SlcatchFraction
					&& sl.SlcommercialTaxon == item.SlcommercialTaxon
					&& sl.SlspeciesCode == item.SlspeciesCode;
		}

		public static Expression<Func<VesselDetail, bool>> MakePredicate(VesselDetail item)
		{
			return (VesselDetail vd) =>
					vd.Vdcountry == item.Vdcountry
					&& vd.VdencryptedVesselCode == item.VdencryptedVesselCode
					&& vd.Vdyear == item.Vdyear;
		}

		public static IEnumerable<IdLookup.SLItem> GetSLItems(DatabaseContext context)
		{
			var result = context.SpeciesLists.GroupBy(sl => new { sl.Slcountry, sl.SlspeciesListName, sl.Slyear, sl.SlcatchFraction })
				.Select(slg => new IdLookup.SLItem
				{
					Slid = slg.Min(sl => sl.Slid),
					Slcountry = slg.Key.Slcountry,
					SlspeciesListName = slg.Key.SlspeciesListName,
					Slyear = slg.Key.Slyear,
					SlcatchFraction = slg.Key.SlcatchFraction
				});
			return result;
		}


	}
}
