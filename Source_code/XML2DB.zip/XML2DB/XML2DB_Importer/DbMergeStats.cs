﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace XML2DB_Importer
{
	public class DbMergeStats 
	{
		private Dictionary<Type, Counter> _content = new Dictionary<Type, Counter>();
		private readonly Counter _Totals = new Counter();

		public List<KeyValuePair<Type, Counter>> Content
		{
			get
			{
				return _content.Select(p => p).ToList();
			}
		}

		public void AddInserts(Type type, int count)
		{
			lock (_content)
			{
				GetCounter(type).Inserts += count;
				_Totals.Inserts += count;
			}
		}
		public void AddUpdates(Type type, int count)
		{
			lock (_content)
			{
				GetCounter(type).Updates += count;
				_Totals.Updates += count;
			}
		}
		public void AddDeletes(Type type, int count)
		{
			lock (_content)
			{
				GetCounter(type).Deletes += count;
				_Totals.Deletes += count;
			}
		}

		public override string ToString()
		{
			StringBuilder sbResult = new StringBuilder();
			foreach (var pair in _content)
			{
                if (pair.Value.HasAnyOperation)
                {
                    sbResult.AppendLine($"{pair.Key.Name}\n{pair.Value}");
                }
			}
			if (_Totals.HasAnyOperation)
			{
				sbResult.AppendLine($"Total:\n{_Totals}");
			}
			return sbResult.ToString();
		}

		private Counter GetCounter(Type type)
		{
			Counter counter;
			if (!_content.TryGetValue(type, out counter))
			{
				counter = new Counter();
				_content.Add(type, counter);
			}
			return counter;
		}
	}

	public class Counter
	{
		public int Inserts { get; set; }
		public int Updates { get; set; }
		public int Deletes { get; set; }

        public bool HasAnyOperation
        {
            get
            {
                return Inserts != 0 || Updates != 0 || Deletes != 0;
            }
        }

		public override string ToString()
		{
			return $"Inserts: {Inserts}      Updates: {Updates}      Deletes: {Deletes}";
        }
	}
}
