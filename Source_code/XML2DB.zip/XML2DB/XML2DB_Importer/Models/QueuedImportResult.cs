﻿
namespace XML2DB_Importer.Models
{
    public class QueuedImportResult<T>
    {
        public int ImportQueueId { get; set; }
        public string UploadedFileName { get; set; }
        public bool Success { get; set; } = false;
        public UserData RequestedUser { get; set; }
        public T Content { get; set; }
    }
}
