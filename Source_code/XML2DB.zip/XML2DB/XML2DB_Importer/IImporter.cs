﻿using System.Threading.Tasks;
using Xml2DB_Conversions.ConversionSets;

namespace XML2DB_Importer
{
	public interface IImporter
	{
		Task<DbMergeStats> Import(string pathToXml, ConversionSet conversionSet, string userId);
	}
}