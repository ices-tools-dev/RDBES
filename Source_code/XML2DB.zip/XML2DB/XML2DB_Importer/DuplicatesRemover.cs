﻿using System.Collections.Generic;
using System.Linq;
using Xml2DB_Conversions.ConversionSets;
using Xml2DB_DAL;
using Xml2DB_DAL.Models;

namespace XML2DB_Importer
{
	internal class DuplicatesRemover
	{
		private readonly DatabaseContext context;
		private DbMergeStats stats;

		public class DuplicateInfo
		{
			public Design DE { get; set; }
			public SamplingDetail SD { get; set; }
		}

		public DuplicatesRemover(DatabaseContext context)
		{
			this.context = context;
		}

		public List<DuplicateInfo> RemoveDuplicates(List<object> elements, ConversionSet conversionSet, DbMergeStats stats)
		{
			this.stats = stats;
			var removedDuplicates = new List<DuplicateInfo>();
			foreach (var de in elements)
			{
				CheckAndRemoveDuplicates(de as Design, removedDuplicates, conversionSet);
			}
			return removedDuplicates;
		}

		private void CheckAndRemoveDuplicates(Design de, List<DuplicateInfo> duplicates, ConversionSet conversionSet)
		{
			if (de == null)
			{
				return;
			}
			var deRecord = conversionSet.LoadFromDb(context, Utils.MakePredicate(de));
			if (deRecord == null)
			{
				return;
			}
			int removedSdRecordsCount = 0;
			foreach (var sd in de.SamplingDetails)
			{
				if (CheckAndRemoveSd(deRecord, sd))
				{
					removedSdRecordsCount++;
					duplicates.Add(new DuplicateInfo { DE = de, SD = sd });
				}
			}
			if (deRecord.SamplingDetails.Count == 0)
			{
				context.Remove(deRecord);
				stats.AddDeletes(deRecord.GetType(), 1);
			}
		}

		private bool CheckAndRemoveSd(Design de, SamplingDetail sd)
		{
			var existingSd = de.SamplingDetails
							.Where(Utils.MakePredicate(sd).Compile())
							.Select(sdRecord => sdRecord).SingleOrDefault();
			if (existingSd != null)
			{
				de.SamplingDetails.Remove(existingSd);
				context.RemoveEntity(existingSd, stats);
				return true;
			}
			return false;
		}

	}
}
