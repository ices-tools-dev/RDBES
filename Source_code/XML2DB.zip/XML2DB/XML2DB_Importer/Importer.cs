﻿using System;
using System.Collections.Generic;
using Xml2DB_DAL;
using XML2DB_Mapping;
using XML2DB_Reader;
using XML2DB_Reader.Definitions;
using Xml2DB_DAL.Models;
using Xml2DB_Conversions.ConversionSets;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using XML2DB_Mapping.Conversions;
using System.Linq;
using Xml2DB_Conversions.IdLookup;
using System.Collections;
using XML2DB_Importer.ImportFlatData;
using System.Data.SqlClient;
using Xml2DB_Conversions;


namespace XML2DB_Importer
{
	public class Importer : IImporter
	{
		public const int DB_COMMAND_TIMEOUT_MINUTES = 60;
		private readonly DatabaseContext context;
		private readonly ILookupProvider lookupProvider;
		private readonly IidLookup idLookup;

		public Importer(DatabaseContext context, ILookupProvider lookupProvider = null, IidLookup idLookup = null)
		{
			this.context = context;
			this.context.Database.SetCommandTimeout(TimeSpan.FromMinutes(DB_COMMAND_TIMEOUT_MINUTES));
			if (lookupProvider == null)
			{
				var provider = new LookupProvider();
				provider.Load(context);
				lookupProvider = provider;
			}
			this.lookupProvider = lookupProvider;
			if (idLookup == null)
			{
				var slItems = Utils.GetSLItems(context);
				var vdItems = context.VesselDetails.ToList();
				idLookup = new IdLookup(slItems, vdItems);
			}
			this.idLookup = idLookup;

		}

		public async Task<DbMergeStats> Import(string pathToXml, ConversionSet conversionSet, string userId)
		{
			return conversionSet.GetType().Name switch
			{
				nameof(HCE) => await ImportCommercialEffort(pathToXml, conversionSet, userId),
				nameof(HCL) => await ImportCommercialLanding(pathToXml, conversionSet, userId),
				_ => await ImportRegular(pathToXml, conversionSet, userId),
			};
		}

		private void FillSystemFields(object content, string userId, DateTime time)
		{
			if (content is IModelWithUserIdAndTimeStamp stamp)
			{
				stamp.UserId = userId;
				stamp.TimeStamp = time;
			}
			foreach (var childList in ReflectionUtils.GetObjectChildLists(content))
			{
				foreach (var child in (IEnumerable)childList)
				{
					FillSystemFields(child, userId, time);
				}
			}
		}

		private static List<Element> LoadXml(string pathToXml, XmlDefinition xmlDefinition)
		{
			Loader loader = new(pathToXml, xmlDefinition);
			return loader.ReadAll();
		}

		private List<object> MapContent(List<Element> elements, List<ElementMapping> mappings)
		{
			Mapper mapper = new(mappings, lookupProvider, idLookup);
			return mapper.MapToObjects(elements);
		}

		private async Task<DbMergeStats> ImportRegular(string pathToXml, ConversionSet conversionSet, string userId)
		{
			List<Element> elements = LoadXml(pathToXml, conversionSet.XmlSet);
			List<object> mappedContent = MapContent(elements, conversionSet.Mapping.ElementMappings);
			var stats = new DbMergeStats();
			var duplicatesRemover = new DuplicatesRemover(context);
			var contextMerger = new ContextMerger(context);
			try
			{
				DebugUtils.MeasureTime("Removing duplicates", () =>
					{
						duplicatesRemover.RemoveDuplicates(mappedContent, conversionSet, stats);
					}
				);
				await DebugUtils.MeasureTimeAsync("Saving removing duplicates",
					async () =>
					{
						await context.SaveChangesAsync();
					}
				);
				foreach (var item in mappedContent)
				{
					FillSystemFields(item, userId, DateTime.Now);
				}
				DebugUtils.MeasureTime("MergeToDB", () =>
					{
						contextMerger.MergeToDB(mappedContent, stats);
					}
				);
				await DebugUtils.MeasureTimeAsync("SaveChangesAsync",
					async () =>
					{
						await context.SaveChangesAsync();
					}
				);
			}
			catch (Exception)
			{
				throw;
			}
			return stats;
		}

		private async Task<DbMergeStats> ImportCommercialEffort(string pathToXml, ConversionSet conversionSet, string userId)
		{
			return await ImportFlatFile(new CE_DataImporter(), pathToXml, conversionSet, userId);
		}

		private async Task<DbMergeStats> ImportCommercialLanding(string pathToXml, ConversionSet conversionSet, string userId)
		{
			return await ImportFlatFile(new CL_DataImporter(), pathToXml, conversionSet, userId);
		}

		private async Task<DbMergeStats> ImportFlatFile<T>(IFlatDataImporter<T> importer, string pathToXml, ConversionSet conversionSet, string userId) where T : class
		{
			var reader = new Reader(pathToXml, conversionSet.XmlSet, conversionSet.XmlSet.ElementDefinitions[0].Name);
			Mapper mapper = new(conversionSet.Mapping.ElementMappings, lookupProvider, idLookup);
			var enumerableReader = MakeEnumerable<T>(reader, mapper, conversionSet.Mapping.ElementMappings[0], userId);
			using (var conn = new SqlConnection(context.ConnectionString))
			{
				conn.Open();
				return await importer.Import(enumerableReader, conn);
			}
		}

		public IEnumerable<T> MakeEnumerable<T>(IReader reader, Mapper mapper, ElementMapping mapping, string userId) where T : class
		{
			DateTime now = DateTime.Now;
			while (!reader.Finished)
			{
				var element = reader.Read();
				if (element == null)
					break;
				var result = mapper.ConvertToFlatObject<T>(element, mapping) as T;
				FillSystemFields(result, userId, now);
				yield return result;
			}
		}


	}
}