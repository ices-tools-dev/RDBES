﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Xml2DB_DAL;
using XML2DB_Mapping.Conversions;

namespace XML2DB_Importer
{
    public class LookupProvider : ILookupProvider
    {
        private Dictionary<CodeType, Dictionary<string, int>> lookupGroups = new Dictionary<CodeType, Dictionary<string, int>>();
        public void Load(DatabaseContext context)
        {
            var codeTypes = context.TblCodeTypes
                .OrderBy(cr => cr.CodeType)
                .ToList();
            var codes = context.TblCodes.ToList();

            foreach (var codeType in codeTypes)
            {
                Dictionary<string, int> lookupGroup = new Dictionary<string, int>();
                var parsedCodeType = ParseCodeType(codeType.CodeType.Trim());
                if (!parsedCodeType.HasValue)
                {
                    continue;
                }
                lookupGroups.Add(parsedCodeType.Value, lookupGroup);
                foreach (var codeRecord in codes.Where(code=>code.TblCodeTypeId == codeType.TblCodeTypeId))
                {
                    try
                    {
                        lookupGroup.Add(codeRecord.Code, codeRecord.TblCodeId);
                    }
                    catch
                    {

                    }
                  
                }
            }
        }

        public int Lookup(CodeType codeType, string value)
        {
            Dictionary<string, int> lookupGroup;
            if (!lookupGroups.TryGetValue(codeType, out lookupGroup))
            {
                throw new ArgumentException($"Failed to find lookup group for code type:'{codeType}'");
            }
            int result;
            if (!lookupGroup.TryGetValue(value, out result))
            {
                throw new ArgumentException($"Failed to find lookup value for value:'{value}' with code type:'{codeType}'");
            }
            return result;
        }

        private CodeType? ParseCodeType(string value)
        {
            CodeType result;
            if (!Enum.TryParse(value, out result))
            {
                Debug.WriteLine($"Warning: Unsupported CodeType found in the DB:'{value}'. You should either update the enum XML2DB_Mapping.Conversions.CodeType, or remove this deprecated codeType from the tblCodeType table");
                return null;
            }
            return result;
        }
    }
}
