﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xml2DB_Conversions.CheckDuplicates;
using Xml2DB_Conversions.CheckDuplicates.Impl;
using Xml2DB_Conversions.ConversionSets;
using Xml2DB_DAL.ImportQueue;
using XML2DB_Importer.Impl;
using XML2DB_Importer.Models;

namespace XML2DB_Importer
{
    public class ImportQueue : IImportQueue
    {
        private string _connectionString;
        private SemaphoreSlim _semaphore = new SemaphoreSlim(1);
        private Queue<Xml2DB_DAL.ImportQueue.ImportQueue> _queue;
        private bool _stopRequested = false;
        
        public ImportQueue(string connectionString,
                            Action<QueuedImportResult<Exception>> onError,
                            Action<QueuedImportResult<IEnumerable<object>>> onDuplicateCheckFailed,
                            Action<QueuedImportResult<DbMergeStats>> onImportCompleted)
        {
            OnError = onError;
            OnDuplicateCheckFailed = onDuplicateCheckFailed;
            OnImportCompleted = onImportCompleted;
            _connectionString = connectionString;
            _queue = new Queue<Xml2DB_DAL.ImportQueue.ImportQueue>();
            using (var context = new ImportQueueContext(connectionString))
            {
                context.CreateTableIfNotExists();
            }

        }

        public async Task EnqueueCheckAndImport(string pathToXml, string uploadedFileName, string hierarchyName, bool checkForDuplicates, ConversionSet conversionSet, UserData userData)
        {
            await _semaphore.WaitAsync();
            Xml2DB_DAL.ImportQueue.ImportQueue newQueueItem = new Xml2DB_DAL.ImportQueue.ImportQueue
            {
                AddedAt = DateTime.Now,
                Email = userData.Email,
                Errors = null,
                FilePath = pathToXml,
                UploadedFileName = uploadedFileName,
                FirstName = userData.FirstName,
                Hierarchy = hierarchyName,
                LastName = userData.LastName,
                ShouldCheckForDuplicates = checkForDuplicates,
                ProcessingEndedAt = null,
                ProcessingStartedAt = null,
                Success = null,
                UserId = userData.UserId
            };
            await Save(newQueueItem);
            _queue.Enqueue(newQueueItem);
            _semaphore.Release();
        }

        public Action<QueuedImportResult<Exception>> OnError { get; private set; }

        public Action<QueuedImportResult<IEnumerable<object>>> OnDuplicateCheckFailed { get; private set; }

        public Action<QueuedImportResult<DbMergeStats>> OnImportCompleted { get; private set; }

        public bool IsRunning { get; private set; }

        public async Task Start()
        {
            await Task.Yield();
            LoadQueue();
            _ = Task.Factory.StartNew(() => RunQueue());
        }

        private async Task RunQueue()
        {
            IsRunning = true;
            while (!_stopRequested)
            {
                if (_queue.Any())
                {
                    await _semaphore.WaitAsync();
                    var queuedItem = _queue.Dequeue();
                    _semaphore.Release();
                    await ProcessQueueItem(queuedItem);
                }
                else
                {
                    await Task.Delay(1000);
                }
            }
            IsRunning = false;
        }

        private async Task ProcessQueueItem(Xml2DB_DAL.ImportQueue.ImportQueue item)
        {
            try
            {
                item.ProcessingStartedAt = DateTime.Now;
                await Save(item);
                if (item.ShouldCheckForDuplicates)
                {
                    using (var context = new Xml2DB_DAL.DatabaseContext(_connectionString))
                    {
                        IDbDuplicateCheckerFactory checkerFactory = new DbDuplicateCheckerFactory();
                        var duplicatesChecker = new DuplicatesChecker(context, checkerFactory);
                        var duplicates = await duplicatesChecker.CheckFoDuplicatesNonTyped(item.FilePath, item.Hierarchy);
                        if (duplicates.Any())
                        {
                            item.ProcessingEndedAt = DateTime.Now;
                            item.Success = false;
                            item.Errors = "Found duplicates";
                            await Save(item);
                            OnDuplicateCheckFailed(new QueuedImportResult<IEnumerable<object>>
                            {
                                ImportQueueId = item.Id,
                                UploadedFileName = item.UploadedFileName,
                                RequestedUser = GetUserDataFromQueuedItem(item),
                                Content = duplicates,
                                Success = false
                            });
                            return;
                        }
                    }
                }
                var conversionSet = ConversionSet.GetByHierarchyName(item.Hierarchy);
                using (var context = new Xml2DB_DAL.DatabaseContext(_connectionString))
                {
                    var importer = new Importer(context);
                    var importResult = await importer.Import(item.FilePath, conversionSet, item.UserId);

                    item.ProcessingEndedAt = DateTime.Now;
                    item.Success = true;
                    await Save(item);
                    OnImportCompleted(new QueuedImportResult<DbMergeStats>
                    {
                        ImportQueueId = item.Id,
                        UploadedFileName = item.UploadedFileName,
                        Content = importResult,
                        RequestedUser = GetUserDataFromQueuedItem(item),
                        Success = true
                    });
                }
            }
            catch (Exception ex)
            {
                item.Success = false;
                item.Errors = "Internal server error";
                await Save(item);
                OnError(new QueuedImportResult<Exception>
                {
                    ImportQueueId = item.Id,
                    UploadedFileName = item.UploadedFileName,
                    Content = ex,
                    RequestedUser = GetUserDataFromQueuedItem(item),
                    Success = false
                });
            }
        }

        private UserData GetUserDataFromQueuedItem(Xml2DB_DAL.ImportQueue.ImportQueue item)
        {
            return new UserData
            {
                Email = item.Email,
                FirstName = item.FirstName,
                LastName = item.LastName,
                UserId = item.UserId
            };
        }

        public async Task Stop()
        {
            _stopRequested = true;
            while (IsRunning)
            {
                await Task.Delay(100);
            }
        }

        private void LoadQueue()
        {
            using (ImportQueueContext context = new ImportQueueContext(_connectionString))
            {
                var dbQueueContent = context.ImportQueue
                       .Where(record => record.Success == null)
                       .OrderBy(record => record.AddedAt)
                       .Select(record => record)
                       .ToList();
                foreach (var item in dbQueueContent)
                {
                    _queue.Enqueue(item);
                }
            }
        }

        private async Task Save(Xml2DB_DAL.ImportQueue.ImportQueue item)
        {
            try
            {
                using (ImportQueueContext context = new ImportQueueContext(_connectionString))
                {
                    if (item.Id == 0)
                    {
                        context.ImportQueue.Add(item);
                    }
                    else
                    {
                        var dbItem = context.ImportQueue.Where(itm => itm.Id == item.Id).Single();
                        dbItem.Errors = item.Errors;
                        dbItem.ProcessingEndedAt = item.ProcessingEndedAt;
                        dbItem.ProcessingStartedAt = item.ProcessingStartedAt;
                        dbItem.Success = item.Success;
                    }
                    await context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                OnError(new QueuedImportResult<Exception>
                {
                    ImportQueueId = item.Id,
                    UploadedFileName = item.UploadedFileName,
                    Content = ex,
                    RequestedUser = GetUserDataFromQueuedItem(item),
                    Success = false
                });
                throw;
            }
        }

    }
}
