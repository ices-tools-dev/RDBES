﻿using AutoMapper;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Xml2DB_DAL;
using XML2DB_Mapping;

namespace XML2DB_Importer
{
    internal class CollectionMapper<T> : ITypeConverter<ICollection<T>, ICollection<T>> where T : class, new()
    {
        private DatabaseContext context;
        private IMapper mapper;
        private DbMergeStats stats;
        public CollectionMapper(DatabaseContext context, DbMergeStats stats)
        {
            this.context = context;
            this.stats = stats;
        }
        public ICollection<T> Convert(ICollection<T> source, ICollection<T> destination, ResolutionContext resolutionContext)
        {
            if (mapper == null)
            {
                mapper = MapperFactory.CreateMapper(context, stats);
            }
            EqualizeItemsCount(source, destination);
            List<T> destinationList = destination.ToList();
            int index = 0;
            foreach (T sourceItem in source)
            {
                mapper.Map(sourceItem, destinationList[index]);
                index++;
            }
            return destination;
        }

        private void EqualizeItemsCount(ICollection<T> source, ICollection<T> destination)
        {
            if (source == null || destination.Count == source.Count)
            {
                stats.AddUpdates(typeof(T), destination.Count);
                return;
            }
            if (destination.Count < source.Count)
            {
                while (destination.Count < source.Count)
                {
                    var newItem = new T();
                    destination.Add(newItem);
                    context.Add(newItem);
                    stats.AddInserts(typeof(T), 1);
                }
            }
            else if (source.Count < destination.Count)
            {
                var list = destination.ToList();
                while (source.Count < destination.Count)
                {
                    var itemToRemove = list[list.Count - 1];
                    destination.Remove(itemToRemove);
                    list.Remove(itemToRemove);
                    RemoveEntity(itemToRemove);
                }
            }
            else
            {
                stats.AddUpdates(typeof(T), source.Count);
            }
        }

        private void RemoveEntity(object entity)
        {
            RemoveChilds(entity);
            context.Remove(entity);
            stats.AddDeletes(entity.GetType(), 1);
        }

        private void RemoveChilds(object entity)
        {
            foreach (var childList in ReflectionUtils.GetObjectChildLists(entity))
            {
                foreach (var child in (IEnumerable)childList)
                {
                    RemoveEntity(child);
                }
            }
        }
    }

}
