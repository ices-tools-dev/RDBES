﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xml2DB_Conversions.CheckDuplicates.ResultTypes;
using Xml2DB_Conversions.ConversionSets;
using XML2DB_Importer.Models;

namespace XML2DB_Importer
{
    public interface IImportQueue
    {
        /// <summary>
        /// Add a new import operation to the queue
        /// </summary>
        Task EnqueueCheckAndImport(string pathToXml, string uploadedFileName, string hierarchyName, bool checkForDuplicates, ConversionSet conversionSet, UserData userData);

        /// <summary>
        /// Executed if there is an unexpected error during operation of the queue. 
        /// </summary>
        Action<QueuedImportResult<Exception>> OnError { get; }
        
        /// <summary>
        /// Executed if duplicate check have found duplicates, which also means that the import for the respective file will not run
        /// </summary>
        Action<QueuedImportResult<IEnumerable<object>>> OnDuplicateCheckFailed { get; }

        /// <summary>
        /// Executed when import operation has completed
        /// </summary>
        Action<QueuedImportResult<DbMergeStats>> OnImportCompleted { get; }

        Task Start();

        Task Stop();

        bool IsRunning { get; }
    }
}
