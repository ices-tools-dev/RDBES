﻿using AutoMapper;
using System.Collections;
using System.Collections.Generic;

using System.Linq;
using Xml2DB_DAL;
using Xml2DB_DAL.Models;
using Xml2DB_Conversions.ConversionSets;
using XML2DB_Mapping;
using System;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Linq.Expressions;

namespace XML2DB_Importer
{
	internal class ContextMerger
	{
		private IMapper mapper;
		private DbMergeStats stats;
		private readonly DatabaseContext context;
		private object locker = new object();

		private List<CommercialEffort> commercialEffortContent = null;
		private List<CommercialLanding> commercialLandingContent = null;

		public ContextMerger(DatabaseContext context)
		{
			this.context = context;
		}

		public void MergeToDB(List<object> elements, DbMergeStats stats)
		{
			this.stats = stats;
			mapper = MapperFactory.CreateMapper(context, stats);
			if (elements.Count > 0)
			{
				MergeItemsToDb(elements, stats, elements.First().GetType().Name);
			}
		}

		private void MergeItemsToDb(List<object> items, DbMergeStats stats, string elementTypeName)
		{
			switch (elementTypeName)
			{
				case nameof(Design):
					items.ForEach(item => MergeDeToDb(item as Design, stats));
					break;
				case nameof(CommercialEffort):
					Parallel.ForEach(items, item => MergeCEToDb(item as CommercialEffort, stats));
					break;
				case nameof(CommercialLanding):
					Parallel.ForEach(items, item => MergeCLToDb(item as CommercialLanding, stats));
					break;
				case nameof(SpeciesList):
					items.ForEach(item => MergeSLToDb(item as SpeciesList, stats));
					break;
				case nameof(VesselDetail):
					items.ForEach(item => MergeVDToDb(item as VesselDetail, stats));
					break;
				default:
					throw new NotSupportedException($"Type:{elementTypeName}");
			}
		}

		private void MergeCEToDb(CommercialEffort ce, DbMergeStats stats)
		{
			var dbRecord = LoadFromDb(Utils.MakePredicate(ce));

			lock (context)
			{
				if (dbRecord == null)
				{
					dbRecord = new CommercialEffort();
					context.Add(dbRecord);
					stats.AddInserts(dbRecord.GetType(), 1);
				}
				else
				{
					stats.AddUpdates(dbRecord.GetType(), 1);
				}
			}
			mapper.Map(ce, dbRecord);
		}


		private void MergeCLToDb(CommercialLanding cl, DbMergeStats stats)
		{
			var dbRecord = LoadFromDb(Utils.MakePredicate(cl));

			lock (context)
			{
				if (dbRecord == null)
				{
					dbRecord = new CommercialLanding();
					context.Add(dbRecord);
					stats.AddInserts(dbRecord.GetType(), 1);
				}

				else
				{
					stats.AddUpdates(dbRecord.GetType(), 1);
				}
			}
			mapper.Map(cl, dbRecord);
		}

		private void MergeSLToDb(SpeciesList sl, DbMergeStats stats)
		{
			var dbRecord = LoadFromDb(Utils.MakePredicate(sl));

			if (dbRecord == null)
			{
				dbRecord = new SpeciesList();
				context.Add(dbRecord);
				stats.AddInserts(dbRecord.GetType(), 1);
			}
			else
			{
				stats.AddUpdates(dbRecord.GetType(), 1);
			}
			mapper.Map(sl, dbRecord);
		}


		private void MergeVDToDb(VesselDetail vd, DbMergeStats stats)
		{
			var dbRecord = LoadFromDb(Utils.MakePredicate(vd));

			if (dbRecord == null)
			{
				dbRecord = new VesselDetail();
				context.Add(dbRecord);
				stats.AddInserts(dbRecord.GetType(), 1);
			}
			else
			{
				stats.AddUpdates(dbRecord.GetType(), 1);
			}
			mapper.Map(vd, dbRecord);
		}


		private void MergeDeToDb(Design de, DbMergeStats stats)
		{
			var dbRecord = LoadFromDb(Utils.MakePredicate(de));

			if (dbRecord == null)
			{
				dbRecord = new Design();
				context.Add(dbRecord);
				stats.AddInserts(dbRecord.GetType(), 1);
			}
			else
			{
				stats.AddUpdates(typeof(Design), 1);
			}
			mapper.Map(de, dbRecord);
			foreach (var sd in de.SamplingDetails)
			{
				MergeSdToDb(dbRecord, sd);
			}
		}

		private Design LoadFromDb(Expression<Func<Design, bool>> predicate)
		{
			var dbRecord = context.Designs
				.Include(a => a.SamplingDetails)
				.Where(predicate)
				.Select(d => d)
				.SingleOrDefault();
			return dbRecord;
		}

		private List<CommercialEffort> CommercialEffortCachedContent
		{
			get
			{
				if (commercialEffortContent == null)
				{
					lock (locker)
					{
						if (commercialEffortContent == null)
						{
							commercialEffortContent = context.CommercialEfforts.ToList();
						}
					}
				}
				return commercialEffortContent;
			}
		}

		private List<CommercialLanding> CommercialLandingCachedContent
		{
			get
			{
				if (commercialLandingContent == null)
				{
					lock (locker)
					{
						if (commercialLandingContent == null)
						{
							commercialLandingContent = context.CommercialLandings.ToList();
						}
					}
				}
				return commercialLandingContent;
			}
		}

		private CommercialEffort LoadFromDb(Func<CommercialEffort, bool> predicate)
		{
			return CommercialEffortCachedContent
					.Where(predicate)
					.Select(d => d)
					.SingleOrDefault();
		}

		private CommercialLanding LoadFromDb(Func<CommercialLanding, bool> predicate)
		{
			return CommercialLandingCachedContent
				.Where(predicate)
				.Select(d => d)
				.SingleOrDefault();
		}

		private SpeciesList LoadFromDb(Expression<Func<SpeciesList, bool>> predicate)
		{
			var dbRecord = context.SpeciesLists
				.Where(predicate)
				.Select(d => d)
				.SingleOrDefault();
			return dbRecord;
		}

		private VesselDetail LoadFromDb(Expression<Func<VesselDetail, bool>> predicate)
		{
			var dbRecord = context.VesselDetails
				.Where(predicate)
				.Select(d => d)
				.SingleOrDefault();
			return dbRecord;
		}

		private void MergeSdToDb(Design design, SamplingDetail samplingDetails)
		{
			var dbRecord = design.SamplingDetails
							.Where(Utils.MakePredicate(samplingDetails).Compile())
							.Select(sd => sd)
							.SingleOrDefault();
			if (dbRecord == null)
			{
				dbRecord = new SamplingDetail();
				design.SamplingDetails.Add(dbRecord);
				stats.AddInserts(typeof(SamplingDetail), 1);
			}
			else
			{
				stats.AddUpdates(typeof(SamplingDetail), 1);
			}
			mapper.Map(samplingDetails, dbRecord); // this fills the sd and all the hierarchy elements below it
		}

	}
}
