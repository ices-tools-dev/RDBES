﻿using System.Collections;
using Xml2DB_DAL;
using XML2DB_Mapping;

namespace XML2DB_Importer
{
	internal static class ExtensionMethods
	{
		public static void RemoveEntity(this DatabaseContext context, object entity, DbMergeStats stats)
		{
			context.RemoveChilds(entity, stats);
			context.Remove(entity);
			stats.AddDeletes(entity.GetType(), 1);
		}


		private static void RemoveChilds(this DatabaseContext context, object entity, DbMergeStats stats)
		{
			foreach (var childList in ReflectionUtils.GetObjectChildLists(entity))
			{
				foreach (var child in (IEnumerable)childList)
				{
					context.RemoveEntity(child, stats);
				}
			}
		}
	}
}
