﻿using System.Collections.Generic;
using Xml2DB_DAL.Models;

namespace XML2DB_Importer.ImportFlatData
{
	class CE_DataImporter : FlatDataImporterBase<CommercialEffort>
	{
		protected override string IDColumnName => nameof(CommercialEffort.Ceid);

		protected override string GetFieldDefinitions()
		{
			return @"
	[UserId] [nvarchar](450) NOT NULL,
	[TimeStamp] [datetime] NOT NULL,
	[CErecordType] [char](2) NOT NULL,
	[CEdataTypeForScientificEffort] [int] NOT NULL,
	[CEdataSourceForScientificEffort] [int] NOT NULL,
	[CEsamplingScheme] [int] NULL,
	[CEvesselFlagCountry] [int] NOT NULL,
	[CEyear] [int] NOT NULL,
	[CEquarter] [int] NOT NULL,
	[CEmonth] [int] NULL,
	[CEarea] [int] NOT NULL,
	[CEstatisticalRectangle] [int] NOT NULL,
	[CEgsaSubarea] [int] NOT NULL,
	[CEjurisdictionArea] [int] NULL,
	[CEexclusiveEconomicZoneIndicator] [int] NULL,
	[CEnationalFishingActivity] [int] NULL,
	[CEmetier6] [int] NOT NULL,
	[CEincidentalByCatchMitigationDevice] [int] NOT NULL,
	[CElandingLocation] [int] NOT NULL,
	[CEvesselLengthCategory] [int] NOT NULL,
	[CEfishingTechnique] [int] NULL,
	[CEdeepSeaRegulation] [int] NULL,
	[CEnumberOfFractionTrips] [decimal](18, 2) NOT NULL,
	[CEnumberOfDominantTrips] [int] NOT NULL,
	[CEofficialDaysAtSea] [decimal](18, 2) NOT NULL,
	[CEScientificDaysAtSea] [decimal](18, 2) NOT NULL,
	[CEofficialFishingDays] [decimal](18, 2) NOT NULL,
	[CEscientificFishingDays] [decimal](18, 2) NOT NULL,
	[CEofficialNumberOfHaulsOrSets] [int] NULL,
	[CEscientificNumberOfHaulsOrSets] [int] NULL,
	[CEofficialVesselFishingHour] [decimal](18, 2) NULL,
	[CEscientificVesselFishingHour] [decimal](18, 2) NULL,
	[CEofficialSoakingMeterHour] [decimal](18, 2) NULL,
	[CEscientificSoakingMeterHour] [decimal](18, 2) NULL,
	[CEofficialkWDaysAtSea] [int] NOT NULL,
	[CEscientifickWDaysAtSea] [int] NOT NULL,
	[CEofficialkWFishingDays] [int] NOT NULL,
	[CEscientifickWFishingDays] [int] NOT NULL,
	[CEofficialkWFishingHours] [int] NULL,
	[CEscientifickWFishingHours] [int] NULL,
	[CEgTDaysAtSea] [int] NOT NULL,
	[CEgTFishingDays] [int] NOT NULL,
	[CEgTFishingHours] [bigint] NULL,
	[CEnumberOfUniqueVessels] [int] NOT NULL,
	[CEscientificFishingDaysRSE] [int] NULL,
	[CEscientificFishingDaysQualitativeBias] [int] NULL
";
		}

		protected override string SaveQuery =>
$@"
DECLARE @TotalCount int = (SELECT Count(*) FROM {TEMP_TABLE_NAME});
DECLARE @Updates int = 0;
DECLARE @HaveMatches bit = 
(
	SELECT CASE WHEN Exists(
		SELECT CEid 
		FROM 
		{TEMP_TABLE_NAME} t (NOLOCK) LEFT JOIN CommercialEffort ce
		ON 
		t.CEdataTypeForScientificEffort = ce.CEdataTypeForScientificEffort
		AND	t.CEdataSourceForScientificEffort = ce.CEdataSourceForScientificEffort
		AND	((t.CEsamplingScheme IS NULL AND ce.CEsamplingScheme IS NULL) OR (t.CEsamplingScheme = ce.CEsamplingScheme))
		AND	t.CEvesselFlagCountry = ce.CEvesselFlagCountry
		AND	t.CEyear = ce.CEyear
		AND	t.CEquarter = ce.CEquarter
		AND	((t.CEmonth IS NULL AND ce.CEmonth IS NULL) OR (t.CEmonth = ce.CEmonth))
		AND	t.CEarea = ce.CEarea
		AND	t.CEstatisticalRectangle = ce.CEstatisticalRectangle
		AND	t.CEgsaSubarea = ce.CEgsaSubarea
		AND	((t.CEjurisdictionArea IS NULL AND ce.CEjurisdictionArea IS NULL) OR (t.CEjurisdictionArea = ce.CEjurisdictionArea))
		AND	((t.CEexclusiveEconomicZoneIndicator IS NULL AND ce.CEexclusiveEconomicZoneIndicator IS NULL) OR (t.CEexclusiveEconomicZoneIndicator = ce.CEexclusiveEconomicZoneIndicator))
		AND	((t.CEnationalFishingActivity IS NULL AND ce.CEnationalFishingActivity IS NULL) OR (t.CEnationalFishingActivity = ce.CEnationalFishingActivity))
		AND	t.CEmetier6 = ce.CEmetier6
		AND	t.CEincidentalByCatchMitigationDevice = ce.CEincidentalByCatchMitigationDevice
		AND	t.CElandingLocation = ce.CElandingLocation
		AND	t.CEvesselLengthCategory = ce.CEvesselLengthCategory
		AND	((t.CEfishingTechnique IS NULL AND ce.CEfishingTechnique IS NULL) OR (t.CEfishingTechnique = ce.CEfishingTechnique))  
		AND	((t.CEdeepSeaRegulation IS NULL AND ce.CEdeepSeaRegulation IS NULL) OR (t.CEdeepSeaRegulation = ce.CEdeepSeaRegulation))    
		WHERE CEid IS not null
	) THEN 1 ELSE 0 END
);

IF @HaveMatches = 1
BEGIN
	Print 'Merge flow';
	DECLARE @Changes TABLE(Change VARCHAR(20));
		MERGE CommercialEffort AS target  
		USING (
			SELECT 
				UserId, TimeStamp, CErecordType, CEdataTypeForScientificEffort, CEdataSourceForScientificEffort, CEsamplingScheme,
				CEvesselFlagCountry, CEyear, CEquarter, CEmonth, CEarea, CEstatisticalRectangle, CEgsaSubarea, CEjurisdictionArea, CEexclusiveEconomicZoneIndicator,
				CEnationalFishingActivity, CEmetier6, CEincidentalByCatchMitigationDevice, CElandingLocation, CEvesselLengthCategory, CEfishingTechnique,
				CEdeepSeaRegulation, CEnumberOfFractionTrips, CEnumberOfDominantTrips, CEofficialDaysAtSea, CEScientificDaysAtSea, CEofficialFishingDays,
				CEscientificFishingDays, CEofficialNumberOfHaulsOrSets, CEscientificNumberOfHaulsOrSets, CEofficialVesselFishingHour, CEscientificVesselFishingHour,
				CEofficialSoakingMeterHour, CEscientificSoakingMeterHour, CEofficialkWDaysAtSea, CEscientifickWDaysAtSea, CEofficialkWFishingDays,
				CEscientifickWFishingDays, CEofficialkWFishingHours, CEscientifickWFishingHours, CEgTDaysAtSea, CEgTFishingDays, CEgTFishingHours,
				CEnumberOfUniqueVessels, CEscientificFishingDaysRSE, CEscientificFishingDaysQualitativeBias 
			FROM {TEMP_TABLE_NAME}  (NOLOCK)
		) 
		AS source (
				UserId, TimeStamp, CErecordType, CEdataTypeForScientificEffort, CEdataSourceForScientificEffort, CEsamplingScheme,
				CEvesselFlagCountry, CEyear, CEquarter, CEmonth, CEarea, CEstatisticalRectangle, CEgsaSubarea, CEjurisdictionArea, CEexclusiveEconomicZoneIndicator,
				CEnationalFishingActivity, CEmetier6, CEincidentalByCatchMitigationDevice, CElandingLocation, CEvesselLengthCategory, CEfishingTechnique,
				CEdeepSeaRegulation, CEnumberOfFractionTrips, CEnumberOfDominantTrips, CEofficialDaysAtSea, CEScientificDaysAtSea, CEofficialFishingDays,
				CEscientificFishingDays, CEofficialNumberOfHaulsOrSets, CEscientificNumberOfHaulsOrSets, CEofficialVesselFishingHour, CEscientificVesselFishingHour,
				CEofficialSoakingMeterHour, CEscientificSoakingMeterHour, CEofficialkWDaysAtSea, CEscientifickWDaysAtSea, CEofficialkWFishingDays,
				CEscientifickWFishingDays, CEofficialkWFishingHours, CEscientifickWFishingHours, CEgTDaysAtSea, CEgTFishingDays, CEgTFishingHours,
				CEnumberOfUniqueVessels, CEscientificFishingDaysRSE, CEscientificFishingDaysQualitativeBias
		)
		ON (
			target.CEdataTypeForScientificEffort = source.CEdataTypeForScientificEffort
			AND	target.CEdataSourceForScientificEffort = source.CEdataSourceForScientificEffort
			AND	((target.CEsamplingScheme IS NULL AND source.CEsamplingScheme IS NULL) OR (target.CEsamplingScheme = source.CEsamplingScheme))
			AND	target.CEvesselFlagCountry = source.CEvesselFlagCountry
			AND	target.CEyear = source.CEyear
			AND	target.CEquarter = source.CEquarter
			AND	((target.CEmonth IS NULL AND source.CEmonth IS NULL) OR (target.CEmonth = source.CEmonth))
			AND	target.CEarea = source.CEarea
			AND	target.CEstatisticalRectangle = source.CEstatisticalRectangle
			AND	target.CEgsaSubarea = source.CEgsaSubarea
			AND	((target.CEjurisdictionArea IS NULL AND source.CEjurisdictionArea IS NULL) OR (target.CEjurisdictionArea = source.CEjurisdictionArea))
			AND	((target.CEexclusiveEconomicZoneIndicator IS NULL AND source.CEexclusiveEconomicZoneIndicator IS NULL) OR (target.CEexclusiveEconomicZoneIndicator = source.CEexclusiveEconomicZoneIndicator))
			AND	((target.CEnationalFishingActivity IS NULL AND source.CEnationalFishingActivity IS NULL) OR (target.CEnationalFishingActivity = source.CEnationalFishingActivity))
			AND	target.CEmetier6 = source.CEmetier6
			AND	target.CEincidentalByCatchMitigationDevice = source.CEincidentalByCatchMitigationDevice
			AND	target.CElandingLocation = source.CElandingLocation
			AND	target.CEvesselLengthCategory = source.CEvesselLengthCategory
			AND	((target.CEfishingTechnique IS NULL AND source.CEfishingTechnique IS NULL) OR (target.CEfishingTechnique = source.CEfishingTechnique))  
			AND	((target.CEdeepSeaRegulation IS NULL AND source.CEdeepSeaRegulation IS NULL) OR (target.CEdeepSeaRegulation = source.CEdeepSeaRegulation))
		)

		WHEN MATCHED THEN
			UPDATE SET -- update only fields which are not included in the unique index, as the other are equal anyway
				-- UserId and TimeStamp are left unchanged on update
				CErecordType = source.CErecordType,
				CEnumberOfDominantTrips = source.CEnumberOfDominantTrips,
				CEofficialDaysAtSea = source.CEofficialDaysAtSea,
				CEScientificDaysAtSea = source.CEScientificDaysAtSea,
				CEofficialFishingDays = source.CEofficialFishingDays,
				CEscientificFishingDays = source.CEscientificFishingDays,
				CEofficialNumberOfHaulsOrSets = source.CEofficialNumberOfHaulsOrSets,
				CEscientificNumberOfHaulsOrSets = source.CEscientificNumberOfHaulsOrSets,
				CEofficialVesselFishingHour = source.CEofficialVesselFishingHour,
				CEscientificVesselFishingHour = source.CEscientificVesselFishingHour,
				CEofficialSoakingMeterHour = source.CEofficialSoakingMeterHour,
				CEscientificSoakingMeterHour = source.CEscientificSoakingMeterHour,
				CEofficialkWDaysAtSea = source.CEofficialkWDaysAtSea,
				CEscientifickWDaysAtSea = source.CEscientifickWDaysAtSea,
				CEscientifickWFishingDays = source.CEscientifickWFishingDays,
				CEofficialkWFishingHours = source.CEofficialkWFishingHours,
				CEscientifickWFishingHours = source.CEscientifickWFishingHours,
				CEgTDaysAtSea = source.CEgTDaysAtSea,
				CEgTFishingDays = source.CEgTFishingDays,
				CEgTFishingHours = source.CEgTFishingHours,
				CEnumberOfUniqueVessels = source.CEnumberOfUniqueVessels,
				CEscientificFishingDaysRSE = source.CEscientificFishingDaysRSE,
				CEscientificFishingDaysQualitativeBias = source.CEscientificFishingDaysQualitativeBias

		WHEN NOT MATCHED THEN  
			INSERT (
				UserId, TimeStamp, CErecordType, CEdataTypeForScientificEffort, CEdataSourceForScientificEffort, CEsamplingScheme,
				CEvesselFlagCountry, CEyear, CEquarter, CEmonth, CEarea, CEstatisticalRectangle, CEgsaSubarea, CEjurisdictionArea, CEexclusiveEconomicZoneIndicator,
				CEnationalFishingActivity, CEmetier6, CEincidentalByCatchMitigationDevice, CElandingLocation, CEvesselLengthCategory, CEfishingTechnique,
				CEdeepSeaRegulation, CEnumberOfFractionTrips, CEnumberOfDominantTrips, CEofficialDaysAtSea, CEScientificDaysAtSea, CEofficialFishingDays,
				CEscientificFishingDays, CEofficialNumberOfHaulsOrSets, CEscientificNumberOfHaulsOrSets, CEofficialVesselFishingHour, CEscientificVesselFishingHour,
				CEofficialSoakingMeterHour, CEscientificSoakingMeterHour, CEofficialkWDaysAtSea, CEscientifickWDaysAtSea, CEofficialkWFishingDays,
				CEscientifickWFishingDays, CEofficialkWFishingHours, CEscientifickWFishingHours, CEgTDaysAtSea, CEgTFishingDays, CEgTFishingHours,
				CEnumberOfUniqueVessels, CEscientificFishingDaysRSE, CEscientificFishingDaysQualitativeBias
			)  
			VALUES (
				source.UserId, source.TimeStamp, source.CErecordType, source.CEdataTypeForScientificEffort, source.CEdataSourceForScientificEffort, 
				source.CEsamplingScheme, source.CEvesselFlagCountry, source.CEyear, source.CEquarter, source.CEmonth, 
				source.CEarea, source.CEstatisticalRectangle, source.CEgsaSubarea, source.CEjurisdictionArea, source.CEexclusiveEconomicZoneIndicator,
				source.CEnationalFishingActivity, source.CEmetier6, source.CEincidentalByCatchMitigationDevice, source.CElandingLocation, source.CEvesselLengthCategory, 
				source.CEfishingTechnique, source.CEdeepSeaRegulation, source.CEnumberOfFractionTrips, source.CEnumberOfDominantTrips, source.CEofficialDaysAtSea, 
				source.CEScientificDaysAtSea, source.CEofficialFishingDays, source.CEscientificFishingDays, source.CEofficialNumberOfHaulsOrSets, 
				source.CEscientificNumberOfHaulsOrSets, source.CEofficialVesselFishingHour, source.CEscientificVesselFishingHour,
				source.CEofficialSoakingMeterHour, source.CEscientificSoakingMeterHour, source.CEofficialkWDaysAtSea, source.CEscientifickWDaysAtSea, 
				source.CEofficialkWFishingDays, source.CEscientifickWFishingDays, source.CEofficialkWFishingHours, source.CEscientifickWFishingHours, 
				source.CEgTDaysAtSea, source.CEgTFishingDays, source.CEgTFishingHours, source.CEnumberOfUniqueVessels, source.CEscientificFishingDaysRSE, 
				source.CEscientificFishingDaysQualitativeBias
			)
		OUTPUT $action INTO @Changes;
		SET @Updates = (SELECT COUNT (Change) FROM @Changes WHERE Change='UPDATE');
END
ELSE
BEGIN 
Print 'Insert flow';
	INSERT INTO CommercialEffort(
		UserId, TimeStamp, CErecordType, CEdataTypeForScientificEffort, CEdataSourceForScientificEffort, CEsamplingScheme,
		CEvesselFlagCountry, CEyear, CEquarter, CEmonth, CEarea, CEstatisticalRectangle, CEgsaSubarea, CEjurisdictionArea, CEexclusiveEconomicZoneIndicator,
		CEnationalFishingActivity, CEmetier6, CEincidentalByCatchMitigationDevice, CElandingLocation, CEvesselLengthCategory, CEfishingTechnique,
		CEdeepSeaRegulation, CEnumberOfFractionTrips, CEnumberOfDominantTrips, CEofficialDaysAtSea, CEScientificDaysAtSea, CEofficialFishingDays,
		CEscientificFishingDays, CEofficialNumberOfHaulsOrSets, CEscientificNumberOfHaulsOrSets, CEofficialVesselFishingHour, CEscientificVesselFishingHour,
		CEofficialSoakingMeterHour, CEscientificSoakingMeterHour, CEofficialkWDaysAtSea, CEscientifickWDaysAtSea, CEofficialkWFishingDays,
		CEscientifickWFishingDays, CEofficialkWFishingHours, CEscientifickWFishingHours, CEgTDaysAtSea, CEgTFishingDays, CEgTFishingHours,
		CEnumberOfUniqueVessels, CEscientificFishingDaysRSE, CEscientificFishingDaysQualitativeBias
)
SELECT 
		UserId, TimeStamp, CErecordType, CEdataTypeForScientificEffort, CEdataSourceForScientificEffort, CEsamplingScheme,
		CEvesselFlagCountry, CEyear, CEquarter, CEmonth, CEarea, CEstatisticalRectangle, CEgsaSubarea, CEjurisdictionArea, CEexclusiveEconomicZoneIndicator,
		CEnationalFishingActivity, CEmetier6, CEincidentalByCatchMitigationDevice, CElandingLocation, CEvesselLengthCategory, CEfishingTechnique,
		CEdeepSeaRegulation, CEnumberOfFractionTrips, CEnumberOfDominantTrips, CEofficialDaysAtSea, CEScientificDaysAtSea, CEofficialFishingDays,
		CEscientificFishingDays, CEofficialNumberOfHaulsOrSets, CEscientificNumberOfHaulsOrSets, CEofficialVesselFishingHour, CEscientificVesselFishingHour,
		CEofficialSoakingMeterHour, CEscientificSoakingMeterHour, CEofficialkWDaysAtSea, CEscientifickWDaysAtSea, CEofficialkWFishingDays,
		CEscientifickWFishingDays, CEofficialkWFishingHours, CEscientifickWFishingHours, CEgTDaysAtSea, CEgTFishingDays, CEgTFishingHours,
		CEnumberOfUniqueVessels, CEscientificFishingDaysRSE, CEscientificFishingDaysQualitativeBias
FROM {TEMP_TABLE_NAME} (NOLOCK);

END

SELECT 
0 as Deletes,
@TotalCount - @Updates as Inserts,
@Updates as Updates;
";

		protected override Dictionary<string, string> SpecialCaseColumnMappings =>
			new Dictionary<string, string>
			{
				{ nameof(CommercialEffort.CescientificDaysAtSea), "CEScientificDaysAtSea" },
				{ nameof(CommercialEffort.CeofficialkWdaysAtSea), "CEofficialkWDaysAtSea" },
				{ nameof(CommercialEffort.CescientifickWdaysAtSea), "CEscientifickWDaysAtSea" },
				{ nameof(CommercialEffort.CeofficialkWfishingDays), "CEofficialkWFishingDays" },
				{ nameof(CommercialEffort.CescientifickWfishingDays), "CEscientifickWFishingDays" },
				{ nameof(CommercialEffort.CeofficialkWfishingHours), "CEofficialkWFishingHours" },
				{ nameof(CommercialEffort.CescientifickWfishingHours), "CEscientifickWFishingHours" },
				{ nameof(CommercialEffort.CegTdaysAtSea), "CEgTDaysAtSea" },
				{ nameof(CommercialEffort.CegTfishingDays), "CEgTFishingDays" },
				{ nameof(CommercialEffort.CegTfishingHours), "CEgTFishingHours" },
				{ nameof(CommercialEffort.CescientificFishingDaysRse), "CEscientificFishingDaysRSE" },
				{ nameof(CommercialLanding.UserId), "UserId" },
				{ nameof(CommercialEffort.TimeStamp), "TimeStamp" }
			};

	}
}
