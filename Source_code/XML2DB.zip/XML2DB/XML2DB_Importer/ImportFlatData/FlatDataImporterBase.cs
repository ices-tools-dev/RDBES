﻿using Dapper;
using FastMember;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Xml2DB_Conversions;

namespace XML2DB_Importer.ImportFlatData
{
	internal abstract class FlatDataImporterBase<T> : IFlatDataImporter<T>
	{
		public const int DB_COMMAND_TIMEOUT_MINUTES = 60;
		protected const string TEMP_TABLE_NAME = "#tmpDataToImport";

		private class ImportResult
		{
			public int Deletes { get; set; }
			public int Inserts { get; set; }
			public int Updates { get; set; }
		}

		public async Task<DbMergeStats> Import(IEnumerable<T> dataRecords, SqlConnection conn)
		{
			await BulkSaveDataToTempTable(dataRecords, conn);
			return await Save(conn);
		}

		protected virtual string CreateTempTableSql()
		{
			return
$@"
CREATE TABLE {TEMP_TABLE_NAME}(
	[ID] [int] IDENTITY(1,1) NOT NULL primary key,
	{GetFieldDefinitions()}
)";
		}

		protected abstract string GetFieldDefinitions();

		protected abstract string IDColumnName { get; }

		protected abstract string SaveQuery { get; }

		protected abstract Dictionary<string, string> SpecialCaseColumnMappings { get; }

		protected virtual void SetupColumnMappings(SqlBulkCopy sqlBulkCopy)
		{
			var propertyInfos = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance)
									.Where(pi => !IDColumnName.Equals(pi.Name) && pi.GetCustomAttribute<NotMappedAttribute>() == null);
			foreach (var propInfo in propertyInfos)
			{
				string dbName;
				if (!SpecialCaseColumnMappings.TryGetValue(propInfo.Name, out dbName))
				{
					dbName = string.Concat(propInfo.Name.Substring(0, 2).ToUpper(), propInfo.Name.Substring(2));
				}
				sqlBulkCopy.ColumnMappings.Add(propInfo.Name, dbName);
			}
		}

		private async Task BulkSaveDataToTempTable(IEnumerable<T> items, SqlConnection conn)
		{
			await DebugUtils.MeasureTimeAsync($"{this.GetType().Name}.BulkSaveDataToTempTable",
				async () =>
				{
					new SqlCommand(CreateTempTableSql(), conn).ExecuteNonQuery();
					using (var bulkCopy = new SqlBulkCopy(conn))
					{
						bulkCopy.BulkCopyTimeout = 30;
						bulkCopy.BatchSize = 500;
						bulkCopy.DestinationTableName = TEMP_TABLE_NAME;
						SetupColumnMappings(bulkCopy);
						bulkCopy.EnableStreaming = true;
						using (var dataReader = ObjectReader.Create(items))
						{
							await bulkCopy.WriteToServerAsync(dataReader);
						}
					}
				});
		}

		protected async Task<DbMergeStats> Save(SqlConnection conn)
		{
			ImportResult importResult = null;
			await DebugUtils.MeasureTimeAsync($"{nameof(FlatDataImporterBase<T>)}.Save",
				async () =>
				{
					importResult = await conn.QuerySingleAsync<ImportResult>(SaveQuery, param: null, transaction: null,
						commandTimeout: (int)TimeSpan.FromMinutes(DB_COMMAND_TIMEOUT_MINUTES).TotalSeconds);
				});
			var result = new DbMergeStats();
			result.AddDeletes(typeof(T), importResult.Deletes);
			result.AddInserts(typeof(T), importResult.Inserts);
			result.AddUpdates(typeof(T), importResult.Updates);
			return result;
		}

	}
}
