﻿using System.Collections.Generic;
using Xml2DB_DAL.Models;

namespace XML2DB_Importer.ImportFlatData
{
	class CL_DataImporter : FlatDataImporterBase<CommercialLanding>
	{
		protected override string IDColumnName => nameof(CommercialLanding.Clid);


		protected override string GetFieldDefinitions()
		{
			return @"
	[UserId] [nvarchar](450) NOT NULL,
	[TimeStamp] [datetime] NOT NULL,
	[CLrecordType] [char](2) NOT NULL,
	[CLdataTypeOfScientificWeight] [int] NOT NULL,
	[CLdataSourceOfScientificWeight] [int] NOT NULL,
	[CLsamplingScheme] [int] NULL,
	[CLdataSourceLandingsValue] [int] NOT NULL,
	[CLlandingCountry] [int] NOT NULL,
	[CLvesselFlagCountry] [int] NOT NULL,
	[CLyear] [int] NOT NULL,
	[CLquarter] [int] NOT NULL,
	[CLmonth] [int] NULL,
	[CLarea] [int] NOT NULL,
	[CLstatisticalRectangle] [int] NOT NULL,
	[CLgsaSubarea] [int] NOT NULL,
	[CLjurisdictionArea] [int] NULL,
	[CLexclusiveEconomicZoneIndicator] [int] NOT NULL,
	[CLspeciesCode] [int] NOT NULL,
	[CLspeciesFaoCode] [int] NULL,
	[CLlandingCategory] [int] NOT NULL,
	[CLcatchCategory] [int] NOT NULL,
	[CLregDisCategory] [int] NULL,
	[CLcommercialSizeCategoryScale] [int] NULL,
	[CLcommercialSizeCategory] [int] NULL,
	[CLnationalFishingActivity] [int] NULL,
	[CLmetier6] [int] NOT NULL,
	[CLincidentialByCatchMitigationDevice] [int] NOT NULL,
	[CLlandingLocation] [int] NOT NULL,
	[CLvesselLengthCategory] [int] NOT NULL,
	[CLfishingTechnique] [int] NULL,
	[CLdeepSeaRegulation] [int] NULL,
	[CLofficialWeight] [int] NOT NULL,
	[CLscientificWeight] [int] NOT NULL,
	[CLexplainDifference] [int] NOT NULL,
	[CLtotalOfficialLandingsValue] [int] NOT NULL,
	[CLnumberOfUniqueVessels] [int] NOT NULL,
	[CLscientificWeightRSE] [int] NULL,
	[CLvalueRSE] [int] NULL,
	[CLscientificWeightQualitativeBias] [int] NULL
";
		}

		protected override string SaveQuery =>
$@"
DECLARE @TotalCount int = (SELECT Count(*) FROM {TEMP_TABLE_NAME});
DECLARE @Updates int = 0;
DECLARE @HaveMatches bit = 
(
	SELECT CASE WHEN Exists(
		SELECT CLid 
		FROM 
		{TEMP_TABLE_NAME} t (NOLOCK) LEFT JOIN CommercialLanding cl
		ON 
		t.CLdataTypeOfScientificWeight = cl.CLdataTypeOfScientificWeight
		AND	t.CLdataSourceOfScientificWeight = cl.CLdataSourceOfScientificWeight
		AND	((t.CLsamplingScheme IS NULL AND cl.CLsamplingScheme IS NULL) OR (t.CLsamplingScheme = cl.CLsamplingScheme))
		AND	t.CLdataSourceLandingsValue = cl.CLdataSourceLandingsValue
		AND	t.CLlandingCountry = cl.CLlandingCountry
		AND	t.CLvesselFlagCountry =cl.CLvesselFlagCountry
		AND	t.CLyear = cl.CLyear
		AND	t.CLquarter = cl.CLquarter
		AND	((t.CLmonth IS NULL AND cl.CLmonth IS NULL) OR (t.CLmonth = cl.CLmonth))
		AND	t.CLarea = cl.CLarea
		AND	t.CLstatisticalRectangle = cl.CLstatisticalRectangle
		AND	t.CLgsaSubarea = cl.CLgsaSubarea
		AND	((t.CLjurisdictionArea IS NULL AND cl.CLjurisdictionArea IS NULL) OR (t.CLjurisdictionArea = cl.CLjurisdictionArea))
		AND	t.CLexclusiveEconomicZoneIndicator = cl.CLexclusiveEconomicZoneIndicator
		AND	t.CLspeciesCode = cl.CLspeciesCode
		AND	((t.CLspeciesFaoCode IS NULL AND cl.CLspeciesFaoCode IS NULL) OR (t.CLspeciesFaoCode = cl.CLspeciesFaoCode))
		AND	t.CLlandingCategory = cl.CLlandingCategory
		AND	t.CLcatchCategory = cl.CLcatchCategory
		AND ((t.CLregDisCategory IS NULL AND cl.CLregDisCategory IS NULL) OR (t.CLregDisCategory = cl.CLregDisCategory))	
		AND	((t.CLcommercialSizeCategoryScale IS NULL AND cl.CLcommercialSizeCategoryScale IS NULL) OR (t.CLcommercialSizeCategoryScale = cl.CLcommercialSizeCategoryScale))
		AND	((t.CLcommercialSizeCategory IS NULL AND cl.CLcommercialSizeCategory IS NULL) OR (t.CLcommercialSizeCategory = cl.CLcommercialSizeCategory))   
		AND	((t.CLnationalFishingActivity IS NULL AND cl.CLnationalFishingActivity IS NULL) OR (t.CLnationalFishingActivity = cl.CLnationalFishingActivity))  
		AND	t.CLmetier6 = cl.CLmetier6
		AND	t.CLincidentialByCatchMitigationDevice = cl.CLincidentialByCatchMitigationDevice
		AND	t.CLlandingLocation = cl.CLlandingLocation
		AND	t.CLvesselLengthCategory = cl.CLvesselLengthCategory
		AND	((t.CLfishingTechnique IS NULL AND cl.CLfishingTechnique IS NULL) OR (t.CLfishingTechnique = cl.CLfishingTechnique))  
		AND	((t.CLdeepSeaRegulation IS NULL AND cl.CLdeepSeaRegulation IS NULL) OR (t.CLdeepSeaRegulation = cl.CLdeepSeaRegulation))    
		WHERE CLid IS not null
	) THEN 1 ELSE 0 END
);

IF @HaveMatches = 1
BEGIN
	Print 'Merging';
	DECLARE @Changes TABLE(Change VARCHAR(20));
		MERGE CommercialLanding AS target  
		USING (
			SELECT 
			UserId,TimeStamp,CLrecordType,CLdataTypeOfScientificWeight,CLdataSourceOfScientificWeight,
			CLsamplingScheme,CLdataSourceLandingsValue,CLlandingCountry,
			CLvesselFlagCountry,CLyear,CLquarter,CLmonth,CLarea,CLstatisticalRectangle,CLgsaSubarea,
			CLjurisdictionArea,CLexclusiveEconomicZoneIndicator,CLspeciesCode,CLspeciesFaoCode,CLlandingCategory,
			CLcatchCategory,CLregDisCategory,CLcommercialSizeCategoryScale,CLcommercialSizeCategory,CLnationalFishingActivity,
			CLmetier6, CLincidentialByCatchMitigationDevice,CLlandingLocation,CLvesselLengthCategory,
			CLfishingTechnique,CLdeepSeaRegulation,CLofficialWeight,CLscientificWeight,
			CLexplainDifference,CLtotalOfficialLandingsValue,CLnumberOfUniqueVessels,
			CLscientificWeightRSE,CLvalueRSE,CLscientificWeightQualitativeBias 
			FROM {TEMP_TABLE_NAME}  (NOLOCK)
		) 
		AS source (
			UserId,TimeStamp,CLrecordType,CLdataTypeOfScientificWeight,CLdataSourceOfScientificWeight,
			CLsamplingScheme,CLdataSourceLandingsValue,CLlandingCountry,
			CLvesselFlagCountry,CLyear,CLquarter,CLmonth,CLarea,CLstatisticalRectangle,CLgsaSubarea,
			CLjurisdictionArea,CLexclusiveEconomicZoneIndicator,CLspeciesCode,CLspeciesFaoCode,CLlandingCategory,
			CLcatchCategory,CLregDisCategory,CLcommercialSizeCategoryScale,CLcommercialSizeCategory,CLnationalFishingActivity,
			CLmetier6, CLincidentialByCatchMitigationDevice,CLlandingLocation,CLvesselLengthCategory,
			CLfishingTechnique,CLdeepSeaRegulation,CLofficialWeight,CLscientificWeight,
			CLexplainDifference,CLtotalOfficialLandingsValue,CLnumberOfUniqueVessels,
			CLscientificWeightRSE,CLvalueRSE,CLscientificWeightQualitativeBias
		)
		ON (
			target.CLdataTypeOfScientificWeight = source.CLdataTypeOfScientificWeight
			AND	target.CLdataSourceOfScientificWeight = source.CLdataSourceOfScientificWeight
			AND	((target.CLsamplingScheme IS NULL AND source.CLsamplingScheme IS NULL) OR (target.CLsamplingScheme = source.CLsamplingScheme))
			AND	target.CLdataSourceLandingsValue = source.CLdataSourceLandingsValue
			AND	target.CLlandingCountry = source.CLlandingCountry
			AND	target.CLvesselFlagCountry =source.CLvesselFlagCountry
			AND	target.CLyear = source.CLyear
			AND	target.CLquarter = source.CLquarter
			AND	((target.CLmonth IS NULL AND source.CLmonth IS NULL) OR (target.CLmonth = source.CLmonth))
			AND	target.CLarea = source.CLarea
			AND	target.CLstatisticalRectangle = source.CLstatisticalRectangle
			AND	target.CLgsaSubarea = source.CLgsaSubarea
			AND	((target.CLjurisdictionArea IS NULL AND source.CLjurisdictionArea IS NULL) OR (target.CLjurisdictionArea = source.CLjurisdictionArea))
			AND	target.CLexclusiveEconomicZoneIndicator = source.CLexclusiveEconomicZoneIndicator
			AND	target.CLspeciesCode = source.CLspeciesCode
			AND	((target.CLspeciesFaoCode IS NULL AND target.CLspeciesFaoCode IS NULL) OR (target.CLspeciesFaoCode = source.CLspeciesFaoCode))
			AND	target.CLlandingCategory = source.CLlandingCategory
			AND	target.CLcatchCategory = source.CLcatchCategory
			AND	((target.CLregDisCategory IS NULL AND source.CLregDisCategory IS NULL) OR (target.CLregDisCategory = source.CLregDisCategory))
			AND	((target.CLcommercialSizeCategoryScale IS NULL AND source.CLcommercialSizeCategoryScale IS NULL) OR (target.CLcommercialSizeCategoryScale = source.CLcommercialSizeCategoryScale))
			AND	((target.CLcommercialSizeCategory IS NULL AND source.CLcommercialSizeCategory IS NULL) OR (target.CLcommercialSizeCategory = source.CLcommercialSizeCategory))   
			AND	((target.CLnationalFishingActivity IS NULL AND source.CLnationalFishingActivity IS NULL) OR (target.CLnationalFishingActivity = source.CLnationalFishingActivity))  
			AND	target.CLmetier6 = source.CLmetier6
			AND	target.CLincidentialByCatchMitigationDevice = source.CLincidentialByCatchMitigationDevice
			AND	target.CLlandingLocation = source.CLlandingLocation
			AND	target.CLvesselLengthCategory = source.CLvesselLengthCategory
			AND	((target.CLfishingTechnique IS NULL AND source.CLfishingTechnique IS NULL) OR (target.CLfishingTechnique = source.CLfishingTechnique))  
			AND	((target.CLdeepSeaRegulation IS NULL AND source.CLdeepSeaRegulation IS NULL) OR (target.CLdeepSeaRegulation = source.CLdeepSeaRegulation)) 
		)

		WHEN MATCHED THEN
			UPDATE SET -- update only fields which are not included in the unique index, as the other are equal anyway
				-- UserId and TimeStamp are left unchanged on update
				CLrecordType = source.CLrecordType,
				CLofficialWeight = source.CLofficialWeight,
				CLscientificWeight = source.CLscientificWeight,
				CLexplainDifference = source.CLexplainDifference,
				CLtotalOfficialLandingsValue = source.CLtotalOfficialLandingsValue,
				CLnumberOfUniqueVessels = source.CLnumberOfUniqueVessels,
				CLscientificWeightRSE = source.CLscientificWeightRSE,
				CLvalueRSE = source.CLvalueRSE,
				CLscientificWeightQualitativeBias= source.CLscientificWeightQualitativeBias

		WHEN NOT MATCHED THEN  
			INSERT (
				UserId,TimeStamp,CLrecordType,CLdataTypeOfScientificWeight,CLdataSourceOfScientificWeight,
				CLsamplingScheme,CLdataSourceLandingsValue,CLlandingCountry,
				CLvesselFlagCountry,CLyear,CLquarter,CLmonth,CLarea,CLstatisticalRectangle,CLgsaSubarea,
				CLjurisdictionArea,CLexclusiveEconomicZoneIndicator,CLspeciesCode,CLspeciesFaoCode,CLlandingCategory,
				CLcatchCategory,CLregDisCategory,CLcommercialSizeCategoryScale,CLcommercialSizeCategory,CLnationalFishingActivity,
				CLmetier6, CLincidentialByCatchMitigationDevice,CLlandingLocation,CLvesselLengthCategory,
				CLfishingTechnique,CLdeepSeaRegulation,CLofficialWeight,CLscientificWeight,
				CLexplainDifference,CLtotalOfficialLandingsValue,CLnumberOfUniqueVessels,
				CLscientificWeightRSE,CLvalueRSE,CLscientificWeightQualitativeBias
			)  
			VALUES (
				source.UserId,source.TimeStamp,source.CLrecordType,source.CLdataTypeOfScientificWeight,source.CLdataSourceOfScientificWeight,source.
				CLsamplingScheme,source.CLdataSourceLandingsValue,source.CLlandingCountry,source.
				CLvesselFlagCountry,source.CLyear,source.CLquarter,source.CLmonth,source.CLarea,source.CLstatisticalRectangle,source.CLgsaSubarea,source.
				CLjurisdictionArea,source.CLexclusiveEconomicZoneIndicator,source.CLspeciesCode,source.CLspeciesFaoCode,source.CLlandingCategory,source.
				CLcatchCategory,source.CLregDisCategory,source.CLcommercialSizeCategoryScale,source.CLcommercialSizeCategory,source.CLnationalFishingActivity,source.
				CLmetier6,source.CLincidentialByCatchMitigationDevice,source.CLlandingLocation,source.CLvesselLengthCategory,source.
				CLfishingTechnique,source.CLdeepSeaRegulation,source.CLofficialWeight,source.CLscientificWeight,source.CLexplainDifference,
				source.CLtotalOfficialLandingsValue,source.CLnumberOfUniqueVessels,source.
				CLscientificWeightRSE,source.CLvalueRSE,source.CLscientificWeightQualitativeBias
			)
		OUTPUT $action INTO @Changes;
		SET @Updates = (SELECT COUNT (Change) FROM @Changes WHERE Change='UPDATE');
END
ELSE
BEGIN 
Print 'Pure insert';
	INSERT INTO CommercialLanding(
		UserId,TimeStamp,CLrecordType,CLdataTypeOfScientificWeight,CLdataSourceOfScientificWeight,
		CLsamplingScheme,CLdataSourceLandingsValue,CLlandingCountry,
		CLvesselFlagCountry,CLyear,CLquarter,CLmonth,CLarea,CLstatisticalRectangle,CLgsaSubarea,
		CLjurisdictionArea,CLexclusiveEconomicZoneIndicator,CLspeciesCode,CLspeciesFaoCode,CLlandingCategory,
		CLcatchCategory,CLregDisCategory,CLcommercialSizeCategoryScale,CLcommercialSizeCategory,CLnationalFishingActivity,
		CLmetier6, CLincidentialByCatchMitigationDevice,CLlandingLocation,CLvesselLengthCategory,
		CLfishingTechnique,CLdeepSeaRegulation,CLofficialWeight,CLscientificWeight,
		CLexplainDifference,CLtotalOfficialLandingsValue,CLnumberOfUniqueVessels,
		CLscientificWeightRSE,CLvalueRSE,CLscientificWeightQualitativeBias
)
SELECT 
		UserId,TimeStamp,CLrecordType,CLdataTypeOfScientificWeight,CLdataSourceOfScientificWeight,
		CLsamplingScheme,CLdataSourceLandingsValue,CLlandingCountry,
		CLvesselFlagCountry,CLyear,CLquarter,CLmonth,CLarea,CLstatisticalRectangle,CLgsaSubarea,
		CLjurisdictionArea,CLexclusiveEconomicZoneIndicator,CLspeciesCode,CLspeciesFaoCode,CLlandingCategory,
		CLcatchCategory,CLregDisCategory,CLcommercialSizeCategoryScale,CLcommercialSizeCategory,CLnationalFishingActivity,
		CLmetier6, CLincidentialByCatchMitigationDevice,CLlandingLocation,CLvesselLengthCategory,
		CLfishingTechnique,CLdeepSeaRegulation,CLofficialWeight,CLscientificWeight,
		CLexplainDifference,CLtotalOfficialLandingsValue,CLnumberOfUniqueVessels,
		CLscientificWeightRSE,CLvalueRSE,CLscientificWeightQualitativeBias
FROM {TEMP_TABLE_NAME} (NOLOCK);

END

SELECT 
0 as Deletes,
@TotalCount - @Updates as Inserts,
@Updates as Updates;
";

		protected override Dictionary<string, string> SpecialCaseColumnMappings =>
			new Dictionary<string, string>
			{
				{nameof(CommercialLanding.ClscientificWeightRse), "CLscientificWeightRSE" },
				{nameof(CommercialLanding.ClvalueRse), "CLvalueRSE" },
				{nameof(CommercialLanding.UserId), "UserId" },
				{nameof(CommercialLanding.TimeStamp), "TimeStamp" }
			};




	}
}
