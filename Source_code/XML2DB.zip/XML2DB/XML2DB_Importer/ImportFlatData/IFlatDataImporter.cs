﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using Xml2DB_DAL;

namespace XML2DB_Importer.ImportFlatData
{
	interface IFlatDataImporter<T>
	{
		Task<DbMergeStats> Import(IEnumerable<T> dataRecords, SqlConnection conn);
	}
}
