﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace XML2DB_Importer
{
    public interface IDuplicatesChecker
    {
        /// <summary>
        /// This method checks for duplicates comparing data in db and xml file.
        /// </summary>
        /// <typeparam name="TResult">Custom type containing information about duplicate. Corresponds to the specific hierarchy</typeparam>
        /// <param name="pathToXml"></param>
        /// <param name="hierarchyName"></param>
        /// <returns></returns>
        Task<IEnumerable<TResult>> CheckFoDuplicates<TResult>(string pathToXml, string hierarchyName);

        Task<IEnumerable<object>> CheckFoDuplicatesNonTyped(string pathToXml, string hierarchyName);
    }
}
