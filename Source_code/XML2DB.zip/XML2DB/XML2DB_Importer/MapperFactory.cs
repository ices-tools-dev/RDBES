﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xml2DB_DAL;
using Xml2DB_DAL.Models;

namespace XML2DB_Importer
{
    internal static class MapperFactory
    {
        public static IMapper CreateMapper(DatabaseContext context, DbMergeStats stats)
        {
            MapperConfiguration config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<ICollection<BiologicalVariable>, ICollection<BiologicalVariable>>().ConvertUsing(new CollectionMapper<BiologicalVariable>(context, stats));
                cfg.CreateMap<ICollection<FishingOperation>, ICollection<FishingOperation>>().ConvertUsing(new CollectionMapper<FishingOperation>(context, stats));
                cfg.CreateMap<ICollection<FishingTrip>, ICollection<FishingTrip>>().ConvertUsing(new CollectionMapper<FishingTrip>(context, stats));
                cfg.CreateMap<ICollection<FrequencyMeasure>, ICollection<FrequencyMeasure>>().ConvertUsing(new CollectionMapper<FrequencyMeasure>(context, stats));
                cfg.CreateMap<ICollection<LandingEvent>, ICollection<LandingEvent>>().ConvertUsing(new CollectionMapper<LandingEvent>(context, stats));
                cfg.CreateMap<ICollection<Location>, ICollection<Location>>().ConvertUsing(new CollectionMapper<Location>(context, stats));
                cfg.CreateMap<ICollection<OnshoreEvent>, ICollection<OnshoreEvent>>().ConvertUsing(new CollectionMapper<OnshoreEvent>(context, stats));
                cfg.CreateMap<ICollection<Sample>, ICollection<Sample>>().ConvertUsing(new CollectionMapper<Sample>(context, stats));
                cfg.CreateMap<ICollection<SamplingDetail>, ICollection<SamplingDetail>>().ConvertUsing(new CollectionMapper<SamplingDetail>(context, stats));
                cfg.CreateMap<ICollection<SpeciesSelection>, ICollection<SpeciesSelection>>().ConvertUsing(new CollectionMapper<SpeciesSelection>(context, stats));
                cfg.CreateMap<ICollection<TemporalEvent>, ICollection<TemporalEvent>>().ConvertUsing(new CollectionMapper<TemporalEvent>(context, stats));
                cfg.CreateMap<ICollection<VesselDetail>, ICollection<VesselDetail>>().ConvertUsing(new CollectionMapper<VesselDetail>(context, stats));
                cfg.CreateMap<ICollection<VesselSelection>, ICollection<VesselSelection>>().ConvertUsing(new CollectionMapper<VesselSelection>(context, stats));


                cfg.CreateMap<BiologicalVariable, BiologicalVariable>()
                        .ForMember(m => m.Bvid, opt => opt.Ignore())
                        .ForMember(m => m.Said, opt => opt.Ignore())
                        .ForMember(m => m.Fmid, opt => opt.Ignore())
                        .ForMember(m => m.Fm, opt => opt.Ignore());

                cfg.CreateMap<CommercialEffort, CommercialEffort>()
                    .ForMember(m => m.Ceid, opt => opt.Ignore()); ;

                cfg.CreateMap<CommercialLanding, CommercialLanding>()
                    .ForMember(m => m.Clid, opt => opt.Ignore()); ;

                cfg.CreateMap<Design, Design>()
                    .ForMember(m => m.Deid, opt => opt.Ignore())
                    .ForMember(m => m.SamplingDetails, opt => opt.Ignore())
                    .ForMember(m => m.UserId, opt => opt.Ignore())
                    .ForMember(m => m.TimeStamp, opt => opt.Ignore())
                    .AfterMap((from, to)=> {
                        if (string.IsNullOrEmpty(to.UserId))
                        {
                            to.TimeStamp = from.TimeStamp;
                            to.UserId = from.UserId;
                        }
                    });

                cfg.CreateMap<FishingOperation, FishingOperation>()
                    .ForMember(m => m.Foid, opt => opt.Ignore())
                    .ForMember(m => m.Ftid, opt => opt.Ignore())
                    .ForMember(m => m.Sdid, opt => opt.Ignore())
                    .ForMember(m => m.Ft, opt => opt.Ignore())
                    .ForMember(m => m.Sd, opt => opt.Ignore());

                cfg.CreateMap<FishingTrip, FishingTrip>()
                    .ForMember(m => m.Ftid, opt => opt.Ignore())
                    .ForMember(m => m.Osid, opt => opt.Ignore())
                    .ForMember(m => m.Vsid, opt => opt.Ignore())
                    .ForMember(m => m.Sdid, opt => opt.Ignore())
                    .ForMember(m => m.Foid, opt => opt.Ignore())
                    .ForMember(m => m.Teid, opt => opt.Ignore())
                    .ForMember(m => m.Fo, opt => opt.Ignore())
                    .ForMember(m => m.Os, opt => opt.Ignore())
                    .ForMember(m => m.Sd, opt => opt.Ignore())
                    .ForMember(m => m.Vd, opt => opt.Ignore())
                    .ForMember(m => m.Vs, opt => opt.Ignore());

                cfg.CreateMap<FrequencyMeasure, FrequencyMeasure>()
                    .ForMember(m => m.Fmid, opt => opt.Ignore())
                    .ForMember(m => m.Said, opt => opt.Ignore())
                    .ForMember(m => m.Sa, opt => opt.Ignore())
                    .AfterMap((src, dest) => src.BiologicalVariables.ToList().ForEach(a => a.Fmid = dest.Fmid));

                cfg.CreateMap<LandingEvent, LandingEvent>()
                    .ForMember(m => m.Leid, opt => opt.Ignore())
                    .ForMember(m => m.Osid, opt => opt.Ignore())
                    .ForMember(m => m.Ftid, opt => opt.Ignore())
                    .ForMember(m => m.Vsid, opt => opt.Ignore())
                    .ForMember(m => m.Teid, opt => opt.Ignore())
                    .ForMember(m => m.Said, opt => opt.Ignore())
                    .ForMember(m => m.Ft, opt => opt.Ignore())
                    .ForMember(m => m.Os, opt => opt.Ignore())
                    .ForMember(m => m.Sa, opt => opt.Ignore())
                    .ForMember(m => m.Te, opt => opt.Ignore())
                    .ForMember(m => m.Vd, opt => opt.Ignore())
                    .ForMember(m => m.Vs, opt => opt.Ignore());


                cfg.CreateMap<Location, Location>()
                    .ForMember(m => m.Loid, opt => opt.Ignore())
                    .ForMember(m => m.Loid, opt => opt.Ignore())
                    .ForMember(m => m.Sd, opt => opt.Ignore());

                cfg.CreateMap<OnshoreEvent, OnshoreEvent>()
                    .ForMember(m => m.Osid, opt => opt.Ignore())
                    .ForMember(m => m.Sdid, opt => opt.Ignore())
                    .ForMember(m => m.Sd, opt => opt.Ignore());

                cfg.CreateMap<Sample, Sample>()
                    .ForMember(m => m.Said, opt => opt.Ignore())
                    .ForMember(m => m.SaparentId, opt => opt.Ignore())
                    .ForMember(m => m.Ssid, opt => opt.Ignore())
                    .ForMember(m => m.Saparent, opt => opt.Ignore())
                    .ForMember(m => m.Ss, opt => opt.Ignore())
                    .AfterMap((src, dest) => src.BiologicalVariables.ToList().ForEach(a => a.Said = dest.Said))
                    .AfterMap((src, dest) => src.FrequencyMeasures.ToList().ForEach(a => a.Said = dest.Said));


                cfg.CreateMap<SamplingDetail, SamplingDetail>()
                    .ForMember(m => m.Sdid, opt => opt.Ignore())
                    .ForMember(m => m.Deid, opt => opt.Ignore())
                    .ForMember(m => m.De, opt => opt.Ignore());

                cfg.CreateMap<SpeciesList, SpeciesList>()
                    .ForMember(m => m.Slid, opt => opt.Ignore())
                    .ForMember(m => m.SpeciesSelections, opt => opt.Ignore());

               

                cfg.CreateMap<SpeciesSelection, SpeciesSelection>()
                    .ForMember(m => m.Ssid, opt => opt.Ignore())
                    .ForMember(m => m.Leid, opt => opt.Ignore())
                    .ForMember(m => m.Foid, opt => opt.Ignore())
                    .ForMember(m => m.Teid, opt => opt.Ignore())
                    .ForMember(m => m.Ftid, opt => opt.Ignore())
                    .ForMember(m => m.Osid, opt => opt.Ignore())
                    .ForMember(m => m.Fo, opt => opt.Ignore())
                    .ForMember(m => m.Ft, opt => opt.Ignore())
                    .ForMember(m => m.Le, opt => opt.Ignore())
                    .ForMember(m => m.Sl, opt => opt.Ignore())
                    .ForMember(m => m.Te, opt => opt.Ignore())
                    .ForMember(m => m.Os, opt => opt.Ignore());

                cfg.CreateMap<TemporalEvent, TemporalEvent>()
                    .ForMember(m => m.Teid, opt => opt.Ignore())
                    .ForMember(m => m.Sdid, opt => opt.Ignore())
                    .ForMember(m => m.Loid, opt => opt.Ignore())
                    .ForMember(m => m.Vsid, opt => opt.Ignore())
                    .ForMember(m => m.Lo, opt => opt.Ignore())
                    .ForMember(m => m.Sd, opt => opt.Ignore())
                    .ForMember(m => m.Vs, opt => opt.Ignore());

                cfg.CreateMap<VesselSelection, VesselSelection>()
                    .ForMember(m => m.Vsid, opt => opt.Ignore())
                    .ForMember(m => m.Sdid, opt => opt.Ignore())
                    .ForMember(m => m.Teid, opt => opt.Ignore())
                    .ForMember(m => m.Sd, opt => opt.Ignore())
                    .ForMember(m => m.Te, opt => opt.Ignore())
                    .ForMember(m => m.Vd, opt => opt.Ignore());

                cfg.CreateMap<VesselDetail, VesselDetail>()
                    .ForMember(m => m.Vdid, opt => opt.Ignore());

            });

            config.AssertConfigurationIsValid();
            return config.CreateMapper();
        }

    }
}
