﻿namespace Db2Csv.Processor
{
	public enum ExportFormat:byte
	{
		SingleCsvFile,
		CsvFilePerTable
	}
}
