﻿using Db2Csv.Common;
using System.Collections.Generic;

namespace Db2Csv.Processor
{
	public interface IEraser
	{
		List<(string ElementName, int DeletedRecordsCount)> Delete(EraserParameters parameters, bool dryRun);
		bool ValidateElementsToDelete(string hierarchyName, List<(string ElementName, bool ChildrenOnly)> elementsToDelete, out string error);
	}
}
