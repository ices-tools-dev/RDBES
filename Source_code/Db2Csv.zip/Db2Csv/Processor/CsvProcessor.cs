﻿using Db2Csv.Hierarchies;
using Db2Csv.Lookup;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;

namespace Db2Csv.Processor
{
    internal class CsvProcessor
    {
        private string pathToTempDir;
        private HierarchyBase hierarchy;
        private string pathToResult;
        private string pathToOutputFolder;
        private Dictionary<string, CsvFileReader> readers = new Dictionary<string, CsvFileReader>();
        private ILookupProvider lookup;

        private StreamWriter sw;
        public CsvProcessor(string pathToTempDir, HierarchyBase hierarchy, string pathToOutputFolder, ILookupProvider lookup)
        {
            this.pathToTempDir = pathToTempDir;
            this.hierarchy = hierarchy;
            this.pathToOutputFolder = pathToOutputFolder;
            this.pathToResult = Path.Combine(pathToOutputFolder, Guid.NewGuid().ToString());
            this.lookup = lookup;
            LoadCsvReaders();
        }

        public string Process()
        {
            using (FileStream fw = File.Open(pathToResult, FileMode.Create, FileAccess.Write, FileShare.Read))
            {
                using (ZipArchive archive = new ZipArchive(fw, ZipArchiveMode.Create))
                {
                    ZipArchiveEntry entry = archive.CreateEntry($"{hierarchy.GetType().Name}.csv");
                    sw = new StreamWriter(entry.Open(), new System.Text.UTF8Encoding(false));
                    foreach (var element in hierarchy.Elements)
                    {
                        WriteToCsv(element);
                    }
                    sw.Flush();
                    sw.Close();
                }
            }
            CloseReaders();

            string fileName = $"{hierarchy.GetType().Name}_{DateTime.Now:yyyy_MM_dd_HHmmss}.zip";
            string filePath = Path.Combine(pathToOutputFolder, fileName);
            File.Move(pathToResult, filePath);

            return filePath;
        }

        private void WriteToCsv(HierarchyElement element, string parentId = "0")
        {
            var reader = readers[element.Element.CombinedElementName];
            while (!reader.Finished && reader.ParentId.Equals(parentId))
            {
                sw.WriteLine(reader.GetRowForCsv(element.Element,0));
                foreach (var child in element.Childs)
                {
                    WriteToCsv(child, reader.ID);
                }
                reader.Read();
            }
        }


        private void LoadCsvReaders()
        {
            foreach (var hierarchyElement in hierarchy.GetAllElements())
            {
                string pathToCsv = Path.Combine(pathToTempDir, $"{hierarchyElement.Element.CombinedElementName}.csv");
                CsvFileReader reader = new CsvFileReader(pathToCsv, hierarchyElement.Element.CombinedElementName, lookup);
                readers.Add(hierarchyElement.Element.CombinedElementName, reader);
            }
        }

        private void CloseReaders()
        {
            foreach (var reader in readers.Values)
            {
                reader.Close();
            }
            readers.Clear();
        }


    }
}
