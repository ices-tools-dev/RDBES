﻿using Db2Csv.Common;

namespace Db2Csv.Processor
{
    public interface IProcessor
    {
        /// <returns>path to the produced file, located in the directory provided in parameters.OutputDirectoryPath</returns>
        string Export(ProcessorParameters parameters, ExportFormat format);

        /// <returns>size of the uncompressed output file</returns>
        ulong GetRawDataSize(ProcessorParameters parameters);
    }
}
