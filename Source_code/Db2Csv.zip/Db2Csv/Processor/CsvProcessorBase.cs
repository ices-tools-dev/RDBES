﻿using Db2Csv.Hierarchies;
using Db2Csv.Lookup;
using System;
using System.Collections.Generic;
using System.IO;


namespace Db2Csv.Processor
{
	internal abstract class CsvProcessorBase : ICsvProcessor
	{
		protected string pathToTempDir;
		protected HierarchyBase hierarchy;
		protected string pathToResult;
		protected string pathToOutputFolder;
		protected Dictionary<string, CsvFileReader> readers = new Dictionary<string, CsvFileReader>();
		protected ILookupProvider lookup;

		public CsvProcessorBase(string pathToTempDir, HierarchyBase hierarchy, string pathToOutputFolder, ILookupProvider lookup)
		{
			this.pathToTempDir = pathToTempDir;
			this.hierarchy = hierarchy;
			this.pathToOutputFolder = pathToOutputFolder;
			this.pathToResult = Path.Combine(pathToOutputFolder, Guid.NewGuid().ToString());
			this.lookup = lookup;
		}

		public abstract string Process();

		protected void LoadCsvReaders()
		{
			foreach (var hierarchyElement in hierarchy.GetAllElements())
			{
				string pathToCsv = Path.Combine(pathToTempDir, $"{hierarchyElement.Element.CombinedElementName}.csv");
				if (File.Exists(pathToCsv))
				{
					CsvFileReader reader = new CsvFileReader(pathToCsv, hierarchyElement.Element.CombinedElementName, lookup);
					readers.Add(hierarchyElement.Element.CombinedElementName, reader);
				}
			}
		}

		protected void CloseReaders()
		{
			foreach (var reader in readers.Values)
			{
				reader.Close();
			}
			readers.Clear();
		}
	}
}
