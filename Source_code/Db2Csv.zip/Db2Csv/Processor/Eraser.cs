﻿using Db2Csv.Common;
using Db2Csv.DataReader;
using Db2Csv.Hierarchies;
using Db2Csv.Lookup;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Db2Csv.Processor
{
	public sealed class Eraser : IEraser
	{
		private HierarchyBase hierarchy;

		public List<(string ElementName, int DeletedRecordsCount)> Delete(EraserParameters parameters, bool dryRun = false)
		{
			if (!ValidateElementsToDelete(parameters.HierarchyName, parameters.ElementsToDelete, out string error))
			{
				throw new Exception(error);
			}
			hierarchy = Utils.GetHierarchy(parameters.HierarchyName);

			var sqlHelper = new SqlHelper(parameters.ConnectionString);

			var elements = hierarchy.ExtractElementsToDelete(parameters.ElementsToDelete)
							.OrderByDescending(e => e.Level)
							.Select(e => e.Element).ToList();

			var result = sqlHelper.Delete(hierarchy, parameters.Filters, elements, dryRun);
			return result;
		}

		public bool ValidateElementsToDelete(string hierarchyName, List<(string ElementName, bool ChildrenOnly)> elementsToDelete, out string error)
		{
			error = null;
			if (elementsToDelete == null || elementsToDelete.Count == 0)
			{
				error = $"ElementsToDelete could not be empty";
				return false;
			}
			// check for duplicates
			var groupped = elementsToDelete
							.GroupBy(itm => itm.ElementName)
							.Select(itm => new { itm.Key, Count = itm.Count() })
							.Where(ge => ge.Count > 1).ToList();
			if (groupped.Count > 0)
			{
				error = $"There are duplicated element names: {string.Join(",", groupped.Select(ge => ge.Key))}";
				return false;
			}
			// check for wrong element names
			hierarchy = Utils.GetHierarchy(hierarchyName);
			foreach (var item in elementsToDelete)
			{
				if (!hierarchy.ContainsElement(item.ElementName))
				{
					error = $"There is no element: '{item.ElementName}' in hierarchy: '{hierarchyName}'";
					return false;
				}
			}
			return true;

		}

	}
}
