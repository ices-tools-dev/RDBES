﻿using Db2Csv.Common;
using Db2Csv.ElementDefinitions;
using Db2Csv.Lookup;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using static Db2Csv.Common.Enums;

namespace Db2Csv.Processor
{
	internal class CsvFileReader
	{
		private FileStream fs;
		private StreamReader sr;
		private string[] currentCsvLine;
		private ILookupProvider lookup;
		public string[] ColumnNames;
		public string ElementName { get; private set; }

		/// <summary>
		/// This property allows to exlude some of the columns from the export
		/// </summary>
		public int[] ColumnIndexesToSkip { get; set; } = new int[0];

		public CsvFileReader(string pathToCsv, string elementName, ILookupProvider lookup)
		{
			this.ElementName = elementName;
			fs = File.Open(pathToCsv, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			sr = new StreamReader(fs);
			this.lookup = lookup;
			ReadColumns();
			Read();
		}

		public bool Read()
		{
			if (Finished)
			{
				throw new InvalidOperationException("Reader is already closed!");
			}
			string currentLine = sr.ReadLine();
			if (string.IsNullOrEmpty(currentLine))
			{
				Finished = true;
				return false;
			}
			ProcessLine(currentLine);
			return true;
		}

		public bool Finished { get; private set; }

		public string ID { get { return currentCsvLine[0]; } }

		public string ParentId { get { return currentCsvLine[1]; } }

		public string GetRowForCsv(ElementBase element, int startColumnIndex)
		{
			StringBuilder sbResult = new StringBuilder();
			int indexCorrection = 0;
			for (int i = startColumnIndex; i < currentCsvLine.Length; i++)
			{
				if (ColumnIndexesToSkip.Length > 0 && ColumnIndexesToSkip.Contains(i))
				{
					continue;
				}
				int currentIndex = (i - element.StartColumnIndex) + indexCorrection;
				if (element.ConstantValues.ContainsKey(currentIndex))
				{
					indexCorrection++;
					if (sbResult.Length > 0)
					{
						sbResult.Append(Constants.SEPARATOR);
					}
					sbResult.Append(element.ConstantValues[currentIndex]);
				}
				if (sbResult.Length > 0)
				{
					sbResult.Append(Constants.SEPARATOR);
				}
				string currentValue = currentCsvLine[i];
				if (element.LookupColumns.ContainsKey(ColumnNames[i]))
				{
					try
					{
						currentValue = lookup.Lookup(element.LookupColumns[ColumnNames[i]], currentValue);
					}
					catch (ArgumentException argExcp)
					{
						throw new Exception($"Failed to find lookup value for element: '{element.ElementName}' table name: '{element.TableName}' column: '{ColumnNames[i]}'", argExcp);
					}
				}
				sbResult.Append(currentValue);
			}
			return sbResult.ToString();

		}

		public void Close()
		{
			this.Finished = true;
			sr.Close();
			fs.Dispose();
		}

		private void ProcessLine(string content)
		{
			currentCsvLine = content.Split(Constants.SEPARATOR);
		}

		private void ReadColumns()
		{
			string currentLine = sr.ReadLine();
			if (string.IsNullOrEmpty(currentLine))
			{
				throw new InvalidOperationException("Failed to read columns, the file is empty!");
			}

			ColumnNames = currentLine.Split(Constants.SEPARATOR);
		}


	}
}
