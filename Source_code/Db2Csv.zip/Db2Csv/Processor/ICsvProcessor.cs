﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Db2Csv.Processor
{
	interface ICsvProcessor
	{
		string Process();
	}
}
