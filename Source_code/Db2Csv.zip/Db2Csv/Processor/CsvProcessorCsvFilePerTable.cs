﻿using Db2Csv.Common;
using Db2Csv.ElementDefinitions;
using Db2Csv.Hierarchies;
using Db2Csv.Lookup;
using System;
using System.IO;
using System.IO.Compression;
using System.Linq;

namespace Db2Csv.Processor
{
	internal class CsvProcessorCsvFilePerTable : CsvProcessorBase
	{
		private const int DEFAULT_START_COLUMN_INDEX = 4; // skip just the added internal columns and include all the columns from the table

		public CsvProcessorCsvFilePerTable(string pathToTempDir, HierarchyBase hierarchy, string pathToOutputFolder, ILookupProvider lookup) :
			base(pathToTempDir, hierarchy, pathToOutputFolder, lookup)
		{ }

		public override string Process()
		{
			MergeBvFiles();
			LoadCsvReaders();
			AdjustCsvReadersSettings();
			using (FileStream fw = File.Open(pathToResult, FileMode.Create, FileAccess.ReadWrite, FileShare.Read))
			{
				using (ZipArchive archive = new ZipArchive(fw, ZipArchiveMode.Update))
				{
					foreach (var element in hierarchy.Elements)
					{
						WriteToCsv(element, archive);
					}
				}
			}
			CloseReaders();

			string fileName = $"{hierarchy.GetType().Name}_{DateTime.Now:yyyy_MM_dd_HHmmss}.zip";
			string filePath = Path.Combine(pathToOutputFolder, fileName);
			File.Move(pathToResult, filePath);

			return filePath;
		}

		private void MergeBvFiles()
		{
			var bvFiles = Directory.GetFiles(this.pathToTempDir, "*BV.csv");
			if (bvFiles.Length == 2)
			{
				MergeFiles(bvFiles[0], bvFiles[1]);
			}
		}

		private void MergeFiles(string file1, string file2)
		{
			using (StreamWriter sw = new StreamWriter(file1, true))
			{
				var file2Content = File.ReadAllText(file2);
				file2Content = file2Content.Substring(file2Content.IndexOf(Environment.NewLine) + Environment.NewLine.Length);
				sw.Write(file2Content);
				sw.Flush();
				sw.Close();
			}
			File.Delete(file2);
		}

		private void AdjustCsvReadersSettings()
		{
			foreach (var reader in readers.Values)
			{
				if (reader.ElementName == typeof(DE).Name || reader.ElementName == typeof(CE).Name || reader.ElementName == typeof(CL).Name 
					|| reader.ElementName == typeof(SL).Name || reader.ElementName == typeof(VD).Name)
				{
					reader.ColumnIndexesToSkip = new int[] { 5, 6 };
				}
				else if (reader.ElementName.EndsWith(typeof(SD).Name))
				{
					reader.ColumnIndexesToSkip = new int[] { 6, 7 };
				}
			}
		}

		private void WriteToCsv(HierarchyElement element, ZipArchive archive)
		{
			if (readers.ContainsKey(element.Element.CombinedElementName))
			{
				var reader = readers[element.Element.CombinedElementName];
				var entry = archive.CreateEntry($"{element.Element.TableName}.csv");
				using (var sw = new StreamWriter(entry.Open(), new System.Text.UTF8Encoding(false)))
				{
					bool placeSeparator = false;
					for (int i = DEFAULT_START_COLUMN_INDEX; i < reader.ColumnNames.Length; i++)
					{
						if (reader.ColumnIndexesToSkip.Length > 0 && reader.ColumnIndexesToSkip.Contains(i))
						{
							continue;
						}
						if (placeSeparator)
						{
							sw.Write(Constants.SEPARATOR);
						}
						sw.Write(reader.ColumnNames[i]);
						placeSeparator = true;
					}
					sw.Write(Environment.NewLine);
					while (!reader.Finished)
					{
						sw.WriteLine(reader.GetRowForCsv(element.Element, DEFAULT_START_COLUMN_INDEX));
						reader.Read();
					}
					sw.Flush();
					sw.Close();
				}
			}
			foreach (var childElement in element.Childs)
			{
				WriteToCsv(childElement, archive);
			}
		}

	}
}
