﻿using Db2Csv.Common;
using System.Collections.Generic;

namespace Db2Csv.Processor
{
    interface IFilterDataExtractor
    {
        List<KeyValuePair<int, string>> ExtractFilterData(FilterDataExtractorParameters parameters);
    }
}
