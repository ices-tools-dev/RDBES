﻿using Db2Csv.Hierarchies;
using Db2Csv.Lookup;
using System;
using System.IO;
using System.IO.Compression;


namespace Db2Csv.Processor
{
	internal class CsvProcessorSingleCsvFile : CsvProcessorBase
	{
		public CsvProcessorSingleCsvFile(string pathToTempDir, HierarchyBase hierarchy, string pathToOutputFolder, ILookupProvider lookup) :
			base(pathToTempDir, hierarchy, pathToOutputFolder, lookup)
		{ }

		public override string Process()
		{
			LoadCsvReaders();
			ZipArchiveEntry entry;
			using (FileStream fw = File.Open(pathToResult, FileMode.Create, FileAccess.Write, FileShare.Read))
			{
				using (ZipArchive archive = new ZipArchive(fw, ZipArchiveMode.Create))
				{
					entry = archive.CreateEntry($"{hierarchy.GetType().Name}.csv");
					var sw = new StreamWriter(entry.Open(), new System.Text.UTF8Encoding(false));
					foreach (var element in hierarchy.Elements)
					{
						WriteToCsv(element, sw);
					}
					sw.Flush();
					sw.Close();
				}
			}
			CloseReaders();

			string fileName = $"{hierarchy.GetType().Name}_{DateTime.Now:yyyy_MM_dd_HHmmss}.zip";
			string filePath = Path.Combine(pathToOutputFolder, fileName);
			File.Move(pathToResult, filePath);

			return filePath;
		}


		private void WriteToCsv(HierarchyElement element, StreamWriter sw, string parentId = "0")
		{
			var reader = readers[element.Element.CombinedElementName];
			while (!reader.Finished && reader.ParentId.Equals(parentId))
			{
				sw.WriteLine(reader.GetRowForCsv(element.Element, element.Element.StartColumnIndex));
				foreach (var child in element.Childs)
				{
					WriteToCsv(child, sw, reader.ID);
				}
				reader.Read();
			}
		}

	}
}
