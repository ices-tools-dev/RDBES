﻿using Db2Csv.Common;
using Db2Csv.DataReader;
using Db2Csv.Hierarchies;
using Db2Csv.Lookup;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;

namespace Db2Csv.Processor
{
	public sealed class Processor : IProcessor
	{
		public string Export(ProcessorParameters parameters, ExportFormat format = ExportFormat.SingleCsvFile)
		{
			string tempFolderPath = Utils.CreateTempDir();
			HierarchyBase hierarchy = Utils.GetHierarchy(parameters.HierarchyName);

			var sqlHelper = new SqlHelper(parameters.ConnectionString);
			sqlHelper.ExportData(hierarchy, parameters.Filters, tempFolderPath);

			var lookup = new LookupProvider(parameters.ConnectionString);
			var csvProcessor = MakeProcessor(format, tempFolderPath, hierarchy, parameters.OutputDirectoryPath, lookup);
			string result = csvProcessor.Process();
			Directory.Delete(tempFolderPath, true);
			return result;
		}

		private ICsvProcessor MakeProcessor(ExportFormat format, string tempFolderPath, HierarchyBase hierarchy, string outputDirectoryPath, LookupProvider lookup)
		{
			switch (format)
			{
				case ExportFormat.SingleCsvFile:
					return new CsvProcessorSingleCsvFile(tempFolderPath, hierarchy, outputDirectoryPath, lookup);
				case ExportFormat.CsvFilePerTable:
					return new CsvProcessorCsvFilePerTable(tempFolderPath, hierarchy, outputDirectoryPath, lookup);
				default:
					throw new NotSupportedException($"Unrecognized export format:{format}");
			}
		}

		public ulong GetRawDataSize(ProcessorParameters parameters)
		{
			ulong charactersCount = 0;
			HierarchyBase hierarchy = Utils.GetHierarchy(parameters.HierarchyName);
			var sqlHelper = new SqlHelper(parameters.ConnectionString);
			var lookup = new LookupProvider(parameters.ConnectionString);

			sqlHelper.RunReader(hierarchy, parameters.Filters, (reader) =>
			{
				var allElements = hierarchy.GetAllElements();
				while (true)
				{
					charactersCount += GetCharactersCountFromTable(reader, allElements, lookup);
					if (!reader.NextResult())
					{
						break;
					}
				}
			});

			return charactersCount;
		}


		private ulong GetCharactersCountFromTable(SqlDataReader reader, List<HierarchyElement> allElements, ILookupProvider lookup)
		{
			ulong result = 0;
			DataTable schemaTable = reader.GetSchemaTable();
			string elementName = ((string)schemaTable.Rows[0]["BaseTableName"]).Substring(4);
			var element = allElements.Single(elm => elm.Element.ElementName.Equals(elementName, StringComparison.InvariantCultureIgnoreCase));

			// count separators = count of columns - 1
			ulong countOfColumns = (ulong)(reader.FieldCount - (element.Element.StartColumnIndex));
			countOfColumns += (ulong)element.Element.ConstantValues.Count;

			ulong countOfSeparators = countOfColumns - 1;

			// count bytes in constant fields
			ulong charactersInConstantFields = 0;
			foreach (var constant in element.Element.ConstantValues.Values)
			{
				charactersInConstantFields += (ulong)Encoding.UTF8.GetByteCount(constant);
			}

			// get column names
			List<string> columnNames = new List<string>();
			for (int i = 0; i < reader.FieldCount; i++)
			{
				columnNames.Add(reader.GetName(i));
			}

			// count bytes in columns to export
			ulong charactersInRows = 0;
			ulong rowsCount = 0;
			while (reader.Read())
			{
				for (int i = element.Element.StartColumnIndex; i < reader.FieldCount; i++)
				{
					string value = reader.GetValue(i).ToString();

					if (element.Element.LookupColumns.ContainsKey(columnNames[i]))
					{
						value = lookup.Lookup(element.Element.LookupColumns[columnNames[i]], value);
					}
					charactersInRows += (ulong)Encoding.UTF8.GetByteCount(value);
				}
				rowsCount++;
			}

			// calculate final bytes count
			result = charactersInRows;
			result += charactersInConstantFields * rowsCount;
			result += (ulong)Encoding.UTF8.GetByteCount(new char[] { Constants.SEPARATOR }) * countOfSeparators * rowsCount;
			result += ((ulong)Encoding.UTF8.GetByteCount(Environment.NewLine) * rowsCount);

			return result;
		}



	}
}
