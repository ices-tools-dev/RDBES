﻿using Db2Csv.Common;
using Db2Csv.DataReader;
using Db2Csv.Hierarchies;
using System.Collections.Generic;

namespace Db2Csv.Processor
{
	public class FilterDataExtractor : IFilterDataExtractor
	{
		public List<KeyValuePair<int, string>> ExtractFilterData(FilterDataExtractorParameters parameters)
		{
			string tempFolderPath = Utils.CreateTempDir();
			HierarchyBase hierarchy = Utils.GetHierarchy(parameters.HierarchyName);

			var sqlHelper = new SqlHelper(parameters.ConnectionString);
			return sqlHelper.ExtractFilterData(hierarchy, parameters.Filters, parameters.FilterDataType, parameters.SortAscending);
		}

	}
}
