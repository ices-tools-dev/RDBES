﻿namespace Db2Csv.Common
{
    internal class Enums
    {
        public enum HierarchyLevel1
        {
            H1 = 1,
            H2,
            H3,
            H4,
            H5,
            H6,
            H7,
            H8,
            H9,
            H10,
            H11,
            H12,
            H13
        }

        public enum HierarchyLevel2
        {
            A = 1,
            B,
            C,
            D
        }

        //public enum UtilityCodeType
        //{
        //    RS_Year,
        //    RS_HierarchyCorrect,
        //    RS_Hierarchy,
        //    RS_TimeUnit,
        //    RS_SelectionMethod,
        //    RS_Stratification,
        //    RS_Clustering,
        //    RS_ReasonForNotSampling,
        //    RS_Sampler,
        //    RS_SelectionMethodCluster,
        //    RS_SamplingInstitution,
        //    RS_Harbour,
        //    RS_VesselLengthCategory,
        //    RS_VesselSizeUnit,
        //    RS_VesselType,
        //    RS_AggregationLevel,
        //    RS_FishingValidity,
        //    RS_StatisticalRectangle,
        //    RS_Subpolygon,
        //    RS_FunctionalUnit,
        //    RS_FishingActivityCategoryNational,
        //    RS_FishingActivityCategoryEuropeanLvl5,
        //    RS_FishingActivityCategoryEuropeanLvl6,
        //    RS_GearType,
        //    RS_SelectionDevice,
        //    RS_AssemblageSpecies,
        //    RS_LocationType,
        //    RS_MixedTrip,
        //    RS_CatchRegistration,
        //    RS_LandingLocationType,
        //    RS_EconomicalZone,
        //    RS_Area,
        //    RS_CatchCategory,
        //    RS_SpeciesCode,
        //    RS_FAOAsfisSpeciesCodes,
        //    RS_Presentation,
        //    RS_LandingCategory,
        //    RS_CommercialSizeCategoryScale,
        //    RS_CommercialSizeCategory,
        //    RS_Sex,
        //    RS_UnitType,
        //    RS_LowerHierarchy,
        //    RS_MeasurementType,
        //    RS_AccuracyCode,
        //    RS_BiologicalMeasurementType,
        //    RS_UnitOfValue,
        //    RS_UnitScaleList,
        //    RS_MethodForMeasurement,
        //    RS_LEfullTripAvailable,
        //    RS_BVMeasurementEquipment,
        //    RS_CatchFraction,
        //    RS_Country,
        //    RS_Region
        //}


    }
}
