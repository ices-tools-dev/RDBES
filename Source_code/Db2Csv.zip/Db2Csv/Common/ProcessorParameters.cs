﻿
namespace Db2Csv.Common
{
    public class ProcessorParameters : ParametersBase
    {
        public string OutputDirectoryPath { get; set; }

    }
}
