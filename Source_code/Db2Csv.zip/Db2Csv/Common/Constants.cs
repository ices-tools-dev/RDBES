﻿using System.Globalization;

namespace Db2Csv.Common
{
    internal static class Constants
    {
        public static readonly char SEPARATOR;
        static Constants()
        {
            SEPARATOR = ',';
            SetupDecimalSeparator();
        }

        private static void SetupDecimalSeparator()
        {
            var ci = new CultureInfo(CultureInfo.CurrentCulture.Name);
            ci.NumberFormat.NumberDecimalSeparator = ".";
            ci.NumberFormat.CurrencyDecimalSeparator = ".";
            CultureInfo.DefaultThreadCurrentCulture = ci;
        }
    }
}
