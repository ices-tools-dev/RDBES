﻿using Db2Csv.Common.Filters;
using System.Collections.Generic;

namespace Db2Csv.Common
{
    public class ParametersBase
    {
        public string ConnectionString { get; set; }

        public string HierarchyName { get; set; }

        public List<IFilter> Filters = new List<IFilter>();

    }
}
