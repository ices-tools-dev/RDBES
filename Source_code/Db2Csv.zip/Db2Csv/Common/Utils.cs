﻿using Db2Csv.Hierarchies;
using System;
using System.Reflection;

namespace Db2Csv.Common
{
    internal static class Utils
    {
        public static string CreateTempDir()
        {
            string tempDir = string.Concat(System.IO.Path.GetTempPath(), Guid.NewGuid().ToString());
            System.IO.Directory.CreateDirectory(tempDir);
            return tempDir;
        }

        public static HierarchyBase GetHierarchy(string className)
        {
            Assembly assembly = typeof(HierarchyBase).Assembly;
            Type type = assembly.GetType(string.Concat("Db2Csv.Hierarchies.", className));
            if (type == null)
            {
                throw new Exception($"Failed to find class 'Db2Csv.Hierarchies.{className}'");
            }
            if (!typeof(HierarchyBase).IsAssignableFrom(type))
            {
                throw new Exception($"'Db2Csv.Hierarchies.{className}' is not inheriting from Db2Csv.Hierarchies.HiearchyBase");
            }
            return (HierarchyBase)Activator.CreateInstance(type);
        }
    }
}
