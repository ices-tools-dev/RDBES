﻿
namespace Db2Csv.Common.Filters
{
    public interface IFilter
    {
        FilterType FilterType { get;}
        int ValuesCount { get; }
        string GetValues();

    }
}
