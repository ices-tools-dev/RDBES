﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Db2Csv.Common.Filters
{
	public class Filter<T> : IFilter
	{
		private const string DATE_FORMAT = "yyyy-MM-dd";
		public Filter(FilterType ofType)
		{
			this.FilterType = ofType;
			ValidateFilterType();
		}
		public FilterType FilterType { get; protected set; }

		public int ValuesCount => Values.Count;

		public List<T> Values = new List<T>();

		public string GetValues()
		{
			switch (typeof(T).Name)
			{
				case nameof(String):
					return string.Join(',', Values.Select(item => string.Concat("'", (item as string).Replace("'", "''"), "'")));
				case nameof(DateTime):
					return string.Join(',', (Values as List<DateTime>).Select(item => string.Concat("'", item.ToString(DATE_FORMAT), "'")));
				case nameof(Int64):
					return string.Join(',', Values);
				default:
					throw new NotSupportedException($"Not supported type: '{typeof(T).Name}'");
			}
		}

		protected void ValidateFilterType()
		{
			var memberInfo = FilterType.GetType().GetMember(FilterType.ToString())[0];
			var typeAttribute = memberInfo.GetCustomAttributes(typeof(FilterTypeAttribute), false).FirstOrDefault();
			if (typeAttribute != null)
			{
				if (((FilterTypeAttribute)typeAttribute).ContentType != typeof(T))
				{
					throw new NotSupportedException($"Not supported type is provided as generic argument for filter of type: {FilterType}. Expected: '{((FilterTypeAttribute)typeAttribute).ContentType.Name}'  Received argument:'{typeof(T).Name}'");
				}
			}
			else if (typeof(T) != typeof(long))
			{
				throw new NotSupportedException($"Not supported type is provided as generic argument for filter of type: {FilterType}. Expected: '{typeof(long).Name}'  Received argument:'{typeof(T).Name}'");
			}
		}

	}
}
