﻿using System;

namespace Db2Csv.Common.Filters
{
    [AttributeUsage(AttributeTargets.Field)]

    public class FilterTypeAttribute : Attribute
    {
        public Type ContentType { get; private set; }

        public FilterTypeAttribute(Type type)
        {
            ContentType = type;
        }
    }
}
