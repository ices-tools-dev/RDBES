﻿
namespace Db2Csv.Common
{
    public class FilterDataExtractorParameters : ParametersBase
    {
        public FilterDataType FilterDataType { get; set; }
        public bool SortAscending { get; set; } = true;
    }
}
