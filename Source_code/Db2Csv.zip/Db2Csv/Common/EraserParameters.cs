﻿using System.Collections.Generic;

namespace Db2Csv.Common
{
    public class EraserParameters : ParametersBase
    {
        public List<(string ElementName, bool ChildrenOnly)> ElementsToDelete { get; set; }
    }
}
