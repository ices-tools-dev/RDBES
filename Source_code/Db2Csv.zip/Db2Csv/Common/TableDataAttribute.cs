﻿using System;

namespace Db2Csv.Common
{
    [AttributeUsage(AttributeTargets.Field)]

    public class TableDataAttribute : Attribute
    {
        public string TableName { get; private set; }

        public TableDataAttribute(string tableName)
        {
            TableName = tableName;
        }
    }
}
