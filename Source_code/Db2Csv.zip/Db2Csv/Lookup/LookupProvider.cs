﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Db2Csv.Common;
using ResCommon;
using static Db2Csv.Common.Enums;

namespace Db2Csv.Lookup
{
    internal class LookupProvider : ILookupProvider
    {
        private Dictionary<Utility.CodeType, Dictionary<string, string>> lookups = new Dictionary<Utility.CodeType, Dictionary<string, string>>();
        public bool ReturnEmptyForMissingLookupValue { get; private set; }

        public LookupProvider(string connectionString, bool returnEmptyIfNotFound = true)
        {
            this.ReturnEmptyForMissingLookupValue = returnEmptyIfNotFound;
            Load(connectionString);
        }
        protected void Load(string connectionString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql =
                @"
                SELECT 
                replace(TblCodeType.CodeType,'-','_'), 
                TblCode.TblCodeID,
                TblCode.Code
                FROM TblCode
                INNER JOIN TblCodeType
                ON TblCode.TblCodeTypeID=TblCodeType.TblCodeTypeID
";
                connection.Open();
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.CommandType = CommandType.Text;
                    using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.KeyInfo))
                    {
                        while (reader.Read())
                        {
                            ReadRow(reader);
                        }
                    }

                };

            }
        }

        private void ReadRow(SqlDataReader reader)
        {
            try
            {

                //Utility.CodeType codeType = Enum.Parse<Utility.CodeType>(reader.GetString(0));
                Utility.CodeType codeType;
                bool codeTypeRepresentData = Enum.TryParse<Utility.CodeType>(reader.GetString(0), out codeType);
                if (codeTypeRepresentData)
                {
                    string id = reader.GetValue(1).ToString();
                    string code = reader.GetString(2);
                    if (!lookups.ContainsKey(codeType))
                    {
                        lookups.Add(codeType, new Dictionary<string, string>());
                    }
                    lookups[codeType].Add(id, code);

                }
            }
            catch (Exception excp)
            {
                throw new Exception($"An exception occurred while processing lookup row. CodeType:'{reader.GetValue(0)}', TblCodeID:{reader.GetValue(1)}, Code:{reader.GetValue(2)}", excp);
            }
        }

        public string Lookup(Utility.CodeType codeType, string value)
        {
            Dictionary<string, string> lookupGroup;
            if (!lookups.TryGetValue(codeType, out lookupGroup))
            {
                throw new ArgumentException($"Failed to find lookup group for code type:'{codeType}'");
            }
            string result;
            if (!lookupGroup.TryGetValue(value, out result))
            {
                if (ReturnEmptyForMissingLookupValue)
                {
                    result = string.Empty;
                }
                else
                {
                    throw new ArgumentException($"Failed to find lookup value for value:'{value}' with code type:'{codeType}'");
                }
            }
            return result;
        }
    }
}
