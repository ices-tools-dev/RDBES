﻿using ResCommon;
using System;
using System.Collections.Generic;
using System.Text;
using static Db2Csv.Common.Enums;

namespace Db2Csv.Lookup
{
    internal interface ILookupProvider
    {
        string Lookup(Utility.CodeType codeType, string value);

    }
}
