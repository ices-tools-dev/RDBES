﻿using Db2Csv.Common;
using Db2Csv.Common.Filters;
using ResCommon;
using System.Collections.Generic;
using static Db2Csv.Common.Enums;

namespace Db2Csv.ElementDefinitions
{
	internal class SA : ElementBase
	{
		public SA() : base("Sample", 8)
		{
			this.ParentIdColumnName = "SAparentID";
		}
		protected override void Init()
		{
			AddFilterFunctions(FilterType.SAspeciesCode);

			this.LookupColumns.Add("SAstratification", Utility.CodeType.YesNoFields);
			this.LookupColumns.Add("SAspeciesCode", Utility.CodeType.SpecWoRMS);
			this.LookupColumns.Add("SAcommercialSpecies", Utility.CodeType.SpecASFIS);
			this.LookupColumns.Add("SAspeciesCodeFAO", Utility.CodeType.SpecASFIS);
			this.LookupColumns.Add("SAstateOfProcessing", Utility.CodeType.StateOfProcessing);
			this.LookupColumns.Add("SApresentation", Utility.CodeType.Presentation);
			this.LookupColumns.Add("SAcatchCategory", Utility.CodeType.RS_CatchCategory);
			this.LookupColumns.Add("SAlandingCategory", Utility.CodeType.RS_LandingCategory);




			this.LookupColumns.Add("SAcommSizeCatScale", Utility.CodeType.CommercialSizeCategoryScale);
			// this.LookupColumns.Add("VDlength", Utility.CodeType.R);

			this.LookupColumns.Add("SAcommSizeCat", Utility.CodeType.RS_CommercialSizeCategory);

			this.LookupColumns.Add("SAsex", Utility.CodeType.RS_Sex);

			this.LookupColumns.Add("SAexclusiveEconomicZoneIndicator", Utility.CodeType.RS_EEZI);

			this.LookupColumns.Add("SAarea", Utility.CodeType.ICES_Area);
			this.LookupColumns.Add("SArectangle", Utility.CodeType.StatRec);


			this.LookupColumns.Add("SAgsaSubarea", Utility.CodeType.Areas_GFCM_GSA);
			this.LookupColumns.Add("SAjurisdictionArea", Utility.CodeType.RS_JurisdictionArea);
			this.LookupColumns.Add("SAnationalFishingActivity", Utility.CodeType.ICES_Area);

			this.LookupColumns.Add("SAmetier5", Utility.CodeType.Metier5_FishingActivity);
			this.LookupColumns.Add("SAmetier6", Utility.CodeType.Metier6_FishingActivity);
			this.LookupColumns.Add("SAgear", Utility.CodeType.GearType);
			this.LookupColumns.Add("SAselectionDevice", Utility.CodeType.SelectionDevice);
			//   this.LookupColumns.Add("SAunitType", Utility.CodeType.SamplingUnit);

			this.LookupColumns.Add("SAunitType", Utility.CodeType.SamplingUnit);
			this.LookupColumns.Add("SAselectionMethod", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("SAlowerHierarchy", Utility.CodeType.RS_LowerHierarchy);
			// this.LookupColumns.Add("VDlength", Utility.CodeType.R);
			this.LookupColumns.Add("SAsampler", Utility.CodeType.Sampler);
			this.LookupColumns.Add("SAsampled", Utility.CodeType.YesNoFields);






			this.LookupColumns.Add("SAreasonNotSampledFM", Utility.CodeType.ReasonForNotSampling);
			this.LookupColumns.Add("SAreasonNotSampledBV", Utility.CodeType.ReasonForNotSampling);


		}

		public override string GetLoadTempTableSql(List<IFilter> filters, string additionalConditions = null, FilterDataType? filterDataType = null)
		{
			if (ParentElement is SS)
			{
				this.ParentIdColumnName = ParentElement.IdColumnName;
			}
			string hierarchyCondition = null;
			if (HierarchyLevel != 0)
			{
				hierarchyCondition = GetLookupFilter("SAlowerHierarchy", Utility.CodeType.RS_LowerHierarchy, HierarchyLevel.ToString());
			}
			return base.GetLoadTempTableSql(filters, hierarchyCondition, filterDataType);
		}

		public SA SetHierarchyLevel(HierarchyLevel2 hierarchyLevel)
		{
			this.HierarchyLevel = hierarchyLevel;
			return this;
		}

		public HierarchyLevel2 HierarchyLevel { get; private set; }



	}
}
