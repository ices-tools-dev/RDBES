﻿using Db2Csv.Common.Filters;
using ResCommon;

namespace Db2Csv.ElementDefinitions
{
    internal class CE : ElementBase
    {
        public CE() : base("CommercialEffort", 7) { }
        protected override void Init()
        {
            AddFilterFunctions(
                FilterType.CEyear,
                FilterType.CEarea,
                FilterType.CEvesselFlagCountry,
                FilterType.CEdataTypeForScientificEffort,
                FilterType.CEdataSourceForScientificEffort,
                FilterType.CEsamplingScheme,
                FilterType.CEquarter,
                FilterType.CEmonth,
                FilterType.CEstatisticalRectangle,
                FilterType.CEgsaSubarea,
                FilterType.CEjurisdictionArea,
                FilterType.CEexclusiveEconomicZoneIndicator,
                FilterType.CEnationalFishingActivity,
                FilterType.CEmetier6,
                FilterType.CEincidentalByCatchMitigationDevice,
                FilterType.CElandingLocation,
                FilterType.CEvesselLengthCategory,
                FilterType.CEfishingTechnique,
                FilterType.CEdeepSeaRegulation);



            this.LookupColumns.Add("CEdataTypeForScientificEffort", Utility.CodeType.RS_DataTypeOfScientificWE);
            this.LookupColumns.Add("CEdataSourceForScientificEffort", Utility.CodeType.RS_DataSourceOfScientificWE);
            this.LookupColumns.Add("CEsamplingScheme", Utility.CodeType.RS_SamplingScheme);
            this.LookupColumns.Add("CEvesselFlagCountry", Utility.CodeType.ISO_3166);
            this.LookupColumns.Add("CEyear", Utility.CodeType.Year);
            this.LookupColumns.Add("CEquarter", Utility.CodeType.Quarter);
            this.LookupColumns.Add("CEmonth", Utility.CodeType.Month);
            this.LookupColumns.Add("CEarea", Utility.CodeType.ICES_Area);
            this.LookupColumns.Add("CEstatisticalRectangle", Utility.CodeType.StatRec);
            this.LookupColumns.Add("CEgsaSubarea", Utility.CodeType.Areas_GFCM_GSA);
            this.LookupColumns.Add("CEjurisdictionArea", Utility.CodeType.RS_JurisdictionArea);
            this.LookupColumns.Add("CEexclusiveEconomicZoneIndicator", Utility.CodeType.RS_EEZI);
            //this.LookupColumns.Add("CEexclusiveEconomicZone", Utility.CodeType.RS_EEZ);
            this.LookupColumns.Add("CEnationalFishingActivity", Utility.CodeType.RS_NationalFishingActivity);
            this.LookupColumns.Add("CEmetier6", Utility.CodeType.Metier6_FishingActivity);
            this.LookupColumns.Add("CEincidentialByCatchMitigationDevice", Utility.CodeType.BycatchMitigationDevice);
            this.LookupColumns.Add("CElandingLocation", Utility.CodeType.Harbour_LOCODE);
            this.LookupColumns.Add("CEvesselLengthCategory", Utility.CodeType.RS_VesselLengthCategory);
            this.LookupColumns.Add("CEfishingTechnique", Utility.CodeType.RS_FishingTechnique);
            this.LookupColumns.Add("CEdeepSeaRegulation", Utility.CodeType.YesNoFields);
            this.LookupColumns.Add("CEqualitativeBias", Utility.CodeType.RS_QualitativeBias);  
             

        }
    }
}
