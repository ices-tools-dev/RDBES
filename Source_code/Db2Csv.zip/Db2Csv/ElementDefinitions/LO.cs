﻿using ResCommon;

namespace Db2Csv.ElementDefinitions
{
	internal class LO : ElementBase
	{
		public LO() : base("Location", 6) { }

		protected override void Init()
		{
			this.LookupColumns.Add("LOstratification", Utility.CodeType.YesNoFields);
			this.LookupColumns.Add("LOlocode", Utility.CodeType.Harbour_LOCODE);
			this.LookupColumns.Add("LOclustering", Utility.CodeType.RS_Clustering);
			// this.LookupColumns.Add("VDlength", LookupCodeType.R);
			this.LookupColumns.Add("LOsampler", Utility.CodeType.Sampler);
			// this.LookupColumns.Add("VDpower", LookupCodeType.rs_);
			//    this.LookupColumns.Add("FTarrivalLocation", LookupCodeType.RS_Harbour);
			this.LookupColumns.Add("LOselectionMethod", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("LOselectionMethodCluster", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("LOreasonNotSampled", Utility.CodeType.ReasonForNotSampling);
			this.LookupColumns.Add("LOlocationType", Utility.CodeType.RS_LocationType);
			this.LookupColumns.Add("LOsampled", Utility.CodeType.YesNoFields);
		}

	}
}
