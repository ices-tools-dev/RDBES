﻿using ResCommon;

namespace Db2Csv.ElementDefinitions
{
	internal class TE : ElementBase
	{
		public TE() : base("TemporalEvent", 8) { }

		protected override void Init()
		{
			this.LookupColumns.Add("TEstratification", Utility.CodeType.YesNoFields);
			this.LookupColumns.Add("TEtimeUnit", Utility.CodeType.TimeUnit);
			this.LookupColumns.Add("TEclustering", Utility.CodeType.RS_Clustering);
			this.LookupColumns.Add("TEsampler", Utility.CodeType.Sampler);
			this.LookupColumns.Add("TEselectionMethod", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("TEselectionMethodCluster", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("TEreasonNotSampled", Utility.CodeType.ReasonForNotSampling);
		}
	}
}
