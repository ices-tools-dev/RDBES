﻿using Db2Csv.Common.Filters;
using ResCommon;
//using static Db2Csv.Common.Enums;

namespace Db2Csv.ElementDefinitions
{
    internal class LE : ElementBase
    {
        public LE() : base("LandingEvent", 13) { }

        protected override void Init()
        {
            AddFilterFunctions(FilterType.LEencryptedVesselCode, FilterType.LEsequenceNumber, FilterType.LEhaulNumber, FilterType.LEmixedTrip, FilterType.LEcatchReg, 
                FilterType.LElocation, FilterType.LEcountry, FilterType.LEarea, FilterType.LErectangle, FilterType.LEgsaSubarea, FilterType.LEjurisdictionArea);

          
            this.LookupColumns.Add("LEstratification", Utility.CodeType.YesNoFields);
            this.LookupColumns.Add("LEclustering", Utility.CodeType.RS_Clustering);
            this.LookupColumns.Add("LEsampler", Utility.CodeType.Sampler);
            // this.LookupColumns.Add("VDlength", Utility.CodeType.R);
            this.LookupColumns.Add("LEmixedTrip", Utility.CodeType.YesNoFields );
            // this.LookupColumns.Add("VDpower", Utility.CodeType.rs_);
            //    this.LookupColumns.Add("FTarrivalLocation", Utility.CodeType.RS_Harbour);
            this.LookupColumns.Add("LEcatchReg", Utility.CodeType.RS_CatchRegistration );

           this.LookupColumns.Add("LElocation", Utility.CodeType.Harbour_LOCODE );
            this.LookupColumns.Add("LElocationType", Utility.CodeType.RS_LocationType );
            // this.LookupColumns.Add("VDlength", Utility.CodeType.R);

            this.LookupColumns.Add("LEcountry", Utility.CodeType.ISO_3166);
            this.LookupColumns.Add("LEexclusiveEconomicZoneIndicator", Utility.CodeType.RS_EEZI );
            this.LookupColumns.Add("LEarea", Utility.CodeType.ICES_Area );
            // this.LookupColumns.Add("VDlength", Utility.CodeType.R);
            this.LookupColumns.Add("LErectangle", Utility.CodeType.StatRec );
            // this.LookupColumns.Add("VDpower", Utility.CodeType.rs_);
            //    this.LookupColumns.Add("FTarrivalLocation", Utility.CodeType.RS_Harbour);
            this.LookupColumns.Add("LEgsaSubarea", Utility.CodeType.Areas_GFCM_GSA);
            this.LookupColumns.Add("LEjurisdictionArea", Utility.CodeType.RS_JurisdictionArea);
             this.LookupColumns.Add("LEnationalFishingActivity", Utility.CodeType.RS_NationalFishingActivity);

            
            this.LookupColumns.Add("LEmetier5", Utility.CodeType.Metier5_FishingActivity );
             this.LookupColumns.Add("LEmetier6", Utility.CodeType.Metier6_FishingActivity);
            // this.LookupColumns.Add("VDlength", Utility.CodeType.R);

            //  this.LookupColumns.Add("LEmetier5", Utility.CodeType.Metier5);
            // this.LookupColumns.Add("LEmetier6", Utility.CodeType.Metier6);
            this.LookupColumns.Add("LEgear", Utility.CodeType.GearType );
            // this.LookupColumns.Add("VDlength", Utility.CodeType.R);
            this.LookupColumns.Add("LEselectionDevice", Utility.CodeType.SelectionDevice);
            this.LookupColumns.Add("LEtargetSpecies", Utility.CodeType.TargetSpecies);
            this.LookupColumns.Add("LEmitigationDevice", Utility.CodeType.BycatchMitigationDevice);
            //    this.LookupColumns.Add("FTarrivalLocation", Utility.CodeType.RS_Harbour);
            this.LookupColumns.Add("LEselectionMethod", Utility.CodeType.SelectionMethod);

            this.LookupColumns.Add("LEselectionMethodCluster", Utility.CodeType.SelectionMethod);
            this.LookupColumns.Add("LEreasonNotSampled", Utility.CodeType.ReasonForNotSampling);
            this.LookupColumns.Add("LEfullTripAvailable", Utility.CodeType.RS_LEfullTripAvailable);
            // this.LookupColumns.Add("VDlength", Utility.CodeType.R);
        }



    }
}
