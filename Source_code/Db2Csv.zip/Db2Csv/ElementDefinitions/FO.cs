﻿using Db2Csv.Common;
using Db2Csv.Common.Filters;
using ResCommon;
using System.Collections.Generic;

namespace Db2Csv.ElementDefinitions
{
	internal class FO : ElementBase
	{
		public FO() : base("FishingOperation", 7) { }

		protected override void Init()
		{
			AddFilterFunctions(FilterType.FOarea);


			this.LookupColumns.Add("FOstratification", Utility.CodeType.YesNoFields);
			this.LookupColumns.Add("FOclustering", Utility.CodeType.RS_Clustering);
			this.LookupColumns.Add("FOsampler", Utility.CodeType.Sampler);
			this.LookupColumns.Add("FOaggregationLevel", Utility.CodeType.RS_AggregationLevel);
			this.LookupColumns.Add("FOvalidity", Utility.CodeType.RS_FishingValidity);
			this.LookupColumns.Add("FOcatchReg", Utility.CodeType.RS_CatchRegistration);

			this.LookupColumns.Add("FOexclusiveEconomicZoneIndicator", Utility.CodeType.RS_EEZI);


			this.LookupColumns.Add("FOarea", Utility.CodeType.ICES_Area);
			this.LookupColumns.Add("FOrectangle", Utility.CodeType.StatRec);
			this.LookupColumns.Add("FOgsaSubarea", Utility.CodeType.Areas_GFCM_GSA);
			this.LookupColumns.Add("FOjurisdictionArea", Utility.CodeType.RS_JurisdictionArea);
			this.LookupColumns.Add("FOnationalFishingActivity", Utility.CodeType.RS_NationalFishingActivity);
			this.LookupColumns.Add("FOmetier5", Utility.CodeType.Metier5_FishingActivity);
			this.LookupColumns.Add("FOmetier6", Utility.CodeType.Metier6_FishingActivity);
			this.LookupColumns.Add("FOgear", Utility.CodeType.GearType);
			this.LookupColumns.Add("FOselectionDevice", Utility.CodeType.SelectionDevice);
			this.LookupColumns.Add("FOtargetSpecies", Utility.CodeType.TargetSpecies);
			this.LookupColumns.Add("FOincidentalByCatchMitigationDeviceFirst", Utility.CodeType.BycatchMitigationDevice);
			this.LookupColumns.Add("FOincidentalByCatchMitigationDeviceTargetFirst", Utility.CodeType.BycatchMitigationDeviceTarget);
			this.LookupColumns.Add("FOincidentalByCatchMitigationDeviceSecond", Utility.CodeType.BycatchMitigationDevice);
			this.LookupColumns.Add("FOincidentalByCatchMitigationDeviceTargetSecond", Utility.CodeType.BycatchMitigationDeviceTarget);
			this.LookupColumns.Add("FOobservationCode", Utility.CodeType.ObservationCode);
			this.LookupColumns.Add("FOselectionMethodCluster", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("FOreasonNotSampled", Utility.CodeType.ReasonForNotSampling);
			this.LookupColumns.Add("FOselectionMethod", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("FOsampled", Utility.CodeType.YesNoFields);
		}


		public override string GetLoadTempTableSql(List<IFilter> filters, string additionalConditions = null, FilterDataType? filterDataType = null)
		{
			switch (ParentElement.GetType().Name)
			{
				case nameof(LE):
					return this.GetLoadTempTableSqlForDifferentIdColumnName("FTid", filters, additionalConditions, filterDataType);
				default:
					return base.GetLoadTempTableSql(filters, additionalConditions, filterDataType);
			}
		}

	}
}
