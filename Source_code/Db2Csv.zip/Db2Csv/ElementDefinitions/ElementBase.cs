﻿using Db2Csv.Common.Filters;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
//using static Db2Csv.Common.Enums;
using ResCommon;
using Db2Csv.Common;
using System.Reflection;

namespace Db2Csv.ElementDefinitions
{
	internal abstract class ElementBase
	{
		public string ElementName { get; protected set; }

		public string TableName { get; protected set; }

		public string CombinedElementName
		{
			get
			{
				return $"{ParentElement?.ElementName}{ElementName}";
			}
		}

		public string TempTable
		{
			get
			{
				return $"#tmp{CombinedElementName}";
			}
		}

		public string IdColumnName { get; protected set; }

		public int StartColumnIndex { get; private set; }

		protected Dictionary<FilterType, Func<IFilter, string>> FilterWhereFunctions = new Dictionary<FilterType, Func<IFilter, string>>();

		protected void AddFilterFunction(FilterType filterType)
		{
			this.FilterWhereFunctions.Add(filterType, (IFilter filter) => FilterFunction(filterType.ToString(), filter));
		}

		protected void AddFilterFunction(string fieldName, FilterType filterType)
		{
			this.FilterWhereFunctions.Add(filterType, (IFilter filter) => FilterFunction(fieldName, filter));
		}

		protected void AddFilterFunctions(params FilterType[] filterTypes)
		{
			foreach (var filterType in filterTypes)
			{
				AddFilterFunction(filterType);
			}
		}
		public Dictionary<string, Utility.CodeType> LookupColumns = new Dictionary<string, Utility.CodeType>();

		/// <summary>
		/// List of constant values to be placed in the CSV output, indexed by their position, zero based
		/// </summary>
		public Dictionary<int, string> ConstantValues = new Dictionary<int, string>();

		protected virtual string Columns { get { return "*"; } }

		public string ParentIdColumnName { get; set; } = null;

		public ElementBase ParentElement { get; set; }

		public virtual ElementBase LinkToParentElement
		{
			get { return null; }
			set { throw new NotSupportedException($"Element:'{this.GetType().Name}' doesn't support LinkToParentElement"); }
		}

		protected ElementBase(string tableName, int startColumnIndex)
		{
			this.ElementName = this.GetType().Name;
			this.StartColumnIndex = startColumnIndex;
			this.TableName = tableName;
			//this.TempTable = string.Concat("#tmp", ElementName);
			this.IdColumnName = string.Concat(ElementName, "id");
			this.Init();
		}

		public virtual string GetLoadTempTableSql(List<IFilter> filters, string additionalConditions = null, FilterDataType? filterDataType = null)
		{
			string result;
			if (ParentElement == null)
			{
				result = $@"
SELECT 
ROW_NUMBER() OVER (Order BY {IdColumnName}) as RowNumber,
0 AS ParentRowNumber,
{IdColumnName} AS ID, 0 AS ParentID,
{GetColumns(filters, filterDataType)}
INTO {TempTable} FROM {TableName} {GetWhereClause(filters, additionalConditions)};
";
			}
			else
			{
				result =
$@"
SELECT 
ROW_NUMBER() OVER (Order BY ParentRowNumber, ID) as RowNumber,
{GetColumns(filters, filterDataType)}
INTO {TempTable}  
FROM
(
	SELECT 
	{ParentElement.TempTable}.RowNumber as ParentRowNumber,
	{TableName}.{IdColumnName} AS ID, 
	{TableName}.{ParentIdColumnName ?? ParentElement.IdColumnName} AS ParentID,
	{ColumnsWithPrefix(filters, filterDataType)}
	FROM {TableName} 
	INNER JOIN {ParentElement.TempTable}
	ON {TableName}.{ParentIdColumnName ?? ParentElement.IdColumnName}={ParentElement.TempTable}.ID
) as t
{GetWhereClause(filters, additionalConditions)};
";
			}
			return result;
		}

		protected string GetLoadTempTableSqlForDifferentIdColumnName(string customIdColumnName, List<IFilter> filters, string additionalConditions = null, FilterDataType? filterDataType = null)
		{
			string result;

			result = $@"
SELECT 
ROW_NUMBER() OVER (Order BY ParentRowNumber, ID) as RowNumber,
{Columns}
INTO {TempTable}
FROM 
(
	SELECT 
	{ParentElement.TempTable}.RowNumber as ParentRowNumber,
	{TableName}.{IdColumnName} as ID,
	{ParentElement.TempTable}.{ParentElement.IdColumnName} as ParentID 
	{ColumnsWithPrefix(filters, filterDataType)}
	FROM {TableName} 
	INNER JOIN {ParentElement.TempTable}
	ON {TableName}.{customIdColumnName} = {ParentElement.TempTable}.{customIdColumnName}
) as t
{this.GetWhereClause(filters, additionalConditions)};
";
			return result;
		}

		/// <summary>
		/// Just SELECT * from temporary table
		/// </summary>
		/// <returns></returns>
		public virtual string GetSelectSql(FilterDataType? filterDataType = null)
		{
			if (filterDataType.HasValue)
			{
				if (ExtractTableName(filterDataType.Value).Equals(TableName, StringComparison.OrdinalIgnoreCase))
				{
					return
	$@" 
SELECT 
tblCodeId AS Id, Code as [Value] 
FROM tblCode WHERE tblCodeId IN
(
	SELECT {filterDataType.Value} FROM {TempTable}
);
";
				}
				return string.Empty;
			}

			return $"\nSELECT * FROM {TempTable} AS {this.GetType().Name} {(ParentElement != null ? "ORDER BY ParentRowNumber, RowNumber" : "")};";
		}

		public string GetDeleteSql(bool dryRun)
		{
			if (dryRun)
			{
				return $@"
SELECT {IdColumnName} 
INTO [#tmp{Guid.NewGuid()}]
FROM {TableName} WHERE {IdColumnName} IN (SELECT ID FROM {TempTable});
SELECT '{this.GetType().Name}' as Name, @@ROWCOUNT AS Count;";
			}
			return $@"
DELETE FROM {TableName} WHERE {IdColumnName} IN (SELECT ID FROM {TempTable});
SELECT '{this.GetType().Name}' as Name, @@ROWCOUNT AS Count;";
		}

		public virtual string GetWhereClause(List<IFilter> filters, string additionalConditions = null)
		{
			StringBuilder sbResult = new StringBuilder();

			if (ParentElement != null)
			{
				sbResult.AppendFormat($"ParentID IN(SELECT ID FROM {ParentElement.TempTable})");
			}
			if (!string.IsNullOrEmpty(additionalConditions))
			{
				if (sbResult.Length > 0)
				{
					sbResult.Append(" AND ");
				}
				sbResult.AppendLine(additionalConditions);
			}
			RunWhereForFilters(sbResult, filters);
			if (sbResult.Length > 0)
			{
				return string.Concat("WHERE ", sbResult);
			}
			return string.Empty;
		}

		internal void RunWhereForFilters(StringBuilder sbResult, List<IFilter> filters)
		{
			foreach (var filter in filters)
			{
				Func<IFilter, string> filterFunc;
				if (FilterWhereFunctions.TryGetValue(filter.FilterType, out filterFunc))
				{
					var where = filterFunc(filter);
					if (where.Length > 0)
					{
						if (sbResult.Length > 0)
						{
							sbResult.Append(" AND ");
						}
						sbResult.Append(where);
					}
				}
			}
		}

		protected string FilterFunction(string fieldName, IFilter filter)
		{
			if (filter.ValuesCount > 0)
			{
				return $"{fieldName} IN ({filter.GetValues()})\n";
			}
			return string.Empty;
		}

		protected virtual string GetColumns(List<IFilter> filters, FilterDataType? filterDataType)
		{
			if (filterDataType.HasValue)
			{
				StringBuilder sbResult = new StringBuilder();
				sbResult.Append("ID");
				foreach (var filter in filters)
				{
					if (TableName.Equals(ExtractTableName(filter)))
					{
						sbResult.Append($",{filter.FilterType}");
					}
				}
			}
			return Columns;
		}

		protected string ExtractTableName<T>(T value)
		{
			MemberInfo memberInfo = null;
			if (typeof(T).IsAssignableFrom(typeof(IFilter)))
			{
				memberInfo = (typeof(FilterType)).GetMember(((IFilter)value).FilterType.ToString())[0];
			}
			else
			{
				memberInfo = (typeof(FilterType)).GetMember(value.ToString())[0];
			}
			var tableNameAttribute = memberInfo.GetCustomAttributes(typeof(TableDataAttribute), false).FirstOrDefault() as TableDataAttribute;
			if (tableNameAttribute == null)
			{
				throw new NotSupportedException($"TableName is not set for {memberInfo.Name}'");
			}
			return tableNameAttribute.TableName;
		}

		protected string ColumnsWithPrefix(List<IFilter> filters, FilterDataType? filterDataType)
		{
			var columns = GetColumns(filters, filterDataType).Split(',', StringSplitOptions.RemoveEmptyEntries);
			StringBuilder sbResult = new StringBuilder();
			foreach (var column in columns)
			{
				if (sbResult.Length > 0)
				{
					sbResult.Append(",");
				}
				sbResult.Append($"{TableName}.{column}");
			}
			return sbResult.ToString();
		}

		protected string GetLookupFilter(string columnName, Utility.CodeType codeType, string code)
		{
			string result = $@"
{columnName} IN 
(
	SELECT TblCodeID 
	FROM TblCode 
	WHERE TblCodeTypeID = (SELECT TblCodeTypeID FROM TblCodeType WHERE CodeType='{codeType}')
	AND Code='{code}'
)
";
			return result;
		}

		protected virtual void Init() { }

	}
}
