﻿using ResCommon;

namespace Db2Csv.ElementDefinitions
{
	internal class VS : ElementBase
	{
		public VS() : base("VesselSelection", 8) { }

		protected override void Init()
		{
			this.LookupColumns.Add("VSstratification", Utility.CodeType.YesNoFields);
			this.LookupColumns.Add("VSclustering", Utility.CodeType.RS_Clustering);
			this.LookupColumns.Add("VSsampler", Utility.CodeType.Sampler);
			this.LookupColumns.Add("VSselectionMethod", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("VSselectionMethodCluster", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("VSsampled", Utility.CodeType.YesNoFields );  
			this.LookupColumns.Add("VSreasonNotSampled", Utility.CodeType.ReasonForNotSampling);

		}
	}
}
