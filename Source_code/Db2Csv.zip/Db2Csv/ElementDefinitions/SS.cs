﻿using ResCommon;

namespace Db2Csv.ElementDefinitions
{
	internal class SS : ElementBase
	{
		public SS() : base("SpeciesSelection", 11) { }

		protected override void Init()
		{
			this.LookupColumns.Add("SSstratification", Utility.CodeType.YesNoFields);
            this.LookupColumns.Add("SScatchFraction", Utility.CodeType.RS_CatchFraction);
            this.LookupColumns.Add("SScatchCategory", Utility.CodeType.RS_CatchCategory);
			this.LookupColumns.Add("SSclustering", Utility.CodeType.RS_Clustering);
			this.LookupColumns.Add("SSsampler", Utility.CodeType.Sampler);
			this.LookupColumns.Add("SSselectionMethod", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("SSselectionMethodCluster", Utility.CodeType.SelectionMethod);

			this.LookupColumns.Add("SSObservationActivityType", Utility.CodeType.ObservationActivityType);
			this.LookupColumns.Add("SSObservationType", Utility.CodeType.ObservationMethod);
			this.LookupColumns.Add("SSuseForCalculateZero", Utility.CodeType.YesNoFields);
			this.LookupColumns.Add("SSsampled", Utility.CodeType.YesNoFields);
			this.LookupColumns.Add("SSreasonNotSampled", Utility.CodeType.ReasonForNotSampling);//SAspecimensState
            this.LookupColumns.Add("SAspecimensState", Utility.CodeType.SpecimensState);
        }

	}
}
