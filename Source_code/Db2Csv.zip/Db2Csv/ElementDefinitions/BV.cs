﻿using ResCommon;

namespace Db2Csv.ElementDefinitions
{
    internal class BV : ElementBase
    {
        public BV() : base("BiologicalVariable", 7) { }
        protected override void Init()
        {
            this.LookupColumns.Add("BVstateOfProcessing", Utility.CodeType.StateOfProcessing);
            this.LookupColumns.Add("BVpresentation", Utility.CodeType.Presentation);
            this.LookupColumns.Add("BVstratification", Utility.CodeType.YesNoFields);
            this.LookupColumns.Add("BVtype", Utility.CodeType.BiologicalMeasurementType);
            this.LookupColumns.Add("BVvalueUnitOrScale", Utility.CodeType.ValueUnitOrScale);

            this.LookupColumns.Add("BVtypeMeasured", Utility.CodeType.BiologicalMeasurementType);
            this.LookupColumns.Add("BVtypeAssessment", Utility.CodeType.BiologicalMeasurementType);

            this.LookupColumns.Add("BVaccuracy", Utility.CodeType.RS_AccuracyCode);
            this.LookupColumns.Add("BVcertaintyQualitative", Utility.CodeType.MeasurementCertainty);


            this.LookupColumns.Add("BVmethod", Utility.CodeType.SampleType);
            //this.LookupColumns.Add("BVMeEq", Utility.CodeType.RS_MeasurementEquipment);
            this.LookupColumns.Add("BVselectionMethod", Utility.CodeType.SelectionMethod);
            this.LookupColumns.Add("BVsampler", Utility.CodeType.Sampler);
            this.LookupColumns.Add("BVmeasurementEquipment", Utility.CodeType.METOA);
        }

    }
}

