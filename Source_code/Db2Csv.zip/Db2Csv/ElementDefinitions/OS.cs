﻿using Db2Csv.Common.Filters;
using ResCommon;

namespace Db2Csv.ElementDefinitions
{
	internal class OS : ElementBase
	{
		public OS() : base("OnshoreEvent", 6) { }

		protected override void Init()
		{
			AddFilterFunctions(FilterType.OSsequenceNumber, FilterType.OSnationalLocationName, FilterType.OSstratification, FilterType.OSlocode, FilterType.OSsamplingDate);

			this.LookupColumns.Add("OSstratification", Utility.CodeType.YesNoFields);
			this.LookupColumns.Add("OSlocode", Utility.CodeType.Harbour_LOCODE);
			//this.LookupColumns.Add("OSlocation", Utility.CodeType.RS_Harbour);
			// this.LookupColumns.Add("VDlength", LookupCodeType.R);
			this.LookupColumns.Add("OSclustering", Utility.CodeType.RS_Clustering);
			// this.LookupColumns.Add("VDpower", LookupCodeType.rs_);
			//    this.LookupColumns.Add("FTarrivalLocation", LookupCodeType.RS_Harbour);
			this.LookupColumns.Add("OSsampler", Utility.CodeType.Sampler);
			this.LookupColumns.Add("OSsampled", Utility.CodeType.YesNoFields);

			this.LookupColumns.Add("OStimeUnit", Utility.CodeType.TimeUnit);
			this.LookupColumns.Add("OSselectionMethod", Utility.CodeType.SelectionMethod);
			// this.LookupColumns.Add("VDlength", LookupCodeType.R);

			this.LookupColumns.Add("OSlocationType", Utility.CodeType.RS_LocationType);

			this.LookupColumns.Add("OSselectionMethodCluster", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("OSreasonNotSampled", Utility.CodeType.ReasonForNotSampling);
			// this.LookupColumns.Add("VDlength", LookupCodeType.R);
		}
	}


}
