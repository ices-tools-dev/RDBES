﻿using Db2Csv.Common.Filters;
using ResCommon;

namespace Db2Csv.ElementDefinitions
{
	internal class FT : ElementBase
	{
		public FT() : base("FishingTrip", 11) { }
		protected override void Init()
		{
			AddFilterFunctions(FilterType.FTsequenceNumber, FilterType.FTsampler, FilterType.FTsamplingType, FilterType.FTarrivalLocation, FilterType.FTarrivalDate);

			this.LookupColumns.Add("FTstratification", Utility.CodeType.YesNoFields);
			this.LookupColumns.Add("FTclustering", Utility.CodeType.RS_Clustering);
			this.LookupColumns.Add("FTsampler", Utility.CodeType.Sampler);
			this.LookupColumns.Add("FTsamplingType", Utility.CodeType.RS_SamplingType);
			this.LookupColumns.Add("FTselectionMethod", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("FTdepartureLocation", Utility.CodeType.Harbour_LOCODE);
			this.LookupColumns.Add("FTarrivalLocation", Utility.CodeType.Harbour_LOCODE);

			// this.LookupColumns.Add("FTselectionMethod", Utility.CodeType.SelectionMethod);

			this.LookupColumns.Add("FTselectionMethodCluster", Utility.CodeType.SelectionMethod);
			this.LookupColumns.Add("FTsampled", Utility.CodeType.YesNoFields);
			this.LookupColumns.Add("FTreasonNotSampled", Utility.CodeType.ReasonForNotSampling);
            this.LookupColumns.Add("FOdurationSource", Utility.CodeType.DurationSource);
           
        }
	}
}
