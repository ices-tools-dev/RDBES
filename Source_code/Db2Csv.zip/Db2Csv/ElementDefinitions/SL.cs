﻿using Db2Csv.Common.Filters;
using ResCommon;
using System.Collections.Generic;
using static Db2Csv.Common.Enums;

namespace Db2Csv.ElementDefinitions
{
    internal class SL : ElementBase
    {
        public SL() : base("SpeciesList", 7) { }
        protected override void Init()
        {
            AddFilterFunctions(FilterType.SLcountry, FilterType.SLyear, FilterType.SLspeciesCode);

            this.LookupColumns.Add("SLcountry", Utility.CodeType.ISO_3166);
            this.LookupColumns.Add("SLinstitute", Utility.CodeType.EDMO);
            this.LookupColumns.Add("SLyear", Utility.CodeType.Year);
            this.LookupColumns.Add("SLcatchFraction", Utility.CodeType.RS_CatchFraction);

            this.LookupColumns.Add("SLcommercialTaxon", Utility.CodeType.SpecWoRMS);
            this.LookupColumns.Add("SLspeciesCode", Utility.CodeType.SpecWoRMS);

            //this.LookupColumns.Add("SLcountry", Utility.CodeType.ISO_3166);
            //this.LookupColumns.Add("SLinstitute", Utility.CodeType.EDMO);
            //this.LookupColumns.Add("SLyear", Utility.CodeType.Year);
            //this.LookupColumns.Add("SLcatchFraction", Utility.CodeType.RS_CatchFraction);

            //this.LookupColumns.Add("SLcommercialTaxon", Utility.CodeType.SpecWoRMS);
            //this.LookupColumns.Add("SLspeciesCode", Utility.CodeType.SpecWoRMS);

        }

//        public override string GetLoadTempTableSql(List<IFilter> filters, string additionalConditions = null)
//        {
//            string result;

//            result = $@"
//SELECT 
//ROW_NUMBER() OVER (Order BY {TableName}.{IdColumnName}) as RowNumber,
//0 AS ParentRowNumber,
//{TableName}.{IdColumnName} AS ID, 0 AS ParentID, 
//{TableName}.{Columns}, SLcommercialTaxon, SLspeciesCode
//INTO {TempTable} 
//FROM {TableName} 
//LEFT JOIN SpeciesListContent ON {TableName}.{IdColumnName} = SpeciesListContent.{IdColumnName}
//LEFT JOIN SpeciesListSpecies ON SpeciesListContent.SLCid = SpeciesListSpecies.SLCid
//{GetWhereClause(filters, additionalConditions)};
//";

//            return result;
//        }
    }
}
