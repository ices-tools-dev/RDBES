﻿using Db2Csv.Common;
using Db2Csv.Common.Filters;
using ResCommon;
using System.Collections.Generic;
using static Db2Csv.Common.Enums;

namespace Db2Csv.ElementDefinitions
{
    internal class DE : ElementBase
    {
        public DE() : base("Design", 7) { }

        protected override void Init()
        {
            AddFilterFunctions(FilterType.DEsamplingScheme, FilterType.DEsamplingSchemeType, FilterType.DEyear, FilterType.DEstratumName,
              FilterType.DEhierarchyCorrect, FilterType.DEhierarchy);
            AddFilterFunction("UserId", FilterType.DEuserId);

            this.FilterWhereFunctions.Add(FilterType.SDcountry, (IFilter filter) => this.CountryFilter(filter));

            this.LookupColumns.Add("DEsamplingScheme", Utility.CodeType.RS_SamplingScheme);
            this.LookupColumns.Add("DEsamplingSchemeType", Utility.CodeType.SamplingSchemeType);
            this.LookupColumns.Add("DEhierarchyCorrect", Utility.CodeType.YesNoFields);
            this.LookupColumns.Add("DEhierarchy", Utility.CodeType.RS_UpperHierarchy);
            this.LookupColumns.Add("DEyear", Utility.CodeType.Year);
            this.LookupColumns.Add("DEsampled", Utility.CodeType.YesNoFields);
            this.LookupColumns.Add("DEreasonNotSampled", Utility.CodeType.ReasonForNotSampling);
        }

        public DE SetHierarchyLevel(HierarchyLevel1 hierarchyLevel)
        {
            this.HierarchyLevel = hierarchyLevel;
            return this;
        }

        public HierarchyLevel1 HierarchyLevel { get; private set; }

        public override string GetLoadTempTableSql(List<IFilter> filters, string additionalCondition, FilterDataType? filterDataType = null)
        {
            string result;
            string hierarchyCondition = null;
            if (HierarchyLevel != 0)
            {
                hierarchyCondition = GetLookupFilter("DEHierarchy", Utility.CodeType.RS_UpperHierarchy, HierarchyLevel.ToString("d")); 
            }
            result = $@"
SELECT 
ROW_NUMBER() OVER (Order BY {IdColumnName}) as RowNumber,
0 AS ParentRowNumber,
{IdColumnName} AS ID, 
0 AS ParentID,
{GetColumns(filters, filterDataType)} 
INTO {TempTable} 
FROM {TableName} 
{GetWhereClause(filters, hierarchyCondition)};
";
            return result;
        }


        private string CountryFilter(IFilter filter)
        {
            if (filter.ValuesCount > 0)
            {
                return $"DEId in (SELECT DEId FROM {new SD().TableName} WHERE SDcountry IN ({filter.GetValues()}))\n";
            }
            return string.Empty;
        }


    }
}
