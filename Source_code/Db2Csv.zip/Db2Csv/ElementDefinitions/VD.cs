﻿using System;
using System.Collections.Generic;
using Db2Csv.Common.Filters;
using ResCommon;

namespace Db2Csv.ElementDefinitions
{
	internal class VD : ElementBase
	{
		public VD() : base("VesselDetails", 7) { }

		//private string LinkToParentElementColumnName = "SDid";

		public override ElementBase LinkToParentElement { get; set; }
		protected override void Init()
		{
			AddFilterFunctions(FilterType.VDcountry, FilterType.VDyear);

			this.LookupColumns.Add("VDyear", Utility.CodeType.Year);
			this.LookupColumns.Add("VDcountry", Utility.CodeType.ISO_3166);

			this.LookupColumns.Add("VDsubmitterCountry", Utility.CodeType.ISO_3166);
			this.LookupColumns.Add("VDflagCountry", Utility.CodeType.ISO_3166);
			this.LookupColumns.Add("VDhomePort", Utility.CodeType.Harbour_LOCODE);

			this.LookupColumns.Add("VDlengthCategory", Utility.CodeType.RS_VesselLengthCategory);


			this.LookupColumns.Add("VDtonUnit", Utility.CodeType.RS_VesselSizeUnit);





		}

	}
}
