﻿using Db2Csv.Common.Filters;
using ResCommon;

namespace Db2Csv.ElementDefinitions
{
	internal class SD : ElementBase
	{
		public SD() : base("SamplingDetails", 8) { }

		protected override void Init()
		{
			AddFilterFunctions(FilterType.SDcountry, FilterType.SDinstitution);
			AddFilterFunction("UserId", FilterType.SDuserId);

			this.LookupColumns.Add("SDcountry", Utility.CodeType.ISO_3166);
			this.LookupColumns.Add("SDinstitution", Utility.CodeType.EDMO);

		}
	}
}
