﻿using Db2Csv.Common.Filters;
using ResCommon;

namespace Db2Csv.ElementDefinitions
{
	internal class CL : ElementBase
	{
		public CL() : base("CommercialLanding", 7) { }
		protected override void Init()
		{
			AddFilterFunctions(
				FilterType.CLyear,
				FilterType.CLarea, 
				FilterType.CLvesselFlagCountry,
				FilterType.CLspeciesCode,
				FilterType.CLdataTypeOfScientificWeight,
				FilterType.CLdataSourceOfScientificWeight,
				FilterType.CLsamplingScheme,
				FilterType.CLdataSourceLandingsValue,
				FilterType.CLlandingCountry,
				FilterType.CLquarter,
				FilterType.CLmonth,
				FilterType.CLstatisticalRectangle,
				FilterType.CLgsaSubarea,
				FilterType.CLjurisdictionArea,
				FilterType.CLexclusiveEconomicZoneIndicator,
				FilterType.CLspeciesFaoCode,
				FilterType.CLlandingCategory,
				FilterType.CLcatchCategory,
				FilterType.CLcommercialSizeCategoryScale,
				FilterType.CLcommercialSizeCategory,
				FilterType.CLnationalFishingActivity,
				FilterType.CLmetier6,
				FilterType.CLincidentialByCatchMitigationDevice,
				FilterType.CLlandingLocation,
				FilterType.CLvesselLengthCategory,
				FilterType.CLfishingTechnique,
				FilterType.CLdeepSeaRegulation);
		


			this.LookupColumns.Add("CLdataTypeOfScientificWeight", Utility.CodeType.RS_DataTypeOfScientificWE);
			this.LookupColumns.Add("CLdataSourceOfScientificWeight", Utility.CodeType.RS_DataSourceOfScientificWE);
			this.LookupColumns.Add("CLsamplingScheme", Utility.CodeType.RS_SamplingScheme);
			this.LookupColumns.Add("CLdataSourceLandingsValue", Utility.CodeType.RS_DataSourceLandingsValue);
			this.LookupColumns.Add("CLlandingCountry", Utility.CodeType.ISO_3166);
			this.LookupColumns.Add("CLvesselFlagCountry", Utility.CodeType.ISO_3166);

			this.LookupColumns.Add("CLyear", Utility.CodeType.Year);
			this.LookupColumns.Add("CLquarter", Utility.CodeType.Quarter);
			this.LookupColumns.Add("CLmonth", Utility.CodeType.Month);
			this.LookupColumns.Add("CLarea", Utility.CodeType.ICES_Area);
			this.LookupColumns.Add("CLstatisticalRectangle", Utility.CodeType.StatRec);
            //  this.LookupColumns.Add("CLdataSourceLandingsValue", Utility.CodeType.RS_DataSourceLandingsValue);

            //EM:2010/05/14 commented this line. seems like 'CLnationalProgramBehScientificWeight' is not part of data model
            //this.LookupColumns.Add("CLnationalProgramBehScientificWeight", Utility.CodeType.RS_NationalProgram);

            this.LookupColumns.Add("CLgsaSubarea", Utility.CodeType.Areas_GFCM_GSA);
			this.LookupColumns.Add("CLexclusiveEconomicZoneIndicator", Utility.CodeType.RS_EEZI);

			this.LookupColumns.Add("CLspeciesCode", Utility.CodeType.SpecWoRMS);
			this.LookupColumns.Add("CLspeciesFaoCode", Utility.CodeType.SpecASFIS);
			this.LookupColumns.Add("CLlandingCategory", Utility.CodeType.RS_LandingCategory);

			this.LookupColumns.Add("CLcatchCategory", Utility.CodeType.RS_CatchCategory);
            this.LookupColumns.Add("CLregDisCategory", Utility.CodeType.RegDisCategory);

            this.LookupColumns.Add("CLcommercialSizeCategoryScale", Utility.CodeType.CommercialSizeCategoryScale);
			this.LookupColumns.Add("CLcommercialSizeCategory", Utility.CodeType.RS_CommercialSizeCategory);
			this.LookupColumns.Add("CLnationalFishingActivity", Utility.CodeType.RS_NationalFishingActivity);
			this.LookupColumns.Add("CLmetier6", Utility.CodeType.Metier6_FishingActivity);

			this.LookupColumns.Add("CLincidentialByCatchMitigationDevice", Utility.CodeType.BycatchMitigationDevice);
			this.LookupColumns.Add("CLlandingLocation", Utility.CodeType.Harbour_LOCODE);
			this.LookupColumns.Add("CLvesselLengthCategory", Utility.CodeType.RS_VesselLengthCategory);
			this.LookupColumns.Add("CLfishingTechnique", Utility.CodeType.RS_FishingTechnique);
			this.LookupColumns.Add("CLdeepSeaRegulation", Utility.CodeType.YesNoFields);

			this.LookupColumns.Add("CLexplainDifference", Utility.CodeType.RS_ExplainDifference);
			this.LookupColumns.Add("CLscientificLandingsQualitativeBias", Utility.CodeType.RS_QualitativeBias);

		}
	}
}
