﻿using ResCommon;

namespace Db2Csv.ElementDefinitions
{
    internal class FM : ElementBase
    {
        public FM() : base("FrequencyMeasure", 6) { }
        protected override void Init()
        {
            this.LookupColumns.Add("FMtypeMeasured", Utility.CodeType.BiologicalMeasurementType);
            this.LookupColumns.Add("FMaccuracy", Utility.CodeType.RS_AccuracyCode);
            this.LookupColumns.Add("FMmeasurementEquipment", Utility.CodeType.METOA);
            this.LookupColumns.Add("FMsampler", Utility.CodeType.Sampler);
            this.LookupColumns.Add("FMaddGrpMeasurementType", Utility.CodeType.BiologicalMeasurementType);
            this.LookupColumns.Add("FMstateOfProcessing", Utility.CodeType.StateOfProcessing);
            this.LookupColumns.Add("FMpresentation", Utility.CodeType.Presentation);
            this.LookupColumns.Add("FMmethod", Utility.CodeType.SampleType);
            this.LookupColumns.Add("FMtypeAssessment", Utility.CodeType.BiologicalMeasurementType);
        }
    }
}
