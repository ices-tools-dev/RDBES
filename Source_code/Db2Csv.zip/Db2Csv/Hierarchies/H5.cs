using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
	internal class H5 : HierarchyBase
	{
		protected override void LoadHierarchy()
		{
			Elements.Add(
				new DE().SetHierarchyLevel(Common.Enums.HierarchyLevel1.H5).AddChilds
				(
					new SD().AddChilds
					(
						new OS().AddChilds
						(
							new FT(),
							new LE().AddChilds
							(
								new SS().AddChilds
								(
									new SA().AddChilds(CreateSecondaryLevel())
								)
							)
						)
					)
				)
			);


		}
	}
}
