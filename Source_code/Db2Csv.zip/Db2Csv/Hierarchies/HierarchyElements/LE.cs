﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class LE : HierarchyElement
    {
        public LE() : base(new ElementDefinitions.LE()) { }
        
    }
}
