﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class CE : HierarchyElement
    {
        public CE() : base(new ElementDefinitions.CE()) { }

    }
}
