﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class SS : HierarchyElement
    {
        public SS() : base(new ElementDefinitions.SS()) { }
        
    }
}
