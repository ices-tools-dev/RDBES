﻿using static Db2Csv.Common.Enums;

namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class DE : HierarchyElement
    {
        public DE() : base(new ElementDefinitions.DE()) { }

        public DE SetHierarchyLevel(HierarchyLevel1 hierarchyLevel)
        {
            ((ElementDefinitions.DE)this.Element).SetHierarchyLevel(hierarchyLevel);
            return this;
        }

    }
}
