﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class FO : HierarchyElement
    {
        public FO() : base(new ElementDefinitions.FO()) { }
        
    }
}
