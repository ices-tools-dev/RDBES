﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class TE : HierarchyElement
    {
        public TE() : base(new ElementDefinitions.TE()) { }
        
    }
}
