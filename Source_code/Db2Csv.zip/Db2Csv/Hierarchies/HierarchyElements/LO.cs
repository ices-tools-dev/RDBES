﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class LO : HierarchyElement
    {
        public LO() : base(new ElementDefinitions.LO()) { }
        
    }
}
