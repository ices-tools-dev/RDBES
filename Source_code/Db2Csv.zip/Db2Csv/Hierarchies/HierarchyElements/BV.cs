﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class BV : HierarchyElement
    {
        public BV() : base(new ElementDefinitions.BV()) { }
        
    }
}
