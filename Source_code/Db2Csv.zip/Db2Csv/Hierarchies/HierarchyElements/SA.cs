﻿using static Db2Csv.Common.Enums;

namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class SA : HierarchyElement
    {
        public SA() : base(new ElementDefinitions.SA()) { }
        public SA SetHierarchyLevel(HierarchyLevel2 hierarchyLevel)
        {
            ((ElementDefinitions.SA)this.Element).SetHierarchyLevel(hierarchyLevel);
            return this;
        }
    }
}
