﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class FT : HierarchyElement
    {
        public FT() : base(new ElementDefinitions.FT()) { }
        
    }
}
