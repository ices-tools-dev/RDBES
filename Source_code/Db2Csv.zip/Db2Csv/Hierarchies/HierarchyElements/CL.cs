﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class CL : HierarchyElement
    {
        public CL() : base(new ElementDefinitions.CL()) { }

    }
}
