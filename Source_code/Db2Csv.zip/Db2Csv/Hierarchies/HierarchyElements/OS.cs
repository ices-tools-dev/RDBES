﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class OS : HierarchyElement
    {
        public OS() : base(new ElementDefinitions.OS()) { }
        
    }
}
