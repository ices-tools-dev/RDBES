﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class VS : HierarchyElement
    {
        public VS() : base(new ElementDefinitions.VS()) { }
        
    }
}
