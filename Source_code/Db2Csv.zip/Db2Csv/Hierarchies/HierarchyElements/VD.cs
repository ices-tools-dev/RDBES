﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class VD : HierarchyElement
    {
        public VD() : base(new ElementDefinitions.VD()) { }
        
    }
}
