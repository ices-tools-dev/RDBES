﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class FM : HierarchyElement
    {
        public FM() : base(new ElementDefinitions.FM()) { }
        
    }
}
