﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class SD : HierarchyElement
    {
        public SD() : base(new ElementDefinitions.SD()) { }
        
    }
}
