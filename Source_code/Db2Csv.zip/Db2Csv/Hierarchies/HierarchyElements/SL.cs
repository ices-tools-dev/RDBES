﻿namespace Db2Csv.Hierarchies.HierarchyElements
{
    internal class SL : HierarchyElement
    {
        public SL() : base(new ElementDefinitions.SL()) { }
        
    }
}
