using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
	internal class H3 : HierarchyBase
	{
		protected override void LoadHierarchy()
		{
			Elements.Add(
				new DE().SetHierarchyLevel(Common.Enums.HierarchyLevel1.H3).AddChilds
				(
					new SD().AddChilds
					(
						new TE().AddChilds
						(
							new VS().AddChilds
							(
								new FT().AddChilds
								(
									new FO().AddChilds
									(
										new SS().AddChilds
										(
											new SA().AddChilds(CreateSecondaryLevel())
										)
									)
								)
							)
						)
					)
				)
			);

		}
	}
}
