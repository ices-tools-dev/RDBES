using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
	internal class H9 : HierarchyBase
	{
		protected override void LoadHierarchy()
		{
			Elements.Add(
				new DE().SetHierarchyLevel(Common.Enums.HierarchyLevel1.H9).AddChilds
				(
					new SD().AddChilds
					(
						new LO().AddChilds
						(
							 new TE().AddChilds
							 (
								 new LE().AddChilds
								 (
									 new SS().AddChilds
									 (
										new SA().AddChilds(CreateSecondaryLevel())
									)
								 )
							)
						)
					)
				)
			);

		}
	}
}
