using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
	internal class H4 : HierarchyBase
	{
		protected override void LoadHierarchy()
		{
			Elements.Add(
				new DE().SetHierarchyLevel(Common.Enums.HierarchyLevel1.H4).AddChilds
				(
					new SD().AddChilds
					(
						new OS().AddChilds
						(
							new FT().AddChilds
							(
								new LE().AddChilds
								(
									new SS().AddChilds
									(
										new SA().AddChilds(CreateSecondaryLevel())
									)
								)
							)
						)
					)
				)
			);

		}
	}
}
