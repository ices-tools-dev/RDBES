using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
    internal class H13 : HierarchyBase
    {
        protected override void LoadHierarchy()
        {
            Elements.Add(
                new DE().SetHierarchyLevel(Common.Enums.HierarchyLevel1.H13).AddChilds
                (
                    new SD().AddChilds
                    (
                        new FO().AddChilds(
                            new FT(),
                            new SS().AddChilds
                            (
                                new SA().AddChilds(CreateSecondaryLevel())
                            )
                        )
                    )
                )
            );
        }
    }
}
