﻿using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
	internal class H1 : HierarchyBase
	{
		protected override void LoadHierarchy()
		{
			Elements.Add(
				new DE().SetHierarchyLevel(Common.Enums.HierarchyLevel1.H1).AddChilds
				(
					new SD().AddChilds
					(
						new VS().AddChilds
						(
							new FT().AddChilds
							(
								new FO().AddChilds
								(
									new SS().AddChilds
									(
										new SA().AddChilds(CreateSecondaryLevel())
									)
								)
							)
						)
					)
				)
			);

		}
	}
}
