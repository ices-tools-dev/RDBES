﻿using Db2Csv.ElementDefinitions;
using System.Collections.Generic;
using System;

namespace Db2Csv.Hierarchies
{
    internal abstract class HierarchyElement
    {
        public readonly ElementBase Element;

        public HierarchyElement Parent = null;

        public List<HierarchyElement> Childs = new List<HierarchyElement>();

        protected HierarchyElement(ElementBase element)
        {
            this.Element = element;
        }

        public HierarchyElement AddChilds(params HierarchyElement[] args)
        {
            if (args.Length == 0)
            {
                throw new InvalidOperationException($"AddChilds expects at least one argument!");
            }
            foreach (var item in args)
            {
                AddChild(item);
            }
            return this;
        }

        public void SetLinkToParentElement(HierarchyElement linkToParent)
        {
            this.Element.LinkToParentElement = linkToParent.Element;
        }

        public HierarchyElement FindElement<T>() where T : HierarchyElement
        {
            if (this.GetType() == typeof(T))
            {
                return this;
            }
            HierarchyElement result = null;
            foreach (var element in Childs)
            {
                if (element.GetType().Equals(typeof(T)))
                {
                    result = element;
                    break;
                }
                result = element.FindElement<T>();
            }
            return result;
        }

        protected void AddChild(HierarchyElement child)
        {
            child.Parent = this;
            child.Element.ParentElement = this.Element;
            Childs.Add(child);
        }

    }
}
