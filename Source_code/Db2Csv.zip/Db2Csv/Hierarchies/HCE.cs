﻿using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
    internal class HCE : HierarchyBase
    {
        protected override void LoadHierarchy()
        {
            Elements.Add(
                new CE()
            );

        }
    }
}
