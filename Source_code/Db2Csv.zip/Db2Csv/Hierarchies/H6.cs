using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
    internal class H6 : HierarchyBase
    {
        protected override void LoadHierarchy()
        {
            Elements.Add(
                new DE().SetHierarchyLevel(Common.Enums.HierarchyLevel1.H6).AddChilds
                (
                    new SD().AddChilds
                    (
                        new OS().AddChilds
                        (
                            new FT().AddChilds
                            (
                                new FO().AddChilds
                                (
                                    new LE(),
                                    new SS().AddChilds
                                    (
                                        new SA().AddChilds(CreateSecondaryLevel())
                                    )
                                )
                            )
                        )
                    )
                )
            );

        }
    }
}
