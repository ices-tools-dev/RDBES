﻿using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
	internal class H11 : HierarchyBase
	{
		protected override void LoadHierarchy()
		{
			Elements.Add(
				new DE().SetHierarchyLevel(Common.Enums.HierarchyLevel1.H11).AddChilds
				(
					new SD().AddChilds
					(
						new LO().AddChilds
						(
							new TE().AddChilds
							(
								new FT().AddChilds
								(
									new LE(),
									new SS().AddChilds
									(
										new SA().AddChilds(CreateSecondaryLevel())
									)
								)
							)
						)
					)
				)
			);

		}
	}
}
