﻿using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
	internal class H2 : HierarchyBase
	{
		protected override void LoadHierarchy()
		{
			Elements.Add(
				new DE().SetHierarchyLevel(Common.Enums.HierarchyLevel1.H2).AddChilds
				(
					new SD().AddChilds
					(
						new FT().AddChilds
						(
							new FO().AddChilds
							(
								new SS().AddChilds
								(
									new SA().AddChilds(CreateSecondaryLevel())
								)
							)
						)
					)
				)
			);

		}
	}
}
