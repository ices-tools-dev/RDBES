﻿using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
	internal class HVD : HierarchyBase
	{
		protected override void LoadHierarchy()
		{
			Elements.Add(
				new VD()
			);

		}
	}
}
