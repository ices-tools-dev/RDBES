﻿using Db2Csv.Hierarchies.HierarchyElements;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Db2Csv.Hierarchies
{
	internal abstract class HierarchyBase 
	{
		private const int LEVEL_ZERO = 0;

		public class ElementWithLevel
		{
			public int Level { get; set; }
			public HierarchyElement Element { get; set; }
		}

		public readonly List<HierarchyElement> Elements = new List<HierarchyElement>();

		public bool ContainsElement(string elementName)
		{
			return ContainsElement(elementName, Elements);
		}

		private bool ContainsElement(string elementName, List<HierarchyElement> elements)
		{
			foreach (var element in elements)
			{
				if (element.GetType().Name.Equals(elementName))
				{
					return true;
				}
				if (ContainsElement(elementName, element.Childs))
				{
					return true;
				}
			}
			return false;
		}

		protected HierarchyBase()
		{
			LoadHierarchy();
		}

		protected abstract void LoadHierarchy();

		protected HierarchyBase AddElement(HierarchyElement element)
		{
			this.Elements.Add(element);
			return this;
		}

		protected HierarchyElement FindElement<T>() where T : HierarchyElement
		{
			HierarchyElement result=null;
			foreach (var element in Elements)
			{
				result = element.FindElement<T>();
				if (result != null)
				{
					break;
				}
			}
			if (result == null)
			{
				throw new Exception($"Failed to find element of type:{nameof(T)} in hierarchy:{this.GetType().Name}");
			}
			return result;
		}

		public List<HierarchyElement> GetAllElements()
		{
			List<HierarchyElement> result = new List<HierarchyElement>();
			foreach (var element in Elements)
			{
				result.Add(element);
				AddAllChildsToList(result, element);
			}
			return result;
		}

		private void AddAllChildsToList(List<HierarchyElement> list, HierarchyElement element)
		{
			foreach (var child in element.Childs)
			{
				list.Add(child);
				AddAllChildsToList(list, child);
			}
		}

		protected HierarchyElement[] CreateSecondaryLevel()
		{
			HierarchyElement[] result = new HierarchyElement[2] {
				new BV(),
				new FM().AddChilds(new BV()),
			};

			return result;
		}


		public List<ElementWithLevel> ExtractElementsToDelete(IEnumerable<(string ElementName, bool ChildrenOnly)> itemsToGet)
		{
			Dictionary<HierarchyElement, ElementWithLevel> result = new Dictionary<HierarchyElement, ElementWithLevel>();
			IterateElementsForDeletion(LEVEL_ZERO, Elements, itemsToGet, result);
			return result.Values.ToList();
		}

		private void IterateElementsForDeletion(int level, IEnumerable<HierarchyElement> elements, 
			IEnumerable<(string ElementName, bool ChildrenOnly)> itemsToGet, Dictionary<HierarchyElement, ElementWithLevel> result)
		{
			foreach (var element in elements)
			{
				string elementName = element.GetType().Name;
				if (result.ContainsKey(element))
				{
					continue;
				}
				var item = itemsToGet.Where(itm => itm.ElementName.Equals(elementName)).SingleOrDefault();
				if (!item.Equals(default))
				{
					if (!item.ChildrenOnly)
					{
						result.Add(element, new ElementWithLevel { Element = element, Level = level });
					}
					AppendAllChildren(level + 1, result, element);
				}
				else
				{
					IterateElementsForDeletion(level + 1, element.Childs, itemsToGet, result);
				}
			}
		}

		private void AppendAllChildren(int level, Dictionary<HierarchyElement, ElementWithLevel> result, HierarchyElement parent)
		{
			foreach (var child in parent.Childs)
			{
				if (!result.ContainsKey(child))
				{
					result.Add(child, new ElementWithLevel { Element = child, Level = level });
					AppendAllChildren(level + 1, result, child);
				}
			}
		}

	}
}
