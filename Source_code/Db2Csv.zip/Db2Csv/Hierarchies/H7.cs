﻿using Db2Csv.Hierarchies.HierarchyElements;

namespace Db2Csv.Hierarchies
{
	internal class H7 : HierarchyBase
	{
		protected override void LoadHierarchy()
		{
			Elements.Add(
				new DE().SetHierarchyLevel(Common.Enums.HierarchyLevel1.H7).AddChilds
				(
					new SD().AddChilds
					(
						new OS().AddChilds
						(
							new LE(),
							new SS().AddChilds
							(
								new SA().AddChilds(CreateSecondaryLevel())
							)
						)
					)
				)
			);

		}
	}
}
