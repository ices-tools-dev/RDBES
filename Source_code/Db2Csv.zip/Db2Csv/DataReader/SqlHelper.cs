﻿using Db2Csv.Common;
using Db2Csv.Common.Filters;
using Db2Csv.Hierarchies;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;

namespace Db2Csv.DataReader
{
    internal class SqlHelper
    {
        private string connectionString;
        private const string DATE_FORMAT = "yyyy-MM-dd";
        private int COMMAND_TIMEOUT = 180;
        private readonly string DATE_TIME_FORMAT = string.Concat(DATE_FORMAT, " ", "HH:mm:ss");

        public SqlHelper(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public List<(string ElementName, int Count)> Delete(HierarchyBase hierarchy, List<IFilter> filters, IEnumerable<HierarchyElement> elementsToDelete, bool dryRun)
        {
            var sqlBuilder = new SqlBuilder();
            string sql = sqlBuilder.BuildSqlForDelete(hierarchy, filters, elementsToDelete, dryRun);
            var deletedElements = new Dictionary<string, int>();
            RunReaderInTransaction(sql, (reader) =>
            {
                do
                {
                    while (reader.Read())
                    {
                        string name = reader.GetString(0);
                        int count = reader.GetInt32(1);
                        if (deletedElements.ContainsKey(name))
                        {
                            deletedElements[name] += count;
                        }
                        else
                        {
                            deletedElements.Add(name, count);
                        }
                    }
                }
                while (reader.NextResult());
            });
            return deletedElements.Select(p => (ElementName: p.Key, Count: p.Value)).ToList();
        }

        public void ExportData(HierarchyBase hierarchy, List<IFilter> filters, string tempFolderPath)
        {
            var sqlBuilder = new SqlBuilder();
            string sql = sqlBuilder.BuildSql(hierarchy, filters);
            ExportData(sql, tempFolderPath);
        }

        public void RunReader(HierarchyBase hierarchy, List<IFilter> filters, Action<SqlDataReader> action)
        {
            var sqlBuilder = new SqlBuilder();
            string sql = sqlBuilder.BuildSql(hierarchy, filters);
            RunReader(sql, action);
        }

        public List<KeyValuePair<int, string>> ExtractFilterData(HierarchyBase hierarchy, List<IFilter> filters, FilterDataType filterDataType, bool ascending)
        {
            var sqlBuilder = new SqlBuilder();
            string sql = sqlBuilder.BuildSql(hierarchy, filters, filterDataType);
            var result = new List<KeyValuePair<int, string>>();
            RunReader(sql, (reader) =>
            {
                while (reader.Read())
                {
                    result.Add(new KeyValuePair<int, string>(reader.GetInt32(0), reader.GetString(1)));
                }
            });
            return (ascending ? result.OrderBy(kvp => kvp.Value) : result.OrderByDescending(kvp => kvp.Value)).ToList();
        }

        private void ExportData(string sql, string tempFolderPath)
        {
            RunReader(sql, (reader) =>
            {
                while (true)
                {
                    ExportTable(tempFolderPath, reader);
                    if (!reader.NextResult())
                    {
                        break;
                    }
                }
            });
        }

        private void RunReader(string sql, Action<SqlDataReader> action)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    using (SqlCommand command = new SqlCommand(sql, connection) { CommandType = CommandType.Text, CommandTimeout = COMMAND_TIMEOUT })
                    {
                        using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.KeyInfo))
                        {
                            action(reader);
                        }
                    }
                }
            }
        }

        private void RunReaderInTransaction(string sql, Action<SqlDataReader> action)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    using (SqlTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable))
                    {
                        try
                        {
                            using (SqlCommand command = new SqlCommand(sql, connection) { CommandType = CommandType.Text, CommandTimeout = COMMAND_TIMEOUT, Transaction = transaction })
                            {
                                using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.KeyInfo))
                                {
                                    action(reader);
                                }
                                transaction.Commit();
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
        }

        protected void ExportTable(string tempFolderPath, SqlDataReader reader)
        {
            DataTable schemaTable = reader.GetSchemaTable();
            string elementName = ((string)schemaTable.Rows[0]["BaseTableName"]).Substring(4);
            string pathToCsv = Path.Combine(tempFolderPath, $"{elementName}.csv");
            using (FileStream fw = File.Open(pathToCsv, FileMode.Create, FileAccess.Write, FileShare.Read))
            {
                using (StreamWriter sw = new StreamWriter(fw, new System.Text.UTF8Encoding(false)))
                {
                    // write columns
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        if (i > 0)
                        {
                            sw.Write(Constants.SEPARATOR);
                        }
                        sw.Write(reader.GetName(i));
                    }
                    sw.WriteLine();

                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            if (i > 0)
                            {
                                sw.Write(Constants.SEPARATOR);
                            }
                            var value = reader.GetValue(i);
                            if (value is DateTime)
                            {
                                var dateValue = (DateTime)value;
                                if (dateValue.Hour != 0 || dateValue.Minute != 0 || dateValue.Second != 0)
                                {
                                    value = dateValue.ToString(DATE_TIME_FORMAT);
                                }
                                else
                                {
                                    value = dateValue.ToString(DATE_FORMAT);
                                }
                            }
                            sw.Write(value);
                        }
                        sw.WriteLine();
                    }
                    sw.Flush();
                }
            }
        }


    }
}
