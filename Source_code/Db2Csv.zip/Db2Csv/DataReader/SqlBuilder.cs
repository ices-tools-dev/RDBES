﻿using Db2Csv.Common;
using Db2Csv.Common.Filters;
using Db2Csv.Hierarchies;
using System.Collections.Generic;
using System.Text;

namespace Db2Csv.DataReader
{
    internal class SqlBuilder
    {
        public string BuildSql(HierarchyBase hierarchy, List<IFilter> filters, FilterDataType? filterDataType = null)
        {
            StringBuilder sbSQL = new StringBuilder();
            foreach (var hierarchyElement in hierarchy.Elements)
            {
                BuildSelectTempTablesSql(sbSQL, hierarchyElement, filters, filterDataType);
            }
            foreach (var hierarchyElement in hierarchy.Elements)
            {
                BuildSelectSql(sbSQL, hierarchyElement, filterDataType);
            }
            return sbSQL.ToString();
        }

        public string BuildSqlForDelete(HierarchyBase hierarchy, List<IFilter> filters, IEnumerable<HierarchyElement> elementsToDelete, bool dryRun)
        {
            StringBuilder sbSQL = new StringBuilder();
            foreach (var hierarchyElement in hierarchy.Elements)
            {
                BuildSelectTempTablesSql(sbSQL, hierarchyElement, filters);
            }
            foreach (var element in elementsToDelete)
            {
                sbSQL.Append(element.Element.GetDeleteSql(dryRun));
            }
            return sbSQL.ToString();
        }

        protected void BuildSelectTempTablesSql(StringBuilder sbSQL, HierarchyElement hierarchyElement, List<IFilter> filters, FilterDataType? filterDataType = null)
        {
            sbSQL.Append(hierarchyElement.Element.GetLoadTempTableSql(filters, null, filterDataType));
            sbSQL.AppendLine("-----------------------------------------------------");
            foreach (var child in hierarchyElement.Childs)
            {
                BuildSelectTempTablesSql(sbSQL, child, filters, filterDataType);
            }
        }

        protected void BuildSelectSql(StringBuilder sbSQL, HierarchyElement hierarchyElement, FilterDataType? filterDataType = null)
        {
            sbSQL.Append(hierarchyElement.Element.GetSelectSql(filterDataType));
            foreach (var child in hierarchyElement.Childs)
            {
                BuildSelectSql(sbSQL, child, filterDataType);
            }
        }

    }
}
