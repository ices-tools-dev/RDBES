﻿using RDBES.Code.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RDBES.Code.Extenions
{
    public static class StringExtensions
    {
        public static string RemoveQuotes(this string value)
        {
            if (value.StartsWith(Constants.QUOTE) && value.EndsWith(Constants.QUOTE))
            {
                return value.Substring(1, value.Length - 2);
            }
            return value;
        }

        public static string WrapInQuotes(this string value)
        {
            return string.Concat(Constants.QUOTE, value, Constants.QUOTE);
        }
    }
}
