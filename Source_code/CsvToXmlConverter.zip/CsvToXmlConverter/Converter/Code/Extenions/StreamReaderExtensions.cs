﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace RDBES.Code.Extenions
{
    public static class StreamReaderExtensions
    {
        public static void ResetToStart(this StreamReader sr)
        {
            sr.BaseStream.Position = 0;
            sr.DiscardBufferedData();
        }
    }
}
