﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class CL : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "CL",
                opening: "\n<CL ",
                closure: "\n</CL>",
                escape: escapeProvider,
                startIndex: startIndex);



            set.Add(">^<CLdataTypeOfScientificWeight>|</CLdataTypeOfScientificWeight>")
               .Add("^<CLdataSourceOfScientificWeight>|</CLdataSourceOfScientificWeight>")
               .Add("^<CLsamplingScheme>|</CLsamplingScheme>", new OptionalSetting { IsOptional = true })
               .Add("^<CLdataSourceLandingsValue>|</CLdataSourceLandingsValue>")
               .Add("^<CLlandingCountry>|</CLlandingCountry>")
               .Add("^<CLvesselFlagCountry>|</CLvesselFlagCountry>")
               .Add("^<CLyear>|</CLyear>")
               .Add("^<CLquarter>|</CLquarter>")
               .Add("^<CLmonth>|</CLmonth>", new OptionalSetting { IsOptional = true })
               .Add("^<CLarea>|</CLarea>")
               .Add("^<CLstatisticalRectangle>|</CLstatisticalRectangle>")
               .Add("^<CLgsaSubarea>|</CLgsaSubarea>")
               .Add("^<CLjurisdictionArea>|</CLjurisdictionArea>", new OptionalSetting { IsOptional = true })
               .Add("^<CLexclusiveEconomicZoneIndicator>|</CLexclusiveEconomicZoneIndicator>", new OptionalSetting { IsOptional = true })
               .Add("^<CLspeciesCode>|</CLspeciesCode>")
               .Add("^<CLspeciesFaoCode>|</CLspeciesFaoCode>", new OptionalSetting { IsOptional = true })
               .Add("^<CLlandingCategory>|</CLlandingCategory>")
               .Add("^<CLcatchCategory>|</CLcatchCategory>")
               .Add("^<CLregDisCategory>|</CLregDisCategory>", new OptionalSetting { IsOptional = true })
               .Add("^<CLcommercialSizeCategoryScale>|</CLcommercialSizeCategoryScale>", new OptionalSetting { IsOptional = true })
               .Add("^<CLcommercialSizeCategory>|</CLcommercialSizeCategory>", new OptionalSetting { IsOptional = true })
               .Add("^<CLnationalFishingActivity>|</CLnationalFishingActivity>", new OptionalSetting { IsOptional = true })
               .Add("^<CLmetier6>|</CLmetier6>")
               .Add("^<CLincidentialByCatchMitigationDevice>|</CLincidentialByCatchMitigationDevice>")
               .Add("^<CLlandingLocation>|</CLlandingLocation>")
               .Add("^<CLvesselLengthCategory>|</CLvesselLengthCategory>")
               .Add("^<CLfishingTechnique>|</CLfishingTechnique>", new OptionalSetting { IsOptional = true })
               .Add("^<CLdeepSeaRegulation>|</CLdeepSeaRegulation>", new OptionalSetting { IsOptional = true })
               .Add("^<CLofficialWeight>|</CLofficialWeight>")
               .Add("^<CLscientificWeight>|</CLscientificWeight>")
               .Add("^<CLexplainDifference>|</CLexplainDifference>")
               .Add("^<CLtotalOfficialLandingsValue>|</CLtotalOfficialLandingsValue>")
               .Add("^<CLnumberOfUniqueVessels>|</CLnumberOfUniqueVessels>")
               .Add("^<CLscientificWeightRSE>|</CLscientificWeightRSE>", new OptionalSetting { IsOptional = true })
               .Add("^<CLvalueRSE>|</CLvalueRSE>", new OptionalSetting { IsOptional = true })
               .Add("^<CLscientificWeightQualitativeBias>|</CLscientificWeightQualitativeBias>", new OptionalSetting { IsOptional = true });


            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
