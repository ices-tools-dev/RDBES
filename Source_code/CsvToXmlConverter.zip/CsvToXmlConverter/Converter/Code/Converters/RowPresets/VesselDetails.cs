﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class VD : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "VD",
                opening: "\n<VD ",
                closure: "\n</VD>",
                escape: escapeProvider,
                startIndex: startIndex);
            set.Add(">^<VDencryptedVesselCode>|</VDencryptedVesselCode>")
               .Add("^<VDyear>|</VDyear>")
               .Add("^<VDcountry>|</VDcountry>")
               .Add("^<VDhomePort>|</VDhomePort>", new OptionalSetting { IsOptional = true })
               .Add("^<VDflagCountry>|</VDflagCountry>")
               .Add("^<VDlength>|</VDlength>", new OptionalSetting { IsOptional = true })
               .Add("^<VDlengthCategory>|</VDlengthCategory>")
               .Add("^<VDpower>|</VDpower>", new OptionalSetting { IsOptional = true })
               .Add("^<VDtonnage>|</VDtonnage>", new OptionalSetting { IsOptional = true })
               .Add("^<VDtonUnit>|</VDtonUnit>", new OptionalSetting { IsOptional = true });


            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
