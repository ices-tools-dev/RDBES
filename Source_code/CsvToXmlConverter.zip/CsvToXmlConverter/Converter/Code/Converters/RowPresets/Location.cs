﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class LO : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "LO",
                opening: "\n<LO ",
                closure: "\n</LO>",
                escape: escapeProvider,
                startIndex: startIndex);


            set.Add(">^<LOsequenceNumber>|</LOsequenceNumber>")
               .Add("^<LOstratification>|</LOstratification>")
               .Add("^<LOlocode>|</LOlocode>")
               .Add("^<LOlocationName>|</LOlocationName>")
               .Add("^<LOlocationType>|</LOlocationType>", new OptionalSetting { IsOptional = true })
               .Add("^<LOstratumName>|</LOstratumName>")
               .Add("^<LOclustering>|</LOclustering>")
               .Add("^<LOclusterName>|</LOclusterName>")
               .Add("^<LOsampler>|</LOsampler>", new OptionalSetting { IsOptional = true })
               .Add("^<LOnumberTotal>|</LOnumberTotal>", new OptionalSetting { IsOptional = true })
               .Add("^<LOnumberSampled>|</LOnumberSampled>", new OptionalSetting { IsOptional = true })
               .Add("^<LOselectionProb>|</LOselectionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<LOinclusionProb>|</LOinclusionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<LOselectionMethod>|</LOselectionMethod>")
               .Add("^<LOunitName>|</LOunitName>", new OptionalSetting { IsOptional = true })
               .Add("^<LOselectionMethodCluster>|</LOselectionMethodCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<LOnumberTotalClusters>|</LOnumberTotalClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<LOnumberSampledClusters>|</LOnumberSampledClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<LOselectionProbCluster>|</LOselectionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<LOinclusionProbCluster>|</LOinclusionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<LOsampled>|</LOsampled>")
               .Add("^<LOreasonNotSampled>|</LOreasonNotSampled>", new OptionalSetting { IsOptional = true });

            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
