﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class CE : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "CE",
                opening: "\n<CE ",
                closure: "\n</CE>",
                escape: escapeProvider,
                startIndex: startIndex);



            set.Add(">^<CEdataTypeForScientificEffort>|</CEdataTypeForScientificEffort>")
               .Add("^<CEdataSourceForScientificEffort>|</CEdataSourceForScientificEffort>")
               .Add("^<CEsamplingScheme>|</CEsamplingScheme>", new OptionalSetting { IsOptional = true })
               .Add("^<CEvesselFlagCountry>|</CEvesselFlagCountry>")
               .Add("^<CEyear>|</CEyear>")
               .Add("^<CEquarter>|</CEquarter>")
               .Add("^<CEmonth>|</CEmonth>", new OptionalSetting { IsOptional = true })
               .Add("^<CEarea>|</CEarea>")
               .Add("^<CEstatisticalRectangle>|</CEstatisticalRectangle>")
               .Add("^<CEgsaSubarea>|</CEgsaSubarea>")
               .Add("^<CEjurisdictionArea>|</CEjurisdictionArea>", new OptionalSetting { IsOptional = true })
               .Add("^<CEexclusiveEconomicZoneIndicator>|</CEexclusiveEconomicZoneIndicator>", new OptionalSetting { IsOptional = true })
               .Add("^<CEnationalFishingActivity>|</CEnationalFishingActivity>", new OptionalSetting { IsOptional = true })
               .Add("^<CEmetier6>|</CEmetier6>")
               .Add("^<CEincidentalByCatchMitigationDevice>|</CEincidentalByCatchMitigationDevice>")
               .Add("^<CElandingLocation>|</CElandingLocation>")
               .Add("^<CEvesselLengthCategory>|</CEvesselLengthCategory>")
               .Add("^<CEfishingTechnique>|</CEfishingTechnique>", new OptionalSetting { IsOptional = true })
               .Add("^<CEdeepSeaRegulation>|</CEdeepSeaRegulation>", new OptionalSetting { IsOptional = true })
               .Add("^<CEnumberOfFractionTrips>|</CEnumberOfFractionTrips>")
               .Add("^<CEnumberOfDominantTrips>|</CEnumberOfDominantTrips>")
               .Add("^<CEofficialDaysAtSea>|</CEofficialDaysAtSea>")
               .Add("^<CEscientificDaysAtSea>|</CEscientificDaysAtSea>")
               .Add("^<CEofficialFishingDays>|</CEofficialFishingDays>")
               .Add("^<CEscientificFishingDays>|</CEscientificFishingDays>")
               .Add("^<CEofficialNumberOfHaulsOrSets>|</CEofficialNumberOfHaulsOrSets>", new OptionalSetting { IsOptional = true })
               .Add("^<CEscientificNumberOfHaulsOrSets>|</CEscientificNumberOfHaulsOrSets>", new OptionalSetting { IsOptional = true })
               .Add("^<CEofficialVesselFishingHour>|</CEofficialVesselFishingHour>", new OptionalSetting { IsOptional = true })
               .Add("^<CEscientificVesselFishingHour>|</CEscientificVesselFishingHour>", new OptionalSetting { IsOptional = true })
               .Add("^<CEofficialSoakingMeterHour>|</CEofficialSoakingMeterHour>", new OptionalSetting { IsOptional = true })
               .Add("^<CEscientificSoakingMeterHour>|</CEscientificSoakingMeterHour>", new OptionalSetting { IsOptional = true })
               .Add("^<CEofficialkWDaysAtSea>|</CEofficialkWDaysAtSea>")
               .Add("^<CEscientifickWDaysAtSea>|</CEscientifickWDaysAtSea>")
               .Add("^<CEofficialkWFishingDays>|</CEofficialkWFishingDays>")
               .Add("^<CEscientifickWFishingDays>|</CEscientifickWFishingDays>")
               .Add("^<CEofficialkWFishingHours>|</CEofficialkWFishingHours>", new OptionalSetting { IsOptional = true })
               .Add("^<CEscientifickWFishingHours>|</CEscientifickWFishingHours>", new OptionalSetting { IsOptional = true })
               .Add("^<CEgTDaysAtSea>|</CEgTDaysAtSea>")
               .Add("^<CEgTFishingDays>|</CEgTFishingDays>")
               .Add("^<CEgTFishingHours>|</CEgTFishingHours>", new OptionalSetting { IsOptional = true })
               .Add("^<CEnumberOfUniqueVessels>|</CEnumberOfUniqueVessels>")
               .Add("^<CEscientificFishingDaysRSE>|</CEscientificFishingDaysRSE>", new OptionalSetting { IsOptional = true })
               .Add("^<CEscientificFishingDaysQualitativeBias>|</CEscientificFishingDaysQualitativeBias>", new OptionalSetting { IsOptional = true });

            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
