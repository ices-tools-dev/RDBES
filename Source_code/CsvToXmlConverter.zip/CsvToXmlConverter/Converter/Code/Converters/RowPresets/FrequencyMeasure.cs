﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class FM : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "FM",
                opening: "\n<FM ",
                closure: "\n</FM>",
                escape: escapeProvider,
                startIndex: startIndex);

            set.Add(">^<FMstateOfProcessing>|</FMstateOfProcessing>")
               .Add("^<FMpresentation>|</FMpresentation>")
               .Add("^<FMclassMeasured>|</FMclassMeasured>")
               .Add("^<FMnumberAtUnit>|</FMnumberAtUnit>")
               .Add("^<FMtypeMeasured>|</FMtypeMeasured>")
               .Add("^<FMmethod>|</FMmethod>", new OptionalSetting { IsOptional = true})
               .Add("^<FMmeasurementEquipment>|</FMmeasurementEquipment>", new OptionalSetting { IsOptional = true})
               .Add("^<FMaccuracy>|</FMaccuracy>", new OptionalSetting { IsOptional = true})
               .Add("^<FMconversionFactorAssessment>|</FMconversionFactorAssessment>")
               .Add("^<FMtypeAssessment>|</FMtypeAssessment>")
               .Add("^<FMsampler>|</FMsampler>", new OptionalSetting { IsOptional = true})
               .Add("^<FMaddGrpMeasurement>|</FMaddGrpMeasurement>", new OptionalSetting { IsOptional = true})
               .Add("^<FMaddGrpMeasurementType>|</FMaddGrpMeasurementType>", new OptionalSetting { IsOptional = true});

            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
           // result.NumberofColumns = result.Count ;
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
