﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class SS : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "SS",
                opening: "\n<SS ",
                closure: "\n</SS>",
                escape: escapeProvider,
                startIndex: startIndex);


            set.Add(">^<SSsequenceNumber>|</SSsequenceNumber>")
               .Add("^<SSstratification>|</SSstratification>")
               .Add("^<SSobservationActivityType>|</SSobservationActivityType>")
               .Add("^<SScatchFraction>|</SScatchFraction>")
               .Add("^<SSobservationType>|</SSobservationType>")
               .Add("^<SSstratumName>|</SSstratumName>")
               .Add("^<SSclustering>|</SSclustering>")
               .Add("^<SSclusterName>|</SSclusterName>")
               .Add("^<SSsampler>|</SSsampler>", new OptionalSetting { IsOptional = true })
               .Add("^<SSspeciesListName>|</SSspeciesListName>")
               .Add("^<SSuseForCalculateZero>|</SSuseForCalculateZero>")
               .Add("^<SSnumberTotal>|</SSnumberTotal>", new OptionalSetting { IsOptional = true })
               .Add("^<SSnumberSampled>|</SSnumberSampled>", new OptionalSetting { IsOptional = true })
               .Add("^<SSselectionProb>|</SSselectionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<SSinclusionProb>|</SSinclusionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<SSselectionMethod>|</SSselectionMethod>")
               .Add("^<SSunitName>|</SSunitName>")
               .Add("^<SSselectionMethodCluster>|</SSselectionMethodCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<SSnumberTotalClusters>|</SSnumberTotalClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<SSnumberSampledClusters>|</SSnumberSampledClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<SSselectionProbCluster>|</SSselectionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<SSinclusionProbCluster>|</SSinclusionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<SSsampled>|</SSsampled>")
               .Add("^<SSreasonNotSampled>|</SSreasonNotSampled>", new OptionalSetting { IsOptional = true });


            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
