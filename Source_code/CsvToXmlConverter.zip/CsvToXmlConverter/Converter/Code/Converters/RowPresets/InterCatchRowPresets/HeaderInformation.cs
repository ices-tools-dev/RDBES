﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class IHI : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "HI",
                opening: "\n<HI ",
                closure: "\n</HI>",
                escape: escapeProvider,
                startIndex: startIndex);



            set.Add(">^<Country>|</Country>")
            .Add("^<Year>|</Year>")
            .Add("^<SeasonType>|</SeasonType>")
            .Add("^<Season>|</Season>")
            .Add("^<Fleet>|</Fleet>")
            .Add("^<AreaType>|</AreaType>")
            .Add("^<FishingArea>|</FishingArea>")
            .Add("^<DepthRange>|</DepthRange>", optionalSetting: new OptionalSetting { IsOptional = true })
            .Add("^<UnitEffort>|</UnitEffort>", optionalSetting: new OptionalSetting { IsOptional = true })
            .Add("^<Effort>|</Effort>", optionalSetting: new OptionalSetting { IsOptional = true })
            .Add("^<AreaQualifier>|</AreaQualifier	>", optionalSetting: new OptionalSetting { IsOptional = true })
            

                ;


            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
