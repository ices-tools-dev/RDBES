﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class ISD : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "SD",
                opening: "\n<SD ",
                closure: "\n</SD>",
                escape: escapeProvider,
                startIndex: startIndex);



            set.Add(">^<Country>|</Country>")
                .Add("^<Year>|</Year>")
                .Add("^<SeasonType>|</SeasonType>")
                .Add("^<Season>|</Season>")
                .Add("^<Fleet>|</Fleet>")
                .Add("^<AreaType>|</AreaType>")
                .Add("^<FishingArea>|</FishingArea>")
                .Add("^<DepthRange>|</DepthRange>")
                .Add("^<Species>|</Species>")
                .Add("^<Stock>|</Stock>")
                .Add("^<CatchCategory>|</CatchCategory>")
                .Add("^<ReportingCategory>|</ReportingCategory>")
                 .Add("^<Sex>|</Sex>", optionalSetting: new OptionalSetting { IsOptional = true})
                .Add("^<CANUMtype>|</CANUMtype>")
                .Add("^<AgeLength>|</AgeLength>")
                .Add("^<PlusGroup>|</PlusGroup>", optionalSetting: new OptionalSetting { IsOptional = true })
                .Add("^<SampledCatch>|</SampledCatch>", optionalSetting: new OptionalSetting { IsOptional = true})
               
                .Add("^<NumSamplesLngt>|</NumSamplesLngt>", optionalSetting: new OptionalSetting { IsOptional = true })
                .Add("^<NumLngtMeas>|</NumLngtMeas>", optionalSetting: new OptionalSetting { IsOptional = true})
                  .Add("^<NumSamplesAge>|</NumSamplesAge>", optionalSetting: new OptionalSetting { IsOptional = true })
                .Add("^<NumAgeMeas>|</NumAgeMeas>", optionalSetting: new OptionalSetting { IsOptional = true })
                  .Add("^<unitMeanWeight>|</unitMeanWeight>")
                .Add("^<unitCANUM>|</unitCANUM>")
                  .Add("^<UnitAgeOrLength>|</UnitAgeOrLength>")
                .Add("^<UnitMeanLength>|</UnitMeanLength>", optionalSetting: new OptionalSetting { IsOptional = true})
                  .Add("^<Maturity>|</Maturity>", optionalSetting: new OptionalSetting { IsOptional = true })
                    .Add("^<NumberCaught>|</NumberCaught>")
                  .Add("^<MeanWeight>|</MeanWeight>")
                .Add("^<MeanLength>|</MeanLength>", optionalSetting: new OptionalSetting { IsOptional = true })
                  .Add("^<varNumLanded>|</varNumLanded>", optionalSetting: new OptionalSetting { IsOptional = true })
                .Add("^<varWgtLanded>|</varWgtLanded	>", optionalSetting: new OptionalSetting { IsOptional = true })
                  .Add("^<varLgtLanded>|</varLgtLanded>", optionalSetting: new OptionalSetting { IsOptional = true })
               


                ;


            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
