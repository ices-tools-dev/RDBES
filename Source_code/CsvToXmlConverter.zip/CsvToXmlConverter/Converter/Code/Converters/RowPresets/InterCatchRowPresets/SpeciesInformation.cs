﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class ISI : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "SI",
                opening: "\n<SI ",
                closure: "\n</SI>",
                escape: escapeProvider,
                startIndex: startIndex);


            set.Add(">^<Country>|</Country>")
                       .Add("^<Year>|</Year>")
                       .Add("^<SeasonType>|</SeasonType>")
                       .Add("^<Season>|</Season>")
                       .Add("^<Fleet>|</Fleet>")
                       .Add("^<AreaType>|</AreaType>")
                       .Add("^<FishingArea>|</FishingArea>")
                       .Add("^<DepthRange>|</DepthRange>")
                       .Add("^<Species>|</Species>")
                       .Add("^<Stock>|</Stock>")
                       .Add("^<CatchCategory>|</CatchCategory>")
                       .Add("^<ReportingCategory>|</ReportingCategory>")
                       .Add("^<DataToFrom>|</DataToFrom>", optionalSetting: new OptionalSetting { IsOptional = true})
                       .Add("^<Usage>|</Usage>", optionalSetting: new OptionalSetting { IsOptional = true })
                       .Add("^<SamplesOrigin>|</SamplesOrigin>", optionalSetting: new OptionalSetting { IsOptional = true })
                       .Add("^<QualityFlag>|</QualityFlag>", optionalSetting: new OptionalSetting { IsOptional = true })
                       .Add("^<UnitCATON>|</UnitCATON>")

                       .Add("^<CATON>|</CATON>")
                       .Add("^<OffLandings>|</OffLandings>", optionalSetting: new OptionalSetting { IsOptional = true })
                       .Add("^<varCATON>|</varCATON>", optionalSetting: new OptionalSetting { IsOptional = true })
                       .Add("^<InfoFleet>|</InfoFleet>", optionalSetting: new OptionalSetting { IsOptional = true })
                       .Add("^<InfoStockCoordinator>|</InfoStockCoordinator>", optionalSetting: new OptionalSetting { IsOptional = true })
                       .Add("^<InfoGeneral>|</InfoGeneral>", optionalSetting: new OptionalSetting { IsOptional = true })
                

                ;


            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
