﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class LE : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "LE",
                opening: "\n<LE ",
                closure: "\n</LE>",
                escape: escapeProvider,
                startIndex: startIndex);



            set.Add(">^<LEencryptedVesselCode>|</LEencryptedVesselCode>", new OptionalSetting { IsOptional = true, WriteIfEmpty = ">" })
               .Add("^<LEstratification>|</LEstratification>")
               .Add("^<LEsequenceNumber>|</LEsequenceNumber>")
               .Add("^<LEhaulNumber>|</LEhaulNumber>", new OptionalSetting { IsOptional = true })
               .Add("^<LEstratumName>|</LEstratumName>")
               .Add("^<LEclustering>|</LEclustering>")
               .Add("^<LEclusterName>|</LEclusterName>")
               .Add("^<LEsampler>|</LEsampler>", new OptionalSetting { IsOptional = true })
               .Add("^<LEmixedTrip>|</LEmixedTrip>")
               .Add("^<LEcatchReg>|</LEcatchReg>")
               .Add("^<LElocode>|</LElocode>", new OptionalSetting { IsOptional = true })
               .Add("^<LElocationName>|</LElocationName>", new OptionalSetting { IsOptional = true })
               .Add("^<LElocationType>|</LElocationType>", new OptionalSetting { IsOptional = true })
               .Add("^<LEcountry>|</LEcountry>")
               .Add("^<LEdate>|</LEdate>", new OptionalSetting { IsOptional = true })
               .Add("^<LEtime>|</LEtime>", new OptionalSetting { IsOptional = true })
               .Add("^<LEexclusiveEconomicZoneIndicator>|</LEexclusiveEconomicZoneIndicator>", new OptionalSetting { IsOptional = true })
               .Add("^<LEarea>|</LEarea>")
               .Add("^<LErectangle>|</LErectangle>", new OptionalSetting { IsOptional = true })
               .Add("^<LEgsaSubarea>|</LEgsaSubarea>", new OptionalSetting { IsOptional = true })
               .Add("^<LEjurisdictionArea>|</LEjurisdictionArea>", new OptionalSetting { IsOptional = true })
               .Add("^<LEnationalFishingActivity>|</LEnationalFishingActivity>", new OptionalSetting { IsOptional = true })
               .Add("^<LEmetier5>|</LEmetier5>", new OptionalSetting { IsOptional = true })
               .Add("^<LEmetier6>|</LEmetier6>")
               .Add("^<LEgear>|</LEgear>")
               .Add("^<LEmeshSize>|</LEmeshSize>", new OptionalSetting { IsOptional = true })
               .Add("^<LEselectionDevice>|</LEselectionDevice>", new OptionalSetting { IsOptional = true })
               .Add("^<LEselectionDeviceMeshSize>|</LEselectionDeviceMeshSize>", new OptionalSetting { IsOptional = true })
               .Add("^<LEtargetSpecies>|</LEtargetSpecies>", new OptionalSetting { IsOptional = true })
               .Add("^<LEmitigationDevice>|</LEmitigationDevice>")
               .Add("^<LEgearDimensions>|</LEgearDimensions>", new OptionalSetting { IsOptional = true })
               .Add("^<LEnumberTotal>|</LEnumberTotal>", new OptionalSetting { IsOptional = true })
               .Add("^<LEnumberSampled>|</LEnumberSampled>", new OptionalSetting { IsOptional = true })
               .Add("^<LEselectionProb>|</LEselectionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<LEinclusionProb>|</LEinclusionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<LEselectionMethod>|</LEselectionMethod>")
               .Add("^<LEunitName>|</LEunitName>")
               .Add("^<LEselectionMethodCluster>|</LEselectionMethodCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<LEnumberTotalClusters>|</LEnumberTotalClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<LEnumberSampledClusters>|</LEnumberSampledClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<LEselectionProbCluster>|</LEselectionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<LEinclusionProbCluster>|</LEinclusionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<LEsampled>|</LEsampled>")
               .Add("^<LEreasonNotSampled>|</LEreasonNotSampled>", new OptionalSetting { IsOptional = true })
               .Add("^<LEfullTripAvailable>|</LEfullTripAvailable>", new OptionalSetting { IsOptional = true });

            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
