﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class SL : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "SL",
                opening: "\n<SL ",
                closure: "\n</SL>",
                escape: escapeProvider,
                startIndex: startIndex);


            set.Add(">^<SLcountry>|</SLcountry>")
               .Add("^<SLinstitute>|</SLinstitute>")
               .Add("^<SLspeciesListName>|</SLspeciesListName>")               
               .Add("^<SLyear>|</SLyear>")
               .Add("^<SLcatchFraction>|</SLcatchFraction>")                
               .Add("^<SLcommercialTaxon>|</SLcommercialTaxon>")
               .Add("^<SLspeciesCode>|</SLspeciesCode>");
               

            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
