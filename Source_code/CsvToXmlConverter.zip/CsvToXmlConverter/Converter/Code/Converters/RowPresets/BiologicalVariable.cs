﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class BV : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "BV",
                opening: "\n<BV ",
                closure: "\n</BV>",
                escape: escapeProvider,
                startIndex: startIndex);


            set.Add(">^<BVnationalUniqueFishId>|</BVnationalUniqueFishId>")
               .Add("^<BVstateOfProcessing>|</BVstateOfProcessing>")
               .Add("^<BVpresentation>|</BVpresentation>")
               .Add("^<BVstratification>|</BVstratification>")
               .Add("^<BVstratumName>|</BVstratumName>")
               .Add("^<BVtypeMeasured>|</BVtypeMeasured>")
               .Add("^<BVvalueMeasured>|</BVvalueMeasured>")
               .Add("^<BVvalueUnitOrScale>|</BVvalueUnitOrScale>")
               .Add("^<BVmethod>|</BVmethod>", new OptionalSetting { IsOptional = true })
               .Add("^<BVmeasurementEquipment>|</BVmeasurementEquipment>", new OptionalSetting { IsOptional = true })
               .Add("^<BVaccuracy>|</BVaccuracy>", new OptionalSetting { IsOptional = true })
               .Add("^<BVcertaintyQualitative>|</BVcertaintyQualitative>")
               .Add("^<BVcertaintyQuantitative>|</BVcertaintyQuantitative>", new OptionalSetting { IsOptional = true })
               .Add("^<BVconversionFactorAssessment>|</BVconversionFactorAssessment>")
               .Add("^<BVtypeAssessment>|</BVtypeAssessment>")
               .Add("^<BVnumberTotal>|</BVnumberTotal>", new OptionalSetting { IsOptional = true })
               .Add("^<BVnumberSampled>|</BVnumberSampled>", new OptionalSetting { IsOptional = true })
               .Add("^<BVselectionProb>|</BVselectionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<BVinclusionProb>|</BVinclusionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<BVselectionMethod>|</BVselectionMethod>")
               .Add("^<BVunitName>|</BVunitName>")
               .Add("^<BVsampler>|</BVsampler>", new OptionalSetting { IsOptional = true });


            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
