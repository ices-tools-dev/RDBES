﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class TE : IRowPreset
    {

        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "TE",
                opening: "\n<TE ",
                closure: "\n</TE>",
                escape: escapeProvider,
                startIndex: startIndex);


            set.Add(">^<TEsequenceNumber>|</TEsequenceNumber>")
               .Add("^<TEstratification>|</TEstratification>")
               .Add("^<TEtimeUnit>|</TEtimeUnit>")
               .Add("^<TEstratumName>|</TEstratumName>")
               .Add("^<TEclustering>|</TEclustering>")
               .Add("^<TEclusterName>|</TEclusterName>")
               .Add("^<TEsampler>|</TEsampler>", new OptionalSetting { IsOptional = true })
               .Add("^<TEnumberTotal>|</TEnumberTotal>", new OptionalSetting { IsOptional = true })
               .Add("^<TEnumberSampled>|</TEnumberSampled>", new OptionalSetting { IsOptional = true })
               .Add("^<TEselectionProb>|</TEselectionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<TEinclusionProb>|</TEinclusionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<TEselectionMethod>|</TEselectionMethod>")
               .Add("^<TEunitName>|</TEunitName>")
               .Add("^<TEselectionMethodCluster>|</TEselectionMethodCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<TEnumberTotalClusters>|</TEnumberTotalClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<TEnumberSampledClusters>|</TEnumberSampledClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<TEselectionProbCluster>|</TEselectionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<TEinclusionProbCluster>|</TEinclusionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<TEsampled>|</TEsampled>")
               .Add("^<TEreasonNotSampled>|</TEreasonNotSampled>", new OptionalSetting { IsOptional = true });

            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }

}
