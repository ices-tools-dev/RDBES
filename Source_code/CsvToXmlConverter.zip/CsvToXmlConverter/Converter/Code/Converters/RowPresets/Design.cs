﻿using System;
using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class DE : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {

            ConversionSet set = new ConversionSet(recordType: "DE",
                opening: "\n<DE ",
                closure: "\n</DE>",
                escape: escapeProvider,
                startIndex: startIndex);



            set.Add(">^<DEsamplingScheme>|</DEsamplingScheme>")
               .Add("^<DEsamplingSchemeType>|</DEsamplingSchemeType>")
               .Add("^<DEyear>|</DEyear>")
               .Add("^<DEstratumName>|</DEstratumName>")
               .Add("^<DEhierarchyCorrect>|</DEhierarchyCorrect>")
               .Add("^<DEhierarchy>|</DEhierarchy>")
               .Add("^<DEsampled>|</DEsampled>")
               .Add("^<DEreasonNotSampled>|</DEreasonNotSampled>", new OptionalSetting { IsOptional = true });


            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;

        }

        internal NestedRowConverter CreateConverter(object escapeProvider, int v)
        {
            throw new NotImplementedException();
        }
    }
}
