﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class FO : IRowPreset
    {

        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "FO",
                opening: "\n<FO ",
                closure: "\n</FO>",
                escape: escapeProvider,
                startIndex: startIndex);

            set.Add(">^<FOstratification>|</FOstratification>")
               .Add("^<FOsequenceNumber>|</FOsequenceNumber>")
               .Add("^<FOstratumName>|</FOstratumName>")
               .Add("^<FOclustering>|</FOclustering>")
               .Add("^<FOclusterName>|</FOclusterName>")
               .Add("^<FOsampler>|</FOsampler>", new OptionalSetting { IsOptional = true})
               .Add("^<FOaggregationLevel>|</FOaggregationLevel>")
               .Add("^<FOvalidity>|</FOvalidity>")
               .Add("^<FOcatchReg>|</FOcatchReg>")
               .Add("^<FOstartDate>|</FOstartDate>", new OptionalSetting { IsOptional = true })
               .Add("^<FOstartTime>|</FOstartTime>", new OptionalSetting { IsOptional = true })
               .Add("^<FOendDate>|</FOendDate>")
               .Add("^<FOendTime>|</FOendTime>", new OptionalSetting { IsOptional = true })
               .Add("^<FOduration>|</FOduration>", new OptionalSetting { IsOptional = true })
               .Add("^<FOdurationSource>|</FOdurationSource>")
               .Add("^<FOhandlingTime>|</FOhandlingTime>", new OptionalSetting { IsOptional = true })
               .Add("^<FOstartLat>|</FOstartLat>", new OptionalSetting { IsOptional = true })
               .Add("^<FOstartLon>|</FOstartLon>", new OptionalSetting { IsOptional = true })
               .Add("^<FOstopLat>|</FOstopLat>", new OptionalSetting { IsOptional = true })
               .Add("^<FOstopLon>|</FOstopLon>", new OptionalSetting { IsOptional = true })
               .Add("^<FOexclusiveEconomicZoneIndicator>|</FOexclusiveEconomicZoneIndicator>", new OptionalSetting { IsOptional = true })
               .Add("^<FOarea>|</FOarea>")
               .Add("^<FOrectangle>|</FOrectangle>", new OptionalSetting { IsOptional = true })
               .Add("^<FOgsaSubarea>|</FOgsaSubarea>", new OptionalSetting { IsOptional = true })
               .Add("^<FOjurisdictionArea>|</FOjurisdictionArea>", new OptionalSetting { IsOptional = true })
               .Add("^<FOfishingDepth>|</FOfishingDepth>", new OptionalSetting { IsOptional = true })
               .Add("^<FOwaterDepth>|</FOwaterDepth>", new OptionalSetting { IsOptional = true })
               .Add("^<FOnationalFishingActivity>|</FOnationalFishingActivity>", new OptionalSetting { IsOptional = true })
               .Add("^<FOmetier5>|</FOmetier5>", new OptionalSetting { IsOptional = true })
               .Add("^<FOmetier6>|</FOmetier6>", new OptionalSetting { IsOptional = true })
               .Add("^<FOgear>|</FOgear>")
               .Add("^<FOmeshSize>|</FOmeshSize>", new OptionalSetting { IsOptional = true })
               .Add("^<FOselectionDevice>|</FOselectionDevice>", new OptionalSetting { IsOptional = true })
               .Add("^<FOselectionDeviceMeshSize>|</FOselectionDeviceMeshSize>", new OptionalSetting { IsOptional = true })
               .Add("^<FOtargetSpecies>|</FOtargetSpecies>", new OptionalSetting { IsOptional = true })
               .Add("^<FOincidentalByCatchMitigationDeviceFirst>|</FOincidentalByCatchMitigationDeviceFirst>")
               .Add("^<FOincidentalByCatchMitigationDeviceTargetFirst>|</FOincidentalByCatchMitigationDeviceTargetFirst>")
               .Add("^<FOincidentalByCatchMitigationDeviceSecond>|</FOincidentalByCatchMitigationDeviceSecond>")
               .Add("^<FOincidentalByCatchMitigationDeviceTargetSecond>|</FOincidentalByCatchMitigationDeviceTargetSecond>")
               .Add("^<FOgearDimensions>|</FOgearDimensions>", new OptionalSetting { IsOptional = true })
               .Add("^<FOobservationCode>|</FOobservationCode>")
               .Add("^<FOnumberTotal>|</FOnumberTotal>", new OptionalSetting { IsOptional = true })
               .Add("^<FOnumberSampled>|</FOnumberSampled>", new OptionalSetting { IsOptional = true })
               .Add("^<FOselectionProb>|</FOselectionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<FOinclusionProb>|</FOinclusionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<FOselectionMethod>|</FOselectionMethod>")
               .Add("^<FOunitName>|</FOunitName>")
               .Add("^<FOselectionMethodCluster>|</FOselectionMethodCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<FOnumberTotalClusters>|</FOnumberTotalClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<FOnumberSampledClusters>|</FOnumberSampledClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<FOselectionProbCluster>|</FOselectionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<FOinclusionProbCluster>|</FOinclusionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<FOsampled>|</FOsampled>")
               .Add("^<FOreasonNotSampled>|</FOreasonNotSampled>", new OptionalSetting { IsOptional = true });



            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }

}
