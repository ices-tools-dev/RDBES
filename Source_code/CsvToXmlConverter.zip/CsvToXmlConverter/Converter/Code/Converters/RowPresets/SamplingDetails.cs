﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class SD : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "SD",
                opening: "\n<SD ",
                closure: "\n</SD>",
                escape: escapeProvider,
                startIndex: startIndex);


            set.Add(">^<SDcountry>|</SDcountry>")
                .Add("^<SDinstitution>|</SDinstitution>");
               

            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
