﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class VS : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "VS",
                opening: "\n<VS ",
                closure: "\n</VS>",
                escape: escapeProvider,
                startIndex: startIndex);

            set.Add(">^<VSsequenceNumber>|</VSsequenceNumber>")
               .Add("^<VSencryptedVesselCode>|</VSencryptedVesselCode>")
               .Add("^<VSstratification>|</VSstratification>")
               .Add("^<VSstratumName>|</VSstratumName>")
               .Add("^<VSclustering>|</VSclustering>")
               .Add("^<VSclusterName>|</VSclusterName>")
               .Add("^<VSsampler>|</VSsampler>", new OptionalSetting { IsOptional = true })
               .Add("^<VSnumberTotal>|</VSnumberTotal>", new OptionalSetting { IsOptional = true })
               .Add("^<VSnumberSampled>|</VSnumberSampled>", new OptionalSetting { IsOptional = true })
               .Add("^<VSselectionProb>|</VSselectionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<VSinclusionProb>|</VSinclusionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<VSselectionMethod>|</VSselectionMethod>")
               .Add("^<VSunitName>|</VSunitName>")
               .Add("^<VSselectionMethodCluster>|</VSselectionMethodCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<VSnumberTotalClusters>|</VSnumberTotalClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<VSnumberSampledClusters>|</VSnumberSampledClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<VSselectionProbCluster>|</VSselectionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<VSinclusionProbCluster>|</VSinclusionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<VSsampled>|</VSsampled>")
               .Add("^<VSreasonNotSampled>|</VSreasonNotSampled>", new OptionalSetting { IsOptional = true });


            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
