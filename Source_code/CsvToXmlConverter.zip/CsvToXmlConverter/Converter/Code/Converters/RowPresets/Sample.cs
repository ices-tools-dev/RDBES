﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class SA : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "SA",
                opening: "\n<SA ",
                closure: "\n</SA>",
                escape: escapeProvider,
                startIndex: startIndex);


            set.Add(">^<SAsequenceNumber>|</SAsequenceNumber>")
               .Add("^<SAparentSequenceNumber>|</SAparentSequenceNumber>", new OptionalSetting { IsOptional = true })
               .Add("^<SAstratification>|</SAstratification>")
               .Add("^<SAstratumName>|</SAstratumName>")
               .Add("^<SAspeciesCode>|</SAspeciesCode>")
               .Add("^<SAspeciesCodeFAO>|</SAspeciesCodeFAO>", new OptionalSetting { IsOptional = true })
               .Add("^<SAstateOfProcessing>|</SAstateOfProcessing>")
               .Add("^<SApresentation>|</SApresentation>")
               .Add("^<SAspecimensState>|</SAspecimensState>")
               .Add("^<SAcatchCategory>|</SAcatchCategory>")
               .Add("^<SAlandingCategory>|</SAlandingCategory>", new OptionalSetting { IsOptional = true })
               .Add("^<SAcommSizeCatScale>|</SAcommSizeCatScale>", new OptionalSetting { IsOptional = true })
               .Add("^<SAcommSizeCat>|</SAcommSizeCat>", new OptionalSetting { IsOptional = true })
               .Add("^<SAsex>|</SAsex>")
               .Add("^<SAexclusiveEconomicZoneIndicator>|</SAexclusiveEconomicZoneIndicator>", new OptionalSetting { IsOptional = true })
               .Add("^<SAarea>|</SAarea>", new OptionalSetting { IsOptional = true })
               .Add("^<SArectangle>|</SArectangle>", new OptionalSetting { IsOptional = true })
               .Add("^<SAgsaSubarea>|</SAgsaSubarea>", new OptionalSetting { IsOptional = true })
               .Add("^<SAjurisdictionArea>|</SAjurisdictionArea>", new OptionalSetting { IsOptional = true })
               .Add("^<SAnationalFishingActivity>|</SAnationalFishingActivity>", new OptionalSetting { IsOptional = true })
               .Add("^<SAmetier5>|</SAmetier5>", new OptionalSetting { IsOptional = true })
               .Add("^<SAmetier6>|</SAmetier6>", new OptionalSetting { IsOptional = true })
               .Add("^<SAgear>|</SAgear>", new OptionalSetting { IsOptional = true })
               .Add("^<SAmeshSize>|</SAmeshSize>", new OptionalSetting { IsOptional = true })
               .Add("^<SAselectionDevice>|</SAselectionDevice>", new OptionalSetting { IsOptional = true })
               .Add("^<SAselectionDeviceMeshSize>|</SAselectionDeviceMeshSize>", new OptionalSetting { IsOptional = true })
               .Add("^<SAunitType>|</SAunitType>")
               .Add("^<SAtotalWeightLive>|</SAtotalWeightLive>", new OptionalSetting { IsOptional = true })
               .Add("^<SAsampleWeightLive>|</SAsampleWeightLive>", new OptionalSetting { IsOptional = true })
               .Add("^<SAnumberTotal>|</SAnumberTotal>", new OptionalSetting { IsOptional = true })
               .Add("^<SAnumberSampled>|</SAnumberSampled>", new OptionalSetting { IsOptional = true })
               .Add("^<SAselectionProb>|</SAselectionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<SAinclusionProb>|</SAinclusionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<SAselectionMethod>|</SAselectionMethod>")
               .Add("^<SAunitName>|</SAunitName>")
               .Add("^<SAlowerHierarchy>|</SAlowerHierarchy>")
               .Add("^<SAsampler>|</SAsampler>", new OptionalSetting { IsOptional = true })
               .Add("^<SAsampled>|</SAsampled>")
               .Add("^<SAreasonNotSampledFM>|</SAreasonNotSampledFM>", new OptionalSetting { IsOptional = true })
               .Add("^<SAreasonNotSampledBV>|</SAreasonNotSampledBV>", new OptionalSetting { IsOptional = true })
               .Add("^<SAtotalWeightMeasured>|</SAtotalWeightMeasured>", new OptionalSetting { IsOptional = true })
               .Add("^<SAsampleWeightMeasured>|</SAsampleWeightMeasured>", new OptionalSetting { IsOptional = true })
               .Add("^<SAconversionFactorMeasLive>|</SAconversionFactorMeasLive>", new OptionalSetting { IsOptional = true });


            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
