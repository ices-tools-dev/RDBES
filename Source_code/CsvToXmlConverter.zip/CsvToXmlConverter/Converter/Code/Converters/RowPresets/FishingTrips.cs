﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class FT : IRowPreset
    {

        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "FT",
                opening: "\n<FT ",
                closure: "\n</FT>",
                escape: escapeProvider,
                startIndex: startIndex);


            set.Add(">^<FTencryptedVesselCode>|</FTencryptedVesselCode>")
               .Add("^<FTsequenceNumber>|</FTsequenceNumber>")
               .Add("^<FTstratification>|</FTstratification>")
               .Add("^<FTstratumName>|</FTstratumName>")
               .Add("^<FTclustering>|</FTclustering>")
               .Add("^<FTclusterName>|</FTclusterName>")
               .Add("^<FTsampler>|</FTsampler>")
               .Add("^<FTsamplingType>|</FTsamplingType>")
               .Add("^<FTnumberOfHaulsOrSets>|</FTnumberOfHaulsOrSets>", new OptionalSetting { IsOptional = true })
               .Add("^<FTdepartureLocation>|</FTdepartureLocation>", new OptionalSetting { IsOptional = true })
               .Add("^<FTdepartureDate>|</FTdepartureDate>", new OptionalSetting { IsOptional = true })
               .Add("^<FTdepartureTime>|</FTdepartureTime>", new OptionalSetting { IsOptional = true })
               .Add("^<FTarrivalLocation>|</FTarrivalLocation>")
               .Add("^<FTarrivalDate>|</FTarrivalDate>")
               .Add("^<FTarrivalTime>|</FTarrivalTime>", new OptionalSetting { IsOptional = true })
               .Add("^<FTnumberTotal>|</FTnumberTotal>", new OptionalSetting { IsOptional = true })
               .Add("^<FTnumberSampled>|</FTnumberSampled>", new OptionalSetting { IsOptional = true })
               .Add("^<FTselectionProb>|</FTselectionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<FTinclusionProb>|</FTinclusionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<FTselectionMethod>|</FTselectionMethod>")
               .Add("^<FTunitName>|</FTunitName>")
               .Add("^<FTselectionMethodCluster>|</FTselectionMethodCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<FTnumberTotalClusters>|</FTnumberTotalClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<FTnumberSampledClusters>|</FTnumberSampledClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<FTselectionProbCluster>|</FTselectionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<FTinclusionProbCluster>|</FTinclusionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<FTsampled>|</FTsampled>")
               .Add("^<FTreasonNotSampled>|</FTreasonNotSampled>", new OptionalSetting { IsOptional = true });



            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }

}
