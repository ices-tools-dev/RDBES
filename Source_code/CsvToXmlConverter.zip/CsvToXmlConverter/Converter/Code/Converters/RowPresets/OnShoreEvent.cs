﻿using RDBES.Code.Parts;

namespace RDBES.Code.Converters.RowPresets
{
    public class OS : IRowPreset
    {
        public NestedRowConverter CreateConverter(IEscape escapeProvider, int startIndex = 1)
        {
            ConversionSet set = new ConversionSet(recordType: "OS",
                opening: "\n<OS ",
                closure: "\n</OS>",
                escape: escapeProvider,
                startIndex: startIndex);



            set.Add(">^<OSsequenceNumber>|</OSsequenceNumber>")
               .Add("^<OSstratification>|</OSstratification>")
               .Add("^<OSlocode>|</OSlocode>")
               .Add("^<OSlocationName>|</OSlocationName>")
               .Add("^<OSlocationType>|</OSlocationType>", new OptionalSetting { IsOptional = true })
               .Add("^<OSsamplingDate>|</OSsamplingDate>")
               .Add("^<OSsamplingTime>|</OSsamplingTime>", new OptionalSetting { IsOptional = true })
               .Add("^<OSstratumName>|</OSstratumName>")
               .Add("^<OSclustering>|</OSclustering>")
               .Add("^<OSclusterName>|</OSclusterName>")
               .Add("^<OSsampler>|</OSsampler>", new OptionalSetting { IsOptional = true })
               .Add("^<OStimeUnit>|</OStimeUnit>", new OptionalSetting { IsOptional = true })
               .Add("^<OStimeValue>|</OStimeValue>", new OptionalSetting { IsOptional = true })
               .Add("^<OSnumberTotal>|</OSnumberTotal>", new OptionalSetting { IsOptional = true })
               .Add("^<OSnumberSampled>|</OSnumberSampled>", new OptionalSetting { IsOptional = true })
               .Add("^<OSselectionProb>|</OSselectionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<OSinclusionProb>|</OSinclusionProb>", new OptionalSetting { IsOptional = true })
               .Add("^<OSselectionMethod>|</OSselectionMethod>")
               .Add("^<OSunitName>|</OSunitName>", new OptionalSetting { IsOptional = true })
               .Add("^<OSselectionMethodCluster>|</OSselectionMethodCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<OSnumberTotalClusters>|</OSnumberTotalClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<OSnumberSampledClusters>|</OSnumberSampledClusters>", new OptionalSetting { IsOptional = true })
               .Add("^<OSselectionProbCluster>|</OSselectionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<OSinclusionProbCluster>|</OSinclusionProbCluster>", new OptionalSetting { IsOptional = true })
               .Add("^<OSsampled>|</OSsampled>")
               .Add("^<OSreasonNotSampled>|</OSreasonNotSampled>", new OptionalSetting { IsOptional = true });

            NestedRowConverter result = new NestedRowConverter(set, escapeProvider);
            result.LineNumberElement = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };
            return result;
        }
    }
}
