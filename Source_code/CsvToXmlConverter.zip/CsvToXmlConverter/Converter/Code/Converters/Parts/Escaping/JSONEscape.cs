﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RDBES.Code.Parts.Escaping
{
    public class JSONEscape : IEscape
    {
        private StringBuilder sb = new StringBuilder();

        public string Escape(string val)
        {
            sb=new StringBuilder(val.Length);
            char c;
            for (var index = 0; index < val.Length; index++)
            {
                c = val[index];
                switch (c)
                {
                    case '\t': sb.Append("\\t"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '"':
                    case '\\':
                        sb.Append('\\');
                        sb.Append(c);
                        break;
                    default:
                        sb.Append(c);
                        break;
                }
            }
            return sb.ToString();
        }

    }
}
