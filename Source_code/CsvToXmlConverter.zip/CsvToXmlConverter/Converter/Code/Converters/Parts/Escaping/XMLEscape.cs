﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RDBES.Code.Parts.Escaping
{
    public class XMLEscape : IEscape
    {

        private StringBuilder sb = new StringBuilder();

        public string Escape(string val)
        {
            sb = new StringBuilder(val.Length);
            char c;
            for (var index = 0; index < val.Length; index++)
            {
                c = val[index];
                switch (c)
                {
                    case '<': sb.Append("&lt;"); break;
                    case '"': sb.Append("&quot;"); break;
                    case '&': sb.Append("&amp;"); break;
                    case '>': sb.Append("&gt;"); break;
                    default:
                        sb.Append(c);
                        break;
                }
            }
            return sb.ToString();
        }
    }
}
