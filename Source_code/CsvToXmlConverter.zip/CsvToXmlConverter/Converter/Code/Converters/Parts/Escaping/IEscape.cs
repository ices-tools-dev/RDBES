﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RDBES.Code.Parts
{
    /// <summary>
    /// Interface defining a single method: Escape - to be implemented with custom logic for any specific case which may be needed - like  XML or JSON
    /// </summary>
    public interface IEscape
    {
        string Escape(string val);
    }
}
