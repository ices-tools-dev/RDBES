﻿using RDBES.Code.Tools;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RDBES.Code.Parts
{
    /// <summary>
    ///  A set of NestedRowConverter classes - provides a means to convert files with several different XML types located on a same level
    /// </summary>
    public class NestedRowConvertersSet : List<NestedRowConverter>
    {
        public bool ConvertSection(ConverterStreamReader sourceStream, StreamWriter resultStream)
        {
            if (!sourceStream.Completed)
            {
                foreach (var nestedRowConverter in this)
                {
                    if (nestedRowConverter.ConvertSection(sourceStream, resultStream))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public void Init(char separator, bool quoted)
        {
            foreach (var item in this)
            {
                item.Init(separator, quoted);
            }
        }

        public ConversionItem LineNumberElement
        {
            set
            {
                foreach (var item in this)
                {
                    item.LineNumberElement = value;
                }
            }
        }

        /// <summary>
        /// A convenience method, buids a hierarchy automatically from the provided array of ConversionSet arguments order of building is top to bottom.
        /// Example : Elem1, Elem2, Elem3 are ordered in hierarchy:
        ///  Elem1
        ///   -- Elem2
        ///    -- Elem3
        ///    etc...
        /// </summary>
        /// <param name="args"></param>
        public void Fill(params NestedRowConverter[] args)
        {
            if (args.Length == 0)
            {
                throw new ArgumentException("This method expects at least one argument!");
            }
            this.Clear();
            NestedRowConverter last = null;
            foreach (NestedRowConverter currentSet in args)
            {
                if (last != null)
                {
                    last.AddChilds(currentSet);
                }
                last = currentSet;
            }

            this.Add(args[0]);
        }

        /// <summary>
        /// A convenience method, adds a set of items from the provided array of ConversionSet arguments
        /// Example : Elem1, Elem2, Elem3 are ordered at the same level:
        ///  Elem1
        ///  Elem2
        ///  Elem3
        ///    etc...
        /// </summary>
        /// <param name="args"></param>
        public void AddMultiple(params NestedRowConverter[] args)
        {
            if (args.Length == 0)
            {
                throw new ArgumentException("This method expects at least one argument!");
            }
            this.Clear();
            foreach (NestedRowConverter currentSet in args)
            {
                this.Add(currentSet);
            }
        }

        public string ShowHierarchy()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var item in this)
            {
                item.ShowHierarchy(sb, 0);
            }
            return sb.ToString();
        }

    }
}