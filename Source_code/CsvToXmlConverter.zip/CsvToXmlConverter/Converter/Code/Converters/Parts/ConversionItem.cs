﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace RDBES.Code.Parts
{
    
    public class ConversionItem
    {
        /// <summary>
        /// The resulting content is formatted as LeftPart + content + RightPart + AllwaysIncludePart
        /// </summary>
        public string LeftPart;
        public string RightPart;
        /// <summary>
        /// This string will be allways included at the end, if not empty
        /// </summary>
        public string AllwaysIncludePart = string.Empty;
        /// <summary>
        /// Provides an option to skip an output, if the provided values is an empty string, and also to write different output instead
        /// </summary>
        public OptionalSetting OptionalSetting = new OptionalSetting();
        /// <summary>
        /// Custom escape logic
        /// </summary>
        public IEscape EscapeProvider;

        public void WriteContent(string value, StreamWriter sw)
        {
            if (!OptionalSetting.IsOptional || !string.IsNullOrEmpty(value))
            {
                sw.Write(LeftPart);
                if (EscapeProvider != null)
                {
                     sw.Write(EscapeProvider.Escape(value));
                    
                }
                else
                {
                    sw.Write(value);
                }

                sw.Write(RightPart);
            }
            else if (OptionalSetting.IsOptional)
            {
                sw.Write(OptionalSetting.WriteIfEmpty);
            }
            sw.Write(AllwaysIncludePart);
        }
      
    }
}
