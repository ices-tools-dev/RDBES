﻿namespace RDBES.Code.Parts
{
    public class OptionalSetting
    {
        public bool IsOptional { get; set; } = false;
        /// <summary>
        /// Provides a way to write something (like a closing ">") instead of just skipping an optional element when it is empty.
        /// </summary>
        public string WriteIfEmpty { get; set; } = string.Empty;
    }
}
