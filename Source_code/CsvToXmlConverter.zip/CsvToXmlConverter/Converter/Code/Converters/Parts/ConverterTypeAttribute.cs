﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RDBES.Code.Parts
{
    
    public class ConverterTypeAttribute : Attribute
    {
        public ConversionType DataType { get; set; }

        public ConverterTypeAttribute(ConversionType type)
        {
            DataType = type;
        }

    }
}
