﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RDBES.Code.Parts
{

    public class ConversionSet : List<ConversionItem>
    {
        protected IEscape escapeProvider = null;

        public string RecordType;

        public int StartIndex;
        public string Opening;
        public string Closure;

        public ConversionSet(string recordType, string opening, string closure, IEscape escape = null, int startIndex = 1)
        {
            this.RecordType = recordType;
            this.Opening = opening;
            this.Closure = closure;
            this.StartIndex = startIndex;
            this.escapeProvider = escape;
        }

        public ConversionSet Add(string leftPart, string righPart, OptionalSetting optionalSetting = null, string allwaysInclude = "")
        {
            this.Add(new ConversionItem
            {
                LeftPart = leftPart,
                RightPart = righPart,
                OptionalSetting = optionalSetting ?? new OptionalSetting(),
                EscapeProvider = escapeProvider,
                AllwaysIncludePart = allwaysInclude
            });
            return this;
        }


        public ConversionSet Add(string parts, OptionalSetting optionalSetting = null, string allwaysInclude = "")
        {
            string[] leftAndRight = parts.Replace("^", Environment.NewLine).Split('|');
            if (leftAndRight.Length != 2)
            {
                throw new ArgumentException(string.Format("Provided 'parts' parameter:({0}) is not well formatted", parts));
            }
            this.Add(
                leftAndRight[0],
                leftAndRight[1],
                optionalSetting ?? new OptionalSetting(),
                allwaysInclude);

            return this;
        }
    }
}
