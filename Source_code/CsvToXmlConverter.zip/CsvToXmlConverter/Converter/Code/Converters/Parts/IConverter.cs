﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace RDBES.Code.Parts
{
   
    public interface IConverter
    {
        void Convert(string pathToCsvSource, string pathToResult);
        void Convert(StreamReader csvSourceStream, StreamWriter resultStream);
        string ShowHierarchy();

    }
}
