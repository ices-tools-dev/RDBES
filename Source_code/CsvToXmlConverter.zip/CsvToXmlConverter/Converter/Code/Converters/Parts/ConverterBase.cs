﻿using RDBES.Code.Tools;
using System;
using System.IO;
using RDBES.Code.Extenions;
using RDBES.Code.Common;
using System.Linq;
using RDBES.Code.Converters.RowPresets;
using System.Collections.Generic;
using System.Text;

namespace RDBES.Code.Parts
{

    public abstract class ConverterBase : IConverter
    {

	   protected NestedRowConvertersSet workerConverterSet = new NestedRowConvertersSet();

	   protected ConverterStreamReader customReader;

	   protected IEscape escapeProvider;


	   protected abstract string FileOpening { get; }

	   protected abstract string FileClosure { get; }

	   public char Separator { get; protected set; }

	   /// <summary>
	   /// Indicates if the values in the CSV are wrapped with double quotes
	   /// </summary>
	   public bool Quoted { get; protected set; }

	   public string ShowHierarchy()
	   {
		  return workerConverterSet.ShowHierarchy();
	   }


	   public virtual void Convert(string pathToCsvSource, string pathToResult)
	   {
		  using (FileStream fs = File.Open(pathToCsvSource, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
		  {
			 using (StreamReader sr = new StreamReader(fs))
			 {
				using (FileStream fw = File.Open(pathToResult, FileMode.Create, FileAccess.Write, FileShare.Read))
				{
				    using (StreamWriter sw = new StreamWriter(fw, System.Text.Encoding.UTF8))
				    {
					   Convert(sr, sw);
				    }
				}
			 }
		  }
	   }

	   public virtual void Convert(StreamReader csvSourceStream, StreamWriter resultStream)
	   {
		  ProcessDetection(csvSourceStream);
		  workerConverterSet.Init(Separator, Quoted);

		  customReader = new ConverterStreamReader(csvSourceStream);

		  resultStream.Write(FileOpening);
		  StringBuilder sbProblems = new StringBuilder();
		  while (!customReader.Completed)
		  {
			 if (!workerConverterSet.ConvertSection(customReader, resultStream))
			 {
				string recordType = string.Empty;
				var rowParts = customReader.RowToProces.Split(new char[] { this.Separator }, StringSplitOptions.RemoveEmptyEntries);
				if (rowParts.Length > 0)
				{
				    recordType = rowParts[0];
				    if (Quoted)
				    {
					   recordType = recordType.RemoveQuotes();
				    }
				}
				customReader.RowProcessed();
				sbProblems.AppendLine($"Problem at line:{customReader.CurrentRowIndex + 1} - unrecognized record type:'{recordType}'");
			 }
		  }
		  if (sbProblems.Length > 0)
		  {
			 throw new Exception(sbProblems.ToString());
		  }
		  resultStream.Write(FileClosure);
		  resultStream.Flush();
	   }

	   /// <summary>
	   /// Instantiates and calls a CreateConverter method from a class implementing IRowPreset interface
	   /// </summary>
	   /// <typeparam name="PresetType"></typeparam>
	   /// <param name="escapeProvider"></param>
	   /// <param name="startIndex"></param>
	   /// <returns></returns>
	   public static NestedRowConverter GetPreset<PresetType>(IEscape escapeProvider, int startIndex = 1) where PresetType : IRowPreset, new()
	   {
		  return new PresetType().CreateConverter(escapeProvider, startIndex);
	   }

	   protected void ProcessDetection(StreamReader sr)
	   {
		  string firstLine = sr.ReadLine();
		  DetectQuoted(firstLine);
		  DetectSeparator(firstLine);
		  sr.ResetToStart();
	   }
	   protected void DetectQuoted(string line)
	   {
		  Quoted = line.StartsWith(Constants.QUOTE);
		  Console.WriteLine("Quoted:{0}", Quoted);
	   }

	   protected void DetectSeparator(string line)
	   {
		  foreach (var item in workerConverterSet)
		  {
			 string firstItem = Quoted ? item.RecordType.WrapInQuotes() : item.RecordType;
			 if (line.StartsWith(firstItem))
			 {
				Separator = line.Substring(firstItem.Length, 1).ToCharArray()[0];
				Console.WriteLine("Separator:'{0}'", Separator);
				return;
			 }
		  }
		  throw new Exception(string.Format("Unable to detect separator (first line is expected to start with one of:'{0}')",
			  string.Join(",", workerConverterSet.Select(itm => itm.RecordType))));
	   }


    }
}