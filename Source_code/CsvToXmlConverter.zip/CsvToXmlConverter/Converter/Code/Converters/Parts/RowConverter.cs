﻿using RDBES.Code.Common;
using RDBES.Code.Extenions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace RDBES.Code.Parts
{
    /// <summary>
    /// Contains functionality for conversion of a singe CSV row to a different structure, defined by the contained "ConversionItem"s
    /// </summary>
    public class RowConverter : ConversionSet, IRowConverter
    {
        private char[] splitParam;
        protected char separator;
        protected bool quoted = false;
        /// <summary>
        /// Separator to be placed between top level elements, could be useful for some cases like converting to JSON
        /// </summary>
        public string ElementSeparator = string.Empty;

        /// <summary>
        /// In case the line number of the CSV should be included in the output, set the formatting ConversionItem here
        /// </summary>
        public ConversionItem LineNumberElement = null;

        protected RowConverter(string recordType, string opening, string closure, string elementSeparator, IEscape escape, int startIndex = 1)
            : base(recordType, opening, closure, escape, startIndex)
        {
            this.ElementSeparator = elementSeparator;
        }

        public virtual void Init(char separator, bool quoted)
        {
            this.separator = separator;
            this.splitParam = new char[] { this.separator };
            this.quoted = quoted;
        }

        public void ConvertRow(string rowContent, StreamWriter sw, int rowIndex)
        {
            var rowParts = rowContent.Split(splitParam);
            sw.Write(this.Opening);
            if (this.LineNumberElement != null)
            {
                this.LineNumberElement.WriteContent(rowIndex.ToString(), sw);
            }
            int itemIndex = -1;
            for (int csvFieldIndex = StartIndex; csvFieldIndex < rowParts.Length; csvFieldIndex++)
            {
                    itemIndex++;
                if (itemIndex >= this.Count)
                {
                    break;
                  //  throw new Exception($"{rowParts[0]} has more field than the difined number of fields");
                }
                try
                {
                    if (quoted && rowParts[csvFieldIndex].StartsWith(Constants.QUOTE))
                    {
                        rowParts[csvFieldIndex] = rowParts[csvFieldIndex].RemoveQuotes();
                    }
                    this[itemIndex].WriteContent(rowParts[csvFieldIndex], sw);
                }
                catch (Exception excp)
                {
                    throw new Exception(
                    string.Format(
@"
--------------
An exception ocurred while processing line with index:{0}
RecordType:{1}
StartIndex:{2}
csvFieldIndex:{3}
itemIndex:{4}
Line content:
{5}
--------------
",
                            rowIndex, this.RecordType, StartIndex, csvFieldIndex, itemIndex, rowContent), excp);
                }
            }
        }

        public void Close(StreamWriter sw)
        {
            if (!string.IsNullOrEmpty(this.Closure))
            {
                sw.Write(this.Closure);
            }
        }

    }
}