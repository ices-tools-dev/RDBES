﻿using RDBES.Code.Converters.RowPresets;
using RDBES.Code.Parts.Escaping;

namespace RDBES.Code.Parts
{
    public abstract class HierarchyBase : ConverterBase
    {
        protected override string FileOpening
        {
            get
            {
                return
 $@"<?xml version=""1.0"" encoding=""utf-8""?>
<RDBES>
  <{GetFullHierarchyName}>";
            }
        }

        protected override string FileClosure
        {
            get
            {
                return $@"
  </{GetFullHierarchyName}>
</RDBES>
";
            }
        }

        protected string GetFullHierarchyName
        {
            get
            {
                return string.Concat(this.GetType().Name);
            }
        }

        public ConversionItem lineNumberAttribute;

        public NestedRowConverter converterDE;
        public NestedRowConverter converterSD;
        public NestedRowConverter converterVS;
        public NestedRowConverter converterFT;
        public NestedRowConverter converterFO;
        public NestedRowConverter converterSS;
        public NestedRowConverter converterSA;
        public NestedRowConverter converterVD;
        public NestedRowConverter converterTE;
        public NestedRowConverter converterOS;
        public NestedRowConverter converterLE;
        public NestedRowConverter converterFM;
        public NestedRowConverter converterBV;
        public NestedRowConverter converterLO;
        public NestedRowConverter converterSL;
        public NestedRowConverter converterCL;
        public NestedRowConverter converterCE;

        #region IC type
        public NestedRowConverter converterISD;
        public NestedRowConverter converterISI;
        public NestedRowConverter converterIHI;
        #endregion 

        public HierarchyBase() : this(new XMLEscape()) { }


        protected HierarchyBase(IEscape escape)
        {
            InitEscape(escape);
            SetupConversion();
        }

        protected void InitEscape(IEscape escape)
        {
            escapeProvider = escape;
            converterDE = (new DE()).CreateConverter(escapeProvider, 1);
            converterSD = (new SD()).CreateConverter(escapeProvider, 1);
            converterVS = (new VS()).CreateConverter(escapeProvider, 1);
            converterFT = (new FT()).CreateConverter(escapeProvider, 1);
            converterFO = (new FO()).CreateConverter(escapeProvider, 1);
            converterSS = (new SS()).CreateConverter(escapeProvider, 1);
            converterSA = (new SA()).CreateConverter(escapeProvider, 1);
            converterVD = (new VD()).CreateConverter(escapeProvider, 1);
            converterTE = (new TE()).CreateConverter(escapeProvider, 1);
            converterOS = (new OS()).CreateConverter(escapeProvider, 1);
            converterLE = (new LE()).CreateConverter(escapeProvider, 1);
            converterFM = (new FM()).CreateConverter(escapeProvider, 1);
            converterBV = (new BV()).CreateConverter(escapeProvider, 1);
            converterLO = (new LO()).CreateConverter(escapeProvider, 1);
            converterSL = (new SL()).CreateConverter(escapeProvider, 1);

            converterCL = (new CL()).CreateConverter(escapeProvider, 1);
            converterCE = (new CE()).CreateConverter(escapeProvider, 1);


            converterISI = (new ISI()).CreateConverter(escapeProvider, 1);
            converterISD = (new ISD()).CreateConverter(escapeProvider, 1);
            converterIHI = (new IHI()).CreateConverter(escapeProvider, 1);

            lineNumberAttribute = new ConversionItem { LeftPart = "ln=\"", RightPart = "\" " };

            converterDE.LineNumberElement = lineNumberAttribute;
            converterSD.LineNumberElement = lineNumberAttribute;
            converterVS.LineNumberElement = lineNumberAttribute;
            converterFT.LineNumberElement = lineNumberAttribute;
            converterFO.LineNumberElement = lineNumberAttribute;
            converterSS.LineNumberElement = lineNumberAttribute;
            converterSA.LineNumberElement = lineNumberAttribute;
            converterVD.LineNumberElement = lineNumberAttribute;
            converterTE.LineNumberElement = lineNumberAttribute;
            converterOS.LineNumberElement = lineNumberAttribute;
            converterLE.LineNumberElement = lineNumberAttribute;

            converterFM.LineNumberElement = lineNumberAttribute;

            converterBV.LineNumberElement = lineNumberAttribute;

            converterLO.LineNumberElement = lineNumberAttribute;
            converterSL.LineNumberElement = lineNumberAttribute;

            converterCE.LineNumberElement = lineNumberAttribute;
            converterCL.LineNumberElement = lineNumberAttribute;

            converterISD.LineNumberElement = lineNumberAttribute;
            converterIHI.LineNumberElement = lineNumberAttribute;
            converterISI.LineNumberElement = lineNumberAttribute;
        }

        protected abstract void SetupConversion();

        protected NestedRowConverter[] CreateSecondaryLevel()
        {
            NestedRowConverter[] result = new NestedRowConverter[2] {
                converterFM.AddChilds(converterBV),
                converterBV};

            return result;
        }

    }
}
