﻿using RDBES.Code.Common;
using RDBES.Code.Extenions;
using RDBES.Code.Tools;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RDBES.Code.Parts
{
    
    public class NestedRowConverter : RowConverter
    {
        private Dictionary<string, NestedRowConverter> subItems = new Dictionary<string, NestedRowConverter>();

        public NestedRowConverter(ConversionSet mainSet, IEscape escape, List<NestedRowConverter> childSets = null, string elementSeparator = "")
            : base(mainSet.RecordType, mainSet.Opening, mainSet.Closure, elementSeparator, escape)
        {
            foreach (var item in mainSet)
            {
                this.Add(item);
                this.Opening = mainSet.Opening;
                this.Closure = mainSet.Closure;
                this.RecordType = mainSet.RecordType;
                this.StartIndex = mainSet.StartIndex;
            }
            if (childSets != null)
            {
                foreach (var child in childSets)
                {

                    AddChilds(child);
                }
            }
        }

        public override void Init(char separator, bool quoted)
        {
            base.Init(separator, quoted);
            foreach (var item in subItems.Values)
            {
                item.Init(separator, quoted);
            }

        }

        public NestedRowConverter AddChilds(params NestedRowConverter[] args)
        {
            foreach (var item in args)
            {
                if (item != null)
                {
                    this.subItems.Add(item.RecordType, item);
                }
            }
            return this;
        }
       

        public bool ConvertSection(ConverterStreamReader sourceStream, StreamWriter resultStream)
        {
            bool converted = false;
            if (!sourceStream.Completed)
            {
                if (string.Empty.Equals(this.RecordType) || sourceStream.RowToProces.StartsWith(quoted ? this.RecordType.WrapInQuotes() : this.RecordType, StringComparison.Ordinal))
                {
                    if (sourceStream.CurrentRowIndex > 0)
                    {
                        resultStream.Write(ElementSeparator);
                    }
                    this.ConvertRow(sourceStream.RowToProces, resultStream, sourceStream.CurrentRowIndex + 1);
                    sourceStream.RowProcessed();
                    converted = true;
                }
                // import all occurences of child rows
                while (true)
                {
                    if (ConvertInChildren(sourceStream, resultStream))
                    {
                        converted = true;
                    }
                    else
                    {
                        break;
                    }
                }
                if (converted)
                {
                    this.Close(resultStream);
                }
            }
            return converted;
        }

        public void ShowHierarchy(StringBuilder sb, int padding)
        {
            sb.Append(new string(' ', padding));
            if (padding > 0)
            {
                sb.Append("-");
            }
            sb.AppendLine(this.RecordType);
            foreach (var item in subItems.Values)
            {
                item.ShowHierarchy(sb, padding + 2);
            }
        }

        private bool ConvertInChildren(ConverterStreamReader sourceStream, StreamWriter resultStream)
        {
            if (!sourceStream.Completed)
            {
                string currentRecordType = sourceStream.RowToProces.Substring(0, sourceStream.RowToProces.IndexOf(separator)).ToUpper();
                if (quoted)
                {
                    currentRecordType = currentRecordType.RemoveQuotes();
                }
                if (subItems.ContainsKey(currentRecordType))
                {
                    return subItems[currentRecordType].ConvertSection(sourceStream, resultStream);
                }
            }
            return false;
        }


    }
}
