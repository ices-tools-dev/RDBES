﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RDBES.Code.Parts
{
    
    public enum ConversionType : byte
    {
        H1,
        H2,
        H3,
        H4,
        H5,
        H6,
        H7,
        H8,
        H9,
        H10,
        H11,
        H12,
        H13,
        HCE,
        HCL,
        HSL,
        HVD,
        HIC
      

    }

}
