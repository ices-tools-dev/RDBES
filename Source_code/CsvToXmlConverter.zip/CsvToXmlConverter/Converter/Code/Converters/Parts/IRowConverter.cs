﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace RDBES.Code.Parts
{
   
    public interface IRowConverter
    {
        void ConvertRow(string rowContent, StreamWriter sw, int rowIndex);
    }
}
