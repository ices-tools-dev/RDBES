﻿using RDBES.Code.Parts;

namespace RDBES.Converters
{
    [ConverterType(ConversionType.HIC)]
    public class HIC : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterIHI.AddChilds(
                    converterISI.AddChilds(

                        converterISD.AddChilds(

                        

                                        )
                                )
                            )
                        
                    
                )
            ;

        }

    }
}
