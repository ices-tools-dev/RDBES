﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace RDBES.Code.Tools
{
    /// <summary>
    /// Stream reader wrapper, simplifies the reading from the stream exposing just a single row from the underlaying csv file
    /// </summary>
    public class ConverterStreamReader : IDisposable
    {
        private StreamReader reader;
        private string currentRow = string.Empty;
        private int currentRowIndex = -1;
        public int CurrentRowIndex
        {
            get { return currentRowIndex; }
        }

        public ConverterStreamReader(StreamReader stream)
        {
            reader = stream;
        }

        public void Dispose()
        {
            if (reader != null)
            {
                reader.Dispose();
            }
        }

        public bool Completed
        {
            get
            {
                return (reader.EndOfStream && currentRow.Equals(string.Empty));
            }
        }

        public string RowToProces
        {
            get
            {
                if (!string.IsNullOrEmpty(currentRow))
                {
                    return currentRow;
                }
                if (!reader.EndOfStream)
                {
                    currentRow = reader.ReadLine();
                    currentRowIndex++;
                }
                return currentRow;
            }
        }

        public void RowProcessed()
        {
            currentRow = string.Empty;
        }

    }
}
