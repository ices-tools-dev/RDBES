﻿using RDBES.Code.Parts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace RDBES.Code.Tools
{
   
    public static class ConverterFactory
    {
        private static Dictionary<ConversionType, Type> converterTypes = new Dictionary<ConversionType, Type>();

        static ConverterFactory()
        {
            IndexConverters();
        }

        /// <summary>
        /// Expects to receive hierarchy as string (e.g.: H1)
        /// </summary>
        /// <param name="conversionTypeName"></param>
        /// <returns></returns>
        public static IConverter GetConverter(string hierarchy)
        {
            ConversionType conversionType;
            if (!Enum.TryParse<ConversionType>(hierarchy, out conversionType))
            {
                throw new Exception($"Unrecognized value for the ConversionType enum:{hierarchy}");
            }
            return GetConverter(conversionType);
        }

        public static IConverter GetConverter(ConversionType conversionType)
        {
            Type converterType = null;
            if (!converterTypes.TryGetValue(conversionType, out converterType))
            {
                throw new Exception(string.Format("Unable to locate converter for ConversionType:{0}", conversionType));
            }
            return CreateInstance<ConverterBase>(converterType);
        }

        private static IConverter CreateInstance<T>(Type type) where T : IConverter
        {
            var instance = Activator.CreateInstance(type);
            return (IConverter)instance;
        }

        private static void IndexConverters()
        {
            var converterBaseType = typeof(ConverterBase);
            var types = ((typeof(ConverterFactory))).GetTypeInfo().Assembly.DefinedTypes
                .Where(t => t.IsClass && t.Namespace == "RDBES.Converters")
                .Select(t => new { type = t.UnderlyingSystemType, typeInfo = t })
                .ToList();
            converterTypes = new Dictionary<ConversionType, Type>();
            foreach (var t in types)
            {
                var attr = t.typeInfo.GetCustomAttribute<ConverterTypeAttribute>();
                if (attr != null)
                {
                    converterTypes.Add(attr.DataType, t.type);
                }
            }

        }
    }
}
