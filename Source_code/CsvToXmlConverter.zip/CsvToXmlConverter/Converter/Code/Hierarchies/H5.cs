using RDBES.Code.Parts;

namespace RDBES.Converters
{

    [ConverterType(ConversionType.H5)]
    public class H5 : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                        converterOS.AddChilds(
                          
                                converterFT,
                                converterLE.AddChilds(
                                converterSS.AddChilds(
                                    converterSA.AddChilds(
                                         CreateSecondaryLevel()
                                    )
                                ))
                            )
                        )
                    )
                
            );



        }

    }
}
