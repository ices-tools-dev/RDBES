using RDBES.Code.Parts;

namespace RDBES.Converters
{

    [ConverterType(ConversionType.H9)]
    public class H9 : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                        converterLO.AddChilds(
                            converterTE.AddChilds(
                                converterSS.AddChilds(
                                     converterLE.AddChilds(
                                    converterSA.AddChilds(
                                       ).AddChilds(
                                  
                                        CreateSecondaryLevel())
                                    
                                )
                            )
                        )
                    )
                )))
            ;


        }

    }
}
