﻿using RDBES.Code.Parts;

namespace RDBES.Converters
{

    [ConverterType(ConversionType.HCL)]
    public class HCL : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterCL


                )
            ;


        }

    }
}
