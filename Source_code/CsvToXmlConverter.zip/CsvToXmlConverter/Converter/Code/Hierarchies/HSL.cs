﻿using RDBES.Code.Parts;

namespace RDBES.Converters
{
    [ConverterType(ConversionType.HSL)]
    public class HSL : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterSL.AddChilds(
                 

                                        
                                )
                            
                        
                    
                
            );

        }

    }
}
