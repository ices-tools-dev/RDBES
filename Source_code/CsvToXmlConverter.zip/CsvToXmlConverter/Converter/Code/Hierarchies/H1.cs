using RDBES.Code.Parts;

namespace RDBES.Converters
{
    [ConverterType(ConversionType.H1)]
    public class H1 : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                     
                        converterVS.AddChilds(
                        
                            converterFT.AddChilds(
                                converterFO.AddChilds(
                                    converterSS.AddChilds(
                                  
                                        converterSA.AddChilds(
                                            CreateSecondaryLevel()
                                        )
                      
                                        )
                                )
                            )
                        )
                    )
                )
            );

        }

    }
}
