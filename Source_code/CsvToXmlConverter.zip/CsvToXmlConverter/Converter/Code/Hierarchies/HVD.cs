﻿using RDBES.Code.Parts;

namespace RDBES.Converters
{
    [ConverterType(ConversionType.HVD)]
    public class HVD : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterVD.AddChilds(
                  
                )
            );

        }

    }
}
