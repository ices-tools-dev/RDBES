using RDBES.Code.Parts;

namespace RDBES.Converters
{

    [ConverterType(ConversionType.H6)]
    public class H6 : HierarchyBase
    {
     
        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                        converterOS.AddChilds(
                            converterFT.AddChilds(

                            converterFO.AddChilds(converterLE,
                               
                                converterSS.AddChilds(

                                    converterSA.AddChilds(
                                        CreateSecondaryLevel()
                                    )
                                )
                                )
                            )
                        ))
                    )
                
            );


        }

    }
}
