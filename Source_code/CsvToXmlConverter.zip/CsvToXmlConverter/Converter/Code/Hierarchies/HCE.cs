﻿using RDBES.Code.Parts;

namespace RDBES.Converters
{

    [ConverterType(ConversionType.HCE)]
    public class HCE : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterCE
                   
                       
                )
            ;


        }

    }
}
