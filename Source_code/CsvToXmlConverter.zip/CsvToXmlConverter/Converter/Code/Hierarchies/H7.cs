using RDBES.Code.Parts;

namespace RDBES.Converters
{
    
    [ConverterType(ConversionType.H7)]
    public class H7 : HierarchyBase
    {
      
        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                        converterOS.AddChilds(
                            converterLE,                             
                            converterSS.AddChilds(

                                converterSA.AddChilds(
                                    CreateSecondaryLevel()
                                )
                            )
                                                    )
                    )
                )
            );


        }

    }
}
