using RDBES.Code;
using RDBES.Code.Parts;
using RDBES.Code.Parts.Escaping;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using RDBES.Code.Converters.RowPresets;

namespace RDBES.Converters
{
    
    [ConverterType(ConversionType.H8)]
    public class H8 : HierarchyBase
    {

    
        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                        converterTE.AddChilds(
                         
                                 converterVS.AddChilds(
                                 converterFT,
                                converterLE.AddChilds(
                                    
                                    converterSS.AddChilds(

                                        converterSA.AddChilds(
                                            CreateSecondaryLevel()    
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            );


        }

    }
}
