using RDBES.Code.Parts;

namespace RDBES.Converters
{

    [ConverterType(ConversionType.H3)]
    public class H3 : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                        converterTE.AddChilds(
                          
                            converterVS.AddChilds(
                               
                                converterFT.AddChilds(
                                    converterFO.AddChilds(
                                        converterSS.AddChilds(converterSL,

                                            converterSA.AddChilds(
                                                CreateSecondaryLevel()
                                            )
                                        )
                                    )
                                )
                            )
                        
                    )
                ))
            );




        }

    }
}
