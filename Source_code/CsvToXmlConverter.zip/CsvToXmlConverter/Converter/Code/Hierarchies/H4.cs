using RDBES.Code.Parts;

namespace RDBES.Converters
{

    [ConverterType(ConversionType.H4)]
    public class H4 : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                        converterOS.AddChilds(
                        
                            converterFT.AddChilds(
                               
                                converterLE.AddChilds(
                                    converterSS.AddChilds(converterSL,

                                        converterSA.AddChilds(
                                            CreateSecondaryLevel()
                                        )
                                    )
                                ))
                            )
                        )
                    
                )
            );


        }

    }
}
