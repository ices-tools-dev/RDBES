using RDBES.Code.Parts;

namespace RDBES.Converters
{

    [ConverterType(ConversionType.H13)]
    public class H13 : HierarchyBase
    {
        protected override void SetupConversion()
        {
            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                        converterFT,
                        converterFO.AddChilds(
                                
                        
                                                   
                            converterSS.AddChilds(converterSL,
                                converterSA.AddChilds(
                                    CreateSecondaryLevel()
                                )
                            )
                        
                    )
                ))
            
            );


        }

    }
}
