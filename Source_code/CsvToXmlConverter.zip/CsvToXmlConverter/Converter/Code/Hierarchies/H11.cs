using RDBES.Code.Parts;

namespace RDBES.Converters
{
    [ConverterType(ConversionType.H11)]
    public class H11 : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                        converterLO.AddChilds(
                            converterTE.AddChilds(
                                
                                        converterFT.AddChilds(converterLE, 
                                                    converterSS.AddChilds(

                                        converterSA.AddChilds(
                                            CreateSecondaryLevel()
                                        )
                                    )
                                ))
                            )
                        )
                    )
                
            );


        }

    }
}
