using RDBES.Code.Parts;

namespace RDBES.Converters
{

    [ConverterType(ConversionType.H2)]
    public class H2 : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                    
                        converterFT.AddChilds(
                           
                            converterFO.AddChilds(
                                converterSS.AddChilds(

                                    converterSA.AddChilds(
                                        CreateSecondaryLevel()
                                    )
                                )
                            )
                        )
                    )
                )
            );


        }

    }
}
