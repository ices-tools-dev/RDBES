using RDBES.Code.Parts;

namespace RDBES.Converters
{
    [ConverterType(ConversionType.H12)]
    public class H12 : HierarchyBase
    {

        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                        converterLO.AddChilds(
                            converterTE.AddChilds(
                             
                                    converterFT,
                                converterLE.AddChilds(
                                 
                                    converterSS.AddChilds(

                                        converterSA.AddChilds(
                                            CreateSecondaryLevel()
                                        )
                                    ))
                                )
                            )
                        )
                    )
                
            );


        }

    }
}
