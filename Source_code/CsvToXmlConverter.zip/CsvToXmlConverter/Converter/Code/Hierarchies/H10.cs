using RDBES.Code.Parts;

namespace RDBES.Converters
{

    [ConverterType(ConversionType.H10)]
    public class H10 : HierarchyBase
    {
     
        protected override void SetupConversion()
        {

            workerConverterSet.Fill(
                converterDE.AddChilds(
                    converterSD.AddChilds(
                        converterVS.AddChilds(                            
                            converterTE.AddChilds(
                            
                                    converterFT.AddChilds(
                                         converterFO.AddChilds(
                                             converterSS.AddChilds(
                                               
                                                    converterSA.AddChilds(
                                                        CreateSecondaryLevel()
                                            )
                                        )
                                    )
                                )
                            ))
                        )
                    
                )
            );


        }

    }
}
